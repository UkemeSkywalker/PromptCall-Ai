/**
 * Twilio configuration for PromptCall AI MVP
 */
export interface TwilioConfig {
    accountSid: string;
    authToken: string;
    phoneNumber: string;
    apiKeySid?: string;
    apiKeySecret?: string;
}
/**
 * Gets Twilio configuration from environment variables
 */
export declare function getTwilioConfig(): TwilioConfig;
/**
 * Validates Twilio webhook signature for security
 */
export declare function validateTwilioSignature(signature: string, url: string, params: Record<string, string>, authToken: string): boolean;
