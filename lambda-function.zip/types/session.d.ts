/**
 * Session data models and interfaces for PromptCall AI MVP
 * Defines TypeScript interfaces for call sessions and conversation management
 */
/**
 * Represents a single conversation entry in a call session
 */
export interface ConversationEntry {
    /** Unique identifier for this conversation entry */
    id: string;
    /** Timestamp when this entry was created */
    timestamp: number;
    /** Type of conversation entry */
    type: 'user' | 'ai' | 'system';
    /** The text content of the conversation */
    text: string;
    /** Optional URL to audio file (for user speech or AI responses) */
    audioUrl?: string;
    /** Confidence score for speech-to-text (0-1, only for user entries) */
    confidence?: number;
    /** Processing duration in milliseconds */
    processingDuration?: number;
}
/**
 * Represents the current state of a call session
 */
export type SessionStatus = 'active' | 'completed' | 'failed' | 'timeout' | 'dropped';
/**
 * Main call session interface
 */
export interface CallSession {
    /** Unique session identifier */
    sessionId: string;
    /** Twilio Call SID for tracking */
    callSid: string;
    /** Caller's phone number */
    phoneNumber: string;
    /** Session start timestamp */
    startTime: number;
    /** Session end timestamp (null if still active) */
    endTime?: number;
    /** Current session status */
    status: SessionStatus;
    /** Array of conversation entries */
    conversationHistory: ConversationEntry[];
    /** Total call duration in seconds */
    totalDuration?: number;
    /** Last activity timestamp for timeout management */
    lastActivity: number;
    /** TTL timestamp for DynamoDB automatic cleanup (24 hours from start) */
    ttl: number;
    /** Error information if session failed */
    errorInfo?: {
        code: string;
        message: string;
        timestamp: number;
    };
}
/**
 * Configuration for session TTL and timeouts
 */
export interface SessionConfig {
    /** Session TTL in seconds (default: 24 hours) */
    sessionTtlSeconds: number;
    /** Inactivity timeout in seconds (default: 30 seconds) */
    inactivityTimeoutSeconds: number;
    /** Maximum call duration in seconds (default: 10 minutes) */
    maxCallDurationSeconds: number;
}
/**
 * Default session configuration
 */
export declare const DEFAULT_SESSION_CONFIG: SessionConfig;
/**
 * Generates a new unique session ID
 */
export declare function generateSessionId(): string;
/**
 * Generates a TTL timestamp for DynamoDB (current time + TTL seconds)
 */
export declare function generateTtl(ttlSeconds?: number): number;
/**
 * Creates a new conversation entry
 */
export declare function createConversationEntry(type: ConversationEntry['type'], text: string, audioUrl?: string, confidence?: number): ConversationEntry;
/**
 * Validates a CallSession object
 */
export declare function validateCallSession(session: any): session is CallSession;
/**
 * Validates a ConversationEntry object
 */
export declare function validateConversationEntry(entry: any): entry is ConversationEntry;
/**
 * Checks if a session has timed out due to inactivity
 */
export declare function isSessionTimedOut(session: CallSession, config?: SessionConfig): boolean;
/**
 * Checks if a session has exceeded maximum call duration
 */
export declare function isSessionOverDuration(session: CallSession, config?: SessionConfig): boolean;
/**
 * Creates a new CallSession with default values
 */
export declare function createCallSession(callSid: string, phoneNumber: string, config?: SessionConfig): CallSession;
