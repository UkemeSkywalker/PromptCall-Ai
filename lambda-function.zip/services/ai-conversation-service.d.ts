/**
 * AI Conversation Service for handling AI interactions via AWS Bedrock
 */
export interface AIResponse {
    text: string;
    model: string;
    usage?: {
        inputTokens: number;
        outputTokens: number;
    };
}
export interface AIConversationConfig {
    region?: string;
    model?: string;
    maxTokens?: number;
    temperature?: number;
}
export declare class AIConversationService {
    private bedrockClient;
    private config;
    constructor(config?: AIConversationConfig);
    /**
     * Generate AI response for user query
     */
    generateResponse(userQuery: string, conversationHistory?: string[]): Promise<AIResponse>;
    /**
     * Build system prompt optimized for voice interactions
     */
    private buildSystemPrompt;
    /**
     * Build context prompt from conversation history
     */
    private buildContextPrompt;
    /**
     * Process user message with full conversation context
     */
    processUserMessage(userQuery: string, sessionId: string, conversationHistory?: string[]): Promise<AIResponse>;
    /**
     * Optimize response for voice delivery
     */
    optimizeForVoice(text: string): string;
}
