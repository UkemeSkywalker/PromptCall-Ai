"use strict";
/**
 * Conversation Pipeline Orchestrator
 *
 * Orchestrates the complete conversation pipeline:
 * Speech-to-Text → AI Processing → Text-to-Speech
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationPipelineOrchestrator = void 0;
const call_termination_service_1 = require("./call-termination-service");
const session_1 = require("../types/session");
class ConversationPipelineOrchestrator {
    constructor(sessionManager, s3Service, transcriptionProcessor, aiConversationService, pollyService, timeoutManager) {
        this.sessionManager = sessionManager;
        this.s3Service = s3Service;
        this.transcriptionProcessor = transcriptionProcessor;
        this.aiConversationService = aiConversationService;
        this.pollyService = pollyService;
        // Initialize termination service if timeout manager is provided
        if (timeoutManager) {
            this.terminationService = new call_termination_service_1.CallTerminationService(sessionManager, timeoutManager, {
                enableCompletionDetection: true,
                maxConversationTurns: 15,
                enableGracefulGoodbyes: true
            });
        }
    }
    /**
     * Process complete conversation pipeline from audio input to TwiML response
     */
    async processConversationTurn(recordingUrl, callSid, recordingDuration) {
        const startTime = Date.now();
        try {
            console.log(`🚀 PIPELINE: Starting complete conversation processing for CallSid: ${callSid}`);
            // Find session
            const session = await this.sessionManager.getSessionByCallSid(callSid);
            if (!session) {
                throw new Error(`Session not found for CallSid: ${callSid}`);
            }
            // Determine conversation turn and phase
            const conversationTurn = this.calculateConversationTurn(session);
            const conversationPhase = this.determineConversationPhase(session, conversationTurn);
            console.log(`🔄 CONVERSATION: Turn ${conversationTurn}, Phase: ${conversationPhase}`);
            // Stage 1: Audio Upload and Processing
            console.log(`📤 PIPELINE STAGE 1: Audio upload and validation`);
            const userEntry = (0, session_1.createConversationEntry)('user', 'Audio recording received - processing transcription...', recordingUrl);
            await this.sessionManager.appendConversationEntry(session.sessionId, userEntry);
            const uploadResult = await this.s3Service.uploadAudioFromUrl(recordingUrl, session.sessionId, callSid);
            // Update the conversation entry with audio information
            // For now, we'll update the entry by finding its index
            const session_updated = await this.sessionManager.getSession(session.sessionId);
            if (session_updated) {
                const entryIndex = session_updated.conversationHistory.findIndex(entry => entry.id === userEntry.id);
                if (entryIndex >= 0) {
                    await this.sessionManager.updateConversationEntryWithAudio(session.sessionId, entryIndex, uploadResult.s3Url);
                }
            }
            // Validate audio quality
            const audioQuality = this.transcriptionProcessor.validateAudioQuality({
                fileSize: uploadResult.metadata.fileSize,
                duration: recordingDuration ? parseFloat(recordingDuration) : undefined
            });
            if (!audioQuality.isValid) {
                throw new Error(`Audio quality validation failed: ${audioQuality.reason}`);
            }
            // Stage 2: Transcription
            console.log(`🎤 PIPELINE STAGE 2: Speech-to-text transcription`);
            const transcriptionResult = await this.transcriptionProcessor.processTranscription(uploadResult.s3Url, session.sessionId, userEntry.id, callSid);
            if (!transcriptionResult.success) {
                return this.createTranscriptionFailureResponse(transcriptionResult.attempts);
            }
            console.log(`✅ TRANSCRIPTION SUCCESS: "${transcriptionResult.text}" (confidence: ${transcriptionResult.confidence.toFixed(3)})`);
            // Stage 3: AI Processing
            console.log(`🤖 PIPELINE STAGE 3: AI response generation`);
            const conversationResult = await this.aiConversationService.processUserMessage(session.sessionId, transcriptionResult.text, uploadResult.s3Url, transcriptionResult.confidence);
            console.log(`✅ AI RESPONSE: "${conversationResult.aiResponse.text}"`);
            // Check for termination intent before generating response
            if (this.terminationService) {
                const terminationAnalysis = await this.terminationService.analyzeTerminationIntent(session.sessionId, transcriptionResult.text, conversationTurn, transcriptionResult.confidence);
                if (terminationAnalysis.shouldTerminate) {
                    console.log(`🔚 TERMINATION: Call termination detected - ${terminationAnalysis.terminationType}`);
                    const processingTime = Date.now() - startTime;
                    return {
                        success: true,
                        twimlResponse: terminationAnalysis.twimlResponse,
                        processingTimeMs: processingTime,
                        conversationTurn,
                        isFollowUpExpected: false,
                        conversationPhase: 'closing'
                    };
                }
            }
            // Stage 4: Speech Synthesis and TwiML Generation
            console.log(`🎤 PIPELINE STAGE 4: Text-to-speech synthesis`);
            // Detect if this is a follow-up question or conversation continuation
            const isFollowUpExpected = this.detectFollowUpExpectation(transcriptionResult.text, conversationResult.aiResponse.text, conversationPhase);
            const twimlResponse = await this.generateResponseTwiML(session.sessionId, conversationResult.aiResponse.text, conversationPhase, isFollowUpExpected);
            const processingTime = Date.now() - startTime;
            console.log(`✅ PIPELINE COMPLETE: Total processing time: ${processingTime}ms`);
            return {
                success: true,
                twimlResponse,
                processingTimeMs: processingTime,
                conversationTurn,
                isFollowUpExpected,
                conversationPhase
            };
        }
        catch (error) {
            const processingTime = Date.now() - startTime;
            console.error(`❌ PIPELINE ERROR: ${error instanceof Error ? error.message : 'Unknown error'}`);
            return {
                success: false,
                twimlResponse: this.createErrorTwiML('Sorry, there was an error processing your request. Please try again.'),
                error: error instanceof Error ? error.message : 'Unknown error',
                processingTimeMs: processingTime
            };
        }
    }
    calculateConversationTurn(session) {
        // Count user entries in conversation history to determine turn number
        // Add 1 because we're about to process the current user input
        const userEntries = session.conversationHistory?.filter((entry) => entry.type === 'user') || [];
        return userEntries.length + 1;
    }
    determineConversationPhase(session, turnNumber) {
        if (turnNumber === 1) {
            return 'greeting';
        }
        else if (turnNumber <= 5) {
            return 'conversation';
        }
        else if (turnNumber <= 8) {
            return 'clarification';
        }
        else {
            return 'closing';
        }
    }
    detectFollowUpExpectation(userText, aiResponse, phase) {
        // Keywords that suggest the user might have follow-up questions
        const followUpIndicators = [
            'tell me more', 'explain', 'how', 'why', 'what about', 'can you',
            'also', 'another', 'more information', 'details', 'example'
        ];
        // AI responses that naturally invite follow-ups
        const aiFollowUpIndicators = [
            'would you like to know more', 'any other questions', 'anything else',
            'let me know if', 'feel free to ask', 'is there anything'
        ];
        const userLower = userText.toLowerCase();
        const aiLower = aiResponse.toLowerCase();
        const userHasFollowUpIntent = followUpIndicators.some(indicator => userLower.includes(indicator));
        const aiInvitesFollowUp = aiFollowUpIndicators.some(indicator => aiLower.includes(indicator));
        // More likely to expect follow-ups in conversation phase
        const phaseExpectsFollowUp = phase === 'conversation' || phase === 'clarification';
        return userHasFollowUpIntent || aiInvitesFollowUp || phaseExpectsFollowUp;
    }
    async generateResponseTwiML(sessionId, aiResponse, phase = 'conversation', expectFollowUp = true) {
        try {
            // Generate AI response audio with Polly
            const responseAudio = await this.pollyService.synthesizeSpeech(aiResponse, sessionId, this.pollyService.getTelephonyConfig(), {
                telephonyOptimized: true,
                addPauses: true
            });
            // Generate appropriate follow-up based on conversation phase and expectation
            const followUpText = this.generateFollowUpText(phase, expectFollowUp);
            const followUpAudio = await this.pollyService.synthesizeSpeech(followUpText, sessionId, this.pollyService.getTelephonyConfig(), { telephonyOptimized: true });
            console.log(`🎤 POLLY SUCCESS: Generated response and follow-up audio`);
            // Ensure we have playback URLs, fallback to audioUrl if needed
            const responseUrl = responseAudio.playbackUrl || responseAudio.audioUrl;
            const followUpUrl = followUpAudio.playbackUrl || followUpAudio.audioUrl;
            if (!responseUrl || !followUpUrl) {
                throw new Error('Failed to generate audio URLs for TwiML playback');
            }
            return this.createConversationTwiML(responseUrl, followUpUrl, phase, expectFollowUp);
        }
        catch (error) {
            console.error(`❌ POLLY ERROR: Falling back to Twilio TTS:`, error);
            // Fallback to Twilio's built-in TTS
            const escapedResponse = aiResponse
                .replace(/&/g, '&amp;')
                .replace(/</g, '&lt;')
                .replace(/>/g, '&gt;')
                .replace(/"/g, '&quot;')
                .replace(/'/g, '&apos;');
            const followUpText = this.generateFollowUpText(phase, expectFollowUp);
            return this.createFallbackConversationTwiML(escapedResponse, followUpText, phase, expectFollowUp);
        }
    }
    createTranscriptionFailureResponse(attempts) {
        return {
            success: false,
            twimlResponse: `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" rate="1">
    I'm sorry, but I wasn't able to understand your speech clearly after ${attempts} attempts. 
    Please try speaking more clearly, or call back from a quieter location.
  </Say>
  <Pause length="1"/>
  <Say voice="alice">Would you like to try again?</Say>
  <Record 
    action="https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/speech" 
    method="POST" 
    maxLength="30" 
    timeout="10"
    playBeep="true"
    recordingStatusCallback="https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/events"
    recordingStatusCallbackMethod="POST"
  />
  <Say voice="alice">Thank you for using PromptCall AI. Goodbye!</Say>
</Response>`,
            error: `Transcription failed after ${attempts} attempts`
        };
    }
    generateFollowUpText(phase, expectFollowUp) {
        if (phase === 'closing' || !expectFollowUp) {
            return "Is there anything else I can help you with before we end our call?";
        }
        const followUpOptions = {
            greeting: [
                "What else would you like to know?",
                "Do you have any other questions?",
                "How else can I assist you today?"
            ],
            conversation: [
                "Is there anything else I can help you with?",
                "Do you have any follow-up questions?",
                "Would you like to know more about anything else?"
            ],
            clarification: [
                "Does that answer your question, or would you like me to explain further?",
                "Is there anything else you'd like me to clarify?",
                "Do you need more details about anything?"
            ]
        };
        const options = followUpOptions[phase] || followUpOptions.conversation;
        return options[Math.floor(Math.random() * options.length)];
    }
    createConversationTwiML(responseAudioUrl, followUpAudioUrl, phase, expectFollowUp) {
        const timeout = expectFollowUp ? "15" : "10"; // Longer timeout if follow-up expected
        const maxLength = phase === 'closing' ? "20" : "30"; // Shorter for closing phase
        // Escape XML characters in URLs
        const escapedResponseUrl = responseAudioUrl
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
        const escapedFollowUpUrl = followUpAudioUrl
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
        return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Play>${escapedResponseUrl}</Play>
  <Pause length="1"/>
  <Play>${escapedFollowUpUrl}</Play>
  <Record 
    action="https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/speech" 
    method="POST" 
    maxLength="${maxLength}" 
    timeout="${timeout}"
    playBeep="true"
    recordingStatusCallback="https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/events"
    recordingStatusCallbackMethod="POST"
  />
  ${phase === 'closing' ? '<Say voice="alice">Thank you for using PromptCall AI. Goodbye!</Say>' : '<Redirect>https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/timeout</Redirect>'}
</Response>`;
    }
    createFallbackConversationTwiML(aiResponse, followUpText, phase, expectFollowUp) {
        const timeout = expectFollowUp ? "15" : "10";
        const maxLength = phase === 'closing' ? "20" : "30";
        return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" rate="1">
    ${aiResponse}
  </Say>
  <Pause length="1"/>
  <Say voice="alice">
    ${followUpText}
  </Say>
  <Record 
    action="https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/speech" 
    method="POST" 
    maxLength="${maxLength}" 
    timeout="${timeout}"
    playBeep="true"
    recordingStatusCallback="https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/events"
    recordingStatusCallbackMethod="POST"
  />
  ${phase === 'closing' ? '<Say voice="alice">Thank you for using PromptCall AI. Goodbye!</Say>' : '<Redirect>https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/timeout</Redirect>'}
</Response>`;
    }
    createErrorTwiML(message) {
        return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice">${message}</Say>
</Response>`;
    }
}
exports.ConversationPipelineOrchestrator = ConversationPipelineOrchestrator;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udmVyc2F0aW9uLXBpcGVsaW5lLW9yY2hlc3RyYXRvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9zZXJ2aWNlcy9jb252ZXJzYXRpb24tcGlwZWxpbmUtb3JjaGVzdHJhdG9yLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7Ozs7R0FLRzs7O0FBT0gseUVBQW9FO0FBRXBFLDhDQUEyRDtBQVkzRCxNQUFhLGdDQUFnQztJQVEzQyxZQUNFLGNBQW9DLEVBQ3BDLFNBQW9CLEVBQ3BCLHNCQUE4QyxFQUM5QyxxQkFBNEMsRUFDNUMsWUFBMEIsRUFDMUIsY0FBK0I7UUFFL0IsSUFBSSxDQUFDLGNBQWMsR0FBRyxjQUFjLENBQUM7UUFDckMsSUFBSSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUM7UUFDM0IsSUFBSSxDQUFDLHNCQUFzQixHQUFHLHNCQUFzQixDQUFDO1FBQ3JELElBQUksQ0FBQyxxQkFBcUIsR0FBRyxxQkFBcUIsQ0FBQztRQUNuRCxJQUFJLENBQUMsWUFBWSxHQUFHLFlBQVksQ0FBQztRQUVqQyxnRUFBZ0U7UUFDaEUsSUFBSSxjQUFjLEVBQUUsQ0FBQztZQUNuQixJQUFJLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxpREFBc0IsQ0FDbEQsY0FBYyxFQUNkLGNBQWMsRUFDZDtnQkFDRSx5QkFBeUIsRUFBRSxJQUFJO2dCQUMvQixvQkFBb0IsRUFBRSxFQUFFO2dCQUN4QixzQkFBc0IsRUFBRSxJQUFJO2FBQzdCLENBQ0YsQ0FBQztRQUNKLENBQUM7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsdUJBQXVCLENBQzNCLFlBQW9CLEVBQ3BCLE9BQWUsRUFDZixpQkFBMEI7UUFFMUIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1FBRTdCLElBQUksQ0FBQztZQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsdUVBQXVFLE9BQU8sRUFBRSxDQUFDLENBQUM7WUFFOUYsZUFBZTtZQUNmLE1BQU0sT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUN2RSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7Z0JBQ2IsTUFBTSxJQUFJLEtBQUssQ0FBQyxrQ0FBa0MsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUMvRCxDQUFDO1lBRUQsd0NBQXdDO1lBQ3hDLE1BQU0sZ0JBQWdCLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2pFLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLDBCQUEwQixDQUFDLE9BQU8sRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDO1lBRXJGLE9BQU8sQ0FBQyxHQUFHLENBQUMseUJBQXlCLGdCQUFnQixZQUFZLGlCQUFpQixFQUFFLENBQUMsQ0FBQztZQUV0Rix1Q0FBdUM7WUFDdkMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrREFBa0QsQ0FBQyxDQUFDO1lBQ2hFLE1BQU0sU0FBUyxHQUFHLElBQUEsaUNBQXVCLEVBQ3ZDLE1BQU0sRUFDTix3REFBd0QsRUFDeEQsWUFBWSxDQUNiLENBQUM7WUFFRixNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsdUJBQXVCLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztZQUVoRixNQUFNLFlBQVksR0FBRyxNQUFNLElBQUksQ0FBQyxTQUFTLENBQUMsa0JBQWtCLENBQzFELFlBQVksRUFDWixPQUFPLENBQUMsU0FBUyxFQUNqQixPQUFPLENBQ1IsQ0FBQztZQUVGLHVEQUF1RDtZQUN2RCx1REFBdUQ7WUFDdkQsTUFBTSxlQUFlLEdBQUcsTUFBTSxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLENBQUM7WUFDaEYsSUFBSSxlQUFlLEVBQUUsQ0FBQztnQkFDcEIsTUFBTSxVQUFVLEdBQUcsZUFBZSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxFQUFFLEtBQUssU0FBUyxDQUFDLEVBQUUsQ0FBQyxDQUFDO2dCQUNyRyxJQUFJLFVBQVUsSUFBSSxDQUFDLEVBQUUsQ0FBQztvQkFDcEIsTUFBTSxJQUFJLENBQUMsY0FBYyxDQUFDLGdDQUFnQyxDQUN4RCxPQUFPLENBQUMsU0FBUyxFQUNqQixVQUFVLEVBQ1YsWUFBWSxDQUFDLEtBQUssQ0FDbkIsQ0FBQztnQkFDSixDQUFDO1lBQ0gsQ0FBQztZQUVELHlCQUF5QjtZQUN6QixNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsb0JBQW9CLENBQUM7Z0JBQ3BFLFFBQVEsRUFBRSxZQUFZLENBQUMsUUFBUSxDQUFDLFFBQVE7Z0JBQ3hDLFFBQVEsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLENBQUMsQ0FBQyxDQUFDLFNBQVM7YUFDeEUsQ0FBQyxDQUFDO1lBRUgsSUFBSSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDMUIsTUFBTSxJQUFJLEtBQUssQ0FBQyxvQ0FBb0MsWUFBWSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUM7WUFDN0UsQ0FBQztZQUVELHlCQUF5QjtZQUN6QixPQUFPLENBQUMsR0FBRyxDQUFDLG1EQUFtRCxDQUFDLENBQUM7WUFDakUsTUFBTSxtQkFBbUIsR0FBRyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxvQkFBb0IsQ0FDaEYsWUFBWSxDQUFDLEtBQUssRUFDbEIsT0FBTyxDQUFDLFNBQVMsRUFDakIsU0FBUyxDQUFDLEVBQUUsRUFDWixPQUFPLENBQ1IsQ0FBQztZQUVGLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLEVBQUUsQ0FBQztnQkFDakMsT0FBTyxJQUFJLENBQUMsa0NBQWtDLENBQUMsbUJBQW1CLENBQUMsUUFBUSxDQUFDLENBQUM7WUFDL0UsQ0FBQztZQUVELE9BQU8sQ0FBQyxHQUFHLENBQUMsNkJBQTZCLG1CQUFtQixDQUFDLElBQUksa0JBQWtCLG1CQUFtQixDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBRWpJLHlCQUF5QjtZQUN6QixPQUFPLENBQUMsR0FBRyxDQUFDLDZDQUE2QyxDQUFDLENBQUM7WUFDM0QsTUFBTSxrQkFBa0IsR0FBRyxNQUFNLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxrQkFBa0IsQ0FDNUUsT0FBTyxDQUFDLFNBQVMsRUFDakIsbUJBQW1CLENBQUMsSUFBSSxFQUN4QixZQUFZLENBQUMsS0FBSyxFQUNsQixtQkFBbUIsQ0FBQyxVQUFVLENBQy9CLENBQUM7WUFFRixPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixrQkFBa0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQztZQUV0RSwwREFBMEQ7WUFDMUQsSUFBSSxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQztnQkFDNUIsTUFBTSxtQkFBbUIsR0FBRyxNQUFNLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyx3QkFBd0IsQ0FDaEYsT0FBTyxDQUFDLFNBQVMsRUFDakIsbUJBQW1CLENBQUMsSUFBSSxFQUN4QixnQkFBZ0IsRUFDaEIsbUJBQW1CLENBQUMsVUFBVSxDQUMvQixDQUFDO2dCQUVGLElBQUksbUJBQW1CLENBQUMsZUFBZSxFQUFFLENBQUM7b0JBQ3hDLE9BQU8sQ0FBQyxHQUFHLENBQUMsK0NBQStDLG1CQUFtQixDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7b0JBRWxHLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxTQUFTLENBQUM7b0JBQzlDLE9BQU87d0JBQ0wsT0FBTyxFQUFFLElBQUk7d0JBQ2IsYUFBYSxFQUFFLG1CQUFtQixDQUFDLGFBQWE7d0JBQ2hELGdCQUFnQixFQUFFLGNBQWM7d0JBQ2hDLGdCQUFnQjt3QkFDaEIsa0JBQWtCLEVBQUUsS0FBSzt3QkFDekIsaUJBQWlCLEVBQUUsU0FBUztxQkFDN0IsQ0FBQztnQkFDSixDQUFDO1lBQ0gsQ0FBQztZQUVELGlEQUFpRDtZQUNqRCxPQUFPLENBQUMsR0FBRyxDQUFDLCtDQUErQyxDQUFDLENBQUM7WUFFN0Qsc0VBQXNFO1lBQ3RFLE1BQU0sa0JBQWtCLEdBQUcsSUFBSSxDQUFDLHlCQUF5QixDQUN2RCxtQkFBbUIsQ0FBQyxJQUFJLEVBQ3hCLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQ2xDLGlCQUFpQixDQUNsQixDQUFDO1lBRUYsTUFBTSxhQUFhLEdBQUcsTUFBTSxJQUFJLENBQUMscUJBQXFCLENBQ3BELE9BQU8sQ0FBQyxTQUFTLEVBQ2pCLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQ2xDLGlCQUFpQixFQUNqQixrQkFBa0IsQ0FDbkIsQ0FBQztZQUVGLE1BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsR0FBRyxTQUFTLENBQUM7WUFDOUMsT0FBTyxDQUFDLEdBQUcsQ0FBQywrQ0FBK0MsY0FBYyxJQUFJLENBQUMsQ0FBQztZQUUvRSxPQUFPO2dCQUNMLE9BQU8sRUFBRSxJQUFJO2dCQUNiLGFBQWE7Z0JBQ2IsZ0JBQWdCLEVBQUUsY0FBYztnQkFDaEMsZ0JBQWdCO2dCQUNoQixrQkFBa0I7Z0JBQ2xCLGlCQUFpQjthQUNsQixDQUFDO1FBRUosQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsU0FBUyxDQUFDO1lBQzlDLE9BQU8sQ0FBQyxLQUFLLENBQUMscUJBQXFCLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7WUFFL0YsT0FBTztnQkFDTCxPQUFPLEVBQUUsS0FBSztnQkFDZCxhQUFhLEVBQUUsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHNFQUFzRSxDQUFDO2dCQUM1RyxLQUFLLEVBQUUsS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZTtnQkFDL0QsZ0JBQWdCLEVBQUUsY0FBYzthQUNqQyxDQUFDO1FBQ0osQ0FBQztJQUNILENBQUM7SUFFTyx5QkFBeUIsQ0FBQyxPQUFZO1FBQzVDLHNFQUFzRTtRQUN0RSw4REFBOEQ7UUFDOUQsTUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLG1CQUFtQixFQUFFLE1BQU0sQ0FBQyxDQUFDLEtBQVUsRUFBRSxFQUFFLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDckcsT0FBTyxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztJQUNoQyxDQUFDO0lBRU8sMEJBQTBCLENBQUMsT0FBWSxFQUFFLFVBQWtCO1FBQ2pFLElBQUksVUFBVSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ3JCLE9BQU8sVUFBVSxDQUFDO1FBQ3BCLENBQUM7YUFBTSxJQUFJLFVBQVUsSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUMzQixPQUFPLGNBQWMsQ0FBQztRQUN4QixDQUFDO2FBQU0sSUFBSSxVQUFVLElBQUksQ0FBQyxFQUFFLENBQUM7WUFDM0IsT0FBTyxlQUFlLENBQUM7UUFDekIsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLFNBQVMsQ0FBQztRQUNuQixDQUFDO0lBQ0gsQ0FBQztJQUVPLHlCQUF5QixDQUMvQixRQUFnQixFQUNoQixVQUFrQixFQUNsQixLQUFhO1FBRWIsZ0VBQWdFO1FBQ2hFLE1BQU0sa0JBQWtCLEdBQUc7WUFDekIsY0FBYyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsS0FBSyxFQUFFLFlBQVksRUFBRSxTQUFTO1lBQ2hFLE1BQU0sRUFBRSxTQUFTLEVBQUUsa0JBQWtCLEVBQUUsU0FBUyxFQUFFLFNBQVM7U0FDNUQsQ0FBQztRQUVGLGdEQUFnRDtRQUNoRCxNQUFNLG9CQUFvQixHQUFHO1lBQzNCLDZCQUE2QixFQUFFLHFCQUFxQixFQUFFLGVBQWU7WUFDckUsZ0JBQWdCLEVBQUUsa0JBQWtCLEVBQUUsbUJBQW1CO1NBQzFELENBQUM7UUFFRixNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUM7UUFDekMsTUFBTSxPQUFPLEdBQUcsVUFBVSxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBRXpDLE1BQU0scUJBQXFCLEdBQUcsa0JBQWtCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxFQUFFLENBQ2hFLFNBQVMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLENBQzlCLENBQUM7UUFFRixNQUFNLGlCQUFpQixHQUFHLG9CQUFvQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUM5RCxPQUFPLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxDQUM1QixDQUFDO1FBRUYseURBQXlEO1FBQ3pELE1BQU0sb0JBQW9CLEdBQUcsS0FBSyxLQUFLLGNBQWMsSUFBSSxLQUFLLEtBQUssZUFBZSxDQUFDO1FBRW5GLE9BQU8scUJBQXFCLElBQUksaUJBQWlCLElBQUksb0JBQW9CLENBQUM7SUFDNUUsQ0FBQztJQUVPLEtBQUssQ0FBQyxxQkFBcUIsQ0FDakMsU0FBaUIsRUFDakIsVUFBa0IsRUFDbEIsUUFBbUUsY0FBYyxFQUNqRixpQkFBMEIsSUFBSTtRQUU5QixJQUFJLENBQUM7WUFDSCx3Q0FBd0M7WUFDeEMsTUFBTSxhQUFhLEdBQUcsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLGdCQUFnQixDQUM1RCxVQUFVLEVBQ1YsU0FBUyxFQUNULElBQUksQ0FBQyxZQUFZLENBQUMsa0JBQWtCLEVBQUUsRUFDdEM7Z0JBQ0Usa0JBQWtCLEVBQUUsSUFBSTtnQkFDeEIsU0FBUyxFQUFFLElBQUk7YUFDaEIsQ0FDRixDQUFDO1lBRUYsNkVBQTZFO1lBQzdFLE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLEVBQUUsY0FBYyxDQUFDLENBQUM7WUFDdEUsTUFBTSxhQUFhLEdBQUcsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLGdCQUFnQixDQUM1RCxZQUFZLEVBQ1osU0FBUyxFQUNULElBQUksQ0FBQyxZQUFZLENBQUMsa0JBQWtCLEVBQUUsRUFDdEMsRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FDN0IsQ0FBQztZQUVGLE9BQU8sQ0FBQyxHQUFHLENBQUMsMERBQTBELENBQUMsQ0FBQztZQUV4RSwrREFBK0Q7WUFDL0QsTUFBTSxXQUFXLEdBQUcsYUFBYSxDQUFDLFdBQVcsSUFBSSxhQUFhLENBQUMsUUFBUSxDQUFDO1lBQ3hFLE1BQU0sV0FBVyxHQUFHLGFBQWEsQ0FBQyxXQUFXLElBQUksYUFBYSxDQUFDLFFBQVEsQ0FBQztZQUV4RSxJQUFJLENBQUMsV0FBVyxJQUFJLENBQUMsV0FBVyxFQUFFLENBQUM7Z0JBQ2pDLE1BQU0sSUFBSSxLQUFLLENBQUMsa0RBQWtELENBQUMsQ0FBQztZQUN0RSxDQUFDO1lBRUQsT0FBTyxJQUFJLENBQUMsdUJBQXVCLENBQ2pDLFdBQVcsRUFDWCxXQUFXLEVBQ1gsS0FBSyxFQUNMLGNBQWMsQ0FDZixDQUFDO1FBRUosQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLDRDQUE0QyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBRW5FLG9DQUFvQztZQUNwQyxNQUFNLGVBQWUsR0FBRyxVQUFVO2lCQUMvQixPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQztpQkFDdEIsT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUM7aUJBQ3JCLE9BQU8sQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDO2lCQUNyQixPQUFPLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQztpQkFDdkIsT0FBTyxDQUFDLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztZQUUzQixNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsS0FBSyxFQUFFLGNBQWMsQ0FBQyxDQUFDO1lBRXRFLE9BQU8sSUFBSSxDQUFDLCtCQUErQixDQUN6QyxlQUFlLEVBQ2YsWUFBWSxFQUNaLEtBQUssRUFDTCxjQUFjLENBQ2YsQ0FBQztRQUNKLENBQUM7SUFDSCxDQUFDO0lBRU8sa0NBQWtDLENBQUMsUUFBZ0I7UUFDekQsT0FBTztZQUNMLE9BQU8sRUFBRSxLQUFLO1lBQ2QsYUFBYSxFQUFFOzs7MkVBR3NELFFBQVE7Ozs7Ozs7Ozs7Ozs7OztZQWV2RTtZQUNOLEtBQUssRUFBRSw4QkFBOEIsUUFBUSxXQUFXO1NBQ3pELENBQUM7SUFDSixDQUFDO0lBRU8sb0JBQW9CLENBQzFCLEtBQWdFLEVBQ2hFLGNBQXVCO1FBRXZCLElBQUksS0FBSyxLQUFLLFNBQVMsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFDO1lBQzNDLE9BQU8sb0VBQW9FLENBQUM7UUFDOUUsQ0FBQztRQUVELE1BQU0sZUFBZSxHQUFHO1lBQ3RCLFFBQVEsRUFBRTtnQkFDUixtQ0FBbUM7Z0JBQ25DLGtDQUFrQztnQkFDbEMsa0NBQWtDO2FBQ25DO1lBQ0QsWUFBWSxFQUFFO2dCQUNaLDZDQUE2QztnQkFDN0Msc0NBQXNDO2dCQUN0QyxrREFBa0Q7YUFDbkQ7WUFDRCxhQUFhLEVBQUU7Z0JBQ2IsMEVBQTBFO2dCQUMxRSxrREFBa0Q7Z0JBQ2xELDBDQUEwQzthQUMzQztTQUNGLENBQUM7UUFFRixNQUFNLE9BQU8sR0FBRyxlQUFlLENBQUMsS0FBSyxDQUFDLElBQUksZUFBZSxDQUFDLFlBQVksQ0FBQztRQUN2RSxPQUFPLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztJQUM3RCxDQUFDO0lBRU8sdUJBQXVCLENBQzdCLGdCQUF3QixFQUN4QixnQkFBd0IsRUFDeEIsS0FBZ0UsRUFDaEUsY0FBdUI7UUFFdkIsTUFBTSxPQUFPLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLHVDQUF1QztRQUNyRixNQUFNLFNBQVMsR0FBRyxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLDRCQUE0QjtRQUVqRixnQ0FBZ0M7UUFDaEMsTUFBTSxrQkFBa0IsR0FBRyxnQkFBZ0I7YUFDeEMsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUM7YUFDdEIsT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUM7YUFDckIsT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUMsQ0FBQztRQUV6QixNQUFNLGtCQUFrQixHQUFHLGdCQUFnQjthQUN4QyxPQUFPLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQzthQUN0QixPQUFPLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQzthQUNyQixPQUFPLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1FBRXpCLE9BQU87O1VBRUQsa0JBQWtCOztVQUVsQixrQkFBa0I7Ozs7aUJBSVgsU0FBUztlQUNYLE9BQU87Ozs7O0lBS2xCLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLHNFQUFzRSxDQUFDLENBQUMsQ0FBQyxrR0FBa0c7WUFDekwsQ0FBQztJQUNYLENBQUM7SUFFTywrQkFBK0IsQ0FDckMsVUFBa0IsRUFDbEIsWUFBb0IsRUFDcEIsS0FBZ0UsRUFDaEUsY0FBdUI7UUFFdkIsTUFBTSxPQUFPLEdBQUcsY0FBYyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUM3QyxNQUFNLFNBQVMsR0FBRyxLQUFLLEtBQUssU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQztRQUVwRCxPQUFPOzs7TUFHTCxVQUFVOzs7O01BSVYsWUFBWTs7Ozs7aUJBS0QsU0FBUztlQUNYLE9BQU87Ozs7O0lBS2xCLEtBQUssS0FBSyxTQUFTLENBQUMsQ0FBQyxDQUFDLHNFQUFzRSxDQUFDLENBQUMsQ0FBQyxrR0FBa0c7WUFDekwsQ0FBQztJQUNYLENBQUM7SUFFTyxnQkFBZ0IsQ0FBQyxPQUFlO1FBQ3RDLE9BQU87O3VCQUVZLE9BQU87WUFDbEIsQ0FBQztJQUNYLENBQUM7Q0FDRjtBQTNiRCw0RUEyYkMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIENvbnZlcnNhdGlvbiBQaXBlbGluZSBPcmNoZXN0cmF0b3JcbiAqIFxuICogT3JjaGVzdHJhdGVzIHRoZSBjb21wbGV0ZSBjb252ZXJzYXRpb24gcGlwZWxpbmU6XG4gKiBTcGVlY2gtdG8tVGV4dCDihpIgQUkgUHJvY2Vzc2luZyDihpIgVGV4dC10by1TcGVlY2hcbiAqL1xuXG5pbXBvcnQgeyBEeW5hbW9TZXNzaW9uTWFuYWdlciB9IGZyb20gJy4vZHluYW1vLXNlc3Npb24tbWFuYWdlcic7XG5pbXBvcnQgeyBTM1NlcnZpY2UgfSBmcm9tICcuL3MzLXNlcnZpY2UnO1xuaW1wb3J0IHsgVHJhbnNjcmlwdGlvblByb2Nlc3NvciB9IGZyb20gJy4vdHJhbnNjcmlwdGlvbi1wcm9jZXNzb3InO1xuaW1wb3J0IHsgQUlDb252ZXJzYXRpb25TZXJ2aWNlIH0gZnJvbSAnLi9haS1jb252ZXJzYXRpb24tc2VydmljZSc7XG5pbXBvcnQgeyBQb2xseVNlcnZpY2UgfSBmcm9tICcuL3BvbGx5LXNlcnZpY2UnO1xuaW1wb3J0IHsgQ2FsbFRlcm1pbmF0aW9uU2VydmljZSB9IGZyb20gJy4vY2FsbC10ZXJtaW5hdGlvbi1zZXJ2aWNlJztcbmltcG9ydCB7IFRpbWVvdXRNYW5hZ2VyIH0gZnJvbSAnLi90aW1lb3V0LW1hbmFnZXInO1xuaW1wb3J0IHsgY3JlYXRlQ29udmVyc2F0aW9uRW50cnkgfSBmcm9tICcuLi90eXBlcy9zZXNzaW9uJztcblxuZXhwb3J0IGludGVyZmFjZSBQaXBlbGluZVJlc3VsdCB7XG4gIHN1Y2Nlc3M6IGJvb2xlYW47XG4gIHR3aW1sUmVzcG9uc2U6IHN0cmluZztcbiAgZXJyb3I/OiBzdHJpbmc7XG4gIHByb2Nlc3NpbmdUaW1lTXM/OiBudW1iZXI7XG4gIGNvbnZlcnNhdGlvblR1cm4/OiBudW1iZXI7XG4gIGlzRm9sbG93VXBFeHBlY3RlZD86IGJvb2xlYW47XG4gIGNvbnZlcnNhdGlvblBoYXNlPzogJ2dyZWV0aW5nJyB8ICdjb252ZXJzYXRpb24nIHwgJ2NsYXJpZmljYXRpb24nIHwgJ2Nsb3NpbmcnO1xufVxuXG5leHBvcnQgY2xhc3MgQ29udmVyc2F0aW9uUGlwZWxpbmVPcmNoZXN0cmF0b3Ige1xuICBwcml2YXRlIHNlc3Npb25NYW5hZ2VyOiBEeW5hbW9TZXNzaW9uTWFuYWdlcjtcbiAgcHJpdmF0ZSBzM1NlcnZpY2U6IFMzU2VydmljZTtcbiAgcHJpdmF0ZSB0cmFuc2NyaXB0aW9uUHJvY2Vzc29yOiBUcmFuc2NyaXB0aW9uUHJvY2Vzc29yO1xuICBwcml2YXRlIGFpQ29udmVyc2F0aW9uU2VydmljZTogQUlDb252ZXJzYXRpb25TZXJ2aWNlO1xuICBwcml2YXRlIHBvbGx5U2VydmljZTogUG9sbHlTZXJ2aWNlO1xuICBwcml2YXRlIHRlcm1pbmF0aW9uU2VydmljZT86IENhbGxUZXJtaW5hdGlvblNlcnZpY2U7XG5cbiAgY29uc3RydWN0b3IoXG4gICAgc2Vzc2lvbk1hbmFnZXI6IER5bmFtb1Nlc3Npb25NYW5hZ2VyLFxuICAgIHMzU2VydmljZTogUzNTZXJ2aWNlLFxuICAgIHRyYW5zY3JpcHRpb25Qcm9jZXNzb3I6IFRyYW5zY3JpcHRpb25Qcm9jZXNzb3IsXG4gICAgYWlDb252ZXJzYXRpb25TZXJ2aWNlOiBBSUNvbnZlcnNhdGlvblNlcnZpY2UsXG4gICAgcG9sbHlTZXJ2aWNlOiBQb2xseVNlcnZpY2UsXG4gICAgdGltZW91dE1hbmFnZXI/OiBUaW1lb3V0TWFuYWdlclxuICApIHtcbiAgICB0aGlzLnNlc3Npb25NYW5hZ2VyID0gc2Vzc2lvbk1hbmFnZXI7XG4gICAgdGhpcy5zM1NlcnZpY2UgPSBzM1NlcnZpY2U7XG4gICAgdGhpcy50cmFuc2NyaXB0aW9uUHJvY2Vzc29yID0gdHJhbnNjcmlwdGlvblByb2Nlc3NvcjtcbiAgICB0aGlzLmFpQ29udmVyc2F0aW9uU2VydmljZSA9IGFpQ29udmVyc2F0aW9uU2VydmljZTtcbiAgICB0aGlzLnBvbGx5U2VydmljZSA9IHBvbGx5U2VydmljZTtcbiAgICBcbiAgICAvLyBJbml0aWFsaXplIHRlcm1pbmF0aW9uIHNlcnZpY2UgaWYgdGltZW91dCBtYW5hZ2VyIGlzIHByb3ZpZGVkXG4gICAgaWYgKHRpbWVvdXRNYW5hZ2VyKSB7XG4gICAgICB0aGlzLnRlcm1pbmF0aW9uU2VydmljZSA9IG5ldyBDYWxsVGVybWluYXRpb25TZXJ2aWNlKFxuICAgICAgICBzZXNzaW9uTWFuYWdlcixcbiAgICAgICAgdGltZW91dE1hbmFnZXIsXG4gICAgICAgIHtcbiAgICAgICAgICBlbmFibGVDb21wbGV0aW9uRGV0ZWN0aW9uOiB0cnVlLFxuICAgICAgICAgIG1heENvbnZlcnNhdGlvblR1cm5zOiAxNSxcbiAgICAgICAgICBlbmFibGVHcmFjZWZ1bEdvb2RieWVzOiB0cnVlXG4gICAgICAgIH1cbiAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFByb2Nlc3MgY29tcGxldGUgY29udmVyc2F0aW9uIHBpcGVsaW5lIGZyb20gYXVkaW8gaW5wdXQgdG8gVHdpTUwgcmVzcG9uc2VcbiAgICovXG4gIGFzeW5jIHByb2Nlc3NDb252ZXJzYXRpb25UdXJuKFxuICAgIHJlY29yZGluZ1VybDogc3RyaW5nLFxuICAgIGNhbGxTaWQ6IHN0cmluZyxcbiAgICByZWNvcmRpbmdEdXJhdGlvbj86IHN0cmluZ1xuICApOiBQcm9taXNlPFBpcGVsaW5lUmVzdWx0PiB7XG4gICAgY29uc3Qgc3RhcnRUaW1lID0gRGF0ZS5ub3coKTtcbiAgICBcbiAgICB0cnkge1xuICAgICAgY29uc29sZS5sb2coYPCfmoAgUElQRUxJTkU6IFN0YXJ0aW5nIGNvbXBsZXRlIGNvbnZlcnNhdGlvbiBwcm9jZXNzaW5nIGZvciBDYWxsU2lkOiAke2NhbGxTaWR9YCk7XG5cbiAgICAgIC8vIEZpbmQgc2Vzc2lvblxuICAgICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IHRoaXMuc2Vzc2lvbk1hbmFnZXIuZ2V0U2Vzc2lvbkJ5Q2FsbFNpZChjYWxsU2lkKTtcbiAgICAgIGlmICghc2Vzc2lvbikge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFNlc3Npb24gbm90IGZvdW5kIGZvciBDYWxsU2lkOiAke2NhbGxTaWR9YCk7XG4gICAgICB9XG5cbiAgICAgIC8vIERldGVybWluZSBjb252ZXJzYXRpb24gdHVybiBhbmQgcGhhc2VcbiAgICAgIGNvbnN0IGNvbnZlcnNhdGlvblR1cm4gPSB0aGlzLmNhbGN1bGF0ZUNvbnZlcnNhdGlvblR1cm4oc2Vzc2lvbik7XG4gICAgICBjb25zdCBjb252ZXJzYXRpb25QaGFzZSA9IHRoaXMuZGV0ZXJtaW5lQ29udmVyc2F0aW9uUGhhc2Uoc2Vzc2lvbiwgY29udmVyc2F0aW9uVHVybik7XG4gICAgICBcbiAgICAgIGNvbnNvbGUubG9nKGDwn5SEIENPTlZFUlNBVElPTjogVHVybiAke2NvbnZlcnNhdGlvblR1cm59LCBQaGFzZTogJHtjb252ZXJzYXRpb25QaGFzZX1gKTtcblxuICAgICAgLy8gU3RhZ2UgMTogQXVkaW8gVXBsb2FkIGFuZCBQcm9jZXNzaW5nXG4gICAgICBjb25zb2xlLmxvZyhg8J+TpCBQSVBFTElORSBTVEFHRSAxOiBBdWRpbyB1cGxvYWQgYW5kIHZhbGlkYXRpb25gKTtcbiAgICAgIGNvbnN0IHVzZXJFbnRyeSA9IGNyZWF0ZUNvbnZlcnNhdGlvbkVudHJ5KFxuICAgICAgICAndXNlcicsXG4gICAgICAgICdBdWRpbyByZWNvcmRpbmcgcmVjZWl2ZWQgLSBwcm9jZXNzaW5nIHRyYW5zY3JpcHRpb24uLi4nLFxuICAgICAgICByZWNvcmRpbmdVcmxcbiAgICAgICk7XG5cbiAgICAgIGF3YWl0IHRoaXMuc2Vzc2lvbk1hbmFnZXIuYXBwZW5kQ29udmVyc2F0aW9uRW50cnkoc2Vzc2lvbi5zZXNzaW9uSWQsIHVzZXJFbnRyeSk7XG5cbiAgICAgIGNvbnN0IHVwbG9hZFJlc3VsdCA9IGF3YWl0IHRoaXMuczNTZXJ2aWNlLnVwbG9hZEF1ZGlvRnJvbVVybChcbiAgICAgICAgcmVjb3JkaW5nVXJsLFxuICAgICAgICBzZXNzaW9uLnNlc3Npb25JZCxcbiAgICAgICAgY2FsbFNpZFxuICAgICAgKTtcblxuICAgICAgLy8gVXBkYXRlIHRoZSBjb252ZXJzYXRpb24gZW50cnkgd2l0aCBhdWRpbyBpbmZvcm1hdGlvblxuICAgICAgLy8gRm9yIG5vdywgd2UnbGwgdXBkYXRlIHRoZSBlbnRyeSBieSBmaW5kaW5nIGl0cyBpbmRleFxuICAgICAgY29uc3Qgc2Vzc2lvbl91cGRhdGVkID0gYXdhaXQgdGhpcy5zZXNzaW9uTWFuYWdlci5nZXRTZXNzaW9uKHNlc3Npb24uc2Vzc2lvbklkKTtcbiAgICAgIGlmIChzZXNzaW9uX3VwZGF0ZWQpIHtcbiAgICAgICAgY29uc3QgZW50cnlJbmRleCA9IHNlc3Npb25fdXBkYXRlZC5jb252ZXJzYXRpb25IaXN0b3J5LmZpbmRJbmRleChlbnRyeSA9PiBlbnRyeS5pZCA9PT0gdXNlckVudHJ5LmlkKTtcbiAgICAgICAgaWYgKGVudHJ5SW5kZXggPj0gMCkge1xuICAgICAgICAgIGF3YWl0IHRoaXMuc2Vzc2lvbk1hbmFnZXIudXBkYXRlQ29udmVyc2F0aW9uRW50cnlXaXRoQXVkaW8oXG4gICAgICAgICAgICBzZXNzaW9uLnNlc3Npb25JZCxcbiAgICAgICAgICAgIGVudHJ5SW5kZXgsXG4gICAgICAgICAgICB1cGxvYWRSZXN1bHQuczNVcmxcbiAgICAgICAgICApO1xuICAgICAgICB9XG4gICAgICB9XG5cbiAgICAgIC8vIFZhbGlkYXRlIGF1ZGlvIHF1YWxpdHlcbiAgICAgIGNvbnN0IGF1ZGlvUXVhbGl0eSA9IHRoaXMudHJhbnNjcmlwdGlvblByb2Nlc3Nvci52YWxpZGF0ZUF1ZGlvUXVhbGl0eSh7XG4gICAgICAgIGZpbGVTaXplOiB1cGxvYWRSZXN1bHQubWV0YWRhdGEuZmlsZVNpemUsXG4gICAgICAgIGR1cmF0aW9uOiByZWNvcmRpbmdEdXJhdGlvbiA/IHBhcnNlRmxvYXQocmVjb3JkaW5nRHVyYXRpb24pIDogdW5kZWZpbmVkXG4gICAgICB9KTtcblxuICAgICAgaWYgKCFhdWRpb1F1YWxpdHkuaXNWYWxpZCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEF1ZGlvIHF1YWxpdHkgdmFsaWRhdGlvbiBmYWlsZWQ6ICR7YXVkaW9RdWFsaXR5LnJlYXNvbn1gKTtcbiAgICAgIH1cblxuICAgICAgLy8gU3RhZ2UgMjogVHJhbnNjcmlwdGlvblxuICAgICAgY29uc29sZS5sb2coYPCfjqQgUElQRUxJTkUgU1RBR0UgMjogU3BlZWNoLXRvLXRleHQgdHJhbnNjcmlwdGlvbmApO1xuICAgICAgY29uc3QgdHJhbnNjcmlwdGlvblJlc3VsdCA9IGF3YWl0IHRoaXMudHJhbnNjcmlwdGlvblByb2Nlc3Nvci5wcm9jZXNzVHJhbnNjcmlwdGlvbihcbiAgICAgICAgdXBsb2FkUmVzdWx0LnMzVXJsLFxuICAgICAgICBzZXNzaW9uLnNlc3Npb25JZCxcbiAgICAgICAgdXNlckVudHJ5LmlkLFxuICAgICAgICBjYWxsU2lkXG4gICAgICApO1xuXG4gICAgICBpZiAoIXRyYW5zY3JpcHRpb25SZXN1bHQuc3VjY2Vzcykge1xuICAgICAgICByZXR1cm4gdGhpcy5jcmVhdGVUcmFuc2NyaXB0aW9uRmFpbHVyZVJlc3BvbnNlKHRyYW5zY3JpcHRpb25SZXN1bHQuYXR0ZW1wdHMpO1xuICAgICAgfVxuXG4gICAgICBjb25zb2xlLmxvZyhg4pyFIFRSQU5TQ1JJUFRJT04gU1VDQ0VTUzogXCIke3RyYW5zY3JpcHRpb25SZXN1bHQudGV4dH1cIiAoY29uZmlkZW5jZTogJHt0cmFuc2NyaXB0aW9uUmVzdWx0LmNvbmZpZGVuY2UudG9GaXhlZCgzKX0pYCk7XG5cbiAgICAgIC8vIFN0YWdlIDM6IEFJIFByb2Nlc3NpbmdcbiAgICAgIGNvbnNvbGUubG9nKGDwn6SWIFBJUEVMSU5FIFNUQUdFIDM6IEFJIHJlc3BvbnNlIGdlbmVyYXRpb25gKTtcbiAgICAgIGNvbnN0IGNvbnZlcnNhdGlvblJlc3VsdCA9IGF3YWl0IHRoaXMuYWlDb252ZXJzYXRpb25TZXJ2aWNlLnByb2Nlc3NVc2VyTWVzc2FnZShcbiAgICAgICAgc2Vzc2lvbi5zZXNzaW9uSWQsXG4gICAgICAgIHRyYW5zY3JpcHRpb25SZXN1bHQudGV4dCxcbiAgICAgICAgdXBsb2FkUmVzdWx0LnMzVXJsLFxuICAgICAgICB0cmFuc2NyaXB0aW9uUmVzdWx0LmNvbmZpZGVuY2VcbiAgICAgICk7XG5cbiAgICAgIGNvbnNvbGUubG9nKGDinIUgQUkgUkVTUE9OU0U6IFwiJHtjb252ZXJzYXRpb25SZXN1bHQuYWlSZXNwb25zZS50ZXh0fVwiYCk7XG5cbiAgICAgIC8vIENoZWNrIGZvciB0ZXJtaW5hdGlvbiBpbnRlbnQgYmVmb3JlIGdlbmVyYXRpbmcgcmVzcG9uc2VcbiAgICAgIGlmICh0aGlzLnRlcm1pbmF0aW9uU2VydmljZSkge1xuICAgICAgICBjb25zdCB0ZXJtaW5hdGlvbkFuYWx5c2lzID0gYXdhaXQgdGhpcy50ZXJtaW5hdGlvblNlcnZpY2UuYW5hbHl6ZVRlcm1pbmF0aW9uSW50ZW50KFxuICAgICAgICAgIHNlc3Npb24uc2Vzc2lvbklkLFxuICAgICAgICAgIHRyYW5zY3JpcHRpb25SZXN1bHQudGV4dCxcbiAgICAgICAgICBjb252ZXJzYXRpb25UdXJuLFxuICAgICAgICAgIHRyYW5zY3JpcHRpb25SZXN1bHQuY29uZmlkZW5jZVxuICAgICAgICApO1xuXG4gICAgICAgIGlmICh0ZXJtaW5hdGlvbkFuYWx5c2lzLnNob3VsZFRlcm1pbmF0ZSkge1xuICAgICAgICAgIGNvbnNvbGUubG9nKGDwn5SaIFRFUk1JTkFUSU9OOiBDYWxsIHRlcm1pbmF0aW9uIGRldGVjdGVkIC0gJHt0ZXJtaW5hdGlvbkFuYWx5c2lzLnRlcm1pbmF0aW9uVHlwZX1gKTtcbiAgICAgICAgICBcbiAgICAgICAgICBjb25zdCBwcm9jZXNzaW5nVGltZSA9IERhdGUubm93KCkgLSBzdGFydFRpbWU7XG4gICAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgICAgICB0d2ltbFJlc3BvbnNlOiB0ZXJtaW5hdGlvbkFuYWx5c2lzLnR3aW1sUmVzcG9uc2UsXG4gICAgICAgICAgICBwcm9jZXNzaW5nVGltZU1zOiBwcm9jZXNzaW5nVGltZSxcbiAgICAgICAgICAgIGNvbnZlcnNhdGlvblR1cm4sXG4gICAgICAgICAgICBpc0ZvbGxvd1VwRXhwZWN0ZWQ6IGZhbHNlLFxuICAgICAgICAgICAgY29udmVyc2F0aW9uUGhhc2U6ICdjbG9zaW5nJ1xuICAgICAgICAgIH07XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgLy8gU3RhZ2UgNDogU3BlZWNoIFN5bnRoZXNpcyBhbmQgVHdpTUwgR2VuZXJhdGlvblxuICAgICAgY29uc29sZS5sb2coYPCfjqQgUElQRUxJTkUgU1RBR0UgNDogVGV4dC10by1zcGVlY2ggc3ludGhlc2lzYCk7XG4gICAgICBcbiAgICAgIC8vIERldGVjdCBpZiB0aGlzIGlzIGEgZm9sbG93LXVwIHF1ZXN0aW9uIG9yIGNvbnZlcnNhdGlvbiBjb250aW51YXRpb25cbiAgICAgIGNvbnN0IGlzRm9sbG93VXBFeHBlY3RlZCA9IHRoaXMuZGV0ZWN0Rm9sbG93VXBFeHBlY3RhdGlvbihcbiAgICAgICAgdHJhbnNjcmlwdGlvblJlc3VsdC50ZXh0LFxuICAgICAgICBjb252ZXJzYXRpb25SZXN1bHQuYWlSZXNwb25zZS50ZXh0LFxuICAgICAgICBjb252ZXJzYXRpb25QaGFzZVxuICAgICAgKTtcbiAgICAgIFxuICAgICAgY29uc3QgdHdpbWxSZXNwb25zZSA9IGF3YWl0IHRoaXMuZ2VuZXJhdGVSZXNwb25zZVR3aU1MKFxuICAgICAgICBzZXNzaW9uLnNlc3Npb25JZCxcbiAgICAgICAgY29udmVyc2F0aW9uUmVzdWx0LmFpUmVzcG9uc2UudGV4dCxcbiAgICAgICAgY29udmVyc2F0aW9uUGhhc2UsXG4gICAgICAgIGlzRm9sbG93VXBFeHBlY3RlZFxuICAgICAgKTtcblxuICAgICAgY29uc3QgcHJvY2Vzc2luZ1RpbWUgPSBEYXRlLm5vdygpIC0gc3RhcnRUaW1lO1xuICAgICAgY29uc29sZS5sb2coYOKchSBQSVBFTElORSBDT01QTEVURTogVG90YWwgcHJvY2Vzc2luZyB0aW1lOiAke3Byb2Nlc3NpbmdUaW1lfW1zYCk7XG5cbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN1Y2Nlc3M6IHRydWUsXG4gICAgICAgIHR3aW1sUmVzcG9uc2UsXG4gICAgICAgIHByb2Nlc3NpbmdUaW1lTXM6IHByb2Nlc3NpbmdUaW1lLFxuICAgICAgICBjb252ZXJzYXRpb25UdXJuLFxuICAgICAgICBpc0ZvbGxvd1VwRXhwZWN0ZWQsXG4gICAgICAgIGNvbnZlcnNhdGlvblBoYXNlXG4gICAgICB9O1xuXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnN0IHByb2Nlc3NpbmdUaW1lID0gRGF0ZS5ub3coKSAtIHN0YXJ0VGltZTtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYOKdjCBQSVBFTElORSBFUlJPUjogJHtlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICdVbmtub3duIGVycm9yJ31gKTtcbiAgICAgIFxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICAgIHR3aW1sUmVzcG9uc2U6IHRoaXMuY3JlYXRlRXJyb3JUd2lNTCgnU29ycnksIHRoZXJlIHdhcyBhbiBlcnJvciBwcm9jZXNzaW5nIHlvdXIgcmVxdWVzdC4gUGxlYXNlIHRyeSBhZ2Fpbi4nKSxcbiAgICAgICAgZXJyb3I6IGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJ1Vua25vd24gZXJyb3InLFxuICAgICAgICBwcm9jZXNzaW5nVGltZU1zOiBwcm9jZXNzaW5nVGltZVxuICAgICAgfTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGNhbGN1bGF0ZUNvbnZlcnNhdGlvblR1cm4oc2Vzc2lvbjogYW55KTogbnVtYmVyIHtcbiAgICAvLyBDb3VudCB1c2VyIGVudHJpZXMgaW4gY29udmVyc2F0aW9uIGhpc3RvcnkgdG8gZGV0ZXJtaW5lIHR1cm4gbnVtYmVyXG4gICAgLy8gQWRkIDEgYmVjYXVzZSB3ZSdyZSBhYm91dCB0byBwcm9jZXNzIHRoZSBjdXJyZW50IHVzZXIgaW5wdXRcbiAgICBjb25zdCB1c2VyRW50cmllcyA9IHNlc3Npb24uY29udmVyc2F0aW9uSGlzdG9yeT8uZmlsdGVyKChlbnRyeTogYW55KSA9PiBlbnRyeS50eXBlID09PSAndXNlcicpIHx8IFtdO1xuICAgIHJldHVybiB1c2VyRW50cmllcy5sZW5ndGggKyAxO1xuICB9XG5cbiAgcHJpdmF0ZSBkZXRlcm1pbmVDb252ZXJzYXRpb25QaGFzZShzZXNzaW9uOiBhbnksIHR1cm5OdW1iZXI6IG51bWJlcik6ICdncmVldGluZycgfCAnY29udmVyc2F0aW9uJyB8ICdjbGFyaWZpY2F0aW9uJyB8ICdjbG9zaW5nJyB7XG4gICAgaWYgKHR1cm5OdW1iZXIgPT09IDEpIHtcbiAgICAgIHJldHVybiAnZ3JlZXRpbmcnO1xuICAgIH0gZWxzZSBpZiAodHVybk51bWJlciA8PSA1KSB7XG4gICAgICByZXR1cm4gJ2NvbnZlcnNhdGlvbic7XG4gICAgfSBlbHNlIGlmICh0dXJuTnVtYmVyIDw9IDgpIHtcbiAgICAgIHJldHVybiAnY2xhcmlmaWNhdGlvbic7XG4gICAgfSBlbHNlIHtcbiAgICAgIHJldHVybiAnY2xvc2luZyc7XG4gICAgfVxuICB9XG5cbiAgcHJpdmF0ZSBkZXRlY3RGb2xsb3dVcEV4cGVjdGF0aW9uKFxuICAgIHVzZXJUZXh0OiBzdHJpbmcsXG4gICAgYWlSZXNwb25zZTogc3RyaW5nLFxuICAgIHBoYXNlOiBzdHJpbmdcbiAgKTogYm9vbGVhbiB7XG4gICAgLy8gS2V5d29yZHMgdGhhdCBzdWdnZXN0IHRoZSB1c2VyIG1pZ2h0IGhhdmUgZm9sbG93LXVwIHF1ZXN0aW9uc1xuICAgIGNvbnN0IGZvbGxvd1VwSW5kaWNhdG9ycyA9IFtcbiAgICAgICd0ZWxsIG1lIG1vcmUnLCAnZXhwbGFpbicsICdob3cnLCAnd2h5JywgJ3doYXQgYWJvdXQnLCAnY2FuIHlvdScsXG4gICAgICAnYWxzbycsICdhbm90aGVyJywgJ21vcmUgaW5mb3JtYXRpb24nLCAnZGV0YWlscycsICdleGFtcGxlJ1xuICAgIF07XG5cbiAgICAvLyBBSSByZXNwb25zZXMgdGhhdCBuYXR1cmFsbHkgaW52aXRlIGZvbGxvdy11cHNcbiAgICBjb25zdCBhaUZvbGxvd1VwSW5kaWNhdG9ycyA9IFtcbiAgICAgICd3b3VsZCB5b3UgbGlrZSB0byBrbm93IG1vcmUnLCAnYW55IG90aGVyIHF1ZXN0aW9ucycsICdhbnl0aGluZyBlbHNlJyxcbiAgICAgICdsZXQgbWUga25vdyBpZicsICdmZWVsIGZyZWUgdG8gYXNrJywgJ2lzIHRoZXJlIGFueXRoaW5nJ1xuICAgIF07XG5cbiAgICBjb25zdCB1c2VyTG93ZXIgPSB1c2VyVGV4dC50b0xvd2VyQ2FzZSgpO1xuICAgIGNvbnN0IGFpTG93ZXIgPSBhaVJlc3BvbnNlLnRvTG93ZXJDYXNlKCk7XG5cbiAgICBjb25zdCB1c2VySGFzRm9sbG93VXBJbnRlbnQgPSBmb2xsb3dVcEluZGljYXRvcnMuc29tZShpbmRpY2F0b3IgPT4gXG4gICAgICB1c2VyTG93ZXIuaW5jbHVkZXMoaW5kaWNhdG9yKVxuICAgICk7XG5cbiAgICBjb25zdCBhaUludml0ZXNGb2xsb3dVcCA9IGFpRm9sbG93VXBJbmRpY2F0b3JzLnNvbWUoaW5kaWNhdG9yID0+IFxuICAgICAgYWlMb3dlci5pbmNsdWRlcyhpbmRpY2F0b3IpXG4gICAgKTtcblxuICAgIC8vIE1vcmUgbGlrZWx5IHRvIGV4cGVjdCBmb2xsb3ctdXBzIGluIGNvbnZlcnNhdGlvbiBwaGFzZVxuICAgIGNvbnN0IHBoYXNlRXhwZWN0c0ZvbGxvd1VwID0gcGhhc2UgPT09ICdjb252ZXJzYXRpb24nIHx8IHBoYXNlID09PSAnY2xhcmlmaWNhdGlvbic7XG5cbiAgICByZXR1cm4gdXNlckhhc0ZvbGxvd1VwSW50ZW50IHx8IGFpSW52aXRlc0ZvbGxvd1VwIHx8IHBoYXNlRXhwZWN0c0ZvbGxvd1VwO1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBnZW5lcmF0ZVJlc3BvbnNlVHdpTUwoXG4gICAgc2Vzc2lvbklkOiBzdHJpbmcsIFxuICAgIGFpUmVzcG9uc2U6IHN0cmluZywgXG4gICAgcGhhc2U6ICdncmVldGluZycgfCAnY29udmVyc2F0aW9uJyB8ICdjbGFyaWZpY2F0aW9uJyB8ICdjbG9zaW5nJyA9ICdjb252ZXJzYXRpb24nLFxuICAgIGV4cGVjdEZvbGxvd1VwOiBib29sZWFuID0gdHJ1ZVxuICApOiBQcm9taXNlPHN0cmluZz4ge1xuICAgIHRyeSB7XG4gICAgICAvLyBHZW5lcmF0ZSBBSSByZXNwb25zZSBhdWRpbyB3aXRoIFBvbGx5XG4gICAgICBjb25zdCByZXNwb25zZUF1ZGlvID0gYXdhaXQgdGhpcy5wb2xseVNlcnZpY2Uuc3ludGhlc2l6ZVNwZWVjaChcbiAgICAgICAgYWlSZXNwb25zZSxcbiAgICAgICAgc2Vzc2lvbklkLFxuICAgICAgICB0aGlzLnBvbGx5U2VydmljZS5nZXRUZWxlcGhvbnlDb25maWcoKSxcbiAgICAgICAgeyBcbiAgICAgICAgICB0ZWxlcGhvbnlPcHRpbWl6ZWQ6IHRydWUsXG4gICAgICAgICAgYWRkUGF1c2VzOiB0cnVlIFxuICAgICAgICB9XG4gICAgICApO1xuXG4gICAgICAvLyBHZW5lcmF0ZSBhcHByb3ByaWF0ZSBmb2xsb3ctdXAgYmFzZWQgb24gY29udmVyc2F0aW9uIHBoYXNlIGFuZCBleHBlY3RhdGlvblxuICAgICAgY29uc3QgZm9sbG93VXBUZXh0ID0gdGhpcy5nZW5lcmF0ZUZvbGxvd1VwVGV4dChwaGFzZSwgZXhwZWN0Rm9sbG93VXApO1xuICAgICAgY29uc3QgZm9sbG93VXBBdWRpbyA9IGF3YWl0IHRoaXMucG9sbHlTZXJ2aWNlLnN5bnRoZXNpemVTcGVlY2goXG4gICAgICAgIGZvbGxvd1VwVGV4dCxcbiAgICAgICAgc2Vzc2lvbklkLFxuICAgICAgICB0aGlzLnBvbGx5U2VydmljZS5nZXRUZWxlcGhvbnlDb25maWcoKSxcbiAgICAgICAgeyB0ZWxlcGhvbnlPcHRpbWl6ZWQ6IHRydWUgfVxuICAgICAgKTtcblxuICAgICAgY29uc29sZS5sb2coYPCfjqQgUE9MTFkgU1VDQ0VTUzogR2VuZXJhdGVkIHJlc3BvbnNlIGFuZCBmb2xsb3ctdXAgYXVkaW9gKTtcblxuICAgICAgLy8gRW5zdXJlIHdlIGhhdmUgcGxheWJhY2sgVVJMcywgZmFsbGJhY2sgdG8gYXVkaW9VcmwgaWYgbmVlZGVkXG4gICAgICBjb25zdCByZXNwb25zZVVybCA9IHJlc3BvbnNlQXVkaW8ucGxheWJhY2tVcmwgfHwgcmVzcG9uc2VBdWRpby5hdWRpb1VybDtcbiAgICAgIGNvbnN0IGZvbGxvd1VwVXJsID0gZm9sbG93VXBBdWRpby5wbGF5YmFja1VybCB8fCBmb2xsb3dVcEF1ZGlvLmF1ZGlvVXJsO1xuXG4gICAgICBpZiAoIXJlc3BvbnNlVXJsIHx8ICFmb2xsb3dVcFVybCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ0ZhaWxlZCB0byBnZW5lcmF0ZSBhdWRpbyBVUkxzIGZvciBUd2lNTCBwbGF5YmFjaycpO1xuICAgICAgfVxuXG4gICAgICByZXR1cm4gdGhpcy5jcmVhdGVDb252ZXJzYXRpb25Ud2lNTChcbiAgICAgICAgcmVzcG9uc2VVcmwsXG4gICAgICAgIGZvbGxvd1VwVXJsLFxuICAgICAgICBwaGFzZSxcbiAgICAgICAgZXhwZWN0Rm9sbG93VXBcbiAgICAgICk7XG5cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcihg4p2MIFBPTExZIEVSUk9SOiBGYWxsaW5nIGJhY2sgdG8gVHdpbGlvIFRUUzpgLCBlcnJvcik7XG4gICAgICBcbiAgICAgIC8vIEZhbGxiYWNrIHRvIFR3aWxpbydzIGJ1aWx0LWluIFRUU1xuICAgICAgY29uc3QgZXNjYXBlZFJlc3BvbnNlID0gYWlSZXNwb25zZVxuICAgICAgICAucmVwbGFjZSgvJi9nLCAnJmFtcDsnKVxuICAgICAgICAucmVwbGFjZSgvPC9nLCAnJmx0OycpXG4gICAgICAgIC5yZXBsYWNlKC8+L2csICcmZ3Q7JylcbiAgICAgICAgLnJlcGxhY2UoL1wiL2csICcmcXVvdDsnKVxuICAgICAgICAucmVwbGFjZSgvJy9nLCAnJmFwb3M7Jyk7XG5cbiAgICAgIGNvbnN0IGZvbGxvd1VwVGV4dCA9IHRoaXMuZ2VuZXJhdGVGb2xsb3dVcFRleHQocGhhc2UsIGV4cGVjdEZvbGxvd1VwKTtcbiAgICAgIFxuICAgICAgcmV0dXJuIHRoaXMuY3JlYXRlRmFsbGJhY2tDb252ZXJzYXRpb25Ud2lNTChcbiAgICAgICAgZXNjYXBlZFJlc3BvbnNlLFxuICAgICAgICBmb2xsb3dVcFRleHQsXG4gICAgICAgIHBoYXNlLFxuICAgICAgICBleHBlY3RGb2xsb3dVcFxuICAgICAgKTtcbiAgICB9XG4gIH1cblxuICBwcml2YXRlIGNyZWF0ZVRyYW5zY3JpcHRpb25GYWlsdXJlUmVzcG9uc2UoYXR0ZW1wdHM6IG51bWJlcik6IFBpcGVsaW5lUmVzdWx0IHtcbiAgICByZXR1cm4ge1xuICAgICAgc3VjY2VzczogZmFsc2UsXG4gICAgICB0d2ltbFJlc3BvbnNlOiBgPD94bWwgdmVyc2lvbj1cIjEuMFwiIGVuY29kaW5nPVwiVVRGLThcIj8+XG48UmVzcG9uc2U+XG4gIDxTYXkgdm9pY2U9XCJhbGljZVwiIHJhdGU9XCIxXCI+XG4gICAgSSdtIHNvcnJ5LCBidXQgSSB3YXNuJ3QgYWJsZSB0byB1bmRlcnN0YW5kIHlvdXIgc3BlZWNoIGNsZWFybHkgYWZ0ZXIgJHthdHRlbXB0c30gYXR0ZW1wdHMuIFxuICAgIFBsZWFzZSB0cnkgc3BlYWtpbmcgbW9yZSBjbGVhcmx5LCBvciBjYWxsIGJhY2sgZnJvbSBhIHF1aWV0ZXIgbG9jYXRpb24uXG4gIDwvU2F5PlxuICA8UGF1c2UgbGVuZ3RoPVwiMVwiLz5cbiAgPFNheSB2b2ljZT1cImFsaWNlXCI+V291bGQgeW91IGxpa2UgdG8gdHJ5IGFnYWluPzwvU2F5PlxuICA8UmVjb3JkIFxuICAgIGFjdGlvbj1cImh0dHBzOi8va2wxenpyM3Y1ay5leGVjdXRlLWFwaS51cy1lYXN0LTEuYW1hem9uYXdzLmNvbS9wcm9kL3dlYmhvb2svc3BlZWNoXCIgXG4gICAgbWV0aG9kPVwiUE9TVFwiIFxuICAgIG1heExlbmd0aD1cIjMwXCIgXG4gICAgdGltZW91dD1cIjEwXCJcbiAgICBwbGF5QmVlcD1cInRydWVcIlxuICAgIHJlY29yZGluZ1N0YXR1c0NhbGxiYWNrPVwiaHR0cHM6Ly9rbDF6enIzdjVrLmV4ZWN1dGUtYXBpLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tL3Byb2Qvd2ViaG9vay9ldmVudHNcIlxuICAgIHJlY29yZGluZ1N0YXR1c0NhbGxiYWNrTWV0aG9kPVwiUE9TVFwiXG4gIC8+XG4gIDxTYXkgdm9pY2U9XCJhbGljZVwiPlRoYW5rIHlvdSBmb3IgdXNpbmcgUHJvbXB0Q2FsbCBBSS4gR29vZGJ5ZSE8L1NheT5cbjwvUmVzcG9uc2U+YCxcbiAgICAgIGVycm9yOiBgVHJhbnNjcmlwdGlvbiBmYWlsZWQgYWZ0ZXIgJHthdHRlbXB0c30gYXR0ZW1wdHNgXG4gICAgfTtcbiAgfVxuXG4gIHByaXZhdGUgZ2VuZXJhdGVGb2xsb3dVcFRleHQoXG4gICAgcGhhc2U6ICdncmVldGluZycgfCAnY29udmVyc2F0aW9uJyB8ICdjbGFyaWZpY2F0aW9uJyB8ICdjbG9zaW5nJyxcbiAgICBleHBlY3RGb2xsb3dVcDogYm9vbGVhblxuICApOiBzdHJpbmcge1xuICAgIGlmIChwaGFzZSA9PT0gJ2Nsb3NpbmcnIHx8ICFleHBlY3RGb2xsb3dVcCkge1xuICAgICAgcmV0dXJuIFwiSXMgdGhlcmUgYW55dGhpbmcgZWxzZSBJIGNhbiBoZWxwIHlvdSB3aXRoIGJlZm9yZSB3ZSBlbmQgb3VyIGNhbGw/XCI7XG4gICAgfVxuXG4gICAgY29uc3QgZm9sbG93VXBPcHRpb25zID0ge1xuICAgICAgZ3JlZXRpbmc6IFtcbiAgICAgICAgXCJXaGF0IGVsc2Ugd291bGQgeW91IGxpa2UgdG8ga25vdz9cIixcbiAgICAgICAgXCJEbyB5b3UgaGF2ZSBhbnkgb3RoZXIgcXVlc3Rpb25zP1wiLFxuICAgICAgICBcIkhvdyBlbHNlIGNhbiBJIGFzc2lzdCB5b3UgdG9kYXk/XCJcbiAgICAgIF0sXG4gICAgICBjb252ZXJzYXRpb246IFtcbiAgICAgICAgXCJJcyB0aGVyZSBhbnl0aGluZyBlbHNlIEkgY2FuIGhlbHAgeW91IHdpdGg/XCIsXG4gICAgICAgIFwiRG8geW91IGhhdmUgYW55IGZvbGxvdy11cCBxdWVzdGlvbnM/XCIsXG4gICAgICAgIFwiV291bGQgeW91IGxpa2UgdG8ga25vdyBtb3JlIGFib3V0IGFueXRoaW5nIGVsc2U/XCJcbiAgICAgIF0sXG4gICAgICBjbGFyaWZpY2F0aW9uOiBbXG4gICAgICAgIFwiRG9lcyB0aGF0IGFuc3dlciB5b3VyIHF1ZXN0aW9uLCBvciB3b3VsZCB5b3UgbGlrZSBtZSB0byBleHBsYWluIGZ1cnRoZXI/XCIsXG4gICAgICAgIFwiSXMgdGhlcmUgYW55dGhpbmcgZWxzZSB5b3UnZCBsaWtlIG1lIHRvIGNsYXJpZnk/XCIsXG4gICAgICAgIFwiRG8geW91IG5lZWQgbW9yZSBkZXRhaWxzIGFib3V0IGFueXRoaW5nP1wiXG4gICAgICBdXG4gICAgfTtcblxuICAgIGNvbnN0IG9wdGlvbnMgPSBmb2xsb3dVcE9wdGlvbnNbcGhhc2VdIHx8IGZvbGxvd1VwT3B0aW9ucy5jb252ZXJzYXRpb247XG4gICAgcmV0dXJuIG9wdGlvbnNbTWF0aC5mbG9vcihNYXRoLnJhbmRvbSgpICogb3B0aW9ucy5sZW5ndGgpXTtcbiAgfVxuXG4gIHByaXZhdGUgY3JlYXRlQ29udmVyc2F0aW9uVHdpTUwoXG4gICAgcmVzcG9uc2VBdWRpb1VybDogc3RyaW5nLFxuICAgIGZvbGxvd1VwQXVkaW9Vcmw6IHN0cmluZyxcbiAgICBwaGFzZTogJ2dyZWV0aW5nJyB8ICdjb252ZXJzYXRpb24nIHwgJ2NsYXJpZmljYXRpb24nIHwgJ2Nsb3NpbmcnLFxuICAgIGV4cGVjdEZvbGxvd1VwOiBib29sZWFuXG4gICk6IHN0cmluZyB7XG4gICAgY29uc3QgdGltZW91dCA9IGV4cGVjdEZvbGxvd1VwID8gXCIxNVwiIDogXCIxMFwiOyAvLyBMb25nZXIgdGltZW91dCBpZiBmb2xsb3ctdXAgZXhwZWN0ZWRcbiAgICBjb25zdCBtYXhMZW5ndGggPSBwaGFzZSA9PT0gJ2Nsb3NpbmcnID8gXCIyMFwiIDogXCIzMFwiOyAvLyBTaG9ydGVyIGZvciBjbG9zaW5nIHBoYXNlXG5cbiAgICAvLyBFc2NhcGUgWE1MIGNoYXJhY3RlcnMgaW4gVVJMc1xuICAgIGNvbnN0IGVzY2FwZWRSZXNwb25zZVVybCA9IHJlc3BvbnNlQXVkaW9VcmxcbiAgICAgIC5yZXBsYWNlKC8mL2csICcmYW1wOycpXG4gICAgICAucmVwbGFjZSgvPC9nLCAnJmx0OycpXG4gICAgICAucmVwbGFjZSgvPi9nLCAnJmd0OycpO1xuICAgIFxuICAgIGNvbnN0IGVzY2FwZWRGb2xsb3dVcFVybCA9IGZvbGxvd1VwQXVkaW9VcmxcbiAgICAgIC5yZXBsYWNlKC8mL2csICcmYW1wOycpXG4gICAgICAucmVwbGFjZSgvPC9nLCAnJmx0OycpXG4gICAgICAucmVwbGFjZSgvPi9nLCAnJmd0OycpO1xuXG4gICAgcmV0dXJuIGA8P3htbCB2ZXJzaW9uPVwiMS4wXCIgZW5jb2Rpbmc9XCJVVEYtOFwiPz5cbjxSZXNwb25zZT5cbiAgPFBsYXk+JHtlc2NhcGVkUmVzcG9uc2VVcmx9PC9QbGF5PlxuICA8UGF1c2UgbGVuZ3RoPVwiMVwiLz5cbiAgPFBsYXk+JHtlc2NhcGVkRm9sbG93VXBVcmx9PC9QbGF5PlxuICA8UmVjb3JkIFxuICAgIGFjdGlvbj1cImh0dHBzOi8va2wxenpyM3Y1ay5leGVjdXRlLWFwaS51cy1lYXN0LTEuYW1hem9uYXdzLmNvbS9wcm9kL3dlYmhvb2svc3BlZWNoXCIgXG4gICAgbWV0aG9kPVwiUE9TVFwiIFxuICAgIG1heExlbmd0aD1cIiR7bWF4TGVuZ3RofVwiIFxuICAgIHRpbWVvdXQ9XCIke3RpbWVvdXR9XCJcbiAgICBwbGF5QmVlcD1cInRydWVcIlxuICAgIHJlY29yZGluZ1N0YXR1c0NhbGxiYWNrPVwiaHR0cHM6Ly9rbDF6enIzdjVrLmV4ZWN1dGUtYXBpLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tL3Byb2Qvd2ViaG9vay9ldmVudHNcIlxuICAgIHJlY29yZGluZ1N0YXR1c0NhbGxiYWNrTWV0aG9kPVwiUE9TVFwiXG4gIC8+XG4gICR7cGhhc2UgPT09ICdjbG9zaW5nJyA/ICc8U2F5IHZvaWNlPVwiYWxpY2VcIj5UaGFuayB5b3UgZm9yIHVzaW5nIFByb21wdENhbGwgQUkuIEdvb2RieWUhPC9TYXk+JyA6ICc8UmVkaXJlY3Q+aHR0cHM6Ly9rbDF6enIzdjVrLmV4ZWN1dGUtYXBpLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tL3Byb2Qvd2ViaG9vay90aW1lb3V0PC9SZWRpcmVjdD4nfVxuPC9SZXNwb25zZT5gO1xuICB9XG5cbiAgcHJpdmF0ZSBjcmVhdGVGYWxsYmFja0NvbnZlcnNhdGlvblR3aU1MKFxuICAgIGFpUmVzcG9uc2U6IHN0cmluZyxcbiAgICBmb2xsb3dVcFRleHQ6IHN0cmluZyxcbiAgICBwaGFzZTogJ2dyZWV0aW5nJyB8ICdjb252ZXJzYXRpb24nIHwgJ2NsYXJpZmljYXRpb24nIHwgJ2Nsb3NpbmcnLFxuICAgIGV4cGVjdEZvbGxvd1VwOiBib29sZWFuXG4gICk6IHN0cmluZyB7XG4gICAgY29uc3QgdGltZW91dCA9IGV4cGVjdEZvbGxvd1VwID8gXCIxNVwiIDogXCIxMFwiO1xuICAgIGNvbnN0IG1heExlbmd0aCA9IHBoYXNlID09PSAnY2xvc2luZycgPyBcIjIwXCIgOiBcIjMwXCI7XG5cbiAgICByZXR1cm4gYDw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cIlVURi04XCI/PlxuPFJlc3BvbnNlPlxuICA8U2F5IHZvaWNlPVwiYWxpY2VcIiByYXRlPVwiMVwiPlxuICAgICR7YWlSZXNwb25zZX1cbiAgPC9TYXk+XG4gIDxQYXVzZSBsZW5ndGg9XCIxXCIvPlxuICA8U2F5IHZvaWNlPVwiYWxpY2VcIj5cbiAgICAke2ZvbGxvd1VwVGV4dH1cbiAgPC9TYXk+XG4gIDxSZWNvcmQgXG4gICAgYWN0aW9uPVwiaHR0cHM6Ly9rbDF6enIzdjVrLmV4ZWN1dGUtYXBpLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tL3Byb2Qvd2ViaG9vay9zcGVlY2hcIiBcbiAgICBtZXRob2Q9XCJQT1NUXCIgXG4gICAgbWF4TGVuZ3RoPVwiJHttYXhMZW5ndGh9XCIgXG4gICAgdGltZW91dD1cIiR7dGltZW91dH1cIlxuICAgIHBsYXlCZWVwPVwidHJ1ZVwiXG4gICAgcmVjb3JkaW5nU3RhdHVzQ2FsbGJhY2s9XCJodHRwczovL2tsMXp6cjN2NWsuZXhlY3V0ZS1hcGkudXMtZWFzdC0xLmFtYXpvbmF3cy5jb20vcHJvZC93ZWJob29rL2V2ZW50c1wiXG4gICAgcmVjb3JkaW5nU3RhdHVzQ2FsbGJhY2tNZXRob2Q9XCJQT1NUXCJcbiAgLz5cbiAgJHtwaGFzZSA9PT0gJ2Nsb3NpbmcnID8gJzxTYXkgdm9pY2U9XCJhbGljZVwiPlRoYW5rIHlvdSBmb3IgdXNpbmcgUHJvbXB0Q2FsbCBBSS4gR29vZGJ5ZSE8L1NheT4nIDogJzxSZWRpcmVjdD5odHRwczovL2tsMXp6cjN2NWsuZXhlY3V0ZS1hcGkudXMtZWFzdC0xLmFtYXpvbmF3cy5jb20vcHJvZC93ZWJob29rL3RpbWVvdXQ8L1JlZGlyZWN0Pid9XG48L1Jlc3BvbnNlPmA7XG4gIH1cblxuICBwcml2YXRlIGNyZWF0ZUVycm9yVHdpTUwobWVzc2FnZTogc3RyaW5nKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYDw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cIlVURi04XCI/PlxuPFJlc3BvbnNlPlxuICA8U2F5IHZvaWNlPVwiYWxpY2VcIj4ke21lc3NhZ2V9PC9TYXk+XG48L1Jlc3BvbnNlPmA7XG4gIH1cbn0iXX0=