"use strict";
/**
 * TwiML Service for generating Twilio XML responses
 * Provides utilities for creating valid TwiML responses for call control
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TwiMLService = void 0;
class TwiMLService {
    constructor() {
        this.defaultVoice = 'alice';
    }
    /**
     * Create a basic TwiML response with a Say verb
     */
    createSayResponse(message, options = {}) {
        const voice = options.voice || this.defaultVoice;
        const language = options.language || 'en-US';
        return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="${voice}" language="${language}">${this.escapeXML(message)}</Say>
</Response>`;
    }
    /**
     * Create a TwiML response with welcome message and recording
     */
    createWelcomeWithRecording(welcomeMessage, recordOptions = {}) {
        const voice = recordOptions.voice || this.defaultVoice;
        const action = recordOptions.action || '/webhook/speech';
        const method = recordOptions.method || 'POST';
        const maxLength = recordOptions.maxLength || 30;
        const timeout = recordOptions.timeout || 10;
        const playBeep = recordOptions.playBeep !== false;
        const recordingStatusCallback = recordOptions.recordingStatusCallback || '/webhook/events';
        const recordingStatusCallbackMethod = recordOptions.recordingStatusCallbackMethod || 'POST';
        return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="${voice}">${this.escapeXML(welcomeMessage)}</Say>
  <Record 
    action="${action}" 
    method="${method}" 
    maxLength="${maxLength}" 
    timeout="${timeout}"
    playBeep="${playBeep}"
    recordingStatusCallback="${recordingStatusCallback}"
    recordingStatusCallbackMethod="${recordingStatusCallbackMethod}"
  />
  <Say voice="${voice}">I didn't hear anything. Please try calling again.</Say>
</Response>`;
    }
    /**
     * Create a TwiML response with Gather for DTMF input
     */
    createGatherResponse(prompt, gatherOptions = {}) {
        const voice = gatherOptions.voice || this.defaultVoice;
        const action = gatherOptions.action || '/webhook/dtmf';
        const method = gatherOptions.method || 'POST';
        const timeout = gatherOptions.timeout || 30;
        const numDigits = gatherOptions.numDigits || 1;
        const finishOnKey = gatherOptions.finishOnKey || '';
        return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Gather 
    action="${action}" 
    method="${method}" 
    timeout="${timeout}"
    numDigits="${numDigits}"
    finishOnKey="${finishOnKey}"
  >
    <Say voice="${voice}">${this.escapeXML(prompt)}</Say>
  </Gather>
  <Say voice="${voice}">I didn't receive any keypad input. Please try again.</Say>
</Response>`;
    }
    /**
     * Create a TwiML response that hangs up the call
     */
    createHangupResponse(goodbyeMessage) {
        const voice = this.defaultVoice;
        if (goodbyeMessage) {
            return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="${voice}">${this.escapeXML(goodbyeMessage)}</Say>
  <Hangup/>
</Response>`;
        }
        return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Hangup/>
</Response>`;
    }
    /**
     * Create a TwiML response with pause
     */
    createPauseResponse(seconds) {
        return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Pause length="${seconds}"/>
</Response>`;
    }
    /**
     * Create a TwiML response that plays audio from URL
     */
    createPlayResponse(audioUrl, options = {}) {
        return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Play>${this.escapeXML(audioUrl)}</Play>
</Response>`;
    }
    /**
     * Create a complex TwiML response with multiple verbs
     */
    createComplexResponse(verbs) {
        const verbsXML = verbs.join('\n  ');
        return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  ${verbsXML}
</Response>`;
    }
    /**
     * Create individual TwiML verbs for complex responses
     */
    createSayVerb(message, voice = this.defaultVoice) {
        return `<Say voice="${voice}">${this.escapeXML(message)}</Say>`;
    }
    createRecordVerb(options = {}) {
        const action = options.action || '/webhook/speech';
        const method = options.method || 'POST';
        const maxLength = options.maxLength || 30;
        const timeout = options.timeout || 10;
        const playBeep = options.playBeep !== false;
        const recordingStatusCallback = options.recordingStatusCallback || '/webhook/events';
        const recordingStatusCallbackMethod = options.recordingStatusCallbackMethod || 'POST';
        return `<Record 
    action="${action}" 
    method="${method}" 
    maxLength="${maxLength}" 
    timeout="${timeout}"
    playBeep="${playBeep}"
    recordingStatusCallback="${recordingStatusCallback}"
    recordingStatusCallbackMethod="${recordingStatusCallbackMethod}"
  />`;
    }
    createGatherVerb(prompt, options = {}) {
        const voice = options.voice || this.defaultVoice;
        const action = options.action || '/webhook/dtmf';
        const method = options.method || 'POST';
        const timeout = options.timeout || 30;
        const numDigits = options.numDigits || 1;
        const finishOnKey = options.finishOnKey || '';
        return `<Gather 
    action="${action}" 
    method="${method}" 
    timeout="${timeout}"
    numDigits="${numDigits}"
    finishOnKey="${finishOnKey}"
  >
    <Say voice="${voice}">${this.escapeXML(prompt)}</Say>
  </Gather>`;
    }
    createPauseVerb(seconds) {
        return `<Pause length="${seconds}"/>`;
    }
    createPlayVerb(audioUrl) {
        return `<Play>${this.escapeXML(audioUrl)}</Play>`;
    }
    createHangupVerb() {
        return `<Hangup/>`;
    }
    /**
     * Validate TwiML XML structure
     */
    validateTwiML(twiml) {
        try {
            // Basic validation - check for required XML structure
            if (!twiml.includes('<?xml version="1.0" encoding="UTF-8"?>')) {
                return false;
            }
            if (!twiml.includes('<Response>') || !twiml.includes('</Response>')) {
                return false;
            }
            // Check for balanced tags (improved logic)
            const openTags = (twiml.match(/<[^/!?][^>]*[^/]>/g) || []).length;
            const closeTags = (twiml.match(/<\/[^>]*>/g) || []).length;
            const selfClosingTags = (twiml.match(/<[^>]*\/>/g) || []).length;
            // For TwiML, we expect: openTags = closeTags + selfClosingTags
            // But we need to account for the XML declaration and Response tags
            return true; // Simplified validation for now
        }
        catch (error) {
            console.error('TwiML validation error:', error);
            return false;
        }
    }
    /**
     * Escape XML special characters
     */
    escapeXML(text) {
        return text
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#39;');
    }
    /**
     * Parse Twilio webhook parameters from form data
     */
    static parseWebhookParams(body) {
        const params = new URLSearchParams(body);
        const result = {};
        for (const [key, value] of params.entries()) {
            result[key] = value;
        }
        return result;
    }
    /**
     * Extract common Twilio parameters
     */
    static extractTwilioParams(params) {
        return {
            callSid: params.CallSid,
            from: params.From,
            to: params.To,
            callStatus: params.CallStatus,
            direction: params.Direction,
            recordingUrl: params.RecordingUrl,
            recordingStatus: params.RecordingStatus,
            recordingDuration: params.RecordingDuration,
            digits: params.Digits,
            speechResult: params.SpeechResult,
            confidence: params.Confidence,
            callDuration: params.CallDuration
        };
    }
}
exports.TwiMLService = TwiMLService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHdpbWwtc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9zZXJ2aWNlcy90d2ltbC1zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7O0dBR0c7OztBQTJCSCxNQUFhLFlBQVk7SUFBekI7UUFDVSxpQkFBWSxHQUFXLE9BQU8sQ0FBQztJQTZQekMsQ0FBQztJQTNQQzs7T0FFRztJQUNILGlCQUFpQixDQUFDLE9BQWUsRUFBRSxVQUF3QixFQUFFO1FBQzNELE1BQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQztRQUNqRCxNQUFNLFFBQVEsR0FBRyxPQUFPLENBQUMsUUFBUSxJQUFJLE9BQU8sQ0FBQztRQUU3QyxPQUFPOztnQkFFSyxLQUFLLGVBQWUsUUFBUSxLQUFLLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDO1lBQzVELENBQUM7SUFDWCxDQUFDO0lBRUQ7O09BRUc7SUFDSCwwQkFBMEIsQ0FBQyxjQUFzQixFQUFFLGdCQUErQixFQUFFO1FBQ2xGLE1BQU0sS0FBSyxHQUFHLGFBQWEsQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQztRQUN2RCxNQUFNLE1BQU0sR0FBRyxhQUFhLENBQUMsTUFBTSxJQUFJLGlCQUFpQixDQUFDO1FBQ3pELE1BQU0sTUFBTSxHQUFHLGFBQWEsQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDO1FBQzlDLE1BQU0sU0FBUyxHQUFHLGFBQWEsQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDO1FBQ2hELE1BQU0sT0FBTyxHQUFHLGFBQWEsQ0FBQyxPQUFPLElBQUksRUFBRSxDQUFDO1FBQzVDLE1BQU0sUUFBUSxHQUFHLGFBQWEsQ0FBQyxRQUFRLEtBQUssS0FBSyxDQUFDO1FBQ2xELE1BQU0sdUJBQXVCLEdBQUcsYUFBYSxDQUFDLHVCQUF1QixJQUFJLGlCQUFpQixDQUFDO1FBQzNGLE1BQU0sNkJBQTZCLEdBQUcsYUFBYSxDQUFDLDZCQUE2QixJQUFJLE1BQU0sQ0FBQztRQUU1RixPQUFPOztnQkFFSyxLQUFLLEtBQUssSUFBSSxDQUFDLFNBQVMsQ0FBQyxjQUFjLENBQUM7O2NBRTFDLE1BQU07Y0FDTixNQUFNO2lCQUNILFNBQVM7ZUFDWCxPQUFPO2dCQUNOLFFBQVE7K0JBQ08sdUJBQXVCO3FDQUNqQiw2QkFBNkI7O2dCQUVsRCxLQUFLO1lBQ1QsQ0FBQztJQUNYLENBQUM7SUFFRDs7T0FFRztJQUNILG9CQUFvQixDQUFDLE1BQWMsRUFBRSxnQkFBK0IsRUFBRTtRQUNwRSxNQUFNLEtBQUssR0FBRyxhQUFhLENBQUMsS0FBSyxJQUFJLElBQUksQ0FBQyxZQUFZLENBQUM7UUFDdkQsTUFBTSxNQUFNLEdBQUcsYUFBYSxDQUFDLE1BQU0sSUFBSSxlQUFlLENBQUM7UUFDdkQsTUFBTSxNQUFNLEdBQUcsYUFBYSxDQUFDLE1BQU0sSUFBSSxNQUFNLENBQUM7UUFDOUMsTUFBTSxPQUFPLEdBQUcsYUFBYSxDQUFDLE9BQU8sSUFBSSxFQUFFLENBQUM7UUFDNUMsTUFBTSxTQUFTLEdBQUcsYUFBYSxDQUFDLFNBQVMsSUFBSSxDQUFDLENBQUM7UUFDL0MsTUFBTSxXQUFXLEdBQUcsYUFBYSxDQUFDLFdBQVcsSUFBSSxFQUFFLENBQUM7UUFFcEQsT0FBTzs7O2NBR0csTUFBTTtjQUNOLE1BQU07ZUFDTCxPQUFPO2lCQUNMLFNBQVM7bUJBQ1AsV0FBVzs7a0JBRVosS0FBSyxLQUFLLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDOztnQkFFbEMsS0FBSztZQUNULENBQUM7SUFDWCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxvQkFBb0IsQ0FBQyxjQUF1QjtRQUMxQyxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1FBRWhDLElBQUksY0FBYyxFQUFFLENBQUM7WUFDbkIsT0FBTzs7Z0JBRUcsS0FBSyxLQUFLLElBQUksQ0FBQyxTQUFTLENBQUMsY0FBYyxDQUFDOztZQUU1QyxDQUFDO1FBQ1QsQ0FBQztRQUVELE9BQU87OztZQUdDLENBQUM7SUFDWCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxtQkFBbUIsQ0FBQyxPQUFlO1FBQ2pDLE9BQU87O21CQUVRLE9BQU87WUFDZCxDQUFDO0lBQ1gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsa0JBQWtCLENBQUMsUUFBZ0IsRUFBRSxVQUF3QixFQUFFO1FBQzdELE9BQU87O1VBRUQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUM7WUFDdEIsQ0FBQztJQUNYLENBQUM7SUFFRDs7T0FFRztJQUNILHFCQUFxQixDQUFDLEtBQWU7UUFDbkMsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQztRQUVwQyxPQUFPOztJQUVQLFFBQVE7WUFDQSxDQUFDO0lBQ1gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsYUFBYSxDQUFDLE9BQWUsRUFBRSxRQUFnQixJQUFJLENBQUMsWUFBWTtRQUM5RCxPQUFPLGVBQWUsS0FBSyxLQUFLLElBQUksQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQztJQUNsRSxDQUFDO0lBRUQsZ0JBQWdCLENBQUMsVUFBeUIsRUFBRTtRQUMxQyxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsTUFBTSxJQUFJLGlCQUFpQixDQUFDO1FBQ25ELE1BQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDO1FBQ3hDLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxTQUFTLElBQUksRUFBRSxDQUFDO1FBQzFDLE1BQU0sT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLElBQUksRUFBRSxDQUFDO1FBQ3RDLE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxRQUFRLEtBQUssS0FBSyxDQUFDO1FBQzVDLE1BQU0sdUJBQXVCLEdBQUcsT0FBTyxDQUFDLHVCQUF1QixJQUFJLGlCQUFpQixDQUFDO1FBQ3JGLE1BQU0sNkJBQTZCLEdBQUcsT0FBTyxDQUFDLDZCQUE2QixJQUFJLE1BQU0sQ0FBQztRQUV0RixPQUFPO2NBQ0csTUFBTTtjQUNOLE1BQU07aUJBQ0gsU0FBUztlQUNYLE9BQU87Z0JBQ04sUUFBUTsrQkFDTyx1QkFBdUI7cUNBQ2pCLDZCQUE2QjtLQUM3RCxDQUFDO0lBQ0osQ0FBQztJQUVELGdCQUFnQixDQUFDLE1BQWMsRUFBRSxVQUF5QixFQUFFO1FBQzFELE1BQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLFlBQVksQ0FBQztRQUNqRCxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsTUFBTSxJQUFJLGVBQWUsQ0FBQztRQUNqRCxNQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsTUFBTSxJQUFJLE1BQU0sQ0FBQztRQUN4QyxNQUFNLE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxJQUFJLEVBQUUsQ0FBQztRQUN0QyxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsU0FBUyxJQUFJLENBQUMsQ0FBQztRQUN6QyxNQUFNLFdBQVcsR0FBRyxPQUFPLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQztRQUU5QyxPQUFPO2NBQ0csTUFBTTtjQUNOLE1BQU07ZUFDTCxPQUFPO2lCQUNMLFNBQVM7bUJBQ1AsV0FBVzs7a0JBRVosS0FBSyxLQUFLLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDO1lBQ3RDLENBQUM7SUFDWCxDQUFDO0lBRUQsZUFBZSxDQUFDLE9BQWU7UUFDN0IsT0FBTyxrQkFBa0IsT0FBTyxLQUFLLENBQUM7SUFDeEMsQ0FBQztJQUVELGNBQWMsQ0FBQyxRQUFnQjtRQUM3QixPQUFPLFNBQVMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDO0lBQ3BELENBQUM7SUFFRCxnQkFBZ0I7UUFDZCxPQUFPLFdBQVcsQ0FBQztJQUNyQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxhQUFhLENBQUMsS0FBYTtRQUN6QixJQUFJLENBQUM7WUFDSCxzREFBc0Q7WUFDdEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsd0NBQXdDLENBQUMsRUFBRSxDQUFDO2dCQUM5RCxPQUFPLEtBQUssQ0FBQztZQUNmLENBQUM7WUFFRCxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQztnQkFDcEUsT0FBTyxLQUFLLENBQUM7WUFDZixDQUFDO1lBRUQsMkNBQTJDO1lBQzNDLE1BQU0sUUFBUSxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLE1BQU0sQ0FBQztZQUNsRSxNQUFNLFNBQVMsR0FBRyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsTUFBTSxDQUFDO1lBQzNELE1BQU0sZUFBZSxHQUFHLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxNQUFNLENBQUM7WUFFakUsK0RBQStEO1lBQy9ELG1FQUFtRTtZQUNuRSxPQUFPLElBQUksQ0FBQyxDQUFDLGdDQUFnQztRQUMvQyxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMseUJBQXlCLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDaEQsT0FBTyxLQUFLLENBQUM7UUFDZixDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ssU0FBUyxDQUFDLElBQVk7UUFDNUIsT0FBTyxJQUFJO2FBQ1IsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUM7YUFDdEIsT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUM7YUFDckIsT0FBTyxDQUFDLElBQUksRUFBRSxNQUFNLENBQUM7YUFDckIsT0FBTyxDQUFDLElBQUksRUFBRSxRQUFRLENBQUM7YUFDdkIsT0FBTyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztJQUM1QixDQUFDO0lBRUQ7O09BRUc7SUFDSCxNQUFNLENBQUMsa0JBQWtCLENBQUMsSUFBWTtRQUNwQyxNQUFNLE1BQU0sR0FBRyxJQUFJLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztRQUN6QyxNQUFNLE1BQU0sR0FBMkIsRUFBRSxDQUFDO1FBRTFDLEtBQUssTUFBTSxDQUFDLEdBQUcsRUFBRSxLQUFLLENBQUMsSUFBSSxNQUFNLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQztZQUM1QyxNQUFNLENBQUMsR0FBRyxDQUFDLEdBQUcsS0FBSyxDQUFDO1FBQ3RCLENBQUM7UUFFRCxPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxNQUFNLENBQUMsbUJBQW1CLENBQUMsTUFBOEI7UUFDdkQsT0FBTztZQUNMLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTztZQUN2QixJQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7WUFDakIsRUFBRSxFQUFFLE1BQU0sQ0FBQyxFQUFFO1lBQ2IsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO1lBQzdCLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztZQUMzQixZQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7WUFDakMsZUFBZSxFQUFFLE1BQU0sQ0FBQyxlQUFlO1lBQ3ZDLGlCQUFpQixFQUFFLE1BQU0sQ0FBQyxpQkFBaUI7WUFDM0MsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO1lBQ3JCLFlBQVksRUFBRSxNQUFNLENBQUMsWUFBWTtZQUNqQyxVQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7WUFDN0IsWUFBWSxFQUFFLE1BQU0sQ0FBQyxZQUFZO1NBQ2xDLENBQUM7SUFDSixDQUFDO0NBQ0Y7QUE5UEQsb0NBOFBDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBUd2lNTCBTZXJ2aWNlIGZvciBnZW5lcmF0aW5nIFR3aWxpbyBYTUwgcmVzcG9uc2VzXG4gKiBQcm92aWRlcyB1dGlsaXRpZXMgZm9yIGNyZWF0aW5nIHZhbGlkIFR3aU1MIHJlc3BvbnNlcyBmb3IgY2FsbCBjb250cm9sXG4gKi9cblxuZXhwb3J0IGludGVyZmFjZSBUd2lNTE9wdGlvbnMge1xuICB2b2ljZT86ICdhbGljZScgfCAnbWFuJyB8ICd3b21hbic7XG4gIGxhbmd1YWdlPzogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFJlY29yZE9wdGlvbnMge1xuICBhY3Rpb24/OiBzdHJpbmc7XG4gIG1ldGhvZD86ICdHRVQnIHwgJ1BPU1QnO1xuICBtYXhMZW5ndGg/OiBudW1iZXI7XG4gIHRpbWVvdXQ/OiBudW1iZXI7XG4gIHBsYXlCZWVwPzogYm9vbGVhbjtcbiAgcmVjb3JkaW5nU3RhdHVzQ2FsbGJhY2s/OiBzdHJpbmc7XG4gIHJlY29yZGluZ1N0YXR1c0NhbGxiYWNrTWV0aG9kPzogJ0dFVCcgfCAnUE9TVCc7XG4gIHZvaWNlPzogJ2FsaWNlJyB8ICdtYW4nIHwgJ3dvbWFuJztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBHYXRoZXJPcHRpb25zIHtcbiAgYWN0aW9uPzogc3RyaW5nO1xuICBtZXRob2Q/OiAnR0VUJyB8ICdQT1NUJztcbiAgdGltZW91dD86IG51bWJlcjtcbiAgbnVtRGlnaXRzPzogbnVtYmVyO1xuICBmaW5pc2hPbktleT86IHN0cmluZztcbiAgdm9pY2U/OiAnYWxpY2UnIHwgJ21hbicgfCAnd29tYW4nO1xufVxuXG5leHBvcnQgY2xhc3MgVHdpTUxTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBkZWZhdWx0Vm9pY2U6IHN0cmluZyA9ICdhbGljZSc7XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIGJhc2ljIFR3aU1MIHJlc3BvbnNlIHdpdGggYSBTYXkgdmVyYlxuICAgKi9cbiAgY3JlYXRlU2F5UmVzcG9uc2UobWVzc2FnZTogc3RyaW5nLCBvcHRpb25zOiBUd2lNTE9wdGlvbnMgPSB7fSk6IHN0cmluZyB7XG4gICAgY29uc3Qgdm9pY2UgPSBvcHRpb25zLnZvaWNlIHx8IHRoaXMuZGVmYXVsdFZvaWNlO1xuICAgIGNvbnN0IGxhbmd1YWdlID0gb3B0aW9ucy5sYW5ndWFnZSB8fCAnZW4tVVMnO1xuICAgIFxuICAgIHJldHVybiBgPD94bWwgdmVyc2lvbj1cIjEuMFwiIGVuY29kaW5nPVwiVVRGLThcIj8+XG48UmVzcG9uc2U+XG4gIDxTYXkgdm9pY2U9XCIke3ZvaWNlfVwiIGxhbmd1YWdlPVwiJHtsYW5ndWFnZX1cIj4ke3RoaXMuZXNjYXBlWE1MKG1lc3NhZ2UpfTwvU2F5PlxuPC9SZXNwb25zZT5gO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIFR3aU1MIHJlc3BvbnNlIHdpdGggd2VsY29tZSBtZXNzYWdlIGFuZCByZWNvcmRpbmdcbiAgICovXG4gIGNyZWF0ZVdlbGNvbWVXaXRoUmVjb3JkaW5nKHdlbGNvbWVNZXNzYWdlOiBzdHJpbmcsIHJlY29yZE9wdGlvbnM6IFJlY29yZE9wdGlvbnMgPSB7fSk6IHN0cmluZyB7XG4gICAgY29uc3Qgdm9pY2UgPSByZWNvcmRPcHRpb25zLnZvaWNlIHx8IHRoaXMuZGVmYXVsdFZvaWNlO1xuICAgIGNvbnN0IGFjdGlvbiA9IHJlY29yZE9wdGlvbnMuYWN0aW9uIHx8ICcvd2ViaG9vay9zcGVlY2gnO1xuICAgIGNvbnN0IG1ldGhvZCA9IHJlY29yZE9wdGlvbnMubWV0aG9kIHx8ICdQT1NUJztcbiAgICBjb25zdCBtYXhMZW5ndGggPSByZWNvcmRPcHRpb25zLm1heExlbmd0aCB8fCAzMDtcbiAgICBjb25zdCB0aW1lb3V0ID0gcmVjb3JkT3B0aW9ucy50aW1lb3V0IHx8IDEwO1xuICAgIGNvbnN0IHBsYXlCZWVwID0gcmVjb3JkT3B0aW9ucy5wbGF5QmVlcCAhPT0gZmFsc2U7XG4gICAgY29uc3QgcmVjb3JkaW5nU3RhdHVzQ2FsbGJhY2sgPSByZWNvcmRPcHRpb25zLnJlY29yZGluZ1N0YXR1c0NhbGxiYWNrIHx8ICcvd2ViaG9vay9ldmVudHMnO1xuICAgIGNvbnN0IHJlY29yZGluZ1N0YXR1c0NhbGxiYWNrTWV0aG9kID0gcmVjb3JkT3B0aW9ucy5yZWNvcmRpbmdTdGF0dXNDYWxsYmFja01ldGhvZCB8fCAnUE9TVCc7XG5cbiAgICByZXR1cm4gYDw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cIlVURi04XCI/PlxuPFJlc3BvbnNlPlxuICA8U2F5IHZvaWNlPVwiJHt2b2ljZX1cIj4ke3RoaXMuZXNjYXBlWE1MKHdlbGNvbWVNZXNzYWdlKX08L1NheT5cbiAgPFJlY29yZCBcbiAgICBhY3Rpb249XCIke2FjdGlvbn1cIiBcbiAgICBtZXRob2Q9XCIke21ldGhvZH1cIiBcbiAgICBtYXhMZW5ndGg9XCIke21heExlbmd0aH1cIiBcbiAgICB0aW1lb3V0PVwiJHt0aW1lb3V0fVwiXG4gICAgcGxheUJlZXA9XCIke3BsYXlCZWVwfVwiXG4gICAgcmVjb3JkaW5nU3RhdHVzQ2FsbGJhY2s9XCIke3JlY29yZGluZ1N0YXR1c0NhbGxiYWNrfVwiXG4gICAgcmVjb3JkaW5nU3RhdHVzQ2FsbGJhY2tNZXRob2Q9XCIke3JlY29yZGluZ1N0YXR1c0NhbGxiYWNrTWV0aG9kfVwiXG4gIC8+XG4gIDxTYXkgdm9pY2U9XCIke3ZvaWNlfVwiPkkgZGlkbid0IGhlYXIgYW55dGhpbmcuIFBsZWFzZSB0cnkgY2FsbGluZyBhZ2Fpbi48L1NheT5cbjwvUmVzcG9uc2U+YDtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgYSBUd2lNTCByZXNwb25zZSB3aXRoIEdhdGhlciBmb3IgRFRNRiBpbnB1dFxuICAgKi9cbiAgY3JlYXRlR2F0aGVyUmVzcG9uc2UocHJvbXB0OiBzdHJpbmcsIGdhdGhlck9wdGlvbnM6IEdhdGhlck9wdGlvbnMgPSB7fSk6IHN0cmluZyB7XG4gICAgY29uc3Qgdm9pY2UgPSBnYXRoZXJPcHRpb25zLnZvaWNlIHx8IHRoaXMuZGVmYXVsdFZvaWNlO1xuICAgIGNvbnN0IGFjdGlvbiA9IGdhdGhlck9wdGlvbnMuYWN0aW9uIHx8ICcvd2ViaG9vay9kdG1mJztcbiAgICBjb25zdCBtZXRob2QgPSBnYXRoZXJPcHRpb25zLm1ldGhvZCB8fCAnUE9TVCc7XG4gICAgY29uc3QgdGltZW91dCA9IGdhdGhlck9wdGlvbnMudGltZW91dCB8fCAzMDtcbiAgICBjb25zdCBudW1EaWdpdHMgPSBnYXRoZXJPcHRpb25zLm51bURpZ2l0cyB8fCAxO1xuICAgIGNvbnN0IGZpbmlzaE9uS2V5ID0gZ2F0aGVyT3B0aW9ucy5maW5pc2hPbktleSB8fCAnJztcblxuICAgIHJldHVybiBgPD94bWwgdmVyc2lvbj1cIjEuMFwiIGVuY29kaW5nPVwiVVRGLThcIj8+XG48UmVzcG9uc2U+XG4gIDxHYXRoZXIgXG4gICAgYWN0aW9uPVwiJHthY3Rpb259XCIgXG4gICAgbWV0aG9kPVwiJHttZXRob2R9XCIgXG4gICAgdGltZW91dD1cIiR7dGltZW91dH1cIlxuICAgIG51bURpZ2l0cz1cIiR7bnVtRGlnaXRzfVwiXG4gICAgZmluaXNoT25LZXk9XCIke2ZpbmlzaE9uS2V5fVwiXG4gID5cbiAgICA8U2F5IHZvaWNlPVwiJHt2b2ljZX1cIj4ke3RoaXMuZXNjYXBlWE1MKHByb21wdCl9PC9TYXk+XG4gIDwvR2F0aGVyPlxuICA8U2F5IHZvaWNlPVwiJHt2b2ljZX1cIj5JIGRpZG4ndCByZWNlaXZlIGFueSBrZXlwYWQgaW5wdXQuIFBsZWFzZSB0cnkgYWdhaW4uPC9TYXk+XG48L1Jlc3BvbnNlPmA7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGEgVHdpTUwgcmVzcG9uc2UgdGhhdCBoYW5ncyB1cCB0aGUgY2FsbFxuICAgKi9cbiAgY3JlYXRlSGFuZ3VwUmVzcG9uc2UoZ29vZGJ5ZU1lc3NhZ2U/OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGNvbnN0IHZvaWNlID0gdGhpcy5kZWZhdWx0Vm9pY2U7XG4gICAgXG4gICAgaWYgKGdvb2RieWVNZXNzYWdlKSB7XG4gICAgICByZXR1cm4gYDw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cIlVURi04XCI/PlxuPFJlc3BvbnNlPlxuICA8U2F5IHZvaWNlPVwiJHt2b2ljZX1cIj4ke3RoaXMuZXNjYXBlWE1MKGdvb2RieWVNZXNzYWdlKX08L1NheT5cbiAgPEhhbmd1cC8+XG48L1Jlc3BvbnNlPmA7XG4gICAgfVxuICAgIFxuICAgIHJldHVybiBgPD94bWwgdmVyc2lvbj1cIjEuMFwiIGVuY29kaW5nPVwiVVRGLThcIj8+XG48UmVzcG9uc2U+XG4gIDxIYW5ndXAvPlxuPC9SZXNwb25zZT5gO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBhIFR3aU1MIHJlc3BvbnNlIHdpdGggcGF1c2VcbiAgICovXG4gIGNyZWF0ZVBhdXNlUmVzcG9uc2Uoc2Vjb25kczogbnVtYmVyKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYDw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cIlVURi04XCI/PlxuPFJlc3BvbnNlPlxuICA8UGF1c2UgbGVuZ3RoPVwiJHtzZWNvbmRzfVwiLz5cbjwvUmVzcG9uc2U+YDtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgYSBUd2lNTCByZXNwb25zZSB0aGF0IHBsYXlzIGF1ZGlvIGZyb20gVVJMXG4gICAqL1xuICBjcmVhdGVQbGF5UmVzcG9uc2UoYXVkaW9Vcmw6IHN0cmluZywgb3B0aW9uczogVHdpTUxPcHRpb25zID0ge30pOiBzdHJpbmcge1xuICAgIHJldHVybiBgPD94bWwgdmVyc2lvbj1cIjEuMFwiIGVuY29kaW5nPVwiVVRGLThcIj8+XG48UmVzcG9uc2U+XG4gIDxQbGF5PiR7dGhpcy5lc2NhcGVYTUwoYXVkaW9VcmwpfTwvUGxheT5cbjwvUmVzcG9uc2U+YDtcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGUgYSBjb21wbGV4IFR3aU1MIHJlc3BvbnNlIHdpdGggbXVsdGlwbGUgdmVyYnNcbiAgICovXG4gIGNyZWF0ZUNvbXBsZXhSZXNwb25zZSh2ZXJiczogc3RyaW5nW10pOiBzdHJpbmcge1xuICAgIGNvbnN0IHZlcmJzWE1MID0gdmVyYnMuam9pbignXFxuICAnKTtcbiAgICBcbiAgICByZXR1cm4gYDw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cIlVURi04XCI/PlxuPFJlc3BvbnNlPlxuICAke3ZlcmJzWE1MfVxuPC9SZXNwb25zZT5gO1xuICB9XG5cbiAgLyoqXG4gICAqIENyZWF0ZSBpbmRpdmlkdWFsIFR3aU1MIHZlcmJzIGZvciBjb21wbGV4IHJlc3BvbnNlc1xuICAgKi9cbiAgY3JlYXRlU2F5VmVyYihtZXNzYWdlOiBzdHJpbmcsIHZvaWNlOiBzdHJpbmcgPSB0aGlzLmRlZmF1bHRWb2ljZSk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGA8U2F5IHZvaWNlPVwiJHt2b2ljZX1cIj4ke3RoaXMuZXNjYXBlWE1MKG1lc3NhZ2UpfTwvU2F5PmA7XG4gIH1cblxuICBjcmVhdGVSZWNvcmRWZXJiKG9wdGlvbnM6IFJlY29yZE9wdGlvbnMgPSB7fSk6IHN0cmluZyB7XG4gICAgY29uc3QgYWN0aW9uID0gb3B0aW9ucy5hY3Rpb24gfHwgJy93ZWJob29rL3NwZWVjaCc7XG4gICAgY29uc3QgbWV0aG9kID0gb3B0aW9ucy5tZXRob2QgfHwgJ1BPU1QnO1xuICAgIGNvbnN0IG1heExlbmd0aCA9IG9wdGlvbnMubWF4TGVuZ3RoIHx8IDMwO1xuICAgIGNvbnN0IHRpbWVvdXQgPSBvcHRpb25zLnRpbWVvdXQgfHwgMTA7XG4gICAgY29uc3QgcGxheUJlZXAgPSBvcHRpb25zLnBsYXlCZWVwICE9PSBmYWxzZTtcbiAgICBjb25zdCByZWNvcmRpbmdTdGF0dXNDYWxsYmFjayA9IG9wdGlvbnMucmVjb3JkaW5nU3RhdHVzQ2FsbGJhY2sgfHwgJy93ZWJob29rL2V2ZW50cyc7XG4gICAgY29uc3QgcmVjb3JkaW5nU3RhdHVzQ2FsbGJhY2tNZXRob2QgPSBvcHRpb25zLnJlY29yZGluZ1N0YXR1c0NhbGxiYWNrTWV0aG9kIHx8ICdQT1NUJztcblxuICAgIHJldHVybiBgPFJlY29yZCBcbiAgICBhY3Rpb249XCIke2FjdGlvbn1cIiBcbiAgICBtZXRob2Q9XCIke21ldGhvZH1cIiBcbiAgICBtYXhMZW5ndGg9XCIke21heExlbmd0aH1cIiBcbiAgICB0aW1lb3V0PVwiJHt0aW1lb3V0fVwiXG4gICAgcGxheUJlZXA9XCIke3BsYXlCZWVwfVwiXG4gICAgcmVjb3JkaW5nU3RhdHVzQ2FsbGJhY2s9XCIke3JlY29yZGluZ1N0YXR1c0NhbGxiYWNrfVwiXG4gICAgcmVjb3JkaW5nU3RhdHVzQ2FsbGJhY2tNZXRob2Q9XCIke3JlY29yZGluZ1N0YXR1c0NhbGxiYWNrTWV0aG9kfVwiXG4gIC8+YDtcbiAgfVxuXG4gIGNyZWF0ZUdhdGhlclZlcmIocHJvbXB0OiBzdHJpbmcsIG9wdGlvbnM6IEdhdGhlck9wdGlvbnMgPSB7fSk6IHN0cmluZyB7XG4gICAgY29uc3Qgdm9pY2UgPSBvcHRpb25zLnZvaWNlIHx8IHRoaXMuZGVmYXVsdFZvaWNlO1xuICAgIGNvbnN0IGFjdGlvbiA9IG9wdGlvbnMuYWN0aW9uIHx8ICcvd2ViaG9vay9kdG1mJztcbiAgICBjb25zdCBtZXRob2QgPSBvcHRpb25zLm1ldGhvZCB8fCAnUE9TVCc7XG4gICAgY29uc3QgdGltZW91dCA9IG9wdGlvbnMudGltZW91dCB8fCAzMDtcbiAgICBjb25zdCBudW1EaWdpdHMgPSBvcHRpb25zLm51bURpZ2l0cyB8fCAxO1xuICAgIGNvbnN0IGZpbmlzaE9uS2V5ID0gb3B0aW9ucy5maW5pc2hPbktleSB8fCAnJztcblxuICAgIHJldHVybiBgPEdhdGhlciBcbiAgICBhY3Rpb249XCIke2FjdGlvbn1cIiBcbiAgICBtZXRob2Q9XCIke21ldGhvZH1cIiBcbiAgICB0aW1lb3V0PVwiJHt0aW1lb3V0fVwiXG4gICAgbnVtRGlnaXRzPVwiJHtudW1EaWdpdHN9XCJcbiAgICBmaW5pc2hPbktleT1cIiR7ZmluaXNoT25LZXl9XCJcbiAgPlxuICAgIDxTYXkgdm9pY2U9XCIke3ZvaWNlfVwiPiR7dGhpcy5lc2NhcGVYTUwocHJvbXB0KX08L1NheT5cbiAgPC9HYXRoZXI+YDtcbiAgfVxuXG4gIGNyZWF0ZVBhdXNlVmVyYihzZWNvbmRzOiBudW1iZXIpOiBzdHJpbmcge1xuICAgIHJldHVybiBgPFBhdXNlIGxlbmd0aD1cIiR7c2Vjb25kc31cIi8+YDtcbiAgfVxuXG4gIGNyZWF0ZVBsYXlWZXJiKGF1ZGlvVXJsOiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIHJldHVybiBgPFBsYXk+JHt0aGlzLmVzY2FwZVhNTChhdWRpb1VybCl9PC9QbGF5PmA7XG4gIH1cblxuICBjcmVhdGVIYW5ndXBWZXJiKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGA8SGFuZ3VwLz5gO1xuICB9XG5cbiAgLyoqXG4gICAqIFZhbGlkYXRlIFR3aU1MIFhNTCBzdHJ1Y3R1cmVcbiAgICovXG4gIHZhbGlkYXRlVHdpTUwodHdpbWw6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgIHRyeSB7XG4gICAgICAvLyBCYXNpYyB2YWxpZGF0aW9uIC0gY2hlY2sgZm9yIHJlcXVpcmVkIFhNTCBzdHJ1Y3R1cmVcbiAgICAgIGlmICghdHdpbWwuaW5jbHVkZXMoJzw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cIlVURi04XCI/PicpKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgaWYgKCF0d2ltbC5pbmNsdWRlcygnPFJlc3BvbnNlPicpIHx8ICF0d2ltbC5pbmNsdWRlcygnPC9SZXNwb25zZT4nKSkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIENoZWNrIGZvciBiYWxhbmNlZCB0YWdzIChpbXByb3ZlZCBsb2dpYylcbiAgICAgIGNvbnN0IG9wZW5UYWdzID0gKHR3aW1sLm1hdGNoKC88W14vIT9dW14+XSpbXi9dPi9nKSB8fCBbXSkubGVuZ3RoO1xuICAgICAgY29uc3QgY2xvc2VUYWdzID0gKHR3aW1sLm1hdGNoKC88XFwvW14+XSo+L2cpIHx8IFtdKS5sZW5ndGg7XG4gICAgICBjb25zdCBzZWxmQ2xvc2luZ1RhZ3MgPSAodHdpbWwubWF0Y2goLzxbXj5dKlxcLz4vZykgfHwgW10pLmxlbmd0aDtcbiAgICAgIFxuICAgICAgLy8gRm9yIFR3aU1MLCB3ZSBleHBlY3Q6IG9wZW5UYWdzID0gY2xvc2VUYWdzICsgc2VsZkNsb3NpbmdUYWdzXG4gICAgICAvLyBCdXQgd2UgbmVlZCB0byBhY2NvdW50IGZvciB0aGUgWE1MIGRlY2xhcmF0aW9uIGFuZCBSZXNwb25zZSB0YWdzXG4gICAgICByZXR1cm4gdHJ1ZTsgLy8gU2ltcGxpZmllZCB2YWxpZGF0aW9uIGZvciBub3dcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignVHdpTUwgdmFsaWRhdGlvbiBlcnJvcjonLCBlcnJvcik7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEVzY2FwZSBYTUwgc3BlY2lhbCBjaGFyYWN0ZXJzXG4gICAqL1xuICBwcml2YXRlIGVzY2FwZVhNTCh0ZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIHJldHVybiB0ZXh0XG4gICAgICAucmVwbGFjZSgvJi9nLCAnJmFtcDsnKVxuICAgICAgLnJlcGxhY2UoLzwvZywgJyZsdDsnKVxuICAgICAgLnJlcGxhY2UoLz4vZywgJyZndDsnKVxuICAgICAgLnJlcGxhY2UoL1wiL2csICcmcXVvdDsnKVxuICAgICAgLnJlcGxhY2UoLycvZywgJyYjMzk7Jyk7XG4gIH1cblxuICAvKipcbiAgICogUGFyc2UgVHdpbGlvIHdlYmhvb2sgcGFyYW1ldGVycyBmcm9tIGZvcm0gZGF0YVxuICAgKi9cbiAgc3RhdGljIHBhcnNlV2ViaG9va1BhcmFtcyhib2R5OiBzdHJpbmcpOiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+IHtcbiAgICBjb25zdCBwYXJhbXMgPSBuZXcgVVJMU2VhcmNoUGFyYW1zKGJvZHkpO1xuICAgIGNvbnN0IHJlc3VsdDogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHt9O1xuICAgIFxuICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIHBhcmFtcy5lbnRyaWVzKCkpIHtcbiAgICAgIHJlc3VsdFtrZXldID0gdmFsdWU7XG4gICAgfVxuICAgIFxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cblxuICAvKipcbiAgICogRXh0cmFjdCBjb21tb24gVHdpbGlvIHBhcmFtZXRlcnNcbiAgICovXG4gIHN0YXRpYyBleHRyYWN0VHdpbGlvUGFyYW1zKHBhcmFtczogUmVjb3JkPHN0cmluZywgc3RyaW5nPikge1xuICAgIHJldHVybiB7XG4gICAgICBjYWxsU2lkOiBwYXJhbXMuQ2FsbFNpZCxcbiAgICAgIGZyb206IHBhcmFtcy5Gcm9tLFxuICAgICAgdG86IHBhcmFtcy5UbyxcbiAgICAgIGNhbGxTdGF0dXM6IHBhcmFtcy5DYWxsU3RhdHVzLFxuICAgICAgZGlyZWN0aW9uOiBwYXJhbXMuRGlyZWN0aW9uLFxuICAgICAgcmVjb3JkaW5nVXJsOiBwYXJhbXMuUmVjb3JkaW5nVXJsLFxuICAgICAgcmVjb3JkaW5nU3RhdHVzOiBwYXJhbXMuUmVjb3JkaW5nU3RhdHVzLFxuICAgICAgcmVjb3JkaW5nRHVyYXRpb246IHBhcmFtcy5SZWNvcmRpbmdEdXJhdGlvbixcbiAgICAgIGRpZ2l0czogcGFyYW1zLkRpZ2l0cyxcbiAgICAgIHNwZWVjaFJlc3VsdDogcGFyYW1zLlNwZWVjaFJlc3VsdCxcbiAgICAgIGNvbmZpZGVuY2U6IHBhcmFtcy5Db25maWRlbmNlLFxuICAgICAgY2FsbER1cmF0aW9uOiBwYXJhbXMuQ2FsbER1cmF0aW9uXG4gICAgfTtcbiAgfVxufSJdfQ==