/**
 * DynamoDB Session Manager for PromptCall AI MVP
 * Handles CRUD operations for call sessions with conversation history
 */
import { CallSession, ConversationEntry, SessionStatus, SessionConfig } from '../types/session';
export interface DynamoSessionManagerConfig {
    tableName: string;
    region?: string;
    sessionConfig?: SessionConfig;
}
export declare class DynamoSessionManager {
    private client;
    private tableName;
    private sessionConfig;
    constructor(config: DynamoSessionManagerConfig);
    /**
     * Creates a new call session in DynamoDB
     */
    createSession(callSid: string, phoneNumber: string): Promise<CallSession>;
    /**
     * Retrieves a session by session ID
     */
    getSession(sessionId: string): Promise<CallSession | null>;
    /**
     * Retrieves a session by Twilio Call SID
     */
    getSessionByCallSid(callSid: string): Promise<CallSession | null>;
    /**
     * Updates session status and metadata
     */
    updateSessionStatus(sessionId: string, status: SessionStatus, endTime?: number, errorInfo?: {
        code: string;
        message: string;
    }): Promise<void>;
    /**
     * Appends a conversation entry to the session history using atomic update
     */
    appendConversationEntry(sessionId: string, entry: ConversationEntry): Promise<void>;
    /**
     * Adds a user message to the conversation
     */
    addUserMessage(sessionId: string, text: string, audioUrl?: string, confidence?: number): Promise<void>;
    /**
     * Adds an AI response to the conversation
     */
    addAiResponse(sessionId: string, text: string, audioUrl?: string, processingDuration?: number): Promise<void>;
    /**
     * Updates a conversation entry with audio URL
     */
    updateConversationEntryWithAudio(sessionId: string, entryIndex: number, audioUrl: string): Promise<void>;
    /**
     * Adds a system message to the conversation
     */
    addSystemMessage(sessionId: string, text: string): Promise<void>;
    /**
     * Updates the total call duration
     */
    updateCallDuration(sessionId: string, durationSeconds: number): Promise<void>;
    /**
     * Deletes a session (for cleanup or testing)
     */
    deleteSession(sessionId: string): Promise<void>;
    /**
     * Lists active sessions (for monitoring/debugging)
     */
    listActiveSessions(limit?: number): Promise<CallSession[]>;
    /**
     * Gets conversation history for a session
     */
    getConversationHistory(sessionId: string): Promise<ConversationEntry[]>;
    /**
     * Builds conversation context string for AI processing
     */
    buildConversationContext(sessionId: string, maxEntries?: number): Promise<string>;
    /**
     * Health check method to verify DynamoDB connectivity
     */
    healthCheck(): Promise<boolean>;
}
