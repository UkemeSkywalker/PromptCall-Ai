/**
 * Timeout and Inactivity Management Service
 *
 * Handles user silence detection, timeout scenarios, and graceful conversation ending
 */
import { DynamoSessionManager } from './dynamo-session-manager';
export interface TimeoutConfig {
    initialTimeoutSeconds: number;
    maxTimeoutSeconds: number;
    inactivityWarningSeconds: number;
    maxInactivityAttempts: number;
    gracefulEndingTimeoutSeconds: number;
}
export interface TimeoutState {
    sessionId: string;
    consecutiveTimeouts: number;
    lastActivityTime: number;
    warningsSent: number;
    isInGracefulEnding: boolean;
    totalInactiveTime: number;
}
export interface TimeoutResult {
    shouldContinue: boolean;
    twimlResponse: string;
    timeoutState: TimeoutState;
    action: 'continue' | 'warn' | 'end_gracefully' | 'end_immediately';
}
export declare class TimeoutManager {
    private sessionManager;
    private config;
    private timeoutStates;
    constructor(sessionManager: DynamoSessionManager, config?: Partial<TimeoutConfig>);
    /**
     * Handle timeout scenario when user doesn't respond
     */
    handleTimeout(sessionId: string, callSid: string): Promise<TimeoutResult>;
    /**
     * Handle user activity - reset timeout counters
     */
    handleUserActivity(sessionId: string): Promise<void>;
    /**
     * Check if session should be ended due to prolonged inactivity
     */
    shouldEndSession(sessionId: string): boolean;
    /**
     * Get appropriate timeout duration based on conversation state
     */
    getTimeoutDuration(conversationPhase: string, consecutiveTimeouts: number): number;
    private initializeTimeoutState;
    private handleFirstTimeout;
    private handleSecondTimeout;
    private handleFinalTimeout;
    private createContinueTwiML;
    /**
     * Clean up timeout state when session ends
     */
    cleanupSession(sessionId: string): void;
    /**
     * Get current timeout state for monitoring
     */
    getTimeoutState(sessionId: string): TimeoutState | null;
}
