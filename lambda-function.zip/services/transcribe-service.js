"use strict";
/**
 * Amazon Transcribe Service for speech-to-text conversion
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TranscribeService = void 0;
const client_transcribe_1 = require("@aws-sdk/client-transcribe");
class TranscribeService {
    constructor(config = {}) {
        this.config = {
            region: config.region || process.env.AWS_REGION || 'us-east-1',
            languageCode: config.languageCode || client_transcribe_1.LanguageCode.EN_US,
            mediaFormat: config.mediaFormat || client_transcribe_1.MediaFormat.WAV,
            mediaSampleRateHertz: config.mediaSampleRateHertz || 8000 // Telephony standard
        };
        this.transcribeClient = new client_transcribe_1.TranscribeClient({
            region: this.config.region
        });
    }
    /**
     * Start transcription job for audio file in S3
     */
    async startTranscriptionJob(s3Uri, sessionId) {
        const jobName = this.generateJobName(sessionId);
        const command = new client_transcribe_1.StartTranscriptionJobCommand({
            TranscriptionJobName: jobName,
            LanguageCode: this.config.languageCode,
            MediaFormat: this.config.mediaFormat,
            Media: {
                MediaFileUri: s3Uri
            },
            MediaSampleRateHertz: this.config.mediaSampleRateHertz,
            Settings: {
                // Optimize for telephony audio
                ShowSpeakerLabels: false,
                MaxSpeakerLabels: 1,
                ChannelIdentification: false,
                ShowAlternatives: true,
                MaxAlternatives: 3
            }
        });
        try {
            const response = await this.transcribeClient.send(command);
            console.log(`Started transcription job: ${jobName}`);
            return jobName;
        }
        catch (error) {
            console.error('Error starting transcription job:', error);
            throw new Error(`Failed to start transcription job: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
     * Get transcription job status and results
     */
    async getTranscriptionJob(jobName) {
        const command = new client_transcribe_1.GetTranscriptionJobCommand({
            TranscriptionJobName: jobName
        });
        try {
            const response = await this.transcribeClient.send(command);
            return response.TranscriptionJob || null;
        }
        catch (error) {
            console.error('Error getting transcription job:', error);
            return null;
        }
    }
    /**
     * Poll transcription job until completion
     */
    async pollTranscriptionJob(jobName, maxAttempts = 30, intervalMs = 2000) {
        let attempts = 0;
        while (attempts < maxAttempts) {
            const job = await this.getTranscriptionJob(jobName);
            if (!job) {
                throw new Error(`Transcription job not found: ${jobName}`);
            }
            console.log(`Transcription job ${jobName} status: ${job.TranscriptionJobStatus}`);
            if (job.TranscriptionJobStatus === 'COMPLETED') {
                return await this.extractTranscriptionResult(job);
            }
            else if (job.TranscriptionJobStatus === 'FAILED') {
                throw new Error(`Transcription job failed: ${job.FailureReason || 'Unknown error'}`);
            }
            // Wait before next poll
            await new Promise(resolve => setTimeout(resolve, intervalMs));
            attempts++;
        }
        throw new Error(`Transcription job timed out after ${maxAttempts} attempts`);
    }
    /**
     * Extract text and confidence from completed transcription job
     */
    async extractTranscriptionResult(job) {
        if (!job.Transcript?.TranscriptFileUri) {
            throw new Error('No transcript file URI found in completed job');
        }
        try {
            // Fetch the transcript JSON file
            const response = await fetch(job.Transcript.TranscriptFileUri);
            if (!response.ok) {
                throw new Error(`Failed to fetch transcript: ${response.status} ${response.statusText}`);
            }
            const transcriptData = await response.json();
            // Extract the best transcript and confidence
            const results = transcriptData.results;
            if (!results || !results.transcripts || results.transcripts.length === 0) {
                throw new Error('No transcripts found in result');
            }
            const bestTranscript = results.transcripts[0].transcript || '';
            // Calculate average confidence from items
            let totalConfidence = 0;
            let itemCount = 0;
            if (results.items) {
                for (const item of results.items) {
                    if (item.confidence) {
                        totalConfidence += parseFloat(item.confidence);
                        itemCount++;
                    }
                }
            }
            const averageConfidence = itemCount > 0 ? totalConfidence / itemCount : 0;
            return {
                text: bestTranscript.trim(),
                confidence: averageConfidence,
                jobName: job.TranscriptionJobName || '',
                status: job.TranscriptionJobStatus || 'COMPLETED'
            };
        }
        catch (error) {
            console.error('Error extracting transcription result:', error);
            throw new Error(`Failed to extract transcription result: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
     * Generate unique job name for transcription
     */
    generateJobName(sessionId) {
        const timestamp = Date.now();
        return `promptcall-${sessionId}-${timestamp}`;
    }
    /**
     * Check if confidence score meets minimum threshold
     */
    isConfidenceAcceptable(confidence, threshold = 0.7) {
        return confidence >= threshold;
    }
    /**
     * Process audio file and return transcription result
     */
    async transcribeAudio(s3Uri, sessionId) {
        console.log(`Starting transcription for session ${sessionId}, S3 URI: ${s3Uri}`);
        const jobName = await this.startTranscriptionJob(s3Uri, sessionId);
        const result = await this.pollTranscriptionJob(jobName);
        console.log(`Transcription completed for session ${sessionId}: "${result.text}" (confidence: ${result.confidence})`);
        return result;
    }
}
exports.TranscribeService = TranscribeService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHJhbnNjcmliZS1zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL3NlcnZpY2VzL3RyYW5zY3JpYmUtc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7O0dBRUc7OztBQUVILGtFQVFvQztBQWdCcEMsTUFBYSxpQkFBaUI7SUFJNUIsWUFBWSxTQUEyQixFQUFFO1FBQ3ZDLElBQUksQ0FBQyxNQUFNLEdBQUc7WUFDWixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsSUFBSSxXQUFXO1lBQzlELFlBQVksRUFBRSxNQUFNLENBQUMsWUFBWSxJQUFJLGdDQUFZLENBQUMsS0FBSztZQUN2RCxXQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVcsSUFBSSwrQkFBVyxDQUFDLEdBQUc7WUFDbEQsb0JBQW9CLEVBQUUsTUFBTSxDQUFDLG9CQUFvQixJQUFJLElBQUksQ0FBQyxxQkFBcUI7U0FDaEYsQ0FBQztRQUVGLElBQUksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLG9DQUFnQixDQUFDO1lBQzNDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU07U0FDM0IsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLHFCQUFxQixDQUFDLEtBQWEsRUFBRSxTQUFpQjtRQUMxRCxNQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBRWhELE1BQU0sT0FBTyxHQUFHLElBQUksZ0RBQTRCLENBQUM7WUFDL0Msb0JBQW9CLEVBQUUsT0FBTztZQUM3QixZQUFZLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZO1lBQ3RDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVc7WUFDcEMsS0FBSyxFQUFFO2dCQUNMLFlBQVksRUFBRSxLQUFLO2FBQ3BCO1lBQ0Qsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0I7WUFDdEQsUUFBUSxFQUFFO2dCQUNSLCtCQUErQjtnQkFDL0IsaUJBQWlCLEVBQUUsS0FBSztnQkFDeEIsZ0JBQWdCLEVBQUUsQ0FBQztnQkFDbkIscUJBQXFCLEVBQUUsS0FBSztnQkFDNUIsZ0JBQWdCLEVBQUUsSUFBSTtnQkFDdEIsZUFBZSxFQUFFLENBQUM7YUFDbkI7U0FDRixDQUFDLENBQUM7UUFFSCxJQUFJLENBQUM7WUFDSCxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDM0QsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUNyRCxPQUFPLE9BQU8sQ0FBQztRQUNqQixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsbUNBQW1DLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDMUQsTUFBTSxJQUFJLEtBQUssQ0FBQyxzQ0FBc0MsS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztRQUNwSCxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLG1CQUFtQixDQUFDLE9BQWU7UUFDdkMsTUFBTSxPQUFPLEdBQUcsSUFBSSw4Q0FBMEIsQ0FBQztZQUM3QyxvQkFBb0IsRUFBRSxPQUFPO1NBQzlCLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQztZQUNILE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUMzRCxPQUFPLFFBQVEsQ0FBQyxnQkFBZ0IsSUFBSSxJQUFJLENBQUM7UUFDM0MsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGtDQUFrQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3pELE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxPQUFlLEVBQUUsY0FBc0IsRUFBRSxFQUFFLGFBQXFCLElBQUk7UUFDN0YsSUFBSSxRQUFRLEdBQUcsQ0FBQyxDQUFDO1FBRWpCLE9BQU8sUUFBUSxHQUFHLFdBQVcsRUFBRSxDQUFDO1lBQzlCLE1BQU0sR0FBRyxHQUFHLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRXBELElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztnQkFDVCxNQUFNLElBQUksS0FBSyxDQUFDLGdDQUFnQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQzdELENBQUM7WUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLHFCQUFxQixPQUFPLFlBQVksR0FBRyxDQUFDLHNCQUFzQixFQUFFLENBQUMsQ0FBQztZQUVsRixJQUFJLEdBQUcsQ0FBQyxzQkFBc0IsS0FBSyxXQUFXLEVBQUUsQ0FBQztnQkFDL0MsT0FBTyxNQUFNLElBQUksQ0FBQywwQkFBMEIsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNwRCxDQUFDO2lCQUFNLElBQUksR0FBRyxDQUFDLHNCQUFzQixLQUFLLFFBQVEsRUFBRSxDQUFDO2dCQUNuRCxNQUFNLElBQUksS0FBSyxDQUFDLDZCQUE2QixHQUFHLENBQUMsYUFBYSxJQUFJLGVBQWUsRUFBRSxDQUFDLENBQUM7WUFDdkYsQ0FBQztZQUVELHdCQUF3QjtZQUN4QixNQUFNLElBQUksT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDO1lBQzlELFFBQVEsRUFBRSxDQUFDO1FBQ2IsQ0FBQztRQUVELE1BQU0sSUFBSSxLQUFLLENBQUMscUNBQXFDLFdBQVcsV0FBVyxDQUFDLENBQUM7SUFDL0UsQ0FBQztJQUVEOztPQUVHO0lBQ0ssS0FBSyxDQUFDLDBCQUEwQixDQUFDLEdBQXFCO1FBQzVELElBQUksQ0FBQyxHQUFHLENBQUMsVUFBVSxFQUFFLGlCQUFpQixFQUFFLENBQUM7WUFDdkMsTUFBTSxJQUFJLEtBQUssQ0FBQywrQ0FBK0MsQ0FBQyxDQUFDO1FBQ25FLENBQUM7UUFFRCxJQUFJLENBQUM7WUFDSCxpQ0FBaUM7WUFDakMsTUFBTSxRQUFRLEdBQUcsTUFBTSxLQUFLLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDO1lBQy9ELElBQUksQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLENBQUM7Z0JBQ2pCLE1BQU0sSUFBSSxLQUFLLENBQUMsK0JBQStCLFFBQVEsQ0FBQyxNQUFNLElBQUksUUFBUSxDQUFDLFVBQVUsRUFBRSxDQUFDLENBQUM7WUFDM0YsQ0FBQztZQUVELE1BQU0sY0FBYyxHQUFHLE1BQU0sUUFBUSxDQUFDLElBQUksRUFBUyxDQUFDO1lBRXBELDZDQUE2QztZQUM3QyxNQUFNLE9BQU8sR0FBRyxjQUFjLENBQUMsT0FBTyxDQUFDO1lBQ3ZDLElBQUksQ0FBQyxPQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxJQUFJLE9BQU8sQ0FBQyxXQUFXLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO2dCQUN6RSxNQUFNLElBQUksS0FBSyxDQUFDLGdDQUFnQyxDQUFDLENBQUM7WUFDcEQsQ0FBQztZQUVELE1BQU0sY0FBYyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxJQUFJLEVBQUUsQ0FBQztZQUUvRCwwQ0FBMEM7WUFDMUMsSUFBSSxlQUFlLEdBQUcsQ0FBQyxDQUFDO1lBQ3hCLElBQUksU0FBUyxHQUFHLENBQUMsQ0FBQztZQUVsQixJQUFJLE9BQU8sQ0FBQyxLQUFLLEVBQUUsQ0FBQztnQkFDbEIsS0FBSyxNQUFNLElBQUksSUFBSSxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUM7b0JBQ2pDLElBQUksSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDO3dCQUNwQixlQUFlLElBQUksVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQzt3QkFDL0MsU0FBUyxFQUFFLENBQUM7b0JBQ2QsQ0FBQztnQkFDSCxDQUFDO1lBQ0gsQ0FBQztZQUVELE1BQU0saUJBQWlCLEdBQUcsU0FBUyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsZUFBZSxHQUFHLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRTFFLE9BQU87Z0JBQ0wsSUFBSSxFQUFFLGNBQWMsQ0FBQyxJQUFJLEVBQUU7Z0JBQzNCLFVBQVUsRUFBRSxpQkFBaUI7Z0JBQzdCLE9BQU8sRUFBRSxHQUFHLENBQUMsb0JBQW9CLElBQUksRUFBRTtnQkFDdkMsTUFBTSxFQUFFLEdBQUcsQ0FBQyxzQkFBc0IsSUFBSSxXQUFXO2FBQ2xELENBQUM7UUFFSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsd0NBQXdDLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDL0QsTUFBTSxJQUFJLEtBQUssQ0FBQywyQ0FBMkMsS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztRQUN6SCxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ssZUFBZSxDQUFDLFNBQWlCO1FBQ3ZDLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQztRQUM3QixPQUFPLGNBQWMsU0FBUyxJQUFJLFNBQVMsRUFBRSxDQUFDO0lBQ2hELENBQUM7SUFFRDs7T0FFRztJQUNILHNCQUFzQixDQUFDLFVBQWtCLEVBQUUsWUFBb0IsR0FBRztRQUNoRSxPQUFPLFVBQVUsSUFBSSxTQUFTLENBQUM7SUFDakMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGVBQWUsQ0FBQyxLQUFhLEVBQUUsU0FBaUI7UUFDcEQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsU0FBUyxhQUFhLEtBQUssRUFBRSxDQUFDLENBQUM7UUFFakYsTUFBTSxPQUFPLEdBQUcsTUFBTSxJQUFJLENBQUMscUJBQXFCLENBQUMsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBQ25FLE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRXhELE9BQU8sQ0FBQyxHQUFHLENBQUMsdUNBQXVDLFNBQVMsTUFBTSxNQUFNLENBQUMsSUFBSSxrQkFBa0IsTUFBTSxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUM7UUFFckgsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQztDQUNGO0FBbExELDhDQWtMQyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQW1hem9uIFRyYW5zY3JpYmUgU2VydmljZSBmb3Igc3BlZWNoLXRvLXRleHQgY29udmVyc2lvblxuICovXG5cbmltcG9ydCB7IFxuICBUcmFuc2NyaWJlQ2xpZW50LCBcbiAgU3RhcnRUcmFuc2NyaXB0aW9uSm9iQ29tbWFuZCwgXG4gIEdldFRyYW5zY3JpcHRpb25Kb2JDb21tYW5kLFxuICBUcmFuc2NyaXB0aW9uSm9iLFxuICBUcmFuc2NyaXB0aW9uSm9iU3RhdHVzLFxuICBMYW5ndWFnZUNvZGUsXG4gIE1lZGlhRm9ybWF0XG59IGZyb20gJ0Bhd3Mtc2RrL2NsaWVudC10cmFuc2NyaWJlJztcblxuZXhwb3J0IGludGVyZmFjZSBUcmFuc2NyaWJlUmVzdWx0IHtcbiAgdGV4dDogc3RyaW5nO1xuICBjb25maWRlbmNlOiBudW1iZXI7XG4gIGpvYk5hbWU6IHN0cmluZztcbiAgc3RhdHVzOiBUcmFuc2NyaXB0aW9uSm9iU3RhdHVzO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFRyYW5zY3JpYmVDb25maWcge1xuICByZWdpb24/OiBzdHJpbmc7XG4gIGxhbmd1YWdlQ29kZT86IExhbmd1YWdlQ29kZTtcbiAgbWVkaWFGb3JtYXQ/OiBNZWRpYUZvcm1hdDtcbiAgbWVkaWFTYW1wbGVSYXRlSGVydHo/OiBudW1iZXI7XG59XG5cbmV4cG9ydCBjbGFzcyBUcmFuc2NyaWJlU2VydmljZSB7XG4gIHByaXZhdGUgdHJhbnNjcmliZUNsaWVudDogVHJhbnNjcmliZUNsaWVudDtcbiAgcHJpdmF0ZSBjb25maWc6IFJlcXVpcmVkPFRyYW5zY3JpYmVDb25maWc+O1xuXG4gIGNvbnN0cnVjdG9yKGNvbmZpZzogVHJhbnNjcmliZUNvbmZpZyA9IHt9KSB7XG4gICAgdGhpcy5jb25maWcgPSB7XG4gICAgICByZWdpb246IGNvbmZpZy5yZWdpb24gfHwgcHJvY2Vzcy5lbnYuQVdTX1JFR0lPTiB8fCAndXMtZWFzdC0xJyxcbiAgICAgIGxhbmd1YWdlQ29kZTogY29uZmlnLmxhbmd1YWdlQ29kZSB8fCBMYW5ndWFnZUNvZGUuRU5fVVMsXG4gICAgICBtZWRpYUZvcm1hdDogY29uZmlnLm1lZGlhRm9ybWF0IHx8IE1lZGlhRm9ybWF0LldBVixcbiAgICAgIG1lZGlhU2FtcGxlUmF0ZUhlcnR6OiBjb25maWcubWVkaWFTYW1wbGVSYXRlSGVydHogfHwgODAwMCAvLyBUZWxlcGhvbnkgc3RhbmRhcmRcbiAgICB9O1xuXG4gICAgdGhpcy50cmFuc2NyaWJlQ2xpZW50ID0gbmV3IFRyYW5zY3JpYmVDbGllbnQoe1xuICAgICAgcmVnaW9uOiB0aGlzLmNvbmZpZy5yZWdpb25cbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBTdGFydCB0cmFuc2NyaXB0aW9uIGpvYiBmb3IgYXVkaW8gZmlsZSBpbiBTM1xuICAgKi9cbiAgYXN5bmMgc3RhcnRUcmFuc2NyaXB0aW9uSm9iKHMzVXJpOiBzdHJpbmcsIHNlc3Npb25JZDogc3RyaW5nKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBqb2JOYW1lID0gdGhpcy5nZW5lcmF0ZUpvYk5hbWUoc2Vzc2lvbklkKTtcbiAgICBcbiAgICBjb25zdCBjb21tYW5kID0gbmV3IFN0YXJ0VHJhbnNjcmlwdGlvbkpvYkNvbW1hbmQoe1xuICAgICAgVHJhbnNjcmlwdGlvbkpvYk5hbWU6IGpvYk5hbWUsXG4gICAgICBMYW5ndWFnZUNvZGU6IHRoaXMuY29uZmlnLmxhbmd1YWdlQ29kZSxcbiAgICAgIE1lZGlhRm9ybWF0OiB0aGlzLmNvbmZpZy5tZWRpYUZvcm1hdCxcbiAgICAgIE1lZGlhOiB7XG4gICAgICAgIE1lZGlhRmlsZVVyaTogczNVcmlcbiAgICAgIH0sXG4gICAgICBNZWRpYVNhbXBsZVJhdGVIZXJ0ejogdGhpcy5jb25maWcubWVkaWFTYW1wbGVSYXRlSGVydHosXG4gICAgICBTZXR0aW5nczoge1xuICAgICAgICAvLyBPcHRpbWl6ZSBmb3IgdGVsZXBob255IGF1ZGlvXG4gICAgICAgIFNob3dTcGVha2VyTGFiZWxzOiBmYWxzZSxcbiAgICAgICAgTWF4U3BlYWtlckxhYmVsczogMSxcbiAgICAgICAgQ2hhbm5lbElkZW50aWZpY2F0aW9uOiBmYWxzZSxcbiAgICAgICAgU2hvd0FsdGVybmF0aXZlczogdHJ1ZSxcbiAgICAgICAgTWF4QWx0ZXJuYXRpdmVzOiAzXG4gICAgICB9XG4gICAgfSk7XG5cbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLnRyYW5zY3JpYmVDbGllbnQuc2VuZChjb21tYW5kKTtcbiAgICAgIGNvbnNvbGUubG9nKGBTdGFydGVkIHRyYW5zY3JpcHRpb24gam9iOiAke2pvYk5hbWV9YCk7XG4gICAgICByZXR1cm4gam9iTmFtZTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3Igc3RhcnRpbmcgdHJhbnNjcmlwdGlvbiBqb2I6JywgZXJyb3IpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gc3RhcnQgdHJhbnNjcmlwdGlvbiBqb2I6ICR7ZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvcid9YCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdldCB0cmFuc2NyaXB0aW9uIGpvYiBzdGF0dXMgYW5kIHJlc3VsdHNcbiAgICovXG4gIGFzeW5jIGdldFRyYW5zY3JpcHRpb25Kb2Ioam9iTmFtZTogc3RyaW5nKTogUHJvbWlzZTxUcmFuc2NyaXB0aW9uSm9iIHwgbnVsbD4ge1xuICAgIGNvbnN0IGNvbW1hbmQgPSBuZXcgR2V0VHJhbnNjcmlwdGlvbkpvYkNvbW1hbmQoe1xuICAgICAgVHJhbnNjcmlwdGlvbkpvYk5hbWU6IGpvYk5hbWVcbiAgICB9KTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMudHJhbnNjcmliZUNsaWVudC5zZW5kKGNvbW1hbmQpO1xuICAgICAgcmV0dXJuIHJlc3BvbnNlLlRyYW5zY3JpcHRpb25Kb2IgfHwgbnVsbDtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgZ2V0dGluZyB0cmFuc2NyaXB0aW9uIGpvYjonLCBlcnJvcik7XG4gICAgICByZXR1cm4gbnVsbDtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogUG9sbCB0cmFuc2NyaXB0aW9uIGpvYiB1bnRpbCBjb21wbGV0aW9uXG4gICAqL1xuICBhc3luYyBwb2xsVHJhbnNjcmlwdGlvbkpvYihqb2JOYW1lOiBzdHJpbmcsIG1heEF0dGVtcHRzOiBudW1iZXIgPSAzMCwgaW50ZXJ2YWxNczogbnVtYmVyID0gMjAwMCk6IFByb21pc2U8VHJhbnNjcmliZVJlc3VsdD4ge1xuICAgIGxldCBhdHRlbXB0cyA9IDA7XG4gICAgXG4gICAgd2hpbGUgKGF0dGVtcHRzIDwgbWF4QXR0ZW1wdHMpIHtcbiAgICAgIGNvbnN0IGpvYiA9IGF3YWl0IHRoaXMuZ2V0VHJhbnNjcmlwdGlvbkpvYihqb2JOYW1lKTtcbiAgICAgIFxuICAgICAgaWYgKCFqb2IpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBUcmFuc2NyaXB0aW9uIGpvYiBub3QgZm91bmQ6ICR7am9iTmFtZX1gKTtcbiAgICAgIH1cblxuICAgICAgY29uc29sZS5sb2coYFRyYW5zY3JpcHRpb24gam9iICR7am9iTmFtZX0gc3RhdHVzOiAke2pvYi5UcmFuc2NyaXB0aW9uSm9iU3RhdHVzfWApO1xuXG4gICAgICBpZiAoam9iLlRyYW5zY3JpcHRpb25Kb2JTdGF0dXMgPT09ICdDT01QTEVURUQnKSB7XG4gICAgICAgIHJldHVybiBhd2FpdCB0aGlzLmV4dHJhY3RUcmFuc2NyaXB0aW9uUmVzdWx0KGpvYik7XG4gICAgICB9IGVsc2UgaWYgKGpvYi5UcmFuc2NyaXB0aW9uSm9iU3RhdHVzID09PSAnRkFJTEVEJykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYFRyYW5zY3JpcHRpb24gam9iIGZhaWxlZDogJHtqb2IuRmFpbHVyZVJlYXNvbiB8fCAnVW5rbm93biBlcnJvcid9YCk7XG4gICAgICB9XG5cbiAgICAgIC8vIFdhaXQgYmVmb3JlIG5leHQgcG9sbFxuICAgICAgYXdhaXQgbmV3IFByb21pc2UocmVzb2x2ZSA9PiBzZXRUaW1lb3V0KHJlc29sdmUsIGludGVydmFsTXMpKTtcbiAgICAgIGF0dGVtcHRzKys7XG4gICAgfVxuXG4gICAgdGhyb3cgbmV3IEVycm9yKGBUcmFuc2NyaXB0aW9uIGpvYiB0aW1lZCBvdXQgYWZ0ZXIgJHttYXhBdHRlbXB0c30gYXR0ZW1wdHNgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBFeHRyYWN0IHRleHQgYW5kIGNvbmZpZGVuY2UgZnJvbSBjb21wbGV0ZWQgdHJhbnNjcmlwdGlvbiBqb2JcbiAgICovXG4gIHByaXZhdGUgYXN5bmMgZXh0cmFjdFRyYW5zY3JpcHRpb25SZXN1bHQoam9iOiBUcmFuc2NyaXB0aW9uSm9iKTogUHJvbWlzZTxUcmFuc2NyaWJlUmVzdWx0PiB7XG4gICAgaWYgKCFqb2IuVHJhbnNjcmlwdD8uVHJhbnNjcmlwdEZpbGVVcmkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcignTm8gdHJhbnNjcmlwdCBmaWxlIFVSSSBmb3VuZCBpbiBjb21wbGV0ZWQgam9iJyk7XG4gICAgfVxuXG4gICAgdHJ5IHtcbiAgICAgIC8vIEZldGNoIHRoZSB0cmFuc2NyaXB0IEpTT04gZmlsZVxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCBmZXRjaChqb2IuVHJhbnNjcmlwdC5UcmFuc2NyaXB0RmlsZVVyaSk7XG4gICAgICBpZiAoIXJlc3BvbnNlLm9rKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGZldGNoIHRyYW5zY3JpcHQ6ICR7cmVzcG9uc2Uuc3RhdHVzfSAke3Jlc3BvbnNlLnN0YXR1c1RleHR9YCk7XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHRyYW5zY3JpcHREYXRhID0gYXdhaXQgcmVzcG9uc2UuanNvbigpIGFzIGFueTtcbiAgICAgIFxuICAgICAgLy8gRXh0cmFjdCB0aGUgYmVzdCB0cmFuc2NyaXB0IGFuZCBjb25maWRlbmNlXG4gICAgICBjb25zdCByZXN1bHRzID0gdHJhbnNjcmlwdERhdGEucmVzdWx0cztcbiAgICAgIGlmICghcmVzdWx0cyB8fCAhcmVzdWx0cy50cmFuc2NyaXB0cyB8fCByZXN1bHRzLnRyYW5zY3JpcHRzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIHRyYW5zY3JpcHRzIGZvdW5kIGluIHJlc3VsdCcpO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBiZXN0VHJhbnNjcmlwdCA9IHJlc3VsdHMudHJhbnNjcmlwdHNbMF0udHJhbnNjcmlwdCB8fCAnJztcbiAgICAgIFxuICAgICAgLy8gQ2FsY3VsYXRlIGF2ZXJhZ2UgY29uZmlkZW5jZSBmcm9tIGl0ZW1zXG4gICAgICBsZXQgdG90YWxDb25maWRlbmNlID0gMDtcbiAgICAgIGxldCBpdGVtQ291bnQgPSAwO1xuICAgICAgXG4gICAgICBpZiAocmVzdWx0cy5pdGVtcykge1xuICAgICAgICBmb3IgKGNvbnN0IGl0ZW0gb2YgcmVzdWx0cy5pdGVtcykge1xuICAgICAgICAgIGlmIChpdGVtLmNvbmZpZGVuY2UpIHtcbiAgICAgICAgICAgIHRvdGFsQ29uZmlkZW5jZSArPSBwYXJzZUZsb2F0KGl0ZW0uY29uZmlkZW5jZSk7XG4gICAgICAgICAgICBpdGVtQ291bnQrKztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cblxuICAgICAgY29uc3QgYXZlcmFnZUNvbmZpZGVuY2UgPSBpdGVtQ291bnQgPiAwID8gdG90YWxDb25maWRlbmNlIC8gaXRlbUNvdW50IDogMDtcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdGV4dDogYmVzdFRyYW5zY3JpcHQudHJpbSgpLFxuICAgICAgICBjb25maWRlbmNlOiBhdmVyYWdlQ29uZmlkZW5jZSxcbiAgICAgICAgam9iTmFtZTogam9iLlRyYW5zY3JpcHRpb25Kb2JOYW1lIHx8ICcnLFxuICAgICAgICBzdGF0dXM6IGpvYi5UcmFuc2NyaXB0aW9uSm9iU3RhdHVzIHx8ICdDT01QTEVURUQnXG4gICAgICB9O1xuXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGV4dHJhY3RpbmcgdHJhbnNjcmlwdGlvbiByZXN1bHQ6JywgZXJyb3IpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gZXh0cmFjdCB0cmFuc2NyaXB0aW9uIHJlc3VsdDogJHtlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICdVbmtub3duIGVycm9yJ31gKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogR2VuZXJhdGUgdW5pcXVlIGpvYiBuYW1lIGZvciB0cmFuc2NyaXB0aW9uXG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlSm9iTmFtZShzZXNzaW9uSWQ6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgY29uc3QgdGltZXN0YW1wID0gRGF0ZS5ub3coKTtcbiAgICByZXR1cm4gYHByb21wdGNhbGwtJHtzZXNzaW9uSWR9LSR7dGltZXN0YW1wfWA7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2sgaWYgY29uZmlkZW5jZSBzY29yZSBtZWV0cyBtaW5pbXVtIHRocmVzaG9sZFxuICAgKi9cbiAgaXNDb25maWRlbmNlQWNjZXB0YWJsZShjb25maWRlbmNlOiBudW1iZXIsIHRocmVzaG9sZDogbnVtYmVyID0gMC43KTogYm9vbGVhbiB7XG4gICAgcmV0dXJuIGNvbmZpZGVuY2UgPj0gdGhyZXNob2xkO1xuICB9XG5cbiAgLyoqXG4gICAqIFByb2Nlc3MgYXVkaW8gZmlsZSBhbmQgcmV0dXJuIHRyYW5zY3JpcHRpb24gcmVzdWx0XG4gICAqL1xuICBhc3luYyB0cmFuc2NyaWJlQXVkaW8oczNVcmk6IHN0cmluZywgc2Vzc2lvbklkOiBzdHJpbmcpOiBQcm9taXNlPFRyYW5zY3JpYmVSZXN1bHQ+IHtcbiAgICBjb25zb2xlLmxvZyhgU3RhcnRpbmcgdHJhbnNjcmlwdGlvbiBmb3Igc2Vzc2lvbiAke3Nlc3Npb25JZH0sIFMzIFVSSTogJHtzM1VyaX1gKTtcbiAgICBcbiAgICBjb25zdCBqb2JOYW1lID0gYXdhaXQgdGhpcy5zdGFydFRyYW5zY3JpcHRpb25Kb2IoczNVcmksIHNlc3Npb25JZCk7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy5wb2xsVHJhbnNjcmlwdGlvbkpvYihqb2JOYW1lKTtcbiAgICBcbiAgICBjb25zb2xlLmxvZyhgVHJhbnNjcmlwdGlvbiBjb21wbGV0ZWQgZm9yIHNlc3Npb24gJHtzZXNzaW9uSWR9OiBcIiR7cmVzdWx0LnRleHR9XCIgKGNvbmZpZGVuY2U6ICR7cmVzdWx0LmNvbmZpZGVuY2V9KWApO1xuICAgIFxuICAgIHJldHVybiByZXN1bHQ7XG4gIH1cbn0iXX0=