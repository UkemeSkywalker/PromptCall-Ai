"use strict";
/**
 * Transcription Processor for handling speech-to-text conversion and validation
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TranscriptionProcessor = void 0;
const transcribe_service_1 = require("./transcribe-service");
const client_transcribe_1 = require("@aws-sdk/client-transcribe");
class TranscriptionProcessor {
    constructor(s3Service, config = {}) {
        this.s3Service = s3Service;
        this.config = {
            region: config.region || process.env.AWS_REGION || 'us-east-1',
            languageCode: config.languageCode || client_transcribe_1.LanguageCode.EN_US,
            mediaFormat: config.mediaFormat || client_transcribe_1.MediaFormat.WAV,
            mediaSampleRateHertz: config.mediaSampleRateHertz || 8000,
            confidenceThreshold: config.confidenceThreshold || 0.7,
            maxRetries: config.maxRetries || 2
        };
        this.transcribeService = new transcribe_service_1.TranscribeService({
            region: this.config.region,
            languageCode: this.config.languageCode,
            mediaFormat: this.config.mediaFormat,
            mediaSampleRateHertz: this.config.mediaSampleRateHertz
        });
    }
    /**
     * Process audio from Twilio recording URL
     */
    async processAudioFromUrl(recordingUrl, sessionId, callSid) {
        try {
            console.log(`Processing audio from URL for session ${sessionId}: ${recordingUrl}`);
            // Upload audio to S3
            const s3Result = await this.s3Service.uploadAudioFromUrl(recordingUrl, sessionId, callSid);
            console.log(`Audio uploaded to S3: ${s3Result.key}`);
            // Start transcription
            const s3Uri = this.s3Service.getS3Uri(s3Result.key);
            const transcribeResult = await this.transcribeService.transcribeAudio(s3Uri, sessionId);
            // Validate confidence and retry if needed
            return await this.validateAndRetryIfNeeded(transcribeResult, s3Uri, sessionId);
        }
        catch (error) {
            console.error('Error processing audio from URL:', error);
            throw new Error(`Failed to process audio: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
     * Validate transcription confidence and retry if needed
     */
    async validateAndRetryIfNeeded(result, s3Uri, sessionId, retryCount = 0) {
        const transcriptionResult = {
            text: result.text,
            confidence: result.confidence,
            jobName: result.jobName,
            status: result.status,
            isRetry: retryCount > 0,
            originalConfidence: retryCount > 0 ? result.confidence : undefined
        };
        // Check if confidence meets threshold
        if (this.transcribeService.isConfidenceAcceptable(result.confidence, this.config.confidenceThreshold)) {
            console.log(`Transcription confidence acceptable: ${result.confidence}`);
            return transcriptionResult;
        }
        // Retry if we haven't exceeded max retries
        if (retryCount < this.config.maxRetries) {
            console.log(`Low confidence (${result.confidence}), retrying transcription (attempt ${retryCount + 1}/${this.config.maxRetries})`);
            try {
                const retryResult = await this.transcribeService.transcribeAudio(s3Uri, sessionId);
                return await this.validateAndRetryIfNeeded(retryResult, s3Uri, sessionId, retryCount + 1);
            }
            catch (error) {
                console.error('Retry transcription failed:', error);
                // Return original result if retry fails
                return transcriptionResult;
            }
        }
        // Return result with low confidence warning
        console.warn(`Transcription confidence below threshold: ${result.confidence} < ${this.config.confidenceThreshold}`);
        return transcriptionResult;
    }
    /**
     * Check if transcription result is acceptable
     */
    isTranscriptionAcceptable(result) {
        return result.status === 'COMPLETED' &&
            result.confidence >= this.config.confidenceThreshold &&
            result.text.trim().length > 0;
    }
    /**
     * Get user-friendly message for transcription issues
     */
    getTranscriptionIssueMessage(result) {
        if (result.status === 'FAILED') {
            return "I'm sorry, I couldn't process your audio. Please try speaking again.";
        }
        if (result.confidence < this.config.confidenceThreshold) {
            return "I didn't catch that clearly. Could you please repeat your question more clearly?";
        }
        if (result.text.trim().length === 0) {
            return "I didn't hear anything. Please speak your question.";
        }
        return "There was an issue processing your speech. Please try again.";
    }
    /**
     * Validate audio quality for transcription
     */
    validateAudioQuality(audioInfo) {
        const issues = [];
        if (!audioInfo.url) {
            issues.push('No audio URL provided');
        }
        if (audioInfo.duration !== undefined && audioInfo.duration < 0.5) {
            issues.push('Audio too short for transcription (minimum 0.5 seconds)');
        }
        if (audioInfo.duration !== undefined && audioInfo.duration > 300) {
            issues.push('Audio too long for transcription (maximum 5 minutes)');
        }
        return {
            isValid: issues.length === 0,
            issues
        };
    }
    /**
     * Process transcription with full pipeline from S3 URI
     */
    async processTranscription(audioS3Uri, sessionId) {
        try {
            const transcribeResult = await this.transcribeService.transcribeAudio(audioS3Uri, sessionId);
            return await this.validateAndRetryIfNeeded(transcribeResult, audioS3Uri, sessionId);
        }
        catch (error) {
            console.error('Error in transcription pipeline:', error);
            throw new Error(`Transcription pipeline failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
     * Get confidence threshold
     */
    getConfidenceThreshold() {
        return this.config.confidenceThreshold;
    }
    /**
     * Format transcription result for logging
     */
    formatResultForLogging(result) {
        return `Text: "${result.text}" | Confidence: ${result.confidence.toFixed(3)} | Status: ${result.status}${result.isRetry ? ' (retry)' : ''}`;
    }
}
exports.TranscriptionProcessor = TranscriptionProcessor;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidHJhbnNjcmlwdGlvbi1wcm9jZXNzb3IuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvc2VydmljZXMvdHJhbnNjcmlwdGlvbi1wcm9jZXNzb3IudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOztHQUVHOzs7QUFFSCw2REFBMkU7QUFZM0Usa0VBQXVFO0FBV3ZFLE1BQWEsc0JBQXNCO0lBS2pDLFlBQVksU0FBb0IsRUFBRSxTQUE4QixFQUFFO1FBQ2hFLElBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFDO1FBQzNCLElBQUksQ0FBQyxNQUFNLEdBQUc7WUFDWixNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sSUFBSSxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsSUFBSSxXQUFXO1lBQzlELFlBQVksRUFBRSxNQUFNLENBQUMsWUFBWSxJQUFJLGdDQUFZLENBQUMsS0FBSztZQUN2RCxXQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVcsSUFBSSwrQkFBVyxDQUFDLEdBQUc7WUFDbEQsb0JBQW9CLEVBQUUsTUFBTSxDQUFDLG9CQUFvQixJQUFJLElBQUk7WUFDekQsbUJBQW1CLEVBQUUsTUFBTSxDQUFDLG1CQUFtQixJQUFJLEdBQUc7WUFDdEQsVUFBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVLElBQUksQ0FBQztTQUNuQyxDQUFDO1FBRUYsSUFBSSxDQUFDLGlCQUFpQixHQUFHLElBQUksc0NBQWlCLENBQUM7WUFDN0MsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTTtZQUMxQixZQUFZLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxZQUFZO1lBQ3RDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVc7WUFDcEMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0I7U0FDdkQsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLG1CQUFtQixDQUFDLFlBQW9CLEVBQUUsU0FBaUIsRUFBRSxPQUFnQjtRQUNqRixJQUFJLENBQUM7WUFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLHlDQUF5QyxTQUFTLEtBQUssWUFBWSxFQUFFLENBQUMsQ0FBQztZQUVuRixxQkFBcUI7WUFDckIsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLGtCQUFrQixDQUFDLFlBQVksRUFBRSxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7WUFDM0YsT0FBTyxDQUFDLEdBQUcsQ0FBQyx5QkFBeUIsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUM7WUFFckQsc0JBQXNCO1lBQ3RCLE1BQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQztZQUNwRCxNQUFNLGdCQUFnQixHQUFHLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxLQUFLLEVBQUUsU0FBUyxDQUFDLENBQUM7WUFFeEYsMENBQTBDO1lBQzFDLE9BQU8sTUFBTSxJQUFJLENBQUMsd0JBQXdCLENBQUMsZ0JBQWdCLEVBQUUsS0FBSyxFQUFFLFNBQVMsQ0FBQyxDQUFDO1FBRWpGLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxrQ0FBa0MsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN6RCxNQUFNLElBQUksS0FBSyxDQUFDLDRCQUE0QixLQUFLLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFDO1FBQzFHLENBQUM7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxLQUFLLENBQUMsd0JBQXdCLENBQ3BDLE1BQXdCLEVBQ3hCLEtBQWEsRUFDYixTQUFpQixFQUNqQixhQUFxQixDQUFDO1FBRXRCLE1BQU0sbUJBQW1CLEdBQXdCO1lBQy9DLElBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtZQUNqQixVQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7WUFDN0IsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO1lBQ3ZCLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBZ0Q7WUFDL0QsT0FBTyxFQUFFLFVBQVUsR0FBRyxDQUFDO1lBQ3ZCLGtCQUFrQixFQUFFLFVBQVUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDLFNBQVM7U0FDbkUsQ0FBQztRQUVGLHNDQUFzQztRQUN0QyxJQUFJLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxzQkFBc0IsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsbUJBQW1CLENBQUMsRUFBRSxDQUFDO1lBQ3RHLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0NBQXdDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDO1lBQ3pFLE9BQU8sbUJBQW1CLENBQUM7UUFDN0IsQ0FBQztRQUVELDJDQUEyQztRQUMzQyxJQUFJLFVBQVUsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxDQUFDO1lBQ3hDLE9BQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLE1BQU0sQ0FBQyxVQUFVLHNDQUFzQyxVQUFVLEdBQUcsQ0FBQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQztZQUVuSSxJQUFJLENBQUM7Z0JBQ0gsTUFBTSxXQUFXLEdBQUcsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxTQUFTLENBQUMsQ0FBQztnQkFDbkYsT0FBTyxNQUFNLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxXQUFXLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxVQUFVLEdBQUcsQ0FBQyxDQUFDLENBQUM7WUFDNUYsQ0FBQztZQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7Z0JBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyw2QkFBNkIsRUFBRSxLQUFLLENBQUMsQ0FBQztnQkFDcEQsd0NBQXdDO2dCQUN4QyxPQUFPLG1CQUFtQixDQUFDO1lBQzdCLENBQUM7UUFDSCxDQUFDO1FBRUQsNENBQTRDO1FBQzVDLE9BQU8sQ0FBQyxJQUFJLENBQUMsNkNBQTZDLE1BQU0sQ0FBQyxVQUFVLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsRUFBRSxDQUFDLENBQUM7UUFDcEgsT0FBTyxtQkFBbUIsQ0FBQztJQUM3QixDQUFDO0lBRUQ7O09BRUc7SUFDSCx5QkFBeUIsQ0FBQyxNQUEyQjtRQUNuRCxPQUFPLE1BQU0sQ0FBQyxNQUFNLEtBQUssV0FBVztZQUM3QixNQUFNLENBQUMsVUFBVSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsbUJBQW1CO1lBQ3BELE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztJQUN2QyxDQUFDO0lBRUQ7O09BRUc7SUFDSCw0QkFBNEIsQ0FBQyxNQUEyQjtRQUN0RCxJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssUUFBUSxFQUFFLENBQUM7WUFDL0IsT0FBTyxzRUFBc0UsQ0FBQztRQUNoRixDQUFDO1FBRUQsSUFBSSxNQUFNLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztZQUN4RCxPQUFPLGtGQUFrRixDQUFDO1FBQzVGLENBQUM7UUFFRCxJQUFJLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQ3BDLE9BQU8scURBQXFELENBQUM7UUFDL0QsQ0FBQztRQUVELE9BQU8sOERBQThELENBQUM7SUFDeEUsQ0FBQztJQUVEOztPQUVHO0lBQ0gsb0JBQW9CLENBQUMsU0FBNkM7UUFDaEUsTUFBTSxNQUFNLEdBQWEsRUFBRSxDQUFDO1FBRTVCLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDbkIsTUFBTSxDQUFDLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDO1FBQ3ZDLENBQUM7UUFFRCxJQUFJLFNBQVMsQ0FBQyxRQUFRLEtBQUssU0FBUyxJQUFJLFNBQVMsQ0FBQyxRQUFRLEdBQUcsR0FBRyxFQUFFLENBQUM7WUFDakUsTUFBTSxDQUFDLElBQUksQ0FBQyx5REFBeUQsQ0FBQyxDQUFDO1FBQ3pFLENBQUM7UUFFRCxJQUFJLFNBQVMsQ0FBQyxRQUFRLEtBQUssU0FBUyxJQUFJLFNBQVMsQ0FBQyxRQUFRLEdBQUcsR0FBRyxFQUFFLENBQUM7WUFDakUsTUFBTSxDQUFDLElBQUksQ0FBQyxzREFBc0QsQ0FBQyxDQUFDO1FBQ3RFLENBQUM7UUFFRCxPQUFPO1lBQ0wsT0FBTyxFQUFFLE1BQU0sQ0FBQyxNQUFNLEtBQUssQ0FBQztZQUM1QixNQUFNO1NBQ1AsQ0FBQztJQUNKLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxVQUFrQixFQUFFLFNBQWlCO1FBQzlELElBQUksQ0FBQztZQUNILE1BQU0sZ0JBQWdCLEdBQUcsTUFBTSxJQUFJLENBQUMsaUJBQWlCLENBQUMsZUFBZSxDQUFDLFVBQVUsRUFBRSxTQUFTLENBQUMsQ0FBQztZQUM3RixPQUFPLE1BQU0sSUFBSSxDQUFDLHdCQUF3QixDQUFDLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN0RixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsa0NBQWtDLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDekQsTUFBTSxJQUFJLEtBQUssQ0FBQyxrQ0FBa0MsS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztRQUNoSCxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsc0JBQXNCO1FBQ3BCLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQztJQUN6QyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxzQkFBc0IsQ0FBQyxNQUEyQjtRQUNoRCxPQUFPLFVBQVUsTUFBTSxDQUFDLElBQUksbUJBQW1CLE1BQU0sQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxjQUFjLE1BQU0sQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztJQUM5SSxDQUFDO0NBQ0Y7QUF6S0Qsd0RBeUtDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBUcmFuc2NyaXB0aW9uIFByb2Nlc3NvciBmb3IgaGFuZGxpbmcgc3BlZWNoLXRvLXRleHQgY29udmVyc2lvbiBhbmQgdmFsaWRhdGlvblxuICovXG5cbmltcG9ydCB7IFRyYW5zY3JpYmVTZXJ2aWNlLCBUcmFuc2NyaWJlUmVzdWx0IH0gZnJvbSAnLi90cmFuc2NyaWJlLXNlcnZpY2UnO1xuaW1wb3J0IHsgUzNTZXJ2aWNlIH0gZnJvbSAnLi9zMy1zZXJ2aWNlJztcblxuZXhwb3J0IGludGVyZmFjZSBUcmFuc2NyaXB0aW9uUmVzdWx0IHtcbiAgdGV4dDogc3RyaW5nO1xuICBjb25maWRlbmNlOiBudW1iZXI7XG4gIGpvYk5hbWU6IHN0cmluZztcbiAgc3RhdHVzOiAnQ09NUExFVEVEJyB8ICdGQUlMRUQnIHwgJ0lOX1BST0dSRVNTJztcbiAgaXNSZXRyeT86IGJvb2xlYW47XG4gIG9yaWdpbmFsQ29uZmlkZW5jZT86IG51bWJlcjtcbn1cblxuaW1wb3J0IHsgTGFuZ3VhZ2VDb2RlLCBNZWRpYUZvcm1hdCB9IGZyb20gJ0Bhd3Mtc2RrL2NsaWVudC10cmFuc2NyaWJlJztcblxuZXhwb3J0IGludGVyZmFjZSBUcmFuc2NyaXB0aW9uQ29uZmlnIHtcbiAgcmVnaW9uPzogc3RyaW5nO1xuICBsYW5ndWFnZUNvZGU/OiBMYW5ndWFnZUNvZGU7XG4gIG1lZGlhRm9ybWF0PzogTWVkaWFGb3JtYXQ7XG4gIG1lZGlhU2FtcGxlUmF0ZUhlcnR6PzogbnVtYmVyO1xuICBjb25maWRlbmNlVGhyZXNob2xkPzogbnVtYmVyO1xuICBtYXhSZXRyaWVzPzogbnVtYmVyO1xufVxuXG5leHBvcnQgY2xhc3MgVHJhbnNjcmlwdGlvblByb2Nlc3NvciB7XG4gIHByaXZhdGUgdHJhbnNjcmliZVNlcnZpY2U6IFRyYW5zY3JpYmVTZXJ2aWNlO1xuICBwcml2YXRlIHMzU2VydmljZTogUzNTZXJ2aWNlO1xuICBwcml2YXRlIGNvbmZpZzogUmVxdWlyZWQ8VHJhbnNjcmlwdGlvbkNvbmZpZz47XG5cbiAgY29uc3RydWN0b3IoczNTZXJ2aWNlOiBTM1NlcnZpY2UsIGNvbmZpZzogVHJhbnNjcmlwdGlvbkNvbmZpZyA9IHt9KSB7XG4gICAgdGhpcy5zM1NlcnZpY2UgPSBzM1NlcnZpY2U7XG4gICAgdGhpcy5jb25maWcgPSB7XG4gICAgICByZWdpb246IGNvbmZpZy5yZWdpb24gfHwgcHJvY2Vzcy5lbnYuQVdTX1JFR0lPTiB8fCAndXMtZWFzdC0xJyxcbiAgICAgIGxhbmd1YWdlQ29kZTogY29uZmlnLmxhbmd1YWdlQ29kZSB8fCBMYW5ndWFnZUNvZGUuRU5fVVMsXG4gICAgICBtZWRpYUZvcm1hdDogY29uZmlnLm1lZGlhRm9ybWF0IHx8IE1lZGlhRm9ybWF0LldBVixcbiAgICAgIG1lZGlhU2FtcGxlUmF0ZUhlcnR6OiBjb25maWcubWVkaWFTYW1wbGVSYXRlSGVydHogfHwgODAwMCxcbiAgICAgIGNvbmZpZGVuY2VUaHJlc2hvbGQ6IGNvbmZpZy5jb25maWRlbmNlVGhyZXNob2xkIHx8IDAuNyxcbiAgICAgIG1heFJldHJpZXM6IGNvbmZpZy5tYXhSZXRyaWVzIHx8IDJcbiAgICB9O1xuXG4gICAgdGhpcy50cmFuc2NyaWJlU2VydmljZSA9IG5ldyBUcmFuc2NyaWJlU2VydmljZSh7XG4gICAgICByZWdpb246IHRoaXMuY29uZmlnLnJlZ2lvbixcbiAgICAgIGxhbmd1YWdlQ29kZTogdGhpcy5jb25maWcubGFuZ3VhZ2VDb2RlLFxuICAgICAgbWVkaWFGb3JtYXQ6IHRoaXMuY29uZmlnLm1lZGlhRm9ybWF0LFxuICAgICAgbWVkaWFTYW1wbGVSYXRlSGVydHo6IHRoaXMuY29uZmlnLm1lZGlhU2FtcGxlUmF0ZUhlcnR6XG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogUHJvY2VzcyBhdWRpbyBmcm9tIFR3aWxpbyByZWNvcmRpbmcgVVJMXG4gICAqL1xuICBhc3luYyBwcm9jZXNzQXVkaW9Gcm9tVXJsKHJlY29yZGluZ1VybDogc3RyaW5nLCBzZXNzaW9uSWQ6IHN0cmluZywgY2FsbFNpZD86IHN0cmluZyk6IFByb21pc2U8VHJhbnNjcmlwdGlvblJlc3VsdD4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zb2xlLmxvZyhgUHJvY2Vzc2luZyBhdWRpbyBmcm9tIFVSTCBmb3Igc2Vzc2lvbiAke3Nlc3Npb25JZH06ICR7cmVjb3JkaW5nVXJsfWApO1xuICAgICAgXG4gICAgICAvLyBVcGxvYWQgYXVkaW8gdG8gUzNcbiAgICAgIGNvbnN0IHMzUmVzdWx0ID0gYXdhaXQgdGhpcy5zM1NlcnZpY2UudXBsb2FkQXVkaW9Gcm9tVXJsKHJlY29yZGluZ1VybCwgc2Vzc2lvbklkLCBjYWxsU2lkKTtcbiAgICAgIGNvbnNvbGUubG9nKGBBdWRpbyB1cGxvYWRlZCB0byBTMzogJHtzM1Jlc3VsdC5rZXl9YCk7XG4gICAgICBcbiAgICAgIC8vIFN0YXJ0IHRyYW5zY3JpcHRpb25cbiAgICAgIGNvbnN0IHMzVXJpID0gdGhpcy5zM1NlcnZpY2UuZ2V0UzNVcmkoczNSZXN1bHQua2V5KTtcbiAgICAgIGNvbnN0IHRyYW5zY3JpYmVSZXN1bHQgPSBhd2FpdCB0aGlzLnRyYW5zY3JpYmVTZXJ2aWNlLnRyYW5zY3JpYmVBdWRpbyhzM1VyaSwgc2Vzc2lvbklkKTtcbiAgICAgIFxuICAgICAgLy8gVmFsaWRhdGUgY29uZmlkZW5jZSBhbmQgcmV0cnkgaWYgbmVlZGVkXG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy52YWxpZGF0ZUFuZFJldHJ5SWZOZWVkZWQodHJhbnNjcmliZVJlc3VsdCwgczNVcmksIHNlc3Npb25JZCk7XG4gICAgICBcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgcHJvY2Vzc2luZyBhdWRpbyBmcm9tIFVSTDonLCBlcnJvcik7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBwcm9jZXNzIGF1ZGlvOiAke2Vycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJ1Vua25vd24gZXJyb3InfWApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZSB0cmFuc2NyaXB0aW9uIGNvbmZpZGVuY2UgYW5kIHJldHJ5IGlmIG5lZWRlZFxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyB2YWxpZGF0ZUFuZFJldHJ5SWZOZWVkZWQoXG4gICAgcmVzdWx0OiBUcmFuc2NyaWJlUmVzdWx0LCBcbiAgICBzM1VyaTogc3RyaW5nLCBcbiAgICBzZXNzaW9uSWQ6IHN0cmluZyxcbiAgICByZXRyeUNvdW50OiBudW1iZXIgPSAwXG4gICk6IFByb21pc2U8VHJhbnNjcmlwdGlvblJlc3VsdD4ge1xuICAgIGNvbnN0IHRyYW5zY3JpcHRpb25SZXN1bHQ6IFRyYW5zY3JpcHRpb25SZXN1bHQgPSB7XG4gICAgICB0ZXh0OiByZXN1bHQudGV4dCxcbiAgICAgIGNvbmZpZGVuY2U6IHJlc3VsdC5jb25maWRlbmNlLFxuICAgICAgam9iTmFtZTogcmVzdWx0LmpvYk5hbWUsXG4gICAgICBzdGF0dXM6IHJlc3VsdC5zdGF0dXMgYXMgJ0NPTVBMRVRFRCcgfCAnRkFJTEVEJyB8ICdJTl9QUk9HUkVTUycsXG4gICAgICBpc1JldHJ5OiByZXRyeUNvdW50ID4gMCxcbiAgICAgIG9yaWdpbmFsQ29uZmlkZW5jZTogcmV0cnlDb3VudCA+IDAgPyByZXN1bHQuY29uZmlkZW5jZSA6IHVuZGVmaW5lZFxuICAgIH07XG5cbiAgICAvLyBDaGVjayBpZiBjb25maWRlbmNlIG1lZXRzIHRocmVzaG9sZFxuICAgIGlmICh0aGlzLnRyYW5zY3JpYmVTZXJ2aWNlLmlzQ29uZmlkZW5jZUFjY2VwdGFibGUocmVzdWx0LmNvbmZpZGVuY2UsIHRoaXMuY29uZmlnLmNvbmZpZGVuY2VUaHJlc2hvbGQpKSB7XG4gICAgICBjb25zb2xlLmxvZyhgVHJhbnNjcmlwdGlvbiBjb25maWRlbmNlIGFjY2VwdGFibGU6ICR7cmVzdWx0LmNvbmZpZGVuY2V9YCk7XG4gICAgICByZXR1cm4gdHJhbnNjcmlwdGlvblJlc3VsdDtcbiAgICB9XG5cbiAgICAvLyBSZXRyeSBpZiB3ZSBoYXZlbid0IGV4Y2VlZGVkIG1heCByZXRyaWVzXG4gICAgaWYgKHJldHJ5Q291bnQgPCB0aGlzLmNvbmZpZy5tYXhSZXRyaWVzKSB7XG4gICAgICBjb25zb2xlLmxvZyhgTG93IGNvbmZpZGVuY2UgKCR7cmVzdWx0LmNvbmZpZGVuY2V9KSwgcmV0cnlpbmcgdHJhbnNjcmlwdGlvbiAoYXR0ZW1wdCAke3JldHJ5Q291bnQgKyAxfS8ke3RoaXMuY29uZmlnLm1heFJldHJpZXN9KWApO1xuICAgICAgXG4gICAgICB0cnkge1xuICAgICAgICBjb25zdCByZXRyeVJlc3VsdCA9IGF3YWl0IHRoaXMudHJhbnNjcmliZVNlcnZpY2UudHJhbnNjcmliZUF1ZGlvKHMzVXJpLCBzZXNzaW9uSWQpO1xuICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy52YWxpZGF0ZUFuZFJldHJ5SWZOZWVkZWQocmV0cnlSZXN1bHQsIHMzVXJpLCBzZXNzaW9uSWQsIHJldHJ5Q291bnQgKyAxKTtcbiAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICAgIGNvbnNvbGUuZXJyb3IoJ1JldHJ5IHRyYW5zY3JpcHRpb24gZmFpbGVkOicsIGVycm9yKTtcbiAgICAgICAgLy8gUmV0dXJuIG9yaWdpbmFsIHJlc3VsdCBpZiByZXRyeSBmYWlsc1xuICAgICAgICByZXR1cm4gdHJhbnNjcmlwdGlvblJlc3VsdDtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBSZXR1cm4gcmVzdWx0IHdpdGggbG93IGNvbmZpZGVuY2Ugd2FybmluZ1xuICAgIGNvbnNvbGUud2FybihgVHJhbnNjcmlwdGlvbiBjb25maWRlbmNlIGJlbG93IHRocmVzaG9sZDogJHtyZXN1bHQuY29uZmlkZW5jZX0gPCAke3RoaXMuY29uZmlnLmNvbmZpZGVuY2VUaHJlc2hvbGR9YCk7XG4gICAgcmV0dXJuIHRyYW5zY3JpcHRpb25SZXN1bHQ7XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2sgaWYgdHJhbnNjcmlwdGlvbiByZXN1bHQgaXMgYWNjZXB0YWJsZVxuICAgKi9cbiAgaXNUcmFuc2NyaXB0aW9uQWNjZXB0YWJsZShyZXN1bHQ6IFRyYW5zY3JpcHRpb25SZXN1bHQpOiBib29sZWFuIHtcbiAgICByZXR1cm4gcmVzdWx0LnN0YXR1cyA9PT0gJ0NPTVBMRVRFRCcgJiYgXG4gICAgICAgICAgIHJlc3VsdC5jb25maWRlbmNlID49IHRoaXMuY29uZmlnLmNvbmZpZGVuY2VUaHJlc2hvbGQgJiZcbiAgICAgICAgICAgcmVzdWx0LnRleHQudHJpbSgpLmxlbmd0aCA+IDA7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHVzZXItZnJpZW5kbHkgbWVzc2FnZSBmb3IgdHJhbnNjcmlwdGlvbiBpc3N1ZXNcbiAgICovXG4gIGdldFRyYW5zY3JpcHRpb25Jc3N1ZU1lc3NhZ2UocmVzdWx0OiBUcmFuc2NyaXB0aW9uUmVzdWx0KTogc3RyaW5nIHtcbiAgICBpZiAocmVzdWx0LnN0YXR1cyA9PT0gJ0ZBSUxFRCcpIHtcbiAgICAgIHJldHVybiBcIkknbSBzb3JyeSwgSSBjb3VsZG4ndCBwcm9jZXNzIHlvdXIgYXVkaW8uIFBsZWFzZSB0cnkgc3BlYWtpbmcgYWdhaW4uXCI7XG4gICAgfVxuICAgIFxuICAgIGlmIChyZXN1bHQuY29uZmlkZW5jZSA8IHRoaXMuY29uZmlnLmNvbmZpZGVuY2VUaHJlc2hvbGQpIHtcbiAgICAgIHJldHVybiBcIkkgZGlkbid0IGNhdGNoIHRoYXQgY2xlYXJseS4gQ291bGQgeW91IHBsZWFzZSByZXBlYXQgeW91ciBxdWVzdGlvbiBtb3JlIGNsZWFybHk/XCI7XG4gICAgfVxuICAgIFxuICAgIGlmIChyZXN1bHQudGV4dC50cmltKCkubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gXCJJIGRpZG4ndCBoZWFyIGFueXRoaW5nLiBQbGVhc2Ugc3BlYWsgeW91ciBxdWVzdGlvbi5cIjtcbiAgICB9XG4gICAgXG4gICAgcmV0dXJuIFwiVGhlcmUgd2FzIGFuIGlzc3VlIHByb2Nlc3NpbmcgeW91ciBzcGVlY2guIFBsZWFzZSB0cnkgYWdhaW4uXCI7XG4gIH1cblxuICAvKipcbiAgICogVmFsaWRhdGUgYXVkaW8gcXVhbGl0eSBmb3IgdHJhbnNjcmlwdGlvblxuICAgKi9cbiAgdmFsaWRhdGVBdWRpb1F1YWxpdHkoYXVkaW9JbmZvOiB7IHVybDogc3RyaW5nOyBkdXJhdGlvbj86IG51bWJlciB9KTogeyBpc1ZhbGlkOiBib29sZWFuOyBpc3N1ZXM6IHN0cmluZ1tdIH0ge1xuICAgIGNvbnN0IGlzc3Vlczogc3RyaW5nW10gPSBbXTtcbiAgICBcbiAgICBpZiAoIWF1ZGlvSW5mby51cmwpIHtcbiAgICAgIGlzc3Vlcy5wdXNoKCdObyBhdWRpbyBVUkwgcHJvdmlkZWQnKTtcbiAgICB9XG4gICAgXG4gICAgaWYgKGF1ZGlvSW5mby5kdXJhdGlvbiAhPT0gdW5kZWZpbmVkICYmIGF1ZGlvSW5mby5kdXJhdGlvbiA8IDAuNSkge1xuICAgICAgaXNzdWVzLnB1c2goJ0F1ZGlvIHRvbyBzaG9ydCBmb3IgdHJhbnNjcmlwdGlvbiAobWluaW11bSAwLjUgc2Vjb25kcyknKTtcbiAgICB9XG4gICAgXG4gICAgaWYgKGF1ZGlvSW5mby5kdXJhdGlvbiAhPT0gdW5kZWZpbmVkICYmIGF1ZGlvSW5mby5kdXJhdGlvbiA+IDMwMCkge1xuICAgICAgaXNzdWVzLnB1c2goJ0F1ZGlvIHRvbyBsb25nIGZvciB0cmFuc2NyaXB0aW9uIChtYXhpbXVtIDUgbWludXRlcyknKTtcbiAgICB9XG4gICAgXG4gICAgcmV0dXJuIHtcbiAgICAgIGlzVmFsaWQ6IGlzc3Vlcy5sZW5ndGggPT09IDAsXG4gICAgICBpc3N1ZXNcbiAgICB9O1xuICB9XG5cbiAgLyoqXG4gICAqIFByb2Nlc3MgdHJhbnNjcmlwdGlvbiB3aXRoIGZ1bGwgcGlwZWxpbmUgZnJvbSBTMyBVUklcbiAgICovXG4gIGFzeW5jIHByb2Nlc3NUcmFuc2NyaXB0aW9uKGF1ZGlvUzNVcmk6IHN0cmluZywgc2Vzc2lvbklkOiBzdHJpbmcpOiBQcm9taXNlPFRyYW5zY3JpcHRpb25SZXN1bHQ+IHtcbiAgICB0cnkge1xuICAgICAgY29uc3QgdHJhbnNjcmliZVJlc3VsdCA9IGF3YWl0IHRoaXMudHJhbnNjcmliZVNlcnZpY2UudHJhbnNjcmliZUF1ZGlvKGF1ZGlvUzNVcmksIHNlc3Npb25JZCk7XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy52YWxpZGF0ZUFuZFJldHJ5SWZOZWVkZWQodHJhbnNjcmliZVJlc3VsdCwgYXVkaW9TM1VyaSwgc2Vzc2lvbklkKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgaW4gdHJhbnNjcmlwdGlvbiBwaXBlbGluZTonLCBlcnJvcik7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYFRyYW5zY3JpcHRpb24gcGlwZWxpbmUgZmFpbGVkOiAke2Vycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJ1Vua25vd24gZXJyb3InfWApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgY29uZmlkZW5jZSB0aHJlc2hvbGRcbiAgICovXG4gIGdldENvbmZpZGVuY2VUaHJlc2hvbGQoKTogbnVtYmVyIHtcbiAgICByZXR1cm4gdGhpcy5jb25maWcuY29uZmlkZW5jZVRocmVzaG9sZDtcbiAgfVxuXG4gIC8qKlxuICAgKiBGb3JtYXQgdHJhbnNjcmlwdGlvbiByZXN1bHQgZm9yIGxvZ2dpbmdcbiAgICovXG4gIGZvcm1hdFJlc3VsdEZvckxvZ2dpbmcocmVzdWx0OiBUcmFuc2NyaXB0aW9uUmVzdWx0KTogc3RyaW5nIHtcbiAgICByZXR1cm4gYFRleHQ6IFwiJHtyZXN1bHQudGV4dH1cIiB8IENvbmZpZGVuY2U6ICR7cmVzdWx0LmNvbmZpZGVuY2UudG9GaXhlZCgzKX0gfCBTdGF0dXM6ICR7cmVzdWx0LnN0YXR1c30ke3Jlc3VsdC5pc1JldHJ5ID8gJyAocmV0cnkpJyA6ICcnfWA7XG4gIH1cbn0iXX0=