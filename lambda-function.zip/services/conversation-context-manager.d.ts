/**
 * Conversation Context Manager for PromptCall AI MVP
 * Manages conversation context, AI prompts, and session state for optimal AI interactions
 */
import { CallSession, ConversationEntry, SessionStatus, SessionConfig } from '../types/session';
import { DynamoSessionManager } from './dynamo-session-manager';
/**
 * User preferences for conversation management
 */
export interface UserPreferences {
    responseLength: 'short' | 'medium' | 'long';
    topics: string[];
    language: string;
    voiceSpeed: 'slow' | 'normal' | 'fast';
}
/**
 * AI Context for processing user queries
 */
export interface AIContext {
    sessionId: string;
    conversationContext: string;
    userPreferences: UserPreferences;
    systemPrompt: string;
    conversationSummary?: string;
    lastUserIntent?: string;
    contextWindow: ConversationEntry[];
}
/**
 * Session state information beyond basic status
 */
export interface SessionState {
    status: SessionStatus;
    phase: 'greeting' | 'conversation' | 'clarification' | 'closing';
    turnCount: number;
    lastActivity: number;
    isWaitingForUser: boolean;
    hasErrors: boolean;
    errorCount: number;
    averageResponseTime: number;
    userEngagement: 'high' | 'medium' | 'low';
}
/**
 * Configuration for conversation context management
 */
export interface ConversationContextConfig {
    maxContextEntries: number;
    maxContextLength: number;
    summaryThreshold: number;
    responseWordLimit: number;
    sessionConfig: SessionConfig;
}
/**
 * Default configuration for conversation context
 */
export declare const DEFAULT_CONTEXT_CONFIG: ConversationContextConfig;
export declare class ConversationContextManager {
    private sessionManager;
    private config;
    constructor(sessionManager: DynamoSessionManager, config?: ConversationContextConfig);
    /**
     * Initializes a new conversation session with greeting phase
     */
    initializeConversation(callSid: string, phoneNumber: string, userPreferences?: Partial<UserPreferences>): Promise<{
        session: CallSession;
        context: AIContext;
    }>;
    /**
     * Processes a user message and updates conversation context
     */
    processUserMessage(sessionId: string, userText: string, audioUrl?: string, confidence?: number): Promise<AIContext>;
    /**
     * Processes an AI response and updates conversation context
     */
    processAIResponse(sessionId: string, aiText: string, audioUrl?: string, processingDuration?: number): Promise<void>;
    /**
     * Builds comprehensive AI context for processing user queries
     */
    buildAIContext(sessionId: string, userPreferences?: Partial<UserPreferences>): Promise<AIContext>;
    /**
     * Gets the relevant context window from conversation history
     */
    private getContextWindow;
    /**
     * Builds a formatted context string for AI processing
     */
    private buildContextString;
    /**
     * Builds user preferences from session data and overrides
     */
    private buildUserPreferences;
    /**
     * Infers user preferences from conversation patterns
     */
    private inferUserPreferences;
    /**
     * Generates system prompt based on conversation phase and preferences
     */
    private generateSystemPrompt;
    /**
     * Gets phase-specific guidance for the system prompt
     */
    private getPhaseGuidance;
    /**
     * Generates a conversation summary for context
     */
    private generateConversationSummary;
    /**
     * Extracts the user's likely intent from recent messages
     */
    private extractUserIntent;
    /**
     * Extracts topics from conversation history
     */
    private extractTopics;
    /**
     * Updates session state with new information
     */
    private updateSessionState;
    /**
     * Updates conversation phase based on AI response content
     */
    private updateConversationPhase;
    /**
     * Checks if session needs attention (timeout, errors, etc.)
     */
    checkSessionHealth(sessionId: string): Promise<{
        needsAttention: boolean;
        reasons: string[];
        recommendations: string[];
    }>;
    /**
     * Validates AI response before sending to user
     */
    validateAIResponse(response: string, preferences: UserPreferences): {
        isValid: boolean;
        issues: string[];
        suggestions: string[];
    };
    /**
     * Gets conversation statistics for monitoring
     */
    getConversationStats(sessionId: string): Promise<{
        turnCount: number;
        duration: number;
        averageResponseLength: number;
        topicsDiscussed: string[];
        userEngagement: 'high' | 'medium' | 'low';
    }>;
}
