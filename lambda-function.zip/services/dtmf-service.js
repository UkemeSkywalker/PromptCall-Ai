"use strict";
/**
 * DTMF Service for handling keypad input during phone calls
 * Supports "1" for submit and "0" for end call
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DTMFService = void 0;
class DTMFService {
    /**
     * Process DTMF input and determine the appropriate action
     */
    processDTMFInput(input) {
        const digit = input.digits;
        console.log(`Processing DTMF input: ${digit} for CallSid: ${input.callSid}`);
        switch (digit) {
            case '1':
                return {
                    action: 'submit',
                    message: 'Processing your request now.',
                    shouldContinue: true
                };
            case '0':
                return {
                    action: 'end_call',
                    message: 'Thank you for using PromptCall AI. Goodbye!',
                    shouldContinue: false
                };
            case '*':
                return {
                    action: 'help',
                    message: 'Press 1 to submit your spoken prompt for processing, or press 0 to end the call.',
                    shouldContinue: true
                };
            default:
                return {
                    action: 'invalid',
                    message: 'Invalid key pressed. Press 1 to submit your prompt or 0 to end the call.',
                    shouldContinue: true
                };
        }
    }
    /**
     * Generate TwiML for DTMF gathering
     */
    generateGatherTwiML(options) {
        const { action, timeout = 10, numDigits = 1, finishOnKey = '#', prompt } = options;
        let twiml = `<Gather action="${action}" method="POST" timeout="${timeout}" numDigits="${numDigits}" finishOnKey="${finishOnKey}">`;
        if (prompt) {
            twiml += `<Say voice="alice">${prompt}</Say>`;
        }
        twiml += '</Gather>';
        return twiml;
    }
    /**
     * Generate TwiML for recording with DTMF controls
     * Note: Record and Gather cannot be nested, so we use Record with timeout
     * and then follow with Gather for DTMF input
     */
    generateRecordWithDTMFTwiML(options) {
        const { speechAction, dtmfAction, maxLength = 30, timeout = 10, prompt } = options;
        let twiml = '';
        if (prompt) {
            twiml += `<Say voice="alice">${prompt}</Say>`;
        }
        // First, record the user's speech
        twiml += `<Record action="${speechAction}" method="POST" maxLength="${maxLength}" timeout="${timeout}" playBeep="true" />`;
        // Then, gather DTMF input with instructions
        twiml += `<Gather action="${dtmfAction}" method="POST" timeout="30" numDigits="1" finishOnKey="#">`;
        twiml += '<Say voice="alice">Press 1 to submit your prompt, or press 0 to end the call.</Say>';
        twiml += '</Gather>';
        // Fallback if no DTMF input
        twiml += '<Say voice="alice">I didn\'t receive any input. Please try again.</Say>';
        return twiml;
    }
    /**
     * Generate welcome message with DTMF instructions
     */
    generateWelcomeWithInstructions() {
        return `Welcome to PromptCall AI. Please speak your question after the beep. 
            When you finish speaking, press 1 to submit your question for AI processing, 
            or press 0 to end the call. You can press star for help at any time.`;
    }
    /**
     * Generate reminder message for DTMF controls
     */
    generateControlsReminder() {
        return `Remember: Press 1 to submit your prompt, or press 0 to end the call.`;
    }
}
exports.DTMFService = DTMFService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHRtZi1zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL3NlcnZpY2VzL2R0bWYtc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7OztHQUdHOzs7QUFlSCxNQUFhLFdBQVc7SUFDdEI7O09BRUc7SUFDSCxnQkFBZ0IsQ0FBQyxLQUFnQjtRQUMvQixNQUFNLEtBQUssR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDO1FBRTNCLE9BQU8sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLEtBQUssaUJBQWlCLEtBQUssQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBRTdFLFFBQVEsS0FBSyxFQUFFLENBQUM7WUFDZCxLQUFLLEdBQUc7Z0JBQ04sT0FBTztvQkFDTCxNQUFNLEVBQUUsUUFBUTtvQkFDaEIsT0FBTyxFQUFFLDhCQUE4QjtvQkFDdkMsY0FBYyxFQUFFLElBQUk7aUJBQ3JCLENBQUM7WUFFSixLQUFLLEdBQUc7Z0JBQ04sT0FBTztvQkFDTCxNQUFNLEVBQUUsVUFBVTtvQkFDbEIsT0FBTyxFQUFFLDZDQUE2QztvQkFDdEQsY0FBYyxFQUFFLEtBQUs7aUJBQ3RCLENBQUM7WUFFSixLQUFLLEdBQUc7Z0JBQ04sT0FBTztvQkFDTCxNQUFNLEVBQUUsTUFBTTtvQkFDZCxPQUFPLEVBQUUsa0ZBQWtGO29CQUMzRixjQUFjLEVBQUUsSUFBSTtpQkFDckIsQ0FBQztZQUVKO2dCQUNFLE9BQU87b0JBQ0wsTUFBTSxFQUFFLFNBQVM7b0JBQ2pCLE9BQU8sRUFBRSwwRUFBMEU7b0JBQ25GLGNBQWMsRUFBRSxJQUFJO2lCQUNyQixDQUFDO1FBQ04sQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILG1CQUFtQixDQUFDLE9BTW5CO1FBQ0MsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLEdBQUcsRUFBRSxFQUFFLFNBQVMsR0FBRyxDQUFDLEVBQUUsV0FBVyxHQUFHLEdBQUcsRUFBRSxNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUM7UUFFbkYsSUFBSSxLQUFLLEdBQUcsbUJBQW1CLE1BQU0sNEJBQTRCLE9BQU8sZ0JBQWdCLFNBQVMsa0JBQWtCLFdBQVcsSUFBSSxDQUFDO1FBRW5JLElBQUksTUFBTSxFQUFFLENBQUM7WUFDWCxLQUFLLElBQUksc0JBQXNCLE1BQU0sUUFBUSxDQUFDO1FBQ2hELENBQUM7UUFFRCxLQUFLLElBQUksV0FBVyxDQUFDO1FBRXJCLE9BQU8sS0FBSyxDQUFDO0lBQ2YsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCwyQkFBMkIsQ0FBQyxPQU0zQjtRQUNDLE1BQU0sRUFBRSxZQUFZLEVBQUUsVUFBVSxFQUFFLFNBQVMsR0FBRyxFQUFFLEVBQUUsT0FBTyxHQUFHLEVBQUUsRUFBRSxNQUFNLEVBQUUsR0FBRyxPQUFPLENBQUM7UUFFbkYsSUFBSSxLQUFLLEdBQUcsRUFBRSxDQUFDO1FBRWYsSUFBSSxNQUFNLEVBQUUsQ0FBQztZQUNYLEtBQUssSUFBSSxzQkFBc0IsTUFBTSxRQUFRLENBQUM7UUFDaEQsQ0FBQztRQUVELGtDQUFrQztRQUNsQyxLQUFLLElBQUksbUJBQW1CLFlBQVksOEJBQThCLFNBQVMsY0FBYyxPQUFPLHNCQUFzQixDQUFDO1FBRTNILDRDQUE0QztRQUM1QyxLQUFLLElBQUksbUJBQW1CLFVBQVUsNkRBQTZELENBQUM7UUFDcEcsS0FBSyxJQUFJLHFGQUFxRixDQUFDO1FBQy9GLEtBQUssSUFBSSxXQUFXLENBQUM7UUFFckIsNEJBQTRCO1FBQzVCLEtBQUssSUFBSSx5RUFBeUUsQ0FBQztRQUVuRixPQUFPLEtBQUssQ0FBQztJQUNmLENBQUM7SUFFRDs7T0FFRztJQUNILCtCQUErQjtRQUM3QixPQUFPOztpRkFFc0UsQ0FBQztJQUNoRixDQUFDO0lBRUQ7O09BRUc7SUFDSCx3QkFBd0I7UUFDdEIsT0FBTyxzRUFBc0UsQ0FBQztJQUNoRixDQUFDO0NBQ0Y7QUFoSEQsa0NBZ0hDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBEVE1GIFNlcnZpY2UgZm9yIGhhbmRsaW5nIGtleXBhZCBpbnB1dCBkdXJpbmcgcGhvbmUgY2FsbHNcbiAqIFN1cHBvcnRzIFwiMVwiIGZvciBzdWJtaXQgYW5kIFwiMFwiIGZvciBlbmQgY2FsbFxuICovXG5cbmV4cG9ydCBpbnRlcmZhY2UgRFRNRklucHV0IHtcbiAgZGlnaXRzOiBzdHJpbmc7XG4gIGNhbGxTaWQ6IHN0cmluZztcbiAgZnJvbTogc3RyaW5nO1xuICB0bzogc3RyaW5nO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIERUTUZSZXNwb25zZSB7XG4gIGFjdGlvbjogJ3N1Ym1pdCcgfCAnZW5kX2NhbGwnIHwgJ2ludmFsaWQnIHwgJ2hlbHAnO1xuICBtZXNzYWdlPzogc3RyaW5nO1xuICBzaG91bGRDb250aW51ZTogYm9vbGVhbjtcbn1cblxuZXhwb3J0IGNsYXNzIERUTUZTZXJ2aWNlIHtcbiAgLyoqXG4gICAqIFByb2Nlc3MgRFRNRiBpbnB1dCBhbmQgZGV0ZXJtaW5lIHRoZSBhcHByb3ByaWF0ZSBhY3Rpb25cbiAgICovXG4gIHByb2Nlc3NEVE1GSW5wdXQoaW5wdXQ6IERUTUZJbnB1dCk6IERUTUZSZXNwb25zZSB7XG4gICAgY29uc3QgZGlnaXQgPSBpbnB1dC5kaWdpdHM7XG4gICAgXG4gICAgY29uc29sZS5sb2coYFByb2Nlc3NpbmcgRFRNRiBpbnB1dDogJHtkaWdpdH0gZm9yIENhbGxTaWQ6ICR7aW5wdXQuY2FsbFNpZH1gKTtcbiAgICBcbiAgICBzd2l0Y2ggKGRpZ2l0KSB7XG4gICAgICBjYXNlICcxJzpcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBhY3Rpb246ICdzdWJtaXQnLFxuICAgICAgICAgIG1lc3NhZ2U6ICdQcm9jZXNzaW5nIHlvdXIgcmVxdWVzdCBub3cuJyxcbiAgICAgICAgICBzaG91bGRDb250aW51ZTogdHJ1ZVxuICAgICAgICB9O1xuICAgICAgXG4gICAgICBjYXNlICcwJzpcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBhY3Rpb246ICdlbmRfY2FsbCcsXG4gICAgICAgICAgbWVzc2FnZTogJ1RoYW5rIHlvdSBmb3IgdXNpbmcgUHJvbXB0Q2FsbCBBSS4gR29vZGJ5ZSEnLFxuICAgICAgICAgIHNob3VsZENvbnRpbnVlOiBmYWxzZVxuICAgICAgICB9O1xuICAgICAgXG4gICAgICBjYXNlICcqJzpcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBhY3Rpb246ICdoZWxwJyxcbiAgICAgICAgICBtZXNzYWdlOiAnUHJlc3MgMSB0byBzdWJtaXQgeW91ciBzcG9rZW4gcHJvbXB0IGZvciBwcm9jZXNzaW5nLCBvciBwcmVzcyAwIHRvIGVuZCB0aGUgY2FsbC4nLFxuICAgICAgICAgIHNob3VsZENvbnRpbnVlOiB0cnVlXG4gICAgICAgIH07XG4gICAgICBcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgYWN0aW9uOiAnaW52YWxpZCcsXG4gICAgICAgICAgbWVzc2FnZTogJ0ludmFsaWQga2V5IHByZXNzZWQuIFByZXNzIDEgdG8gc3VibWl0IHlvdXIgcHJvbXB0IG9yIDAgdG8gZW5kIHRoZSBjYWxsLicsXG4gICAgICAgICAgc2hvdWxkQ29udGludWU6IHRydWVcbiAgICAgICAgfTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogR2VuZXJhdGUgVHdpTUwgZm9yIERUTUYgZ2F0aGVyaW5nXG4gICAqL1xuICBnZW5lcmF0ZUdhdGhlclR3aU1MKG9wdGlvbnM6IHtcbiAgICBhY3Rpb246IHN0cmluZztcbiAgICB0aW1lb3V0PzogbnVtYmVyO1xuICAgIG51bURpZ2l0cz86IG51bWJlcjtcbiAgICBmaW5pc2hPbktleT86IHN0cmluZztcbiAgICBwcm9tcHQ/OiBzdHJpbmc7XG4gIH0pOiBzdHJpbmcge1xuICAgIGNvbnN0IHsgYWN0aW9uLCB0aW1lb3V0ID0gMTAsIG51bURpZ2l0cyA9IDEsIGZpbmlzaE9uS2V5ID0gJyMnLCBwcm9tcHQgfSA9IG9wdGlvbnM7XG4gICAgXG4gICAgbGV0IHR3aW1sID0gYDxHYXRoZXIgYWN0aW9uPVwiJHthY3Rpb259XCIgbWV0aG9kPVwiUE9TVFwiIHRpbWVvdXQ9XCIke3RpbWVvdXR9XCIgbnVtRGlnaXRzPVwiJHtudW1EaWdpdHN9XCIgZmluaXNoT25LZXk9XCIke2ZpbmlzaE9uS2V5fVwiPmA7XG4gICAgXG4gICAgaWYgKHByb21wdCkge1xuICAgICAgdHdpbWwgKz0gYDxTYXkgdm9pY2U9XCJhbGljZVwiPiR7cHJvbXB0fTwvU2F5PmA7XG4gICAgfVxuICAgIFxuICAgIHR3aW1sICs9ICc8L0dhdGhlcj4nO1xuICAgIFxuICAgIHJldHVybiB0d2ltbDtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZW5lcmF0ZSBUd2lNTCBmb3IgcmVjb3JkaW5nIHdpdGggRFRNRiBjb250cm9sc1xuICAgKiBOb3RlOiBSZWNvcmQgYW5kIEdhdGhlciBjYW5ub3QgYmUgbmVzdGVkLCBzbyB3ZSB1c2UgUmVjb3JkIHdpdGggdGltZW91dFxuICAgKiBhbmQgdGhlbiBmb2xsb3cgd2l0aCBHYXRoZXIgZm9yIERUTUYgaW5wdXRcbiAgICovXG4gIGdlbmVyYXRlUmVjb3JkV2l0aERUTUZUd2lNTChvcHRpb25zOiB7XG4gICAgc3BlZWNoQWN0aW9uOiBzdHJpbmc7XG4gICAgZHRtZkFjdGlvbjogc3RyaW5nO1xuICAgIG1heExlbmd0aD86IG51bWJlcjtcbiAgICB0aW1lb3V0PzogbnVtYmVyO1xuICAgIHByb21wdD86IHN0cmluZztcbiAgfSk6IHN0cmluZyB7XG4gICAgY29uc3QgeyBzcGVlY2hBY3Rpb24sIGR0bWZBY3Rpb24sIG1heExlbmd0aCA9IDMwLCB0aW1lb3V0ID0gMTAsIHByb21wdCB9ID0gb3B0aW9ucztcbiAgICBcbiAgICBsZXQgdHdpbWwgPSAnJztcbiAgICBcbiAgICBpZiAocHJvbXB0KSB7XG4gICAgICB0d2ltbCArPSBgPFNheSB2b2ljZT1cImFsaWNlXCI+JHtwcm9tcHR9PC9TYXk+YDtcbiAgICB9XG4gICAgXG4gICAgLy8gRmlyc3QsIHJlY29yZCB0aGUgdXNlcidzIHNwZWVjaFxuICAgIHR3aW1sICs9IGA8UmVjb3JkIGFjdGlvbj1cIiR7c3BlZWNoQWN0aW9ufVwiIG1ldGhvZD1cIlBPU1RcIiBtYXhMZW5ndGg9XCIke21heExlbmd0aH1cIiB0aW1lb3V0PVwiJHt0aW1lb3V0fVwiIHBsYXlCZWVwPVwidHJ1ZVwiIC8+YDtcbiAgICBcbiAgICAvLyBUaGVuLCBnYXRoZXIgRFRNRiBpbnB1dCB3aXRoIGluc3RydWN0aW9uc1xuICAgIHR3aW1sICs9IGA8R2F0aGVyIGFjdGlvbj1cIiR7ZHRtZkFjdGlvbn1cIiBtZXRob2Q9XCJQT1NUXCIgdGltZW91dD1cIjMwXCIgbnVtRGlnaXRzPVwiMVwiIGZpbmlzaE9uS2V5PVwiI1wiPmA7XG4gICAgdHdpbWwgKz0gJzxTYXkgdm9pY2U9XCJhbGljZVwiPlByZXNzIDEgdG8gc3VibWl0IHlvdXIgcHJvbXB0LCBvciBwcmVzcyAwIHRvIGVuZCB0aGUgY2FsbC48L1NheT4nO1xuICAgIHR3aW1sICs9ICc8L0dhdGhlcj4nO1xuICAgIFxuICAgIC8vIEZhbGxiYWNrIGlmIG5vIERUTUYgaW5wdXRcbiAgICB0d2ltbCArPSAnPFNheSB2b2ljZT1cImFsaWNlXCI+SSBkaWRuXFwndCByZWNlaXZlIGFueSBpbnB1dC4gUGxlYXNlIHRyeSBhZ2Fpbi48L1NheT4nO1xuICAgIFxuICAgIHJldHVybiB0d2ltbDtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZW5lcmF0ZSB3ZWxjb21lIG1lc3NhZ2Ugd2l0aCBEVE1GIGluc3RydWN0aW9uc1xuICAgKi9cbiAgZ2VuZXJhdGVXZWxjb21lV2l0aEluc3RydWN0aW9ucygpOiBzdHJpbmcge1xuICAgIHJldHVybiBgV2VsY29tZSB0byBQcm9tcHRDYWxsIEFJLiBQbGVhc2Ugc3BlYWsgeW91ciBxdWVzdGlvbiBhZnRlciB0aGUgYmVlcC4gXG4gICAgICAgICAgICBXaGVuIHlvdSBmaW5pc2ggc3BlYWtpbmcsIHByZXNzIDEgdG8gc3VibWl0IHlvdXIgcXVlc3Rpb24gZm9yIEFJIHByb2Nlc3NpbmcsIFxuICAgICAgICAgICAgb3IgcHJlc3MgMCB0byBlbmQgdGhlIGNhbGwuIFlvdSBjYW4gcHJlc3Mgc3RhciBmb3IgaGVscCBhdCBhbnkgdGltZS5gO1xuICB9XG5cbiAgLyoqXG4gICAqIEdlbmVyYXRlIHJlbWluZGVyIG1lc3NhZ2UgZm9yIERUTUYgY29udHJvbHNcbiAgICovXG4gIGdlbmVyYXRlQ29udHJvbHNSZW1pbmRlcigpOiBzdHJpbmcge1xuICAgIHJldHVybiBgUmVtZW1iZXI6IFByZXNzIDEgdG8gc3VibWl0IHlvdXIgcHJvbXB0LCBvciBwcmVzcyAwIHRvIGVuZCB0aGUgY2FsbC5gO1xuICB9XG59Il19