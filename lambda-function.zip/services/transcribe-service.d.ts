/**
 * Amazon Transcribe Service for speech-to-text conversion
 */
import { TranscriptionJob, TranscriptionJobStatus, LanguageCode, MediaFormat } from '@aws-sdk/client-transcribe';
export interface TranscribeResult {
    text: string;
    confidence: number;
    jobName: string;
    status: TranscriptionJobStatus;
}
export interface TranscribeConfig {
    region?: string;
    languageCode?: LanguageCode;
    mediaFormat?: MediaFormat;
    mediaSampleRateHertz?: number;
}
export declare class TranscribeService {
    private transcribeClient;
    private config;
    constructor(config?: TranscribeConfig);
    /**
     * Start transcription job for audio file in S3
     */
    startTranscriptionJob(s3Uri: string, sessionId: string): Promise<string>;
    /**
     * Get transcription job status and results
     */
    getTranscriptionJob(jobName: string): Promise<TranscriptionJob | null>;
    /**
     * Poll transcription job until completion
     */
    pollTranscriptionJob(jobName: string, maxAttempts?: number, intervalMs?: number): Promise<TranscribeResult>;
    /**
     * Extract text and confidence from completed transcription job
     */
    private extractTranscriptionResult;
    /**
     * Generate unique job name for transcription
     */
    private generateJobName;
    /**
     * Check if confidence score meets minimum threshold
     */
    isConfidenceAcceptable(confidence: number, threshold?: number): boolean;
    /**
     * Process audio file and return transcription result
     */
    transcribeAudio(s3Uri: string, sessionId: string): Promise<TranscribeResult>;
}
