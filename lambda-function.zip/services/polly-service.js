"use strict";
/**
 * Amazon Polly Text-to-Speech Service
 * Handles conversion of AI responses to natural speech audio
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DEFAULT_POLLY_CONFIG = exports.PollyService = void 0;
const client_polly_1 = require("@aws-sdk/client-polly");
class PollyService {
    constructor(config, s3Service) {
        this.config = config;
        this.s3Service = s3Service;
        this.pollyClient = new client_polly_1.PollyClient({
            region: config.region
        });
    }
    /**
     * Convert text to speech using Amazon Polly with optional SSML formatting
     */
    async synthesizeSpeech(text, sessionId, options, ssmlOptions) {
        try {
            // Merge options with default config
            const synthesisConfig = { ...this.config, ...options };
            // Apply SSML formatting if requested
            let processedText = text;
            let textType = 'text';
            if (ssmlOptions) {
                processedText = this.formatWithSSML(text, ssmlOptions);
                textType = 'ssml';
            }
            // Prepare Polly synthesis parameters
            const params = {
                Text: processedText,
                TextType: textType,
                VoiceId: synthesisConfig.voiceId,
                OutputFormat: synthesisConfig.outputFormat,
                Engine: synthesisConfig.engine,
                SampleRate: synthesisConfig.sampleRate
            };
            console.log('Synthesizing speech with Polly:', {
                textLength: text.length,
                voiceId: synthesisConfig.voiceId,
                outputFormat: synthesisConfig.outputFormat
            });
            // Call Polly API
            const command = new client_polly_1.SynthesizeSpeechCommand(params);
            const response = await this.pollyClient.send(command);
            if (!response.AudioStream) {
                throw new Error('No audio stream received from Polly');
            }
            // Convert audio stream to buffer
            const audioBuffer = await this.streamToBuffer(response.AudioStream);
            // Generate unique key for audio file
            const timestamp = Date.now();
            const audioKey = `speech/${sessionId}/${timestamp}.${this.getFileExtension(synthesisConfig.outputFormat)}`;
            // Upload to S3
            const audioUrl = await this.s3Service.uploadAudioFile(audioBuffer, audioKey);
            // Generate presigned URL for telephony playback
            const playbackUrl = await this.s3Service.getTelephonyPlaybackUrl(audioKey);
            console.log('Speech synthesis completed:', {
                audioKey,
                audioUrl,
                playbackUrl,
                audioSize: audioBuffer.length
            });
            return {
                audioUrl,
                audioKey,
                playbackUrl,
                text,
                ssmlText: textType === 'ssml' ? processedText : undefined,
                duration: this.estimateDuration(text)
            };
        }
        catch (error) {
            console.error('Error synthesizing speech:', error);
            throw new Error(`Speech synthesis failed: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
     * Format text with SSML tags for enhanced speech synthesis
     */
    formatWithSSML(text, options) {
        let ssmlText = text;
        // Apply telephony optimization if requested
        if (options.telephonyOptimized) {
            const telephonyOptions = this.getTelephonySSMLOptions();
            options = { ...telephonyOptions, ...options };
        }
        // Add emphasis to important words (words in caps or with exclamation)
        if (options.emphasizeImportant) {
            ssmlText = ssmlText.replace(/\b[A-Z]{2,}\b/g, '<emphasis level="strong">$&</emphasis>');
            ssmlText = ssmlText.replace(/(\w+)!/g, '<emphasis level="moderate">$1</emphasis>!');
        }
        // Add pauses for better comprehension
        if (options.addPauses) {
            ssmlText = ssmlText.replace(/\. /g, '. <break time="500ms"/>');
            ssmlText = ssmlText.replace(/\? /g, '? <break time="500ms"/>');
            ssmlText = ssmlText.replace(/! /g, '! <break time="300ms"/>');
            ssmlText = ssmlText.replace(/,/g, ',<break time="200ms"/>');
        }
        // Wrap in prosody tags for speech rate and volume
        if (options.speechRate || options.volume) {
            const prosodyAttrs = [];
            if (options.speechRate)
                prosodyAttrs.push(`rate="${options.speechRate}"`);
            if (options.volume)
                prosodyAttrs.push(`volume="${options.volume}"`);
            ssmlText = `<prosody ${prosodyAttrs.join(' ')}>${ssmlText}</prosody>`;
        }
        // Wrap in SSML speak tags
        ssmlText = `<speak>${ssmlText}</speak>`;
        return ssmlText;
    }
    /**
     * Get SSML options optimized for telephony
     */
    getTelephonySSMLOptions() {
        return {
            speechRate: 'medium',
            volume: 'loud',
            addPauses: true,
            emphasizeImportant: false, // Keep it simple for phone calls
            telephonyOptimized: true
        };
    }
    /**
     * Optimize text for phone call clarity (pre-SSML processing)
     */
    optimizeForTelephony(text) {
        let optimized = text;
        // Replace common abbreviations with full words
        optimized = optimized.replace(/\bDr\./g, 'Doctor');
        optimized = optimized.replace(/\bMr\./g, 'Mister');
        optimized = optimized.replace(/\bMrs\./g, 'Missus');
        optimized = optimized.replace(/\bMs\./g, 'Miss');
        optimized = optimized.replace(/\betc\./g, 'etcetera');
        optimized = optimized.replace(/\be\.g\./g, 'for example');
        optimized = optimized.replace(/\bi\.e\./g, 'that is');
        // Replace numbers with words for better pronunciation
        optimized = optimized.replace(/\b(\d{1,2})\b/g, (match, num) => {
            const numbers = ['zero', 'one', 'two', 'three', 'four', 'five', 'six', 'seven', 'eight', 'nine', 'ten',
                'eleven', 'twelve', 'thirteen', 'fourteen', 'fifteen', 'sixteen', 'seventeen', 'eighteen', 'nineteen'];
            const n = parseInt(num);
            return n < 20 ? numbers[n] : match;
        });
        // Add pronunciation hints for common technical terms
        optimized = optimized.replace(/\bAPI\b/g, '<phoneme alphabet="ipa" ph="eɪ.pi.aɪ">API</phoneme>');
        optimized = optimized.replace(/\bURL\b/g, '<phoneme alphabet="ipa" ph="jʊ.ɑr.ɛl">URL</phoneme>');
        optimized = optimized.replace(/\bAI\b/g, '<phoneme alphabet="ipa" ph="eɪ.aɪ">AI</phoneme>');
        return optimized;
    }
    /**
     * Get optimal voice for telephony
     */
    getOptimalVoice() {
        // Joanna and Matthew are optimized for telephony
        return client_polly_1.VoiceId.Joanna;
    }
    /**
     * Get telephony-optimized configuration
     */
    getTelephonyConfig() {
        return {
            voiceId: client_polly_1.VoiceId.Joanna,
            engine: client_polly_1.Engine.NEURAL,
            outputFormat: client_polly_1.OutputFormat.MP3,
            sampleRate: '8000' // 8kHz is standard for telephony
        };
    }
    /**
     * Estimate speech duration based on text length
     * Average speaking rate is ~150 words per minute
     */
    estimateDuration(text) {
        const wordCount = text.split(/\s+/).length;
        const wordsPerMinute = 150;
        return Math.ceil((wordCount / wordsPerMinute) * 60); // Duration in seconds
    }
    /**
     * Get file extension for output format
     */
    getFileExtension(format) {
        switch (format) {
            case client_polly_1.OutputFormat.MP3:
                return 'mp3';
            case client_polly_1.OutputFormat.OGG_VORBIS:
                return 'ogg';
            case client_polly_1.OutputFormat.PCM:
                return 'pcm';
            default:
                return 'mp3';
        }
    }
    /**
     * Clean up old speech synthesis files for a session
     */
    async cleanupSessionAudio(sessionId) {
        try {
            // This would typically be handled by S3 lifecycle policies
            // But we can implement manual cleanup if needed
            console.log(`Audio cleanup for session ${sessionId} handled by S3 lifecycle policies`);
        }
        catch (error) {
            console.error('Error cleaning up session audio:', error);
            // Don't throw - cleanup failures shouldn't break the main flow
        }
    }
    /**
     * Get audio file metadata
     */
    async getAudioMetadata(audioKey) {
        try {
            // This could be extended to get file metadata from S3
            return {
                key: audioKey,
                type: 'speech_synthesis',
                createdAt: new Date().toISOString()
            };
        }
        catch (error) {
            console.error('Error getting audio metadata:', error);
            throw new Error(`Failed to get audio metadata: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
     * Convert readable stream to buffer
     */
    async streamToBuffer(stream) {
        const chunks = [];
        return new Promise((resolve, reject) => {
            stream.on('data', (chunk) => chunks.push(chunk));
            stream.on('error', reject);
            stream.on('end', () => resolve(Buffer.concat(chunks)));
        });
    }
}
exports.PollyService = PollyService;
/**
 * Default Polly configuration optimized for telephony
 */
exports.DEFAULT_POLLY_CONFIG = {
    region: process.env.AWS_REGION || 'us-east-1',
    voiceId: client_polly_1.VoiceId.Joanna,
    engine: client_polly_1.Engine.NEURAL,
    outputFormat: client_polly_1.OutputFormat.MP3,
    sampleRate: '8000'
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicG9sbHktc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9zZXJ2aWNlcy9wb2xseS1zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7O0dBR0c7OztBQUVILHdEQU8rQjtBQTRCL0IsTUFBYSxZQUFZO0lBS3ZCLFlBQVksTUFBbUIsRUFBRSxTQUFvQjtRQUNuRCxJQUFJLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUNyQixJQUFJLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQztRQUMzQixJQUFJLENBQUMsV0FBVyxHQUFHLElBQUksMEJBQVcsQ0FBQztZQUNqQyxNQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07U0FDdEIsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGdCQUFnQixDQUNwQixJQUFZLEVBQ1osU0FBaUIsRUFDakIsT0FBOEIsRUFDOUIsV0FBeUI7UUFFekIsSUFBSSxDQUFDO1lBQ0gsb0NBQW9DO1lBQ3BDLE1BQU0sZUFBZSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsT0FBTyxFQUFFLENBQUM7WUFFdkQscUNBQXFDO1lBQ3JDLElBQUksYUFBYSxHQUFHLElBQUksQ0FBQztZQUN6QixJQUFJLFFBQVEsR0FBb0IsTUFBTSxDQUFDO1lBRXZDLElBQUksV0FBVyxFQUFFLENBQUM7Z0JBQ2hCLGFBQWEsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFDLElBQUksRUFBRSxXQUFXLENBQUMsQ0FBQztnQkFDdkQsUUFBUSxHQUFHLE1BQU0sQ0FBQztZQUNwQixDQUFDO1lBRUQscUNBQXFDO1lBQ3JDLE1BQU0sTUFBTSxHQUEwQjtnQkFDcEMsSUFBSSxFQUFFLGFBQWE7Z0JBQ25CLFFBQVEsRUFBRSxRQUFRO2dCQUNsQixPQUFPLEVBQUUsZUFBZSxDQUFDLE9BQU87Z0JBQ2hDLFlBQVksRUFBRSxlQUFlLENBQUMsWUFBWTtnQkFDMUMsTUFBTSxFQUFFLGVBQWUsQ0FBQyxNQUFNO2dCQUM5QixVQUFVLEVBQUUsZUFBZSxDQUFDLFVBQVU7YUFDdkMsQ0FBQztZQUVGLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLEVBQUU7Z0JBQzdDLFVBQVUsRUFBRSxJQUFJLENBQUMsTUFBTTtnQkFDdkIsT0FBTyxFQUFFLGVBQWUsQ0FBQyxPQUFPO2dCQUNoQyxZQUFZLEVBQUUsZUFBZSxDQUFDLFlBQVk7YUFDM0MsQ0FBQyxDQUFDO1lBRUgsaUJBQWlCO1lBQ2pCLE1BQU0sT0FBTyxHQUFHLElBQUksc0NBQXVCLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDcEQsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUV0RCxJQUFJLENBQUMsUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDO2dCQUMxQixNQUFNLElBQUksS0FBSyxDQUFDLHFDQUFxQyxDQUFDLENBQUM7WUFDekQsQ0FBQztZQUVELGlDQUFpQztZQUNqQyxNQUFNLFdBQVcsR0FBRyxNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1lBRXBFLHFDQUFxQztZQUNyQyxNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDN0IsTUFBTSxRQUFRLEdBQUcsVUFBVSxTQUFTLElBQUksU0FBUyxJQUFJLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQztZQUUzRyxlQUFlO1lBQ2YsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLGVBQWUsQ0FDbkQsV0FBVyxFQUNYLFFBQVEsQ0FDVCxDQUFDO1lBRUYsZ0RBQWdEO1lBQ2hELE1BQU0sV0FBVyxHQUFHLE1BQU0sSUFBSSxDQUFDLFNBQVMsQ0FBQyx1QkFBdUIsQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUUzRSxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixFQUFFO2dCQUN6QyxRQUFRO2dCQUNSLFFBQVE7Z0JBQ1IsV0FBVztnQkFDWCxTQUFTLEVBQUUsV0FBVyxDQUFDLE1BQU07YUFDOUIsQ0FBQyxDQUFDO1lBRUgsT0FBTztnQkFDTCxRQUFRO2dCQUNSLFFBQVE7Z0JBQ1IsV0FBVztnQkFDWCxJQUFJO2dCQUNKLFFBQVEsRUFBRSxRQUFRLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLFNBQVM7Z0JBQ3pELFFBQVEsRUFBRSxJQUFJLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxDQUFDO2FBQ3RDLENBQUM7UUFFSixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsNEJBQTRCLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDbkQsTUFBTSxJQUFJLEtBQUssQ0FBQyw0QkFBNEIsS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztRQUMxRyxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsY0FBYyxDQUFDLElBQVksRUFBRSxPQUFvQjtRQUMvQyxJQUFJLFFBQVEsR0FBRyxJQUFJLENBQUM7UUFFcEIsNENBQTRDO1FBQzVDLElBQUksT0FBTyxDQUFDLGtCQUFrQixFQUFFLENBQUM7WUFDL0IsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQztZQUN4RCxPQUFPLEdBQUcsRUFBRSxHQUFHLGdCQUFnQixFQUFFLEdBQUcsT0FBTyxFQUFFLENBQUM7UUFDaEQsQ0FBQztRQUVELHNFQUFzRTtRQUN0RSxJQUFJLE9BQU8sQ0FBQyxrQkFBa0IsRUFBRSxDQUFDO1lBQy9CLFFBQVEsR0FBRyxRQUFRLENBQUMsT0FBTyxDQUFDLGdCQUFnQixFQUFFLHdDQUF3QyxDQUFDLENBQUM7WUFDeEYsUUFBUSxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLDJDQUEyQyxDQUFDLENBQUM7UUFDdEYsQ0FBQztRQUVELHNDQUFzQztRQUN0QyxJQUFJLE9BQU8sQ0FBQyxTQUFTLEVBQUUsQ0FBQztZQUN0QixRQUFRLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUseUJBQXlCLENBQUMsQ0FBQztZQUMvRCxRQUFRLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUseUJBQXlCLENBQUMsQ0FBQztZQUMvRCxRQUFRLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUseUJBQXlCLENBQUMsQ0FBQztZQUM5RCxRQUFRLEdBQUcsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsd0JBQXdCLENBQUMsQ0FBQztRQUM5RCxDQUFDO1FBRUQsa0RBQWtEO1FBQ2xELElBQUksT0FBTyxDQUFDLFVBQVUsSUFBSSxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUM7WUFDekMsTUFBTSxZQUFZLEdBQUcsRUFBRSxDQUFDO1lBQ3hCLElBQUksT0FBTyxDQUFDLFVBQVU7Z0JBQUUsWUFBWSxDQUFDLElBQUksQ0FBQyxTQUFTLE9BQU8sQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDO1lBQzFFLElBQUksT0FBTyxDQUFDLE1BQU07Z0JBQUUsWUFBWSxDQUFDLElBQUksQ0FBQyxXQUFXLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1lBRXBFLFFBQVEsR0FBRyxZQUFZLFlBQVksQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksUUFBUSxZQUFZLENBQUM7UUFDeEUsQ0FBQztRQUVELDBCQUEwQjtRQUMxQixRQUFRLEdBQUcsVUFBVSxRQUFRLFVBQVUsQ0FBQztRQUV4QyxPQUFPLFFBQVEsQ0FBQztJQUNsQixDQUFDO0lBRUQ7O09BRUc7SUFDSCx1QkFBdUI7UUFDckIsT0FBTztZQUNMLFVBQVUsRUFBRSxRQUFRO1lBQ3BCLE1BQU0sRUFBRSxNQUFNO1lBQ2QsU0FBUyxFQUFFLElBQUk7WUFDZixrQkFBa0IsRUFBRSxLQUFLLEVBQUUsaUNBQWlDO1lBQzVELGtCQUFrQixFQUFFLElBQUk7U0FDekIsQ0FBQztJQUNKLENBQUM7SUFFRDs7T0FFRztJQUNILG9CQUFvQixDQUFDLElBQVk7UUFDL0IsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDO1FBRXJCLCtDQUErQztRQUMvQyxTQUFTLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsUUFBUSxDQUFDLENBQUM7UUFDbkQsU0FBUyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxDQUFDO1FBQ25ELFNBQVMsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRSxRQUFRLENBQUMsQ0FBQztRQUNwRCxTQUFTLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7UUFDakQsU0FBUyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQ3RELFNBQVMsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxhQUFhLENBQUMsQ0FBQztRQUMxRCxTQUFTLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsU0FBUyxDQUFDLENBQUM7UUFFdEQsc0RBQXNEO1FBQ3RELFNBQVMsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLGdCQUFnQixFQUFFLENBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFO1lBQzdELE1BQU0sT0FBTyxHQUFHLENBQUMsTUFBTSxFQUFFLEtBQUssRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLEtBQUs7Z0JBQ3RGLFFBQVEsRUFBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLFVBQVUsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFdBQVcsRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLENBQUM7WUFDdkgsTUFBTSxDQUFDLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQ3hCLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUM7UUFDckMsQ0FBQyxDQUFDLENBQUM7UUFFSCxxREFBcUQ7UUFDckQsU0FBUyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLHFEQUFxRCxDQUFDLENBQUM7UUFDakcsU0FBUyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLHFEQUFxRCxDQUFDLENBQUM7UUFDakcsU0FBUyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLGlEQUFpRCxDQUFDLENBQUM7UUFFNUYsT0FBTyxTQUFTLENBQUM7SUFDbkIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsZUFBZTtRQUNiLGlEQUFpRDtRQUNqRCxPQUFPLHNCQUFPLENBQUMsTUFBTSxDQUFDO0lBQ3hCLENBQUM7SUFFRDs7T0FFRztJQUNILGtCQUFrQjtRQUNoQixPQUFPO1lBQ0wsT0FBTyxFQUFFLHNCQUFPLENBQUMsTUFBTTtZQUN2QixNQUFNLEVBQUUscUJBQU0sQ0FBQyxNQUFNO1lBQ3JCLFlBQVksRUFBRSwyQkFBWSxDQUFDLEdBQUc7WUFDOUIsVUFBVSxFQUFFLE1BQU0sQ0FBQyxpQ0FBaUM7U0FDckQsQ0FBQztJQUNKLENBQUM7SUFFRDs7O09BR0c7SUFDSyxnQkFBZ0IsQ0FBQyxJQUFZO1FBQ25DLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQzNDLE1BQU0sY0FBYyxHQUFHLEdBQUcsQ0FBQztRQUMzQixPQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQyxTQUFTLEdBQUcsY0FBYyxDQUFDLEdBQUcsRUFBRSxDQUFDLENBQUMsQ0FBQyxzQkFBc0I7SUFDN0UsQ0FBQztJQUVEOztPQUVHO0lBQ0ssZ0JBQWdCLENBQUMsTUFBb0I7UUFDM0MsUUFBUSxNQUFNLEVBQUUsQ0FBQztZQUNmLEtBQUssMkJBQVksQ0FBQyxHQUFHO2dCQUNuQixPQUFPLEtBQUssQ0FBQztZQUNmLEtBQUssMkJBQVksQ0FBQyxVQUFVO2dCQUMxQixPQUFPLEtBQUssQ0FBQztZQUNmLEtBQUssMkJBQVksQ0FBQyxHQUFHO2dCQUNuQixPQUFPLEtBQUssQ0FBQztZQUNmO2dCQUNFLE9BQU8sS0FBSyxDQUFDO1FBQ2pCLENBQUM7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsbUJBQW1CLENBQUMsU0FBaUI7UUFDekMsSUFBSSxDQUFDO1lBQ0gsMkRBQTJEO1lBQzNELGdEQUFnRDtZQUNoRCxPQUFPLENBQUMsR0FBRyxDQUFDLDZCQUE2QixTQUFTLG1DQUFtQyxDQUFDLENBQUM7UUFDekYsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGtDQUFrQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3pELCtEQUErRDtRQUNqRSxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGdCQUFnQixDQUFDLFFBQWdCO1FBQ3JDLElBQUksQ0FBQztZQUNILHNEQUFzRDtZQUN0RCxPQUFPO2dCQUNMLEdBQUcsRUFBRSxRQUFRO2dCQUNiLElBQUksRUFBRSxrQkFBa0I7Z0JBQ3hCLFNBQVMsRUFBRSxJQUFJLElBQUksRUFBRSxDQUFDLFdBQVcsRUFBRTthQUNwQyxDQUFDO1FBQ0osQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLCtCQUErQixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3RELE1BQU0sSUFBSSxLQUFLLENBQUMsaUNBQWlDLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7UUFDL0csQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNLLEtBQUssQ0FBQyxjQUFjLENBQUMsTUFBVztRQUN0QyxNQUFNLE1BQU0sR0FBaUIsRUFBRSxDQUFDO1FBRWhDLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsTUFBTSxFQUFFLEVBQUU7WUFDckMsTUFBTSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxLQUFpQixFQUFFLEVBQUUsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUM7WUFDN0QsTUFBTSxDQUFDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDM0IsTUFBTSxDQUFDLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBQ3pELENBQUMsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztDQUNGO0FBL1FELG9DQStRQztBQUVEOztHQUVHO0FBQ1UsUUFBQSxvQkFBb0IsR0FBZ0I7SUFDL0MsTUFBTSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxJQUFJLFdBQVc7SUFDN0MsT0FBTyxFQUFFLHNCQUFPLENBQUMsTUFBTTtJQUN2QixNQUFNLEVBQUUscUJBQU0sQ0FBQyxNQUFNO0lBQ3JCLFlBQVksRUFBRSwyQkFBWSxDQUFDLEdBQUc7SUFDOUIsVUFBVSxFQUFFLE1BQU07Q0FDbkIsQ0FBQyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQW1hem9uIFBvbGx5IFRleHQtdG8tU3BlZWNoIFNlcnZpY2VcbiAqIEhhbmRsZXMgY29udmVyc2lvbiBvZiBBSSByZXNwb25zZXMgdG8gbmF0dXJhbCBzcGVlY2ggYXVkaW9cbiAqL1xuXG5pbXBvcnQgeyBcbiAgUG9sbHlDbGllbnQsIFxuICBTeW50aGVzaXplU3BlZWNoQ29tbWFuZCwgXG4gIFN5bnRoZXNpemVTcGVlY2hJbnB1dCxcbiAgT3V0cHV0Rm9ybWF0LFxuICBWb2ljZUlkLFxuICBFbmdpbmVcbn0gZnJvbSAnQGF3cy1zZGsvY2xpZW50LXBvbGx5JztcbmltcG9ydCB7IFMzU2VydmljZSB9IGZyb20gJy4vczMtc2VydmljZSc7XG5cbmV4cG9ydCBpbnRlcmZhY2UgUG9sbHlDb25maWcge1xuICByZWdpb246IHN0cmluZztcbiAgdm9pY2VJZDogVm9pY2VJZDtcbiAgZW5naW5lOiBFbmdpbmU7XG4gIG91dHB1dEZvcm1hdDogT3V0cHV0Rm9ybWF0O1xuICBzYW1wbGVSYXRlOiBzdHJpbmc7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgU3BlZWNoU3ludGhlc2lzUmVzdWx0IHtcbiAgYXVkaW9Vcmw6IHN0cmluZztcbiAgYXVkaW9LZXk6IHN0cmluZztcbiAgcGxheWJhY2tVcmw/OiBzdHJpbmc7IC8vIFByZXNpZ25lZCBVUkwgZm9yIHRlbGVwaG9ueSBwbGF5YmFja1xuICBkdXJhdGlvbj86IG51bWJlcjtcbiAgdGV4dDogc3RyaW5nO1xuICBzc21sVGV4dD86IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBTU01MT3B0aW9ucyB7XG4gIHNwZWVjaFJhdGU/OiAneC1zbG93JyB8ICdzbG93JyB8ICdtZWRpdW0nIHwgJ2Zhc3QnIHwgJ3gtZmFzdCc7XG4gIHZvbHVtZT86ICdzaWxlbnQnIHwgJ3gtc29mdCcgfCAnc29mdCcgfCAnbWVkaXVtJyB8ICdsb3VkJyB8ICd4LWxvdWQnO1xuICBhZGRQYXVzZXM/OiBib29sZWFuO1xuICBlbXBoYXNpemVJbXBvcnRhbnQ/OiBib29sZWFuO1xuICB0ZWxlcGhvbnlPcHRpbWl6ZWQ/OiBib29sZWFuO1xufVxuXG5leHBvcnQgY2xhc3MgUG9sbHlTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBwb2xseUNsaWVudDogUG9sbHlDbGllbnQ7XG4gIHByaXZhdGUgczNTZXJ2aWNlOiBTM1NlcnZpY2U7XG4gIHByaXZhdGUgY29uZmlnOiBQb2xseUNvbmZpZztcblxuICBjb25zdHJ1Y3Rvcihjb25maWc6IFBvbGx5Q29uZmlnLCBzM1NlcnZpY2U6IFMzU2VydmljZSkge1xuICAgIHRoaXMuY29uZmlnID0gY29uZmlnO1xuICAgIHRoaXMuczNTZXJ2aWNlID0gczNTZXJ2aWNlO1xuICAgIHRoaXMucG9sbHlDbGllbnQgPSBuZXcgUG9sbHlDbGllbnQoeyBcbiAgICAgIHJlZ2lvbjogY29uZmlnLnJlZ2lvbiBcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDb252ZXJ0IHRleHQgdG8gc3BlZWNoIHVzaW5nIEFtYXpvbiBQb2xseSB3aXRoIG9wdGlvbmFsIFNTTUwgZm9ybWF0dGluZ1xuICAgKi9cbiAgYXN5bmMgc3ludGhlc2l6ZVNwZWVjaChcbiAgICB0ZXh0OiBzdHJpbmcsIFxuICAgIHNlc3Npb25JZDogc3RyaW5nLFxuICAgIG9wdGlvbnM/OiBQYXJ0aWFsPFBvbGx5Q29uZmlnPixcbiAgICBzc21sT3B0aW9ucz86IFNTTUxPcHRpb25zXG4gICk6IFByb21pc2U8U3BlZWNoU3ludGhlc2lzUmVzdWx0PiB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIE1lcmdlIG9wdGlvbnMgd2l0aCBkZWZhdWx0IGNvbmZpZ1xuICAgICAgY29uc3Qgc3ludGhlc2lzQ29uZmlnID0geyAuLi50aGlzLmNvbmZpZywgLi4ub3B0aW9ucyB9O1xuICAgICAgXG4gICAgICAvLyBBcHBseSBTU01MIGZvcm1hdHRpbmcgaWYgcmVxdWVzdGVkXG4gICAgICBsZXQgcHJvY2Vzc2VkVGV4dCA9IHRleHQ7XG4gICAgICBsZXQgdGV4dFR5cGU6ICd0ZXh0JyB8ICdzc21sJyA9ICd0ZXh0JztcbiAgICAgIFxuICAgICAgaWYgKHNzbWxPcHRpb25zKSB7XG4gICAgICAgIHByb2Nlc3NlZFRleHQgPSB0aGlzLmZvcm1hdFdpdGhTU01MKHRleHQsIHNzbWxPcHRpb25zKTtcbiAgICAgICAgdGV4dFR5cGUgPSAnc3NtbCc7XG4gICAgICB9XG4gICAgICBcbiAgICAgIC8vIFByZXBhcmUgUG9sbHkgc3ludGhlc2lzIHBhcmFtZXRlcnNcbiAgICAgIGNvbnN0IHBhcmFtczogU3ludGhlc2l6ZVNwZWVjaElucHV0ID0ge1xuICAgICAgICBUZXh0OiBwcm9jZXNzZWRUZXh0LFxuICAgICAgICBUZXh0VHlwZTogdGV4dFR5cGUsXG4gICAgICAgIFZvaWNlSWQ6IHN5bnRoZXNpc0NvbmZpZy52b2ljZUlkLFxuICAgICAgICBPdXRwdXRGb3JtYXQ6IHN5bnRoZXNpc0NvbmZpZy5vdXRwdXRGb3JtYXQsXG4gICAgICAgIEVuZ2luZTogc3ludGhlc2lzQ29uZmlnLmVuZ2luZSxcbiAgICAgICAgU2FtcGxlUmF0ZTogc3ludGhlc2lzQ29uZmlnLnNhbXBsZVJhdGVcbiAgICAgIH07XG5cbiAgICAgIGNvbnNvbGUubG9nKCdTeW50aGVzaXppbmcgc3BlZWNoIHdpdGggUG9sbHk6Jywge1xuICAgICAgICB0ZXh0TGVuZ3RoOiB0ZXh0Lmxlbmd0aCxcbiAgICAgICAgdm9pY2VJZDogc3ludGhlc2lzQ29uZmlnLnZvaWNlSWQsXG4gICAgICAgIG91dHB1dEZvcm1hdDogc3ludGhlc2lzQ29uZmlnLm91dHB1dEZvcm1hdFxuICAgICAgfSk7XG5cbiAgICAgIC8vIENhbGwgUG9sbHkgQVBJXG4gICAgICBjb25zdCBjb21tYW5kID0gbmV3IFN5bnRoZXNpemVTcGVlY2hDb21tYW5kKHBhcmFtcyk7XG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHRoaXMucG9sbHlDbGllbnQuc2VuZChjb21tYW5kKTtcblxuICAgICAgaWYgKCFyZXNwb25zZS5BdWRpb1N0cmVhbSkge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ05vIGF1ZGlvIHN0cmVhbSByZWNlaXZlZCBmcm9tIFBvbGx5Jyk7XG4gICAgICB9XG5cbiAgICAgIC8vIENvbnZlcnQgYXVkaW8gc3RyZWFtIHRvIGJ1ZmZlclxuICAgICAgY29uc3QgYXVkaW9CdWZmZXIgPSBhd2FpdCB0aGlzLnN0cmVhbVRvQnVmZmVyKHJlc3BvbnNlLkF1ZGlvU3RyZWFtKTtcbiAgICAgIFxuICAgICAgLy8gR2VuZXJhdGUgdW5pcXVlIGtleSBmb3IgYXVkaW8gZmlsZVxuICAgICAgY29uc3QgdGltZXN0YW1wID0gRGF0ZS5ub3coKTtcbiAgICAgIGNvbnN0IGF1ZGlvS2V5ID0gYHNwZWVjaC8ke3Nlc3Npb25JZH0vJHt0aW1lc3RhbXB9LiR7dGhpcy5nZXRGaWxlRXh0ZW5zaW9uKHN5bnRoZXNpc0NvbmZpZy5vdXRwdXRGb3JtYXQpfWA7XG4gICAgICBcbiAgICAgIC8vIFVwbG9hZCB0byBTM1xuICAgICAgY29uc3QgYXVkaW9VcmwgPSBhd2FpdCB0aGlzLnMzU2VydmljZS51cGxvYWRBdWRpb0ZpbGUoXG4gICAgICAgIGF1ZGlvQnVmZmVyLFxuICAgICAgICBhdWRpb0tleVxuICAgICAgKTtcblxuICAgICAgLy8gR2VuZXJhdGUgcHJlc2lnbmVkIFVSTCBmb3IgdGVsZXBob255IHBsYXliYWNrXG4gICAgICBjb25zdCBwbGF5YmFja1VybCA9IGF3YWl0IHRoaXMuczNTZXJ2aWNlLmdldFRlbGVwaG9ueVBsYXliYWNrVXJsKGF1ZGlvS2V5KTtcblxuICAgICAgY29uc29sZS5sb2coJ1NwZWVjaCBzeW50aGVzaXMgY29tcGxldGVkOicsIHtcbiAgICAgICAgYXVkaW9LZXksXG4gICAgICAgIGF1ZGlvVXJsLFxuICAgICAgICBwbGF5YmFja1VybCxcbiAgICAgICAgYXVkaW9TaXplOiBhdWRpb0J1ZmZlci5sZW5ndGhcbiAgICAgIH0pO1xuXG4gICAgICByZXR1cm4ge1xuICAgICAgICBhdWRpb1VybCxcbiAgICAgICAgYXVkaW9LZXksXG4gICAgICAgIHBsYXliYWNrVXJsLFxuICAgICAgICB0ZXh0LFxuICAgICAgICBzc21sVGV4dDogdGV4dFR5cGUgPT09ICdzc21sJyA/IHByb2Nlc3NlZFRleHQgOiB1bmRlZmluZWQsXG4gICAgICAgIGR1cmF0aW9uOiB0aGlzLmVzdGltYXRlRHVyYXRpb24odGV4dClcbiAgICAgIH07XG5cbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3Igc3ludGhlc2l6aW5nIHNwZWVjaDonLCBlcnJvcik7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYFNwZWVjaCBzeW50aGVzaXMgZmFpbGVkOiAke2Vycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5tZXNzYWdlIDogJ1Vua25vd24gZXJyb3InfWApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBGb3JtYXQgdGV4dCB3aXRoIFNTTUwgdGFncyBmb3IgZW5oYW5jZWQgc3BlZWNoIHN5bnRoZXNpc1xuICAgKi9cbiAgZm9ybWF0V2l0aFNTTUwodGV4dDogc3RyaW5nLCBvcHRpb25zOiBTU01MT3B0aW9ucyk6IHN0cmluZyB7XG4gICAgbGV0IHNzbWxUZXh0ID0gdGV4dDtcbiAgICBcbiAgICAvLyBBcHBseSB0ZWxlcGhvbnkgb3B0aW1pemF0aW9uIGlmIHJlcXVlc3RlZFxuICAgIGlmIChvcHRpb25zLnRlbGVwaG9ueU9wdGltaXplZCkge1xuICAgICAgY29uc3QgdGVsZXBob255T3B0aW9ucyA9IHRoaXMuZ2V0VGVsZXBob255U1NNTE9wdGlvbnMoKTtcbiAgICAgIG9wdGlvbnMgPSB7IC4uLnRlbGVwaG9ueU9wdGlvbnMsIC4uLm9wdGlvbnMgfTtcbiAgICB9XG4gICAgXG4gICAgLy8gQWRkIGVtcGhhc2lzIHRvIGltcG9ydGFudCB3b3JkcyAod29yZHMgaW4gY2FwcyBvciB3aXRoIGV4Y2xhbWF0aW9uKVxuICAgIGlmIChvcHRpb25zLmVtcGhhc2l6ZUltcG9ydGFudCkge1xuICAgICAgc3NtbFRleHQgPSBzc21sVGV4dC5yZXBsYWNlKC9cXGJbQS1aXXsyLH1cXGIvZywgJzxlbXBoYXNpcyBsZXZlbD1cInN0cm9uZ1wiPiQmPC9lbXBoYXNpcz4nKTtcbiAgICAgIHNzbWxUZXh0ID0gc3NtbFRleHQucmVwbGFjZSgvKFxcdyspIS9nLCAnPGVtcGhhc2lzIGxldmVsPVwibW9kZXJhdGVcIj4kMTwvZW1waGFzaXM+IScpO1xuICAgIH1cbiAgICBcbiAgICAvLyBBZGQgcGF1c2VzIGZvciBiZXR0ZXIgY29tcHJlaGVuc2lvblxuICAgIGlmIChvcHRpb25zLmFkZFBhdXNlcykge1xuICAgICAgc3NtbFRleHQgPSBzc21sVGV4dC5yZXBsYWNlKC9cXC4gL2csICcuIDxicmVhayB0aW1lPVwiNTAwbXNcIi8+Jyk7XG4gICAgICBzc21sVGV4dCA9IHNzbWxUZXh0LnJlcGxhY2UoL1xcPyAvZywgJz8gPGJyZWFrIHRpbWU9XCI1MDBtc1wiLz4nKTtcbiAgICAgIHNzbWxUZXh0ID0gc3NtbFRleHQucmVwbGFjZSgvISAvZywgJyEgPGJyZWFrIHRpbWU9XCIzMDBtc1wiLz4nKTtcbiAgICAgIHNzbWxUZXh0ID0gc3NtbFRleHQucmVwbGFjZSgvLC9nLCAnLDxicmVhayB0aW1lPVwiMjAwbXNcIi8+Jyk7XG4gICAgfVxuICAgIFxuICAgIC8vIFdyYXAgaW4gcHJvc29keSB0YWdzIGZvciBzcGVlY2ggcmF0ZSBhbmQgdm9sdW1lXG4gICAgaWYgKG9wdGlvbnMuc3BlZWNoUmF0ZSB8fCBvcHRpb25zLnZvbHVtZSkge1xuICAgICAgY29uc3QgcHJvc29keUF0dHJzID0gW107XG4gICAgICBpZiAob3B0aW9ucy5zcGVlY2hSYXRlKSBwcm9zb2R5QXR0cnMucHVzaChgcmF0ZT1cIiR7b3B0aW9ucy5zcGVlY2hSYXRlfVwiYCk7XG4gICAgICBpZiAob3B0aW9ucy52b2x1bWUpIHByb3NvZHlBdHRycy5wdXNoKGB2b2x1bWU9XCIke29wdGlvbnMudm9sdW1lfVwiYCk7XG4gICAgICBcbiAgICAgIHNzbWxUZXh0ID0gYDxwcm9zb2R5ICR7cHJvc29keUF0dHJzLmpvaW4oJyAnKX0+JHtzc21sVGV4dH08L3Byb3NvZHk+YDtcbiAgICB9XG4gICAgXG4gICAgLy8gV3JhcCBpbiBTU01MIHNwZWFrIHRhZ3NcbiAgICBzc21sVGV4dCA9IGA8c3BlYWs+JHtzc21sVGV4dH08L3NwZWFrPmA7XG4gICAgXG4gICAgcmV0dXJuIHNzbWxUZXh0O1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBTU01MIG9wdGlvbnMgb3B0aW1pemVkIGZvciB0ZWxlcGhvbnlcbiAgICovXG4gIGdldFRlbGVwaG9ueVNTTUxPcHRpb25zKCk6IFNTTUxPcHRpb25zIHtcbiAgICByZXR1cm4ge1xuICAgICAgc3BlZWNoUmF0ZTogJ21lZGl1bScsXG4gICAgICB2b2x1bWU6ICdsb3VkJyxcbiAgICAgIGFkZFBhdXNlczogdHJ1ZSxcbiAgICAgIGVtcGhhc2l6ZUltcG9ydGFudDogZmFsc2UsIC8vIEtlZXAgaXQgc2ltcGxlIGZvciBwaG9uZSBjYWxsc1xuICAgICAgdGVsZXBob255T3B0aW1pemVkOiB0cnVlXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBPcHRpbWl6ZSB0ZXh0IGZvciBwaG9uZSBjYWxsIGNsYXJpdHkgKHByZS1TU01MIHByb2Nlc3NpbmcpXG4gICAqL1xuICBvcHRpbWl6ZUZvclRlbGVwaG9ueSh0ZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIGxldCBvcHRpbWl6ZWQgPSB0ZXh0O1xuICAgIFxuICAgIC8vIFJlcGxhY2UgY29tbW9uIGFiYnJldmlhdGlvbnMgd2l0aCBmdWxsIHdvcmRzXG4gICAgb3B0aW1pemVkID0gb3B0aW1pemVkLnJlcGxhY2UoL1xcYkRyXFwuL2csICdEb2N0b3InKTtcbiAgICBvcHRpbWl6ZWQgPSBvcHRpbWl6ZWQucmVwbGFjZSgvXFxiTXJcXC4vZywgJ01pc3RlcicpO1xuICAgIG9wdGltaXplZCA9IG9wdGltaXplZC5yZXBsYWNlKC9cXGJNcnNcXC4vZywgJ01pc3N1cycpO1xuICAgIG9wdGltaXplZCA9IG9wdGltaXplZC5yZXBsYWNlKC9cXGJNc1xcLi9nLCAnTWlzcycpO1xuICAgIG9wdGltaXplZCA9IG9wdGltaXplZC5yZXBsYWNlKC9cXGJldGNcXC4vZywgJ2V0Y2V0ZXJhJyk7XG4gICAgb3B0aW1pemVkID0gb3B0aW1pemVkLnJlcGxhY2UoL1xcYmVcXC5nXFwuL2csICdmb3IgZXhhbXBsZScpO1xuICAgIG9wdGltaXplZCA9IG9wdGltaXplZC5yZXBsYWNlKC9cXGJpXFwuZVxcLi9nLCAndGhhdCBpcycpO1xuICAgIFxuICAgIC8vIFJlcGxhY2UgbnVtYmVycyB3aXRoIHdvcmRzIGZvciBiZXR0ZXIgcHJvbnVuY2lhdGlvblxuICAgIG9wdGltaXplZCA9IG9wdGltaXplZC5yZXBsYWNlKC9cXGIoXFxkezEsMn0pXFxiL2csIChtYXRjaCwgbnVtKSA9PiB7XG4gICAgICBjb25zdCBudW1iZXJzID0gWyd6ZXJvJywgJ29uZScsICd0d28nLCAndGhyZWUnLCAnZm91cicsICdmaXZlJywgJ3NpeCcsICdzZXZlbicsICdlaWdodCcsICduaW5lJywgJ3RlbicsXG4gICAgICAgICAgICAgICAgICAgICAgJ2VsZXZlbicsICd0d2VsdmUnLCAndGhpcnRlZW4nLCAnZm91cnRlZW4nLCAnZmlmdGVlbicsICdzaXh0ZWVuJywgJ3NldmVudGVlbicsICdlaWdodGVlbicsICduaW5ldGVlbiddO1xuICAgICAgY29uc3QgbiA9IHBhcnNlSW50KG51bSk7XG4gICAgICByZXR1cm4gbiA8IDIwID8gbnVtYmVyc1tuXSA6IG1hdGNoO1xuICAgIH0pO1xuICAgIFxuICAgIC8vIEFkZCBwcm9udW5jaWF0aW9uIGhpbnRzIGZvciBjb21tb24gdGVjaG5pY2FsIHRlcm1zXG4gICAgb3B0aW1pemVkID0gb3B0aW1pemVkLnJlcGxhY2UoL1xcYkFQSVxcYi9nLCAnPHBob25lbWUgYWxwaGFiZXQ9XCJpcGFcIiBwaD1cImXJqi5waS5hyapcIj5BUEk8L3Bob25lbWU+Jyk7XG4gICAgb3B0aW1pemVkID0gb3B0aW1pemVkLnJlcGxhY2UoL1xcYlVSTFxcYi9nLCAnPHBob25lbWUgYWxwaGFiZXQ9XCJpcGFcIiBwaD1cImrKii7JkXIuyZtsXCI+VVJMPC9waG9uZW1lPicpO1xuICAgIG9wdGltaXplZCA9IG9wdGltaXplZC5yZXBsYWNlKC9cXGJBSVxcYi9nLCAnPHBob25lbWUgYWxwaGFiZXQ9XCJpcGFcIiBwaD1cImXJqi5hyapcIj5BSTwvcGhvbmVtZT4nKTtcbiAgICBcbiAgICByZXR1cm4gb3B0aW1pemVkO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBvcHRpbWFsIHZvaWNlIGZvciB0ZWxlcGhvbnlcbiAgICovXG4gIGdldE9wdGltYWxWb2ljZSgpOiBWb2ljZUlkIHtcbiAgICAvLyBKb2FubmEgYW5kIE1hdHRoZXcgYXJlIG9wdGltaXplZCBmb3IgdGVsZXBob255XG4gICAgcmV0dXJuIFZvaWNlSWQuSm9hbm5hO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCB0ZWxlcGhvbnktb3B0aW1pemVkIGNvbmZpZ3VyYXRpb25cbiAgICovXG4gIGdldFRlbGVwaG9ueUNvbmZpZygpOiBQYXJ0aWFsPFBvbGx5Q29uZmlnPiB7XG4gICAgcmV0dXJuIHtcbiAgICAgIHZvaWNlSWQ6IFZvaWNlSWQuSm9hbm5hLFxuICAgICAgZW5naW5lOiBFbmdpbmUuTkVVUkFMLFxuICAgICAgb3V0cHV0Rm9ybWF0OiBPdXRwdXRGb3JtYXQuTVAzLFxuICAgICAgc2FtcGxlUmF0ZTogJzgwMDAnIC8vIDhrSHogaXMgc3RhbmRhcmQgZm9yIHRlbGVwaG9ueVxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogRXN0aW1hdGUgc3BlZWNoIGR1cmF0aW9uIGJhc2VkIG9uIHRleHQgbGVuZ3RoXG4gICAqIEF2ZXJhZ2Ugc3BlYWtpbmcgcmF0ZSBpcyB+MTUwIHdvcmRzIHBlciBtaW51dGVcbiAgICovXG4gIHByaXZhdGUgZXN0aW1hdGVEdXJhdGlvbih0ZXh0OiBzdHJpbmcpOiBudW1iZXIge1xuICAgIGNvbnN0IHdvcmRDb3VudCA9IHRleHQuc3BsaXQoL1xccysvKS5sZW5ndGg7XG4gICAgY29uc3Qgd29yZHNQZXJNaW51dGUgPSAxNTA7XG4gICAgcmV0dXJuIE1hdGguY2VpbCgod29yZENvdW50IC8gd29yZHNQZXJNaW51dGUpICogNjApOyAvLyBEdXJhdGlvbiBpbiBzZWNvbmRzXG4gIH1cblxuICAvKipcbiAgICogR2V0IGZpbGUgZXh0ZW5zaW9uIGZvciBvdXRwdXQgZm9ybWF0XG4gICAqL1xuICBwcml2YXRlIGdldEZpbGVFeHRlbnNpb24oZm9ybWF0OiBPdXRwdXRGb3JtYXQpOiBzdHJpbmcge1xuICAgIHN3aXRjaCAoZm9ybWF0KSB7XG4gICAgICBjYXNlIE91dHB1dEZvcm1hdC5NUDM6XG4gICAgICAgIHJldHVybiAnbXAzJztcbiAgICAgIGNhc2UgT3V0cHV0Rm9ybWF0Lk9HR19WT1JCSVM6XG4gICAgICAgIHJldHVybiAnb2dnJztcbiAgICAgIGNhc2UgT3V0cHV0Rm9ybWF0LlBDTTpcbiAgICAgICAgcmV0dXJuICdwY20nO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcmV0dXJuICdtcDMnO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBDbGVhbiB1cCBvbGQgc3BlZWNoIHN5bnRoZXNpcyBmaWxlcyBmb3IgYSBzZXNzaW9uXG4gICAqL1xuICBhc3luYyBjbGVhbnVwU2Vzc2lvbkF1ZGlvKHNlc3Npb25JZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIFRoaXMgd291bGQgdHlwaWNhbGx5IGJlIGhhbmRsZWQgYnkgUzMgbGlmZWN5Y2xlIHBvbGljaWVzXG4gICAgICAvLyBCdXQgd2UgY2FuIGltcGxlbWVudCBtYW51YWwgY2xlYW51cCBpZiBuZWVkZWRcbiAgICAgIGNvbnNvbGUubG9nKGBBdWRpbyBjbGVhbnVwIGZvciBzZXNzaW9uICR7c2Vzc2lvbklkfSBoYW5kbGVkIGJ5IFMzIGxpZmVjeWNsZSBwb2xpY2llc2ApO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBjbGVhbmluZyB1cCBzZXNzaW9uIGF1ZGlvOicsIGVycm9yKTtcbiAgICAgIC8vIERvbid0IHRocm93IC0gY2xlYW51cCBmYWlsdXJlcyBzaG91bGRuJ3QgYnJlYWsgdGhlIG1haW4gZmxvd1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgYXVkaW8gZmlsZSBtZXRhZGF0YVxuICAgKi9cbiAgYXN5bmMgZ2V0QXVkaW9NZXRhZGF0YShhdWRpb0tleTogc3RyaW5nKTogUHJvbWlzZTxhbnk+IHtcbiAgICB0cnkge1xuICAgICAgLy8gVGhpcyBjb3VsZCBiZSBleHRlbmRlZCB0byBnZXQgZmlsZSBtZXRhZGF0YSBmcm9tIFMzXG4gICAgICByZXR1cm4ge1xuICAgICAgICBrZXk6IGF1ZGlvS2V5LFxuICAgICAgICB0eXBlOiAnc3BlZWNoX3N5bnRoZXNpcycsXG4gICAgICAgIGNyZWF0ZWRBdDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpXG4gICAgICB9O1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciBnZXR0aW5nIGF1ZGlvIG1ldGFkYXRhOicsIGVycm9yKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIGdldCBhdWRpbyBtZXRhZGF0YTogJHtlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICdVbmtub3duIGVycm9yJ31gKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQ29udmVydCByZWFkYWJsZSBzdHJlYW0gdG8gYnVmZmVyXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIHN0cmVhbVRvQnVmZmVyKHN0cmVhbTogYW55KTogUHJvbWlzZTxCdWZmZXI+IHtcbiAgICBjb25zdCBjaHVua3M6IFVpbnQ4QXJyYXlbXSA9IFtdO1xuICAgIFxuICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICBzdHJlYW0ub24oJ2RhdGEnLCAoY2h1bms6IFVpbnQ4QXJyYXkpID0+IGNodW5rcy5wdXNoKGNodW5rKSk7XG4gICAgICBzdHJlYW0ub24oJ2Vycm9yJywgcmVqZWN0KTtcbiAgICAgIHN0cmVhbS5vbignZW5kJywgKCkgPT4gcmVzb2x2ZShCdWZmZXIuY29uY2F0KGNodW5rcykpKTtcbiAgICB9KTtcbiAgfVxufVxuXG4vKipcbiAqIERlZmF1bHQgUG9sbHkgY29uZmlndXJhdGlvbiBvcHRpbWl6ZWQgZm9yIHRlbGVwaG9ueVxuICovXG5leHBvcnQgY29uc3QgREVGQVVMVF9QT0xMWV9DT05GSUc6IFBvbGx5Q29uZmlnID0ge1xuICByZWdpb246IHByb2Nlc3MuZW52LkFXU19SRUdJT04gfHwgJ3VzLWVhc3QtMScsXG4gIHZvaWNlSWQ6IFZvaWNlSWQuSm9hbm5hLFxuICBlbmdpbmU6IEVuZ2luZS5ORVVSQUwsXG4gIG91dHB1dEZvcm1hdDogT3V0cHV0Rm9ybWF0Lk1QMyxcbiAgc2FtcGxlUmF0ZTogJzgwMDAnXG59OyJdfQ==