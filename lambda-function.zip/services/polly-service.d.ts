/**
 * Amazon Polly Text-to-Speech Service
 * Handles conversion of AI responses to natural speech audio
 */
import { OutputFormat, VoiceId, Engine } from '@aws-sdk/client-polly';
import { S3Service } from './s3-service';
export interface PollyConfig {
    region: string;
    voiceId: VoiceId;
    engine: Engine;
    outputFormat: OutputFormat;
    sampleRate: string;
}
export interface SpeechSynthesisResult {
    audioUrl: string;
    audioKey: string;
    playbackUrl?: string;
    duration?: number;
    text: string;
    ssmlText?: string;
}
export interface SSMLOptions {
    speechRate?: 'x-slow' | 'slow' | 'medium' | 'fast' | 'x-fast';
    volume?: 'silent' | 'x-soft' | 'soft' | 'medium' | 'loud' | 'x-loud';
    addPauses?: boolean;
    emphasizeImportant?: boolean;
    telephonyOptimized?: boolean;
}
export declare class PollyService {
    private pollyClient;
    private s3Service;
    private config;
    constructor(config: PollyConfig, s3Service: S3Service);
    /**
     * Convert text to speech using Amazon Polly with optional SSML formatting
     */
    synthesizeSpeech(text: string, sessionId: string, options?: Partial<PollyConfig>, ssmlOptions?: SSMLOptions): Promise<SpeechSynthesisResult>;
    /**
     * Format text with SSML tags for enhanced speech synthesis
     */
    formatWithSSML(text: string, options: SSMLOptions): string;
    /**
     * Get SSML options optimized for telephony
     */
    getTelephonySSMLOptions(): SSMLOptions;
    /**
     * Optimize text for phone call clarity (pre-SSML processing)
     */
    optimizeForTelephony(text: string): string;
    /**
     * Get optimal voice for telephony
     */
    getOptimalVoice(): VoiceId;
    /**
     * Get telephony-optimized configuration
     */
    getTelephonyConfig(): Partial<PollyConfig>;
    /**
     * Estimate speech duration based on text length
     * Average speaking rate is ~150 words per minute
     */
    private estimateDuration;
    /**
     * Get file extension for output format
     */
    private getFileExtension;
    /**
     * Clean up old speech synthesis files for a session
     */
    cleanupSessionAudio(sessionId: string): Promise<void>;
    /**
     * Get audio file metadata
     */
    getAudioMetadata(audioKey: string): Promise<any>;
    /**
     * Convert readable stream to buffer
     */
    private streamToBuffer;
}
/**
 * Default Polly configuration optimized for telephony
 */
export declare const DEFAULT_POLLY_CONFIG: PollyConfig;
