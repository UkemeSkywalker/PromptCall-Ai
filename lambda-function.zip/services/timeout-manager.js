"use strict";
/**
 * Timeout and Inactivity Management Service
 *
 * Handles user silence detection, timeout scenarios, and graceful conversation ending
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.TimeoutManager = void 0;
class TimeoutManager {
    constructor(sessionManager, config = {}) {
        this.timeoutStates = new Map();
        this.sessionManager = sessionManager;
        this.config = {
            initialTimeoutSeconds: 10,
            maxTimeoutSeconds: 20,
            inactivityWarningSeconds: 30,
            maxInactivityAttempts: 2,
            gracefulEndingTimeoutSeconds: 15,
            ...config
        };
    }
    /**
     * Handle timeout scenario when user doesn't respond
     */
    async handleTimeout(sessionId, callSid) {
        console.log(`⏰ TIMEOUT: Handling timeout for session ${sessionId}`);
        // Get or create timeout state
        let timeoutState = this.timeoutStates.get(sessionId);
        if (!timeoutState) {
            timeoutState = this.initializeTimeoutState(sessionId);
            this.timeoutStates.set(sessionId, timeoutState);
        }
        // Update timeout state
        timeoutState.consecutiveTimeouts++;
        timeoutState.totalInactiveTime += this.config.initialTimeoutSeconds;
        const currentTime = Date.now();
        console.log(`⏰ TIMEOUT STATE: Consecutive timeouts: ${timeoutState.consecutiveTimeouts}, Total inactive: ${timeoutState.totalInactiveTime}s`);
        // Determine action based on timeout state
        if (timeoutState.consecutiveTimeouts === 1) {
            // First timeout - gentle prompt
            return await this.handleFirstTimeout(timeoutState, callSid);
        }
        else if (timeoutState.consecutiveTimeouts === 2) {
            // Second timeout - more direct prompt
            return await this.handleSecondTimeout(timeoutState, callSid);
        }
        else if (timeoutState.consecutiveTimeouts >= 3) {
            // Third timeout or more - graceful ending
            return await this.handleFinalTimeout(timeoutState, callSid);
        }
        // Default continue
        return {
            shouldContinue: true,
            twimlResponse: this.createContinueTwiML(),
            timeoutState,
            action: 'continue'
        };
    }
    /**
     * Handle user activity - reset timeout counters
     */
    async handleUserActivity(sessionId) {
        console.log(`✅ ACTIVITY: User activity detected for session ${sessionId}`);
        const timeoutState = this.timeoutStates.get(sessionId);
        if (timeoutState) {
            timeoutState.consecutiveTimeouts = 0;
            timeoutState.warningsSent = 0;
            timeoutState.lastActivityTime = Date.now();
            timeoutState.isInGracefulEnding = false;
            // Add system message about activity resumption
            await this.sessionManager.addSystemMessage(sessionId, 'User activity resumed - timeout counters reset');
        }
    }
    /**
     * Check if session should be ended due to prolonged inactivity
     */
    shouldEndSession(sessionId) {
        const timeoutState = this.timeoutStates.get(sessionId);
        if (!timeoutState)
            return false;
        const totalInactiveMinutes = timeoutState.totalInactiveTime / 60;
        const maxInactiveMinutes = 5; // End session after 5 minutes of total inactivity
        return totalInactiveMinutes >= maxInactiveMinutes ||
            timeoutState.consecutiveTimeouts >= 4;
    }
    /**
     * Get appropriate timeout duration based on conversation state
     */
    getTimeoutDuration(conversationPhase, consecutiveTimeouts) {
        const baseTimeout = this.config.initialTimeoutSeconds;
        // Increase timeout for later conversation phases
        const phaseMultiplier = {
            'greeting': 1.0,
            'conversation': 1.2,
            'clarification': 1.5,
            'closing': 0.8
        }[conversationPhase] || 1.0;
        // Decrease timeout after multiple timeouts to end conversation sooner
        const timeoutMultiplier = Math.max(0.5, 1.0 - (consecutiveTimeouts * 0.2));
        return Math.round(baseTimeout * phaseMultiplier * timeoutMultiplier);
    }
    initializeTimeoutState(sessionId) {
        return {
            sessionId,
            consecutiveTimeouts: 0,
            lastActivityTime: Date.now(),
            warningsSent: 0,
            isInGracefulEnding: false,
            totalInactiveTime: 0
        };
    }
    async handleFirstTimeout(timeoutState, callSid) {
        console.log(`⏰ FIRST TIMEOUT: Sending gentle prompt`);
        await this.sessionManager.addSystemMessage(timeoutState.sessionId, 'First timeout - sending gentle prompt');
        const twimlResponse = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" rate="1">
    I'm here and ready to help. Please let me know what you'd like to ask about.
  </Say>
  <Record 
    action="https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/speech" 
    method="POST" 
    maxLength="30" 
    timeout="15"
    playBeep="true"
    recordingStatusCallback="https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/events"
    recordingStatusCallbackMethod="POST"
  />
</Response>`;
        return {
            shouldContinue: true,
            twimlResponse,
            timeoutState,
            action: 'warn'
        };
    }
    async handleSecondTimeout(timeoutState, callSid) {
        console.log(`⏰ SECOND TIMEOUT: Sending more direct prompt`);
        await this.sessionManager.addSystemMessage(timeoutState.sessionId, 'Second timeout - sending direct prompt');
        const twimlResponse = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" rate="1">
    Are you still there? If you need help, please speak after the beep. 
    If you're finished, you can hang up at any time.
  </Say>
  <Record 
    action="https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/speech" 
    method="POST" 
    maxLength="20" 
    timeout="12"
    playBeep="true"
    recordingStatusCallback="https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/events"
    recordingStatusCallbackMethod="POST"
  />
</Response>`;
        return {
            shouldContinue: true,
            twimlResponse,
            timeoutState,
            action: 'warn'
        };
    }
    async handleFinalTimeout(timeoutState, callSid) {
        console.log(`⏰ FINAL TIMEOUT: Ending conversation gracefully`);
        timeoutState.isInGracefulEnding = true;
        await this.sessionManager.addSystemMessage(timeoutState.sessionId, 'Final timeout - ending conversation gracefully');
        // Update session status to completed due to timeout
        await this.sessionManager.updateSessionStatus(timeoutState.sessionId, 'completed', Date.now(), { code: 'timeout', message: 'Session ended due to user inactivity' });
        const twimlResponse = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" rate="1">
    It seems like you might be busy right now. Thank you for using PromptCall AI. 
    Feel free to call back anytime if you need assistance. Goodbye!
  </Say>
  <Hangup/>
</Response>`;
        return {
            shouldContinue: false,
            twimlResponse,
            timeoutState,
            action: 'end_gracefully'
        };
    }
    createContinueTwiML() {
        return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice">
    Please let me know how I can help you.
  </Say>
  <Record 
    action="https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/speech" 
    method="POST" 
    maxLength="30" 
    timeout="10"
    playBeep="true"
    recordingStatusCallback="https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/events"
    recordingStatusCallbackMethod="POST"
  />
</Response>`;
    }
    /**
     * Clean up timeout state when session ends
     */
    cleanupSession(sessionId) {
        this.timeoutStates.delete(sessionId);
        console.log(`🧹 CLEANUP: Removed timeout state for session ${sessionId}`);
    }
    /**
     * Get current timeout state for monitoring
     */
    getTimeoutState(sessionId) {
        return this.timeoutStates.get(sessionId) || null;
    }
}
exports.TimeoutManager = TimeoutManager;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidGltZW91dC1tYW5hZ2VyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL3NlcnZpY2VzL3RpbWVvdXQtbWFuYWdlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7R0FJRzs7O0FBNEJILE1BQWEsY0FBYztJQUt6QixZQUNFLGNBQW9DLEVBQ3BDLFNBQWlDLEVBQUU7UUFKN0Isa0JBQWEsR0FBOEIsSUFBSSxHQUFHLEVBQUUsQ0FBQztRQU0zRCxJQUFJLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQztRQUNyQyxJQUFJLENBQUMsTUFBTSxHQUFHO1lBQ1oscUJBQXFCLEVBQUUsRUFBRTtZQUN6QixpQkFBaUIsRUFBRSxFQUFFO1lBQ3JCLHdCQUF3QixFQUFFLEVBQUU7WUFDNUIscUJBQXFCLEVBQUUsQ0FBQztZQUN4Qiw0QkFBNEIsRUFBRSxFQUFFO1lBQ2hDLEdBQUcsTUFBTTtTQUNWLENBQUM7SUFDSixDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsYUFBYSxDQUFDLFNBQWlCLEVBQUUsT0FBZTtRQUNwRCxPQUFPLENBQUMsR0FBRyxDQUFDLDJDQUEyQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBRXBFLDhCQUE4QjtRQUM5QixJQUFJLFlBQVksR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNyRCxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUM7WUFDbEIsWUFBWSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztZQUN0RCxJQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsWUFBWSxDQUFDLENBQUM7UUFDbEQsQ0FBQztRQUVELHVCQUF1QjtRQUN2QixZQUFZLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUNuQyxZQUFZLENBQUMsaUJBQWlCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQztRQUNwRSxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7UUFFL0IsT0FBTyxDQUFDLEdBQUcsQ0FBQywwQ0FBMEMsWUFBWSxDQUFDLG1CQUFtQixxQkFBcUIsWUFBWSxDQUFDLGlCQUFpQixHQUFHLENBQUMsQ0FBQztRQUU5SSwwQ0FBMEM7UUFDMUMsSUFBSSxZQUFZLENBQUMsbUJBQW1CLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDM0MsZ0NBQWdDO1lBQ2hDLE9BQU8sTUFBTSxJQUFJLENBQUMsa0JBQWtCLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFDO1FBQzlELENBQUM7YUFBTSxJQUFJLFlBQVksQ0FBQyxtQkFBbUIsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNsRCxzQ0FBc0M7WUFDdEMsT0FBTyxNQUFNLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUM7UUFDL0QsQ0FBQzthQUFNLElBQUksWUFBWSxDQUFDLG1CQUFtQixJQUFJLENBQUMsRUFBRSxDQUFDO1lBQ2pELDBDQUEwQztZQUMxQyxPQUFPLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQztRQUM5RCxDQUFDO1FBRUQsbUJBQW1CO1FBQ25CLE9BQU87WUFDTCxjQUFjLEVBQUUsSUFBSTtZQUNwQixhQUFhLEVBQUUsSUFBSSxDQUFDLG1CQUFtQixFQUFFO1lBQ3pDLFlBQVk7WUFDWixNQUFNLEVBQUUsVUFBVTtTQUNuQixDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGtCQUFrQixDQUFDLFNBQWlCO1FBQ3hDLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0RBQWtELFNBQVMsRUFBRSxDQUFDLENBQUM7UUFFM0UsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDdkQsSUFBSSxZQUFZLEVBQUUsQ0FBQztZQUNqQixZQUFZLENBQUMsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDO1lBQ3JDLFlBQVksQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDO1lBQzlCLFlBQVksQ0FBQyxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUM7WUFDM0MsWUFBWSxDQUFDLGtCQUFrQixHQUFHLEtBQUssQ0FBQztZQUV4QywrQ0FBK0M7WUFDL0MsTUFBTSxJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUN4QyxTQUFTLEVBQ1QsZ0RBQWdELENBQ2pELENBQUM7UUFDSixDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsZ0JBQWdCLENBQUMsU0FBaUI7UUFDaEMsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLENBQUM7UUFDdkQsSUFBSSxDQUFDLFlBQVk7WUFBRSxPQUFPLEtBQUssQ0FBQztRQUVoQyxNQUFNLG9CQUFvQixHQUFHLFlBQVksQ0FBQyxpQkFBaUIsR0FBRyxFQUFFLENBQUM7UUFDakUsTUFBTSxrQkFBa0IsR0FBRyxDQUFDLENBQUMsQ0FBQyxrREFBa0Q7UUFFaEYsT0FBTyxvQkFBb0IsSUFBSSxrQkFBa0I7WUFDMUMsWUFBWSxDQUFDLG1CQUFtQixJQUFJLENBQUMsQ0FBQztJQUMvQyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxrQkFBa0IsQ0FBQyxpQkFBeUIsRUFBRSxtQkFBMkI7UUFDdkUsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxxQkFBcUIsQ0FBQztRQUV0RCxpREFBaUQ7UUFDakQsTUFBTSxlQUFlLEdBQUc7WUFDdEIsVUFBVSxFQUFFLEdBQUc7WUFDZixjQUFjLEVBQUUsR0FBRztZQUNuQixlQUFlLEVBQUUsR0FBRztZQUNwQixTQUFTLEVBQUUsR0FBRztTQUNmLENBQUMsaUJBQWlCLENBQUMsSUFBSSxHQUFHLENBQUM7UUFFNUIsc0VBQXNFO1FBQ3RFLE1BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsR0FBRyxHQUFHLENBQUMsbUJBQW1CLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQztRQUUzRSxPQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLGVBQWUsR0FBRyxpQkFBaUIsQ0FBQyxDQUFDO0lBQ3ZFLENBQUM7SUFFTyxzQkFBc0IsQ0FBQyxTQUFpQjtRQUM5QyxPQUFPO1lBQ0wsU0FBUztZQUNULG1CQUFtQixFQUFFLENBQUM7WUFDdEIsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRTtZQUM1QixZQUFZLEVBQUUsQ0FBQztZQUNmLGtCQUFrQixFQUFFLEtBQUs7WUFDekIsaUJBQWlCLEVBQUUsQ0FBQztTQUNyQixDQUFDO0lBQ0osQ0FBQztJQUVPLEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxZQUEwQixFQUFFLE9BQWU7UUFDMUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3Q0FBd0MsQ0FBQyxDQUFDO1FBRXRELE1BQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FDeEMsWUFBWSxDQUFDLFNBQVMsRUFDdEIsdUNBQXVDLENBQ3hDLENBQUM7UUFFRixNQUFNLGFBQWEsR0FBRzs7Ozs7Ozs7Ozs7Ozs7WUFjZCxDQUFDO1FBRVQsT0FBTztZQUNMLGNBQWMsRUFBRSxJQUFJO1lBQ3BCLGFBQWE7WUFDYixZQUFZO1lBQ1osTUFBTSxFQUFFLE1BQU07U0FDZixDQUFDO0lBQ0osQ0FBQztJQUVPLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxZQUEwQixFQUFFLE9BQWU7UUFDM0UsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4Q0FBOEMsQ0FBQyxDQUFDO1FBRTVELE1BQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FDeEMsWUFBWSxDQUFDLFNBQVMsRUFDdEIsd0NBQXdDLENBQ3pDLENBQUM7UUFFRixNQUFNLGFBQWEsR0FBRzs7Ozs7Ozs7Ozs7Ozs7O1lBZWQsQ0FBQztRQUVULE9BQU87WUFDTCxjQUFjLEVBQUUsSUFBSTtZQUNwQixhQUFhO1lBQ2IsWUFBWTtZQUNaLE1BQU0sRUFBRSxNQUFNO1NBQ2YsQ0FBQztJQUNKLENBQUM7SUFFTyxLQUFLLENBQUMsa0JBQWtCLENBQUMsWUFBMEIsRUFBRSxPQUFlO1FBQzFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsaURBQWlELENBQUMsQ0FBQztRQUUvRCxZQUFZLENBQUMsa0JBQWtCLEdBQUcsSUFBSSxDQUFDO1FBRXZDLE1BQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FDeEMsWUFBWSxDQUFDLFNBQVMsRUFDdEIsZ0RBQWdELENBQ2pELENBQUM7UUFFRixvREFBb0Q7UUFDcEQsTUFBTSxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixDQUMzQyxZQUFZLENBQUMsU0FBUyxFQUN0QixXQUFXLEVBQ1gsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUNWLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsc0NBQXNDLEVBQUUsQ0FDckUsQ0FBQztRQUVGLE1BQU0sYUFBYSxHQUFHOzs7Ozs7O1lBT2QsQ0FBQztRQUVULE9BQU87WUFDTCxjQUFjLEVBQUUsS0FBSztZQUNyQixhQUFhO1lBQ2IsWUFBWTtZQUNaLE1BQU0sRUFBRSxnQkFBZ0I7U0FDekIsQ0FBQztJQUNKLENBQUM7SUFFTyxtQkFBbUI7UUFDekIsT0FBTzs7Ozs7Ozs7Ozs7Ozs7WUFjQyxDQUFDO0lBQ1gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsY0FBYyxDQUFDLFNBQWlCO1FBQzlCLElBQUksQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ3JDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaURBQWlELFNBQVMsRUFBRSxDQUFDLENBQUM7SUFDNUUsQ0FBQztJQUVEOztPQUVHO0lBQ0gsZUFBZSxDQUFDLFNBQWlCO1FBQy9CLE9BQU8sSUFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsU0FBUyxDQUFDLElBQUksSUFBSSxDQUFDO0lBQ25ELENBQUM7Q0FDRjtBQW5RRCx3Q0FtUUMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIFRpbWVvdXQgYW5kIEluYWN0aXZpdHkgTWFuYWdlbWVudCBTZXJ2aWNlXG4gKiBcbiAqIEhhbmRsZXMgdXNlciBzaWxlbmNlIGRldGVjdGlvbiwgdGltZW91dCBzY2VuYXJpb3MsIGFuZCBncmFjZWZ1bCBjb252ZXJzYXRpb24gZW5kaW5nXG4gKi9cblxuaW1wb3J0IHsgRHluYW1vU2Vzc2lvbk1hbmFnZXIgfSBmcm9tICcuL2R5bmFtby1zZXNzaW9uLW1hbmFnZXInO1xuXG5leHBvcnQgaW50ZXJmYWNlIFRpbWVvdXRDb25maWcge1xuICBpbml0aWFsVGltZW91dFNlY29uZHM6IG51bWJlcjtcbiAgbWF4VGltZW91dFNlY29uZHM6IG51bWJlcjtcbiAgaW5hY3Rpdml0eVdhcm5pbmdTZWNvbmRzOiBudW1iZXI7XG4gIG1heEluYWN0aXZpdHlBdHRlbXB0czogbnVtYmVyO1xuICBncmFjZWZ1bEVuZGluZ1RpbWVvdXRTZWNvbmRzOiBudW1iZXI7XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgVGltZW91dFN0YXRlIHtcbiAgc2Vzc2lvbklkOiBzdHJpbmc7XG4gIGNvbnNlY3V0aXZlVGltZW91dHM6IG51bWJlcjtcbiAgbGFzdEFjdGl2aXR5VGltZTogbnVtYmVyO1xuICB3YXJuaW5nc1NlbnQ6IG51bWJlcjtcbiAgaXNJbkdyYWNlZnVsRW5kaW5nOiBib29sZWFuO1xuICB0b3RhbEluYWN0aXZlVGltZTogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFRpbWVvdXRSZXN1bHQge1xuICBzaG91bGRDb250aW51ZTogYm9vbGVhbjtcbiAgdHdpbWxSZXNwb25zZTogc3RyaW5nO1xuICB0aW1lb3V0U3RhdGU6IFRpbWVvdXRTdGF0ZTtcbiAgYWN0aW9uOiAnY29udGludWUnIHwgJ3dhcm4nIHwgJ2VuZF9ncmFjZWZ1bGx5JyB8ICdlbmRfaW1tZWRpYXRlbHknO1xufVxuXG5leHBvcnQgY2xhc3MgVGltZW91dE1hbmFnZXIge1xuICBwcml2YXRlIHNlc3Npb25NYW5hZ2VyOiBEeW5hbW9TZXNzaW9uTWFuYWdlcjtcbiAgcHJpdmF0ZSBjb25maWc6IFRpbWVvdXRDb25maWc7XG4gIHByaXZhdGUgdGltZW91dFN0YXRlczogTWFwPHN0cmluZywgVGltZW91dFN0YXRlPiA9IG5ldyBNYXAoKTtcblxuICBjb25zdHJ1Y3RvcihcbiAgICBzZXNzaW9uTWFuYWdlcjogRHluYW1vU2Vzc2lvbk1hbmFnZXIsXG4gICAgY29uZmlnOiBQYXJ0aWFsPFRpbWVvdXRDb25maWc+ID0ge31cbiAgKSB7XG4gICAgdGhpcy5zZXNzaW9uTWFuYWdlciA9IHNlc3Npb25NYW5hZ2VyO1xuICAgIHRoaXMuY29uZmlnID0ge1xuICAgICAgaW5pdGlhbFRpbWVvdXRTZWNvbmRzOiAxMCxcbiAgICAgIG1heFRpbWVvdXRTZWNvbmRzOiAyMCxcbiAgICAgIGluYWN0aXZpdHlXYXJuaW5nU2Vjb25kczogMzAsXG4gICAgICBtYXhJbmFjdGl2aXR5QXR0ZW1wdHM6IDIsXG4gICAgICBncmFjZWZ1bEVuZGluZ1RpbWVvdXRTZWNvbmRzOiAxNSxcbiAgICAgIC4uLmNvbmZpZ1xuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogSGFuZGxlIHRpbWVvdXQgc2NlbmFyaW8gd2hlbiB1c2VyIGRvZXNuJ3QgcmVzcG9uZFxuICAgKi9cbiAgYXN5bmMgaGFuZGxlVGltZW91dChzZXNzaW9uSWQ6IHN0cmluZywgY2FsbFNpZDogc3RyaW5nKTogUHJvbWlzZTxUaW1lb3V0UmVzdWx0PiB7XG4gICAgY29uc29sZS5sb2coYOKPsCBUSU1FT1VUOiBIYW5kbGluZyB0aW1lb3V0IGZvciBzZXNzaW9uICR7c2Vzc2lvbklkfWApO1xuXG4gICAgLy8gR2V0IG9yIGNyZWF0ZSB0aW1lb3V0IHN0YXRlXG4gICAgbGV0IHRpbWVvdXRTdGF0ZSA9IHRoaXMudGltZW91dFN0YXRlcy5nZXQoc2Vzc2lvbklkKTtcbiAgICBpZiAoIXRpbWVvdXRTdGF0ZSkge1xuICAgICAgdGltZW91dFN0YXRlID0gdGhpcy5pbml0aWFsaXplVGltZW91dFN0YXRlKHNlc3Npb25JZCk7XG4gICAgICB0aGlzLnRpbWVvdXRTdGF0ZXMuc2V0KHNlc3Npb25JZCwgdGltZW91dFN0YXRlKTtcbiAgICB9XG5cbiAgICAvLyBVcGRhdGUgdGltZW91dCBzdGF0ZVxuICAgIHRpbWVvdXRTdGF0ZS5jb25zZWN1dGl2ZVRpbWVvdXRzKys7XG4gICAgdGltZW91dFN0YXRlLnRvdGFsSW5hY3RpdmVUaW1lICs9IHRoaXMuY29uZmlnLmluaXRpYWxUaW1lb3V0U2Vjb25kcztcbiAgICBjb25zdCBjdXJyZW50VGltZSA9IERhdGUubm93KCk7XG5cbiAgICBjb25zb2xlLmxvZyhg4o+wIFRJTUVPVVQgU1RBVEU6IENvbnNlY3V0aXZlIHRpbWVvdXRzOiAke3RpbWVvdXRTdGF0ZS5jb25zZWN1dGl2ZVRpbWVvdXRzfSwgVG90YWwgaW5hY3RpdmU6ICR7dGltZW91dFN0YXRlLnRvdGFsSW5hY3RpdmVUaW1lfXNgKTtcblxuICAgIC8vIERldGVybWluZSBhY3Rpb24gYmFzZWQgb24gdGltZW91dCBzdGF0ZVxuICAgIGlmICh0aW1lb3V0U3RhdGUuY29uc2VjdXRpdmVUaW1lb3V0cyA9PT0gMSkge1xuICAgICAgLy8gRmlyc3QgdGltZW91dCAtIGdlbnRsZSBwcm9tcHRcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLmhhbmRsZUZpcnN0VGltZW91dCh0aW1lb3V0U3RhdGUsIGNhbGxTaWQpO1xuICAgIH0gZWxzZSBpZiAodGltZW91dFN0YXRlLmNvbnNlY3V0aXZlVGltZW91dHMgPT09IDIpIHtcbiAgICAgIC8vIFNlY29uZCB0aW1lb3V0IC0gbW9yZSBkaXJlY3QgcHJvbXB0XG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5oYW5kbGVTZWNvbmRUaW1lb3V0KHRpbWVvdXRTdGF0ZSwgY2FsbFNpZCk7XG4gICAgfSBlbHNlIGlmICh0aW1lb3V0U3RhdGUuY29uc2VjdXRpdmVUaW1lb3V0cyA+PSAzKSB7XG4gICAgICAvLyBUaGlyZCB0aW1lb3V0IG9yIG1vcmUgLSBncmFjZWZ1bCBlbmRpbmdcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLmhhbmRsZUZpbmFsVGltZW91dCh0aW1lb3V0U3RhdGUsIGNhbGxTaWQpO1xuICAgIH1cblxuICAgIC8vIERlZmF1bHQgY29udGludWVcbiAgICByZXR1cm4ge1xuICAgICAgc2hvdWxkQ29udGludWU6IHRydWUsXG4gICAgICB0d2ltbFJlc3BvbnNlOiB0aGlzLmNyZWF0ZUNvbnRpbnVlVHdpTUwoKSxcbiAgICAgIHRpbWVvdXRTdGF0ZSxcbiAgICAgIGFjdGlvbjogJ2NvbnRpbnVlJ1xuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogSGFuZGxlIHVzZXIgYWN0aXZpdHkgLSByZXNldCB0aW1lb3V0IGNvdW50ZXJzXG4gICAqL1xuICBhc3luYyBoYW5kbGVVc2VyQWN0aXZpdHkoc2Vzc2lvbklkOiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zb2xlLmxvZyhg4pyFIEFDVElWSVRZOiBVc2VyIGFjdGl2aXR5IGRldGVjdGVkIGZvciBzZXNzaW9uICR7c2Vzc2lvbklkfWApO1xuICAgIFxuICAgIGNvbnN0IHRpbWVvdXRTdGF0ZSA9IHRoaXMudGltZW91dFN0YXRlcy5nZXQoc2Vzc2lvbklkKTtcbiAgICBpZiAodGltZW91dFN0YXRlKSB7XG4gICAgICB0aW1lb3V0U3RhdGUuY29uc2VjdXRpdmVUaW1lb3V0cyA9IDA7XG4gICAgICB0aW1lb3V0U3RhdGUud2FybmluZ3NTZW50ID0gMDtcbiAgICAgIHRpbWVvdXRTdGF0ZS5sYXN0QWN0aXZpdHlUaW1lID0gRGF0ZS5ub3coKTtcbiAgICAgIHRpbWVvdXRTdGF0ZS5pc0luR3JhY2VmdWxFbmRpbmcgPSBmYWxzZTtcbiAgICAgIFxuICAgICAgLy8gQWRkIHN5c3RlbSBtZXNzYWdlIGFib3V0IGFjdGl2aXR5IHJlc3VtcHRpb25cbiAgICAgIGF3YWl0IHRoaXMuc2Vzc2lvbk1hbmFnZXIuYWRkU3lzdGVtTWVzc2FnZShcbiAgICAgICAgc2Vzc2lvbklkLFxuICAgICAgICAnVXNlciBhY3Rpdml0eSByZXN1bWVkIC0gdGltZW91dCBjb3VudGVycyByZXNldCdcbiAgICAgICk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIENoZWNrIGlmIHNlc3Npb24gc2hvdWxkIGJlIGVuZGVkIGR1ZSB0byBwcm9sb25nZWQgaW5hY3Rpdml0eVxuICAgKi9cbiAgc2hvdWxkRW5kU2Vzc2lvbihzZXNzaW9uSWQ6IHN0cmluZyk6IGJvb2xlYW4ge1xuICAgIGNvbnN0IHRpbWVvdXRTdGF0ZSA9IHRoaXMudGltZW91dFN0YXRlcy5nZXQoc2Vzc2lvbklkKTtcbiAgICBpZiAoIXRpbWVvdXRTdGF0ZSkgcmV0dXJuIGZhbHNlO1xuXG4gICAgY29uc3QgdG90YWxJbmFjdGl2ZU1pbnV0ZXMgPSB0aW1lb3V0U3RhdGUudG90YWxJbmFjdGl2ZVRpbWUgLyA2MDtcbiAgICBjb25zdCBtYXhJbmFjdGl2ZU1pbnV0ZXMgPSA1OyAvLyBFbmQgc2Vzc2lvbiBhZnRlciA1IG1pbnV0ZXMgb2YgdG90YWwgaW5hY3Rpdml0eVxuXG4gICAgcmV0dXJuIHRvdGFsSW5hY3RpdmVNaW51dGVzID49IG1heEluYWN0aXZlTWludXRlcyB8fCBcbiAgICAgICAgICAgdGltZW91dFN0YXRlLmNvbnNlY3V0aXZlVGltZW91dHMgPj0gNDtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgYXBwcm9wcmlhdGUgdGltZW91dCBkdXJhdGlvbiBiYXNlZCBvbiBjb252ZXJzYXRpb24gc3RhdGVcbiAgICovXG4gIGdldFRpbWVvdXREdXJhdGlvbihjb252ZXJzYXRpb25QaGFzZTogc3RyaW5nLCBjb25zZWN1dGl2ZVRpbWVvdXRzOiBudW1iZXIpOiBudW1iZXIge1xuICAgIGNvbnN0IGJhc2VUaW1lb3V0ID0gdGhpcy5jb25maWcuaW5pdGlhbFRpbWVvdXRTZWNvbmRzO1xuICAgIFxuICAgIC8vIEluY3JlYXNlIHRpbWVvdXQgZm9yIGxhdGVyIGNvbnZlcnNhdGlvbiBwaGFzZXNcbiAgICBjb25zdCBwaGFzZU11bHRpcGxpZXIgPSB7XG4gICAgICAnZ3JlZXRpbmcnOiAxLjAsXG4gICAgICAnY29udmVyc2F0aW9uJzogMS4yLFxuICAgICAgJ2NsYXJpZmljYXRpb24nOiAxLjUsXG4gICAgICAnY2xvc2luZyc6IDAuOFxuICAgIH1bY29udmVyc2F0aW9uUGhhc2VdIHx8IDEuMDtcblxuICAgIC8vIERlY3JlYXNlIHRpbWVvdXQgYWZ0ZXIgbXVsdGlwbGUgdGltZW91dHMgdG8gZW5kIGNvbnZlcnNhdGlvbiBzb29uZXJcbiAgICBjb25zdCB0aW1lb3V0TXVsdGlwbGllciA9IE1hdGgubWF4KDAuNSwgMS4wIC0gKGNvbnNlY3V0aXZlVGltZW91dHMgKiAwLjIpKTtcblxuICAgIHJldHVybiBNYXRoLnJvdW5kKGJhc2VUaW1lb3V0ICogcGhhc2VNdWx0aXBsaWVyICogdGltZW91dE11bHRpcGxpZXIpO1xuICB9XG5cbiAgcHJpdmF0ZSBpbml0aWFsaXplVGltZW91dFN0YXRlKHNlc3Npb25JZDogc3RyaW5nKTogVGltZW91dFN0YXRlIHtcbiAgICByZXR1cm4ge1xuICAgICAgc2Vzc2lvbklkLFxuICAgICAgY29uc2VjdXRpdmVUaW1lb3V0czogMCxcbiAgICAgIGxhc3RBY3Rpdml0eVRpbWU6IERhdGUubm93KCksXG4gICAgICB3YXJuaW5nc1NlbnQ6IDAsXG4gICAgICBpc0luR3JhY2VmdWxFbmRpbmc6IGZhbHNlLFxuICAgICAgdG90YWxJbmFjdGl2ZVRpbWU6IDBcbiAgICB9O1xuICB9XG5cbiAgcHJpdmF0ZSBhc3luYyBoYW5kbGVGaXJzdFRpbWVvdXQodGltZW91dFN0YXRlOiBUaW1lb3V0U3RhdGUsIGNhbGxTaWQ6IHN0cmluZyk6IFByb21pc2U8VGltZW91dFJlc3VsdD4ge1xuICAgIGNvbnNvbGUubG9nKGDij7AgRklSU1QgVElNRU9VVDogU2VuZGluZyBnZW50bGUgcHJvbXB0YCk7XG4gICAgXG4gICAgYXdhaXQgdGhpcy5zZXNzaW9uTWFuYWdlci5hZGRTeXN0ZW1NZXNzYWdlKFxuICAgICAgdGltZW91dFN0YXRlLnNlc3Npb25JZCxcbiAgICAgICdGaXJzdCB0aW1lb3V0IC0gc2VuZGluZyBnZW50bGUgcHJvbXB0J1xuICAgICk7XG5cbiAgICBjb25zdCB0d2ltbFJlc3BvbnNlID0gYDw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cIlVURi04XCI/PlxuPFJlc3BvbnNlPlxuICA8U2F5IHZvaWNlPVwiYWxpY2VcIiByYXRlPVwiMVwiPlxuICAgIEknbSBoZXJlIGFuZCByZWFkeSB0byBoZWxwLiBQbGVhc2UgbGV0IG1lIGtub3cgd2hhdCB5b3UnZCBsaWtlIHRvIGFzayBhYm91dC5cbiAgPC9TYXk+XG4gIDxSZWNvcmQgXG4gICAgYWN0aW9uPVwiaHR0cHM6Ly9rbDF6enIzdjVrLmV4ZWN1dGUtYXBpLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tL3Byb2Qvd2ViaG9vay9zcGVlY2hcIiBcbiAgICBtZXRob2Q9XCJQT1NUXCIgXG4gICAgbWF4TGVuZ3RoPVwiMzBcIiBcbiAgICB0aW1lb3V0PVwiMTVcIlxuICAgIHBsYXlCZWVwPVwidHJ1ZVwiXG4gICAgcmVjb3JkaW5nU3RhdHVzQ2FsbGJhY2s9XCJodHRwczovL2tsMXp6cjN2NWsuZXhlY3V0ZS1hcGkudXMtZWFzdC0xLmFtYXpvbmF3cy5jb20vcHJvZC93ZWJob29rL2V2ZW50c1wiXG4gICAgcmVjb3JkaW5nU3RhdHVzQ2FsbGJhY2tNZXRob2Q9XCJQT1NUXCJcbiAgLz5cbjwvUmVzcG9uc2U+YDtcblxuICAgIHJldHVybiB7XG4gICAgICBzaG91bGRDb250aW51ZTogdHJ1ZSxcbiAgICAgIHR3aW1sUmVzcG9uc2UsXG4gICAgICB0aW1lb3V0U3RhdGUsXG4gICAgICBhY3Rpb246ICd3YXJuJ1xuICAgIH07XG4gIH1cblxuICBwcml2YXRlIGFzeW5jIGhhbmRsZVNlY29uZFRpbWVvdXQodGltZW91dFN0YXRlOiBUaW1lb3V0U3RhdGUsIGNhbGxTaWQ6IHN0cmluZyk6IFByb21pc2U8VGltZW91dFJlc3VsdD4ge1xuICAgIGNvbnNvbGUubG9nKGDij7AgU0VDT05EIFRJTUVPVVQ6IFNlbmRpbmcgbW9yZSBkaXJlY3QgcHJvbXB0YCk7XG4gICAgXG4gICAgYXdhaXQgdGhpcy5zZXNzaW9uTWFuYWdlci5hZGRTeXN0ZW1NZXNzYWdlKFxuICAgICAgdGltZW91dFN0YXRlLnNlc3Npb25JZCxcbiAgICAgICdTZWNvbmQgdGltZW91dCAtIHNlbmRpbmcgZGlyZWN0IHByb21wdCdcbiAgICApO1xuXG4gICAgY29uc3QgdHdpbWxSZXNwb25zZSA9IGA8P3htbCB2ZXJzaW9uPVwiMS4wXCIgZW5jb2Rpbmc9XCJVVEYtOFwiPz5cbjxSZXNwb25zZT5cbiAgPFNheSB2b2ljZT1cImFsaWNlXCIgcmF0ZT1cIjFcIj5cbiAgICBBcmUgeW91IHN0aWxsIHRoZXJlPyBJZiB5b3UgbmVlZCBoZWxwLCBwbGVhc2Ugc3BlYWsgYWZ0ZXIgdGhlIGJlZXAuIFxuICAgIElmIHlvdSdyZSBmaW5pc2hlZCwgeW91IGNhbiBoYW5nIHVwIGF0IGFueSB0aW1lLlxuICA8L1NheT5cbiAgPFJlY29yZCBcbiAgICBhY3Rpb249XCJodHRwczovL2tsMXp6cjN2NWsuZXhlY3V0ZS1hcGkudXMtZWFzdC0xLmFtYXpvbmF3cy5jb20vcHJvZC93ZWJob29rL3NwZWVjaFwiIFxuICAgIG1ldGhvZD1cIlBPU1RcIiBcbiAgICBtYXhMZW5ndGg9XCIyMFwiIFxuICAgIHRpbWVvdXQ9XCIxMlwiXG4gICAgcGxheUJlZXA9XCJ0cnVlXCJcbiAgICByZWNvcmRpbmdTdGF0dXNDYWxsYmFjaz1cImh0dHBzOi8va2wxenpyM3Y1ay5leGVjdXRlLWFwaS51cy1lYXN0LTEuYW1hem9uYXdzLmNvbS9wcm9kL3dlYmhvb2svZXZlbnRzXCJcbiAgICByZWNvcmRpbmdTdGF0dXNDYWxsYmFja01ldGhvZD1cIlBPU1RcIlxuICAvPlxuPC9SZXNwb25zZT5gO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIHNob3VsZENvbnRpbnVlOiB0cnVlLFxuICAgICAgdHdpbWxSZXNwb25zZSxcbiAgICAgIHRpbWVvdXRTdGF0ZSxcbiAgICAgIGFjdGlvbjogJ3dhcm4nXG4gICAgfTtcbiAgfVxuXG4gIHByaXZhdGUgYXN5bmMgaGFuZGxlRmluYWxUaW1lb3V0KHRpbWVvdXRTdGF0ZTogVGltZW91dFN0YXRlLCBjYWxsU2lkOiBzdHJpbmcpOiBQcm9taXNlPFRpbWVvdXRSZXN1bHQ+IHtcbiAgICBjb25zb2xlLmxvZyhg4o+wIEZJTkFMIFRJTUVPVVQ6IEVuZGluZyBjb252ZXJzYXRpb24gZ3JhY2VmdWxseWApO1xuICAgIFxuICAgIHRpbWVvdXRTdGF0ZS5pc0luR3JhY2VmdWxFbmRpbmcgPSB0cnVlO1xuICAgIFxuICAgIGF3YWl0IHRoaXMuc2Vzc2lvbk1hbmFnZXIuYWRkU3lzdGVtTWVzc2FnZShcbiAgICAgIHRpbWVvdXRTdGF0ZS5zZXNzaW9uSWQsXG4gICAgICAnRmluYWwgdGltZW91dCAtIGVuZGluZyBjb252ZXJzYXRpb24gZ3JhY2VmdWxseSdcbiAgICApO1xuXG4gICAgLy8gVXBkYXRlIHNlc3Npb24gc3RhdHVzIHRvIGNvbXBsZXRlZCBkdWUgdG8gdGltZW91dFxuICAgIGF3YWl0IHRoaXMuc2Vzc2lvbk1hbmFnZXIudXBkYXRlU2Vzc2lvblN0YXR1cyhcbiAgICAgIHRpbWVvdXRTdGF0ZS5zZXNzaW9uSWQsXG4gICAgICAnY29tcGxldGVkJyxcbiAgICAgIERhdGUubm93KCksXG4gICAgICB7IGNvZGU6ICd0aW1lb3V0JywgbWVzc2FnZTogJ1Nlc3Npb24gZW5kZWQgZHVlIHRvIHVzZXIgaW5hY3Rpdml0eScgfVxuICAgICk7XG5cbiAgICBjb25zdCB0d2ltbFJlc3BvbnNlID0gYDw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cIlVURi04XCI/PlxuPFJlc3BvbnNlPlxuICA8U2F5IHZvaWNlPVwiYWxpY2VcIiByYXRlPVwiMVwiPlxuICAgIEl0IHNlZW1zIGxpa2UgeW91IG1pZ2h0IGJlIGJ1c3kgcmlnaHQgbm93LiBUaGFuayB5b3UgZm9yIHVzaW5nIFByb21wdENhbGwgQUkuIFxuICAgIEZlZWwgZnJlZSB0byBjYWxsIGJhY2sgYW55dGltZSBpZiB5b3UgbmVlZCBhc3Npc3RhbmNlLiBHb29kYnllIVxuICA8L1NheT5cbiAgPEhhbmd1cC8+XG48L1Jlc3BvbnNlPmA7XG5cbiAgICByZXR1cm4ge1xuICAgICAgc2hvdWxkQ29udGludWU6IGZhbHNlLFxuICAgICAgdHdpbWxSZXNwb25zZSxcbiAgICAgIHRpbWVvdXRTdGF0ZSxcbiAgICAgIGFjdGlvbjogJ2VuZF9ncmFjZWZ1bGx5J1xuICAgIH07XG4gIH1cblxuICBwcml2YXRlIGNyZWF0ZUNvbnRpbnVlVHdpTUwoKTogc3RyaW5nIHtcbiAgICByZXR1cm4gYDw/eG1sIHZlcnNpb249XCIxLjBcIiBlbmNvZGluZz1cIlVURi04XCI/PlxuPFJlc3BvbnNlPlxuICA8U2F5IHZvaWNlPVwiYWxpY2VcIj5cbiAgICBQbGVhc2UgbGV0IG1lIGtub3cgaG93IEkgY2FuIGhlbHAgeW91LlxuICA8L1NheT5cbiAgPFJlY29yZCBcbiAgICBhY3Rpb249XCJodHRwczovL2tsMXp6cjN2NWsuZXhlY3V0ZS1hcGkudXMtZWFzdC0xLmFtYXpvbmF3cy5jb20vcHJvZC93ZWJob29rL3NwZWVjaFwiIFxuICAgIG1ldGhvZD1cIlBPU1RcIiBcbiAgICBtYXhMZW5ndGg9XCIzMFwiIFxuICAgIHRpbWVvdXQ9XCIxMFwiXG4gICAgcGxheUJlZXA9XCJ0cnVlXCJcbiAgICByZWNvcmRpbmdTdGF0dXNDYWxsYmFjaz1cImh0dHBzOi8va2wxenpyM3Y1ay5leGVjdXRlLWFwaS51cy1lYXN0LTEuYW1hem9uYXdzLmNvbS9wcm9kL3dlYmhvb2svZXZlbnRzXCJcbiAgICByZWNvcmRpbmdTdGF0dXNDYWxsYmFja01ldGhvZD1cIlBPU1RcIlxuICAvPlxuPC9SZXNwb25zZT5gO1xuICB9XG5cbiAgLyoqXG4gICAqIENsZWFuIHVwIHRpbWVvdXQgc3RhdGUgd2hlbiBzZXNzaW9uIGVuZHNcbiAgICovXG4gIGNsZWFudXBTZXNzaW9uKHNlc3Npb25JZDogc3RyaW5nKTogdm9pZCB7XG4gICAgdGhpcy50aW1lb3V0U3RhdGVzLmRlbGV0ZShzZXNzaW9uSWQpO1xuICAgIGNvbnNvbGUubG9nKGDwn6e5IENMRUFOVVA6IFJlbW92ZWQgdGltZW91dCBzdGF0ZSBmb3Igc2Vzc2lvbiAke3Nlc3Npb25JZH1gKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgY3VycmVudCB0aW1lb3V0IHN0YXRlIGZvciBtb25pdG9yaW5nXG4gICAqL1xuICBnZXRUaW1lb3V0U3RhdGUoc2Vzc2lvbklkOiBzdHJpbmcpOiBUaW1lb3V0U3RhdGUgfCBudWxsIHtcbiAgICByZXR1cm4gdGhpcy50aW1lb3V0U3RhdGVzLmdldChzZXNzaW9uSWQpIHx8IG51bGw7XG4gIH1cbn0iXX0=