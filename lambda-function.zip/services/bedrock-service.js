"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.BedrockService = exports.AVAILABLE_MODELS = void 0;
const client_bedrock_runtime_1 = require("@aws-sdk/client-bedrock-runtime");
/**
 * Available Bedrock models for PromptCall AI
 */
exports.AVAILABLE_MODELS = {
    CLAUDE_HAIKU: 'anthropic.claude-3-haiku-20240307-v1:0',
    CLAUDE_SONNET: 'anthropic.claude-3-sonnet-20240229-v1:0',
    TITAN_EXPRESS: 'amazon.titan-text-express-v1'
};
/**
 * Service for interacting with AWS Bedrock AI models
 */
class BedrockService {
    constructor(config = {}) {
        this.config = {
            region: config.region || process.env.AWS_REGION || 'us-east-1',
            modelId: config.modelId || 'anthropic.claude-3-haiku-20240307-v1:0',
            maxTokens: config.maxTokens || 150, // Limit for voice responses (~60 seconds)
            temperature: config.temperature || 0.7
        };
        this.client = new client_bedrock_runtime_1.BedrockRuntimeClient({
            region: this.config.region
        });
    }
    /**
     * Process a user query with full conversation context integration
     */
    async processQueryWithContext(userQuery, aiContext) {
        try {
            const prompt = this.buildContextualPrompt(userQuery, aiContext);
            const requestBody = this.buildRequestBody(prompt);
            const command = new client_bedrock_runtime_1.InvokeModelCommand({
                modelId: this.config.modelId,
                contentType: 'application/json',
                accept: 'application/json',
                body: JSON.stringify(requestBody)
            });
            const response = await this.client.send(command);
            if (!response.body) {
                throw new Error('No response body from Bedrock');
            }
            const responseBody = JSON.parse(new TextDecoder().decode(response.body));
            const aiResponse = this.parseResponse(responseBody);
            // Optimize response for voice delivery
            aiResponse.text = this.optimizeForVoice(aiResponse.text);
            // Validate response length based on user preferences
            const maxWords = this.getMaxWordsForPreference(aiContext.userPreferences?.responseLength);
            if (!this.validateResponseLength(aiResponse.text, maxWords)) {
                console.warn(`Response exceeds ${maxWords} words: ${aiResponse.text.split(/\s+/).length} words`);
            }
            return aiResponse;
        }
        catch (error) {
            console.error('Bedrock API error:', error);
            throw new Error(`Failed to process query: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
     * Process a user query and generate AI response (legacy method)
     */
    async processQuery(userQuery, conversationContext) {
        try {
            const prompt = this.buildPrompt(userQuery, conversationContext);
            const requestBody = this.buildRequestBody(prompt);
            const command = new client_bedrock_runtime_1.InvokeModelCommand({
                modelId: this.config.modelId,
                contentType: 'application/json',
                accept: 'application/json',
                body: JSON.stringify(requestBody)
            });
            const response = await this.client.send(command);
            if (!response.body) {
                throw new Error('No response body from Bedrock');
            }
            const responseBody = JSON.parse(new TextDecoder().decode(response.body));
            const aiResponse = this.parseResponse(responseBody);
            // Optimize response for voice delivery
            aiResponse.text = this.optimizeForVoice(aiResponse.text);
            // Validate response length
            if (!this.validateResponseLength(aiResponse.text)) {
                console.warn(`Response exceeds 150 words: ${aiResponse.text.split(/\s+/).length} words`);
            }
            return aiResponse;
        }
        catch (error) {
            console.error('Bedrock API error:', error);
            throw new Error(`Failed to process query: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
     * Build request body based on model type
     */
    buildRequestBody(prompt) {
        if (this.config.modelId.startsWith('anthropic.claude')) {
            return {
                anthropic_version: 'bedrock-2023-05-31',
                max_tokens: this.config.maxTokens,
                temperature: this.config.temperature,
                messages: [
                    {
                        role: 'user',
                        content: prompt
                    }
                ]
            };
        }
        else if (this.config.modelId.startsWith('amazon.titan')) {
            return {
                inputText: prompt,
                textGenerationConfig: {
                    maxTokenCount: this.config.maxTokens,
                    temperature: this.config.temperature,
                    topP: 0.9,
                    stopSequences: []
                }
            };
        }
        else {
            throw new Error(`Unsupported model: ${this.config.modelId}`);
        }
    }
    /**
     * Parse response based on model type
     */
    parseResponse(responseBody) {
        if (this.config.modelId.startsWith('anthropic.claude')) {
            return {
                text: responseBody.content[0].text,
                usage: {
                    inputTokens: responseBody.usage?.input_tokens || 0,
                    outputTokens: responseBody.usage?.output_tokens || 0
                }
            };
        }
        else if (this.config.modelId.startsWith('amazon.titan')) {
            return {
                text: responseBody.results[0].outputText,
                usage: {
                    inputTokens: responseBody.inputTextTokenCount || 0,
                    outputTokens: responseBody.results[0].tokenCount || 0
                }
            };
        }
        else {
            throw new Error(`Unsupported model response format: ${this.config.modelId}`);
        }
    }
    /**
     * Build contextual prompt with full AI context integration
     */
    buildContextualPrompt(userQuery, aiContext) {
        const responseLength = aiContext.userPreferences?.responseLength || 'medium';
        const maxWords = this.getMaxWordsForPreference(responseLength);
        let prompt = aiContext.systemPrompt || `You are a helpful AI assistant accessed via phone call in regions with limited internet access.`;
        prompt += `\n\nCRITICAL VOICE OPTIMIZATION RULES:
- MAXIMUM ${maxWords} words (${Math.ceil(maxWords * 0.4)} seconds of speech) - this is STRICT for call cost management
- Use simple, conversational English suitable for phone calls
- Speak as if you're having a natural phone conversation
- NO bullet points, lists, or complex formatting - speak everything naturally
- Use short sentences and natural pauses
- Avoid technical jargon - explain things simply
- Be warm, friendly, and helpful
- If giving multiple points, use natural transitions like "first", "also", "and finally"
- End with a natural conversation closer when appropriate`;
        if (aiContext.conversationSummary) {
            prompt += `\n\nCONVERSATION SUMMARY:\n${aiContext.conversationSummary}`;
        }
        if (aiContext.conversationContext) {
            prompt += `\n\nRECENT CONVERSATION:\n${aiContext.conversationContext}`;
        }
        if (aiContext.lastUserIntent) {
            prompt += `\n\nUSER'S LIKELY INTENT: ${aiContext.lastUserIntent}`;
        }
        if (aiContext.userPreferences?.topics && aiContext.userPreferences.topics.length > 0) {
            prompt += `\n\nTOPICS DISCUSSED: ${aiContext.userPreferences.topics.join(', ')}`;
        }
        prompt += `\n\nUSER'S CURRENT QUESTION: "${userQuery}"

Respond as if you're speaking directly to them on the phone, maintaining conversation continuity:`;
        return prompt;
    }
    /**
     * Get maximum words based on user preference
     */
    getMaxWordsForPreference(preference) {
        switch (preference) {
            case 'short': return 50; // ~20 seconds
            case 'medium': return 100; // ~40 seconds  
            case 'long': return 150; // ~60 seconds
            default: return 100;
        }
    }
    /**
     * Build optimized prompt for voice interactions (legacy method)
     */
    buildPrompt(userQuery, conversationContext) {
        const systemPrompt = `You are a helpful AI assistant accessed via phone call in regions with limited internet access. 

CRITICAL VOICE OPTIMIZATION RULES:
- MAXIMUM 150 words (60 seconds of speech) - this is STRICT for call cost management
- Use simple, conversational English suitable for phone calls
- Speak as if you're having a natural phone conversation
- NO bullet points, lists, or complex formatting - speak everything naturally
- Use short sentences and natural pauses
- Avoid technical jargon - explain things simply
- Be warm, friendly, and helpful
- If giving multiple points, use natural transitions like "first", "also", "and finally"
- End with a natural conversation closer when appropriate

PHONE CONVERSATION STYLE:
- Start responses naturally (avoid "Here's what I can tell you...")
- Use contractions (I'll, you'll, that's, it's) for natural speech
- Include natural speech patterns and filler words occasionally
- Keep explanations simple and direct
- If the topic is complex, focus on the most important points only

${conversationContext ? `PREVIOUS CONVERSATION:\n${conversationContext}\n` : ''}

USER'S QUESTION: "${userQuery}"

Respond as if you're speaking directly to them on the phone:`;
        return systemPrompt;
    }
    /**
     * Validate response length for voice optimization
     */
    validateResponseLength(text, maxWords = 150) {
        const wordCount = text.split(/\s+/).length;
        return wordCount <= maxWords;
    }
    /**
     * Optimize response for voice delivery
     */
    optimizeForVoice(text) {
        // Remove any markdown formatting that might have slipped through
        let optimized = text.replace(/\*\*(.*?)\*\*/g, '$1'); // Remove bold
        optimized = optimized.replace(/\*(.*?)\*/g, '$1'); // Remove italics
        optimized = optimized.replace(/`(.*?)`/g, '$1'); // Remove code formatting
        optimized = optimized.replace(/#{1,6}\s/g, ''); // Remove headers
        // Ensure natural speech patterns
        optimized = optimized.replace(/\n\n/g, ' '); // Replace paragraph breaks with spaces
        optimized = optimized.replace(/\n/g, ' '); // Replace line breaks with spaces
        optimized = optimized.replace(/\s+/g, ' '); // Normalize whitespace
        optimized = optimized.trim();
        return optimized;
    }
    /**
     * Test Bedrock connection and authentication
     */
    async testConnection() {
        try {
            const testResponse = await this.processQuery('Hello, can you hear me?');
            return testResponse.text.length > 0;
        }
        catch (error) {
            console.error('Bedrock connection test failed:', error);
            // Check if it's a model access issue
            if (error instanceof Error && error.message.includes('access to the model')) {
                console.log('💡 Model access issue detected. You may need to:');
                console.log('   1. Go to AWS Console > Bedrock > Model access');
                console.log('   2. Request access to the model:', this.config.modelId);
                console.log('   3. Or try a different model that you have access to');
            }
            return false;
        }
    }
    /**
     * Try different commonly available models
     */
    async findAvailableModel() {
        const modelsToTry = [
            'amazon.titan-text-express-v1',
            'anthropic.claude-3-haiku-20240307-v1:0',
            'anthropic.claude-instant-v1',
            'ai21.j2-mid-v1',
            'ai21.j2-ultra-v1'
        ];
        for (const modelId of modelsToTry) {
            try {
                console.log(`🔍 Trying model: ${modelId}`);
                const tempService = new BedrockService({ ...this.config, modelId });
                const response = await tempService.processQuery('Test');
                if (response.text.length > 0) {
                    console.log(`✅ Model ${modelId} is available`);
                    return modelId;
                }
            }
            catch (error) {
                console.log(`❌ Model ${modelId} not available`);
            }
        }
        return null;
    }
    /**
     * Get current model configuration
     */
    getConfig() {
        return { ...this.config };
    }
    /**
     * Get list of available models
     */
    static getAvailableModels() {
        return exports.AVAILABLE_MODELS;
    }
    /**
     * Switch to a different model
     */
    switchModel(modelId) {
        if (!Object.values(exports.AVAILABLE_MODELS).includes(modelId)) {
            throw new Error(`Model ${modelId} is not available. Available models: ${Object.values(exports.AVAILABLE_MODELS).join(', ')}`);
        }
        this.config.modelId = modelId;
    }
    /**
     * Get response statistics for monitoring
     */
    getResponseStats(text) {
        const wordCount = text.split(/\s+/).length;
        const estimatedSpeechSeconds = Math.ceil(wordCount * 0.4); // ~2.5 words per second
        const isWithinLimit = wordCount <= 150;
        return {
            wordCount,
            estimatedSpeechSeconds,
            isWithinLimit
        };
    }
}
exports.BedrockService = BedrockService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmVkcm9jay1zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL3NlcnZpY2VzL2JlZHJvY2stc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSw0RUFBMkY7QUFZM0Y7O0dBRUc7QUFDVSxRQUFBLGdCQUFnQixHQUFHO0lBQzlCLFlBQVksRUFBRSx3Q0FBd0M7SUFDdEQsYUFBYSxFQUFFLHlDQUF5QztJQUN4RCxhQUFhLEVBQUUsOEJBQThCO0NBQ3JDLENBQUM7QUFhWDs7R0FFRztBQUNILE1BQWEsY0FBYztJQUl6QixZQUFZLFNBQXdCLEVBQUU7UUFDcEMsSUFBSSxDQUFDLE1BQU0sR0FBRztZQUNaLE1BQU0sRUFBRSxNQUFNLENBQUMsTUFBTSxJQUFJLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxJQUFJLFdBQVc7WUFDOUQsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLElBQUksd0NBQXdDO1lBQ25FLFNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUyxJQUFJLEdBQUcsRUFBRSwwQ0FBMEM7WUFDOUUsV0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXLElBQUksR0FBRztTQUN2QyxDQUFDO1FBRUYsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLDZDQUFvQixDQUFDO1lBQ3JDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU07U0FDM0IsQ0FBQyxDQUFDO0lBQ0wsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLHVCQUF1QixDQUMzQixTQUFpQixFQUNqQixTQVNDO1FBRUQsSUFBSSxDQUFDO1lBQ0gsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLHFCQUFxQixDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQztZQUVoRSxNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLENBQUM7WUFFbEQsTUFBTSxPQUFPLEdBQUcsSUFBSSwyQ0FBa0IsQ0FBQztnQkFDckMsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTztnQkFDNUIsV0FBVyxFQUFFLGtCQUFrQjtnQkFDL0IsTUFBTSxFQUFFLGtCQUFrQjtnQkFDMUIsSUFBSSxFQUFFLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDO2FBQ2xDLENBQUMsQ0FBQztZQUVILE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFakQsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsQ0FBQztnQkFDbkIsTUFBTSxJQUFJLEtBQUssQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO1lBQ25ELENBQUM7WUFFRCxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksV0FBVyxFQUFFLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDO1lBQ3pFLE1BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDLENBQUM7WUFFcEQsdUNBQXVDO1lBQ3ZDLFVBQVUsQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztZQUV6RCxxREFBcUQ7WUFDckQsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLHdCQUF3QixDQUFDLFNBQVMsQ0FBQyxlQUFlLEVBQUUsY0FBYyxDQUFDLENBQUM7WUFDMUYsSUFBSSxDQUFDLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxFQUFFLENBQUM7Z0JBQzVELE9BQU8sQ0FBQyxJQUFJLENBQUMsb0JBQW9CLFFBQVEsV0FBVyxVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxDQUFDO1lBQ25HLENBQUM7WUFFRCxPQUFPLFVBQVUsQ0FBQztRQUVwQixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDM0MsTUFBTSxJQUFJLEtBQUssQ0FBQyw0QkFBNEIsS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztRQUMxRyxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLFlBQVksQ0FBQyxTQUFpQixFQUFFLG1CQUE0QjtRQUNoRSxJQUFJLENBQUM7WUFDSCxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsRUFBRSxtQkFBbUIsQ0FBQyxDQUFDO1lBRWhFLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUVsRCxNQUFNLE9BQU8sR0FBRyxJQUFJLDJDQUFrQixDQUFDO2dCQUNyQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPO2dCQUM1QixXQUFXLEVBQUUsa0JBQWtCO2dCQUMvQixNQUFNLEVBQUUsa0JBQWtCO2dCQUMxQixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLENBQUM7YUFDbEMsQ0FBQyxDQUFDO1lBRUgsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUVqRCxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxDQUFDO2dCQUNuQixNQUFNLElBQUksS0FBSyxDQUFDLCtCQUErQixDQUFDLENBQUM7WUFDbkQsQ0FBQztZQUVELE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxXQUFXLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7WUFDekUsTUFBTSxVQUFVLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxZQUFZLENBQUMsQ0FBQztZQUVwRCx1Q0FBdUM7WUFDdkMsVUFBVSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO1lBRXpELDJCQUEyQjtZQUMzQixJQUFJLENBQUMsSUFBSSxDQUFDLHNCQUFzQixDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO2dCQUNsRCxPQUFPLENBQUMsSUFBSSxDQUFDLCtCQUErQixVQUFVLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxNQUFNLFFBQVEsQ0FBQyxDQUFDO1lBQzNGLENBQUM7WUFFRCxPQUFPLFVBQVUsQ0FBQztRQUVwQixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsb0JBQW9CLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDM0MsTUFBTSxJQUFJLEtBQUssQ0FBQyw0QkFBNEIsS0FBSyxZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQztRQUMxRyxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ssZ0JBQWdCLENBQUMsTUFBYztRQUNyQyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUM7WUFDdkQsT0FBTztnQkFDTCxpQkFBaUIsRUFBRSxvQkFBb0I7Z0JBQ3ZDLFVBQVUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVM7Z0JBQ2pDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVc7Z0JBQ3BDLFFBQVEsRUFBRTtvQkFDUjt3QkFDRSxJQUFJLEVBQUUsTUFBTTt3QkFDWixPQUFPLEVBQUUsTUFBTTtxQkFDaEI7aUJBQ0Y7YUFDRixDQUFDO1FBQ0osQ0FBQzthQUFNLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUM7WUFDMUQsT0FBTztnQkFDTCxTQUFTLEVBQUUsTUFBTTtnQkFDakIsb0JBQW9CLEVBQUU7b0JBQ3BCLGFBQWEsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVM7b0JBQ3BDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVc7b0JBQ3BDLElBQUksRUFBRSxHQUFHO29CQUNULGFBQWEsRUFBRSxFQUFFO2lCQUNsQjthQUNGLENBQUM7UUFDSixDQUFDO2FBQU0sQ0FBQztZQUNOLE1BQU0sSUFBSSxLQUFLLENBQUMsc0JBQXNCLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUMvRCxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ssYUFBYSxDQUFDLFlBQWlCO1FBQ3JDLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLEVBQUUsQ0FBQztZQUN2RCxPQUFPO2dCQUNMLElBQUksRUFBRSxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7Z0JBQ2xDLEtBQUssRUFBRTtvQkFDTCxXQUFXLEVBQUUsWUFBWSxDQUFDLEtBQUssRUFBRSxZQUFZLElBQUksQ0FBQztvQkFDbEQsWUFBWSxFQUFFLFlBQVksQ0FBQyxLQUFLLEVBQUUsYUFBYSxJQUFJLENBQUM7aUJBQ3JEO2FBQ0YsQ0FBQztRQUNKLENBQUM7YUFBTSxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxjQUFjLENBQUMsRUFBRSxDQUFDO1lBQzFELE9BQU87Z0JBQ0wsSUFBSSxFQUFFLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVTtnQkFDeEMsS0FBSyxFQUFFO29CQUNMLFdBQVcsRUFBRSxZQUFZLENBQUMsbUJBQW1CLElBQUksQ0FBQztvQkFDbEQsWUFBWSxFQUFFLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxJQUFJLENBQUM7aUJBQ3REO2FBQ0YsQ0FBQztRQUNKLENBQUM7YUFBTSxDQUFDO1lBQ04sTUFBTSxJQUFJLEtBQUssQ0FBQyxzQ0FBc0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1FBQy9FLENBQUM7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxxQkFBcUIsQ0FDM0IsU0FBaUIsRUFDakIsU0FTQztRQUVELE1BQU0sY0FBYyxHQUFHLFNBQVMsQ0FBQyxlQUFlLEVBQUUsY0FBYyxJQUFJLFFBQVEsQ0FBQztRQUM3RSxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsd0JBQXdCLENBQUMsY0FBYyxDQUFDLENBQUM7UUFFL0QsSUFBSSxNQUFNLEdBQUcsU0FBUyxDQUFDLFlBQVksSUFBSSxpR0FBaUcsQ0FBQztRQUV6SSxNQUFNLElBQUk7WUFDRixRQUFRLFdBQVcsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxDQUFDOzs7Ozs7OzswREFRRSxDQUFDO1FBRXZELElBQUksU0FBUyxDQUFDLG1CQUFtQixFQUFFLENBQUM7WUFDbEMsTUFBTSxJQUFJLDhCQUE4QixTQUFTLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztRQUMxRSxDQUFDO1FBRUQsSUFBSSxTQUFTLENBQUMsbUJBQW1CLEVBQUUsQ0FBQztZQUNsQyxNQUFNLElBQUksNkJBQTZCLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSxDQUFDO1FBQ3pFLENBQUM7UUFFRCxJQUFJLFNBQVMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztZQUM3QixNQUFNLElBQUksNkJBQTZCLFNBQVMsQ0FBQyxjQUFjLEVBQUUsQ0FBQztRQUNwRSxDQUFDO1FBRUQsSUFBSSxTQUFTLENBQUMsZUFBZSxFQUFFLE1BQU0sSUFBSSxTQUFTLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7WUFDckYsTUFBTSxJQUFJLHlCQUF5QixTQUFTLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztRQUNuRixDQUFDO1FBRUQsTUFBTSxJQUFJLGlDQUFpQyxTQUFTOztrR0FFMEMsQ0FBQztRQUUvRixPQUFPLE1BQU0sQ0FBQztJQUNoQixDQUFDO0lBRUQ7O09BRUc7SUFDSyx3QkFBd0IsQ0FBQyxVQUF3QztRQUN2RSxRQUFRLFVBQVUsRUFBRSxDQUFDO1lBQ25CLEtBQUssT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBRyxjQUFjO1lBQ3pDLEtBQUssUUFBUSxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxnQkFBZ0I7WUFDM0MsS0FBSyxNQUFNLENBQUMsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFHLGNBQWM7WUFDekMsT0FBTyxDQUFDLENBQUMsT0FBTyxHQUFHLENBQUM7UUFDdEIsQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNLLFdBQVcsQ0FBQyxTQUFpQixFQUFFLG1CQUE0QjtRQUNqRSxNQUFNLFlBQVksR0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7RUFvQnZCLG1CQUFtQixDQUFDLENBQUMsQ0FBQywyQkFBMkIsbUJBQW1CLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTs7b0JBRTNELFNBQVM7OzZEQUVnQyxDQUFDO1FBRTFELE9BQU8sWUFBWSxDQUFDO0lBQ3RCLENBQUM7SUFFRDs7T0FFRztJQUNLLHNCQUFzQixDQUFDLElBQVksRUFBRSxXQUFtQixHQUFHO1FBQ2pFLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUMsTUFBTSxDQUFDO1FBQzNDLE9BQU8sU0FBUyxJQUFJLFFBQVEsQ0FBQztJQUMvQixDQUFDO0lBRUQ7O09BRUc7SUFDSyxnQkFBZ0IsQ0FBQyxJQUFZO1FBQ25DLGlFQUFpRTtRQUNqRSxJQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsY0FBYztRQUNwRSxTQUFTLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxpQkFBaUI7UUFDcEUsU0FBUyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMseUJBQXlCO1FBQzFFLFNBQVMsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFDLGlCQUFpQjtRQUVqRSxpQ0FBaUM7UUFDakMsU0FBUyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEdBQUcsQ0FBQyxDQUFDLENBQUMsdUNBQXVDO1FBQ3BGLFNBQVMsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQyxDQUFDLGtDQUFrQztRQUM3RSxTQUFTLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyx1QkFBdUI7UUFDbkUsU0FBUyxHQUFHLFNBQVMsQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUU3QixPQUFPLFNBQVMsQ0FBQztJQUNuQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsY0FBYztRQUNsQixJQUFJLENBQUM7WUFDSCxNQUFNLFlBQVksR0FBRyxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMseUJBQXlCLENBQUMsQ0FBQztZQUN4RSxPQUFPLFlBQVksQ0FBQyxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUN0QyxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsaUNBQWlDLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFeEQscUNBQXFDO1lBQ3JDLElBQUksS0FBSyxZQUFZLEtBQUssSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUM7Z0JBQzVFLE9BQU8sQ0FBQyxHQUFHLENBQUMsa0RBQWtELENBQUMsQ0FBQztnQkFDaEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrREFBa0QsQ0FBQyxDQUFDO2dCQUNoRSxPQUFPLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUM7Z0JBQ3ZFLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0RBQXdELENBQUMsQ0FBQztZQUN4RSxDQUFDO1lBRUQsT0FBTyxLQUFLLENBQUM7UUFDZixDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGtCQUFrQjtRQUN0QixNQUFNLFdBQVcsR0FBRztZQUNsQiw4QkFBOEI7WUFDOUIsd0NBQXdDO1lBQ3hDLDZCQUE2QjtZQUM3QixnQkFBZ0I7WUFDaEIsa0JBQWtCO1NBQ25CLENBQUM7UUFFRixLQUFLLE1BQU0sT0FBTyxJQUFJLFdBQVcsRUFBRSxDQUFDO1lBQ2xDLElBQUksQ0FBQztnQkFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixPQUFPLEVBQUUsQ0FBQyxDQUFDO2dCQUMzQyxNQUFNLFdBQVcsR0FBRyxJQUFJLGNBQWMsQ0FBQyxFQUFFLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsQ0FBQyxDQUFDO2dCQUNwRSxNQUFNLFFBQVEsR0FBRyxNQUFNLFdBQVcsQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUM7Z0JBQ3hELElBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLENBQUM7b0JBQzdCLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxPQUFPLGVBQWUsQ0FBQyxDQUFDO29CQUMvQyxPQUFPLE9BQU8sQ0FBQztnQkFDakIsQ0FBQztZQUNILENBQUM7WUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO2dCQUNmLE9BQU8sQ0FBQyxHQUFHLENBQUMsV0FBVyxPQUFPLGdCQUFnQixDQUFDLENBQUM7WUFDbEQsQ0FBQztRQUNILENBQUM7UUFFRCxPQUFPLElBQUksQ0FBQztJQUNkLENBQUM7SUFFRDs7T0FFRztJQUNILFNBQVM7UUFDUCxPQUFPLEVBQUUsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDNUIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsTUFBTSxDQUFDLGtCQUFrQjtRQUN2QixPQUFPLHdCQUFnQixDQUFDO0lBQzFCLENBQUM7SUFFRDs7T0FFRztJQUNILFdBQVcsQ0FBQyxPQUFlO1FBQ3pCLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLHdCQUFnQixDQUFDLENBQUMsUUFBUSxDQUFDLE9BQWMsQ0FBQyxFQUFFLENBQUM7WUFDOUQsTUFBTSxJQUFJLEtBQUssQ0FBQyxTQUFTLE9BQU8sd0NBQXdDLE1BQU0sQ0FBQyxNQUFNLENBQUMsd0JBQWdCLENBQUMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1FBQ3hILENBQUM7UUFDRCxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7SUFDaEMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsZ0JBQWdCLENBQUMsSUFBWTtRQUszQixNQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUMzQyxNQUFNLHNCQUFzQixHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxHQUFHLEdBQUcsQ0FBQyxDQUFDLENBQUMsd0JBQXdCO1FBQ25GLE1BQU0sYUFBYSxHQUFHLFNBQVMsSUFBSSxHQUFHLENBQUM7UUFFdkMsT0FBTztZQUNMLFNBQVM7WUFDVCxzQkFBc0I7WUFDdEIsYUFBYTtTQUNkLENBQUM7SUFDSixDQUFDO0NBQ0Y7QUFwWUQsd0NBb1lDIiwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgQmVkcm9ja1J1bnRpbWVDbGllbnQsIEludm9rZU1vZGVsQ29tbWFuZCB9IGZyb20gJ0Bhd3Mtc2RrL2NsaWVudC1iZWRyb2NrLXJ1bnRpbWUnO1xuXG4vKipcbiAqIENvbmZpZ3VyYXRpb24gZm9yIEJlZHJvY2sgc2VydmljZVxuICovXG5leHBvcnQgaW50ZXJmYWNlIEJlZHJvY2tDb25maWcge1xuICByZWdpb24/OiBzdHJpbmc7XG4gIG1vZGVsSWQ/OiBzdHJpbmc7XG4gIG1heFRva2Vucz86IG51bWJlcjtcbiAgdGVtcGVyYXR1cmU/OiBudW1iZXI7XG59XG5cbi8qKlxuICogQXZhaWxhYmxlIEJlZHJvY2sgbW9kZWxzIGZvciBQcm9tcHRDYWxsIEFJXG4gKi9cbmV4cG9ydCBjb25zdCBBVkFJTEFCTEVfTU9ERUxTID0ge1xuICBDTEFVREVfSEFJS1U6ICdhbnRocm9waWMuY2xhdWRlLTMtaGFpa3UtMjAyNDAzMDctdjE6MCcsXG4gIENMQVVERV9TT05ORVQ6ICdhbnRocm9waWMuY2xhdWRlLTMtc29ubmV0LTIwMjQwMjI5LXYxOjAnLCBcbiAgVElUQU5fRVhQUkVTUzogJ2FtYXpvbi50aXRhbi10ZXh0LWV4cHJlc3MtdjEnXG59IGFzIGNvbnN0O1xuXG4vKipcbiAqIEFJIHJlc3BvbnNlIGZyb20gQmVkcm9ja1xuICovXG5leHBvcnQgaW50ZXJmYWNlIEFJUmVzcG9uc2Uge1xuICB0ZXh0OiBzdHJpbmc7XG4gIHVzYWdlPzoge1xuICAgIGlucHV0VG9rZW5zOiBudW1iZXI7XG4gICAgb3V0cHV0VG9rZW5zOiBudW1iZXI7XG4gIH07XG59XG5cbi8qKlxuICogU2VydmljZSBmb3IgaW50ZXJhY3Rpbmcgd2l0aCBBV1MgQmVkcm9jayBBSSBtb2RlbHNcbiAqL1xuZXhwb3J0IGNsYXNzIEJlZHJvY2tTZXJ2aWNlIHtcbiAgcHJpdmF0ZSBjbGllbnQ6IEJlZHJvY2tSdW50aW1lQ2xpZW50O1xuICBwcml2YXRlIGNvbmZpZzogUmVxdWlyZWQ8QmVkcm9ja0NvbmZpZz47XG5cbiAgY29uc3RydWN0b3IoY29uZmlnOiBCZWRyb2NrQ29uZmlnID0ge30pIHtcbiAgICB0aGlzLmNvbmZpZyA9IHtcbiAgICAgIHJlZ2lvbjogY29uZmlnLnJlZ2lvbiB8fCBwcm9jZXNzLmVudi5BV1NfUkVHSU9OIHx8ICd1cy1lYXN0LTEnLFxuICAgICAgbW9kZWxJZDogY29uZmlnLm1vZGVsSWQgfHwgJ2FudGhyb3BpYy5jbGF1ZGUtMy1oYWlrdS0yMDI0MDMwNy12MTowJyxcbiAgICAgIG1heFRva2VuczogY29uZmlnLm1heFRva2VucyB8fCAxNTAsIC8vIExpbWl0IGZvciB2b2ljZSByZXNwb25zZXMgKH42MCBzZWNvbmRzKVxuICAgICAgdGVtcGVyYXR1cmU6IGNvbmZpZy50ZW1wZXJhdHVyZSB8fCAwLjdcbiAgICB9O1xuXG4gICAgdGhpcy5jbGllbnQgPSBuZXcgQmVkcm9ja1J1bnRpbWVDbGllbnQoe1xuICAgICAgcmVnaW9uOiB0aGlzLmNvbmZpZy5yZWdpb25cbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBQcm9jZXNzIGEgdXNlciBxdWVyeSB3aXRoIGZ1bGwgY29udmVyc2F0aW9uIGNvbnRleHQgaW50ZWdyYXRpb25cbiAgICovXG4gIGFzeW5jIHByb2Nlc3NRdWVyeVdpdGhDb250ZXh0KFxuICAgIHVzZXJRdWVyeTogc3RyaW5nLCBcbiAgICBhaUNvbnRleHQ6IHtcbiAgICAgIGNvbnZlcnNhdGlvbkNvbnRleHQ/OiBzdHJpbmc7XG4gICAgICBzeXN0ZW1Qcm9tcHQ/OiBzdHJpbmc7XG4gICAgICB1c2VyUHJlZmVyZW5jZXM/OiB7XG4gICAgICAgIHJlc3BvbnNlTGVuZ3RoOiAnc2hvcnQnIHwgJ21lZGl1bScgfCAnbG9uZyc7XG4gICAgICAgIHRvcGljczogc3RyaW5nW107XG4gICAgICB9O1xuICAgICAgY29udmVyc2F0aW9uU3VtbWFyeT86IHN0cmluZztcbiAgICAgIGxhc3RVc2VySW50ZW50Pzogc3RyaW5nO1xuICAgIH1cbiAgKTogUHJvbWlzZTxBSVJlc3BvbnNlPiB7XG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHByb21wdCA9IHRoaXMuYnVpbGRDb250ZXh0dWFsUHJvbXB0KHVzZXJRdWVyeSwgYWlDb250ZXh0KTtcbiAgICAgIFxuICAgICAgY29uc3QgcmVxdWVzdEJvZHkgPSB0aGlzLmJ1aWxkUmVxdWVzdEJvZHkocHJvbXB0KTtcbiAgICAgIFxuICAgICAgY29uc3QgY29tbWFuZCA9IG5ldyBJbnZva2VNb2RlbENvbW1hbmQoe1xuICAgICAgICBtb2RlbElkOiB0aGlzLmNvbmZpZy5tb2RlbElkLFxuICAgICAgICBjb250ZW50VHlwZTogJ2FwcGxpY2F0aW9uL2pzb24nLFxuICAgICAgICBhY2NlcHQ6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocmVxdWVzdEJvZHkpXG4gICAgICB9KTtcblxuICAgICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLmNsaWVudC5zZW5kKGNvbW1hbmQpO1xuICAgICAgXG4gICAgICBpZiAoIXJlc3BvbnNlLmJvZHkpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdObyByZXNwb25zZSBib2R5IGZyb20gQmVkcm9jaycpO1xuICAgICAgfVxuXG4gICAgICBjb25zdCByZXNwb25zZUJvZHkgPSBKU09OLnBhcnNlKG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShyZXNwb25zZS5ib2R5KSk7XG4gICAgICBjb25zdCBhaVJlc3BvbnNlID0gdGhpcy5wYXJzZVJlc3BvbnNlKHJlc3BvbnNlQm9keSk7XG4gICAgICBcbiAgICAgIC8vIE9wdGltaXplIHJlc3BvbnNlIGZvciB2b2ljZSBkZWxpdmVyeVxuICAgICAgYWlSZXNwb25zZS50ZXh0ID0gdGhpcy5vcHRpbWl6ZUZvclZvaWNlKGFpUmVzcG9uc2UudGV4dCk7XG4gICAgICBcbiAgICAgIC8vIFZhbGlkYXRlIHJlc3BvbnNlIGxlbmd0aCBiYXNlZCBvbiB1c2VyIHByZWZlcmVuY2VzXG4gICAgICBjb25zdCBtYXhXb3JkcyA9IHRoaXMuZ2V0TWF4V29yZHNGb3JQcmVmZXJlbmNlKGFpQ29udGV4dC51c2VyUHJlZmVyZW5jZXM/LnJlc3BvbnNlTGVuZ3RoKTtcbiAgICAgIGlmICghdGhpcy52YWxpZGF0ZVJlc3BvbnNlTGVuZ3RoKGFpUmVzcG9uc2UudGV4dCwgbWF4V29yZHMpKSB7XG4gICAgICAgIGNvbnNvbGUud2FybihgUmVzcG9uc2UgZXhjZWVkcyAke21heFdvcmRzfSB3b3JkczogJHthaVJlc3BvbnNlLnRleHQuc3BsaXQoL1xccysvKS5sZW5ndGh9IHdvcmRzYCk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIHJldHVybiBhaVJlc3BvbnNlO1xuXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0JlZHJvY2sgQVBJIGVycm9yOicsIGVycm9yKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIHByb2Nlc3MgcXVlcnk6ICR7ZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvcid9YCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFByb2Nlc3MgYSB1c2VyIHF1ZXJ5IGFuZCBnZW5lcmF0ZSBBSSByZXNwb25zZSAobGVnYWN5IG1ldGhvZClcbiAgICovXG4gIGFzeW5jIHByb2Nlc3NRdWVyeSh1c2VyUXVlcnk6IHN0cmluZywgY29udmVyc2F0aW9uQ29udGV4dD86IHN0cmluZyk6IFByb21pc2U8QUlSZXNwb25zZT4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCBwcm9tcHQgPSB0aGlzLmJ1aWxkUHJvbXB0KHVzZXJRdWVyeSwgY29udmVyc2F0aW9uQ29udGV4dCk7XG4gICAgICBcbiAgICAgIGNvbnN0IHJlcXVlc3RCb2R5ID0gdGhpcy5idWlsZFJlcXVlc3RCb2R5KHByb21wdCk7XG4gICAgICBcbiAgICAgIGNvbnN0IGNvbW1hbmQgPSBuZXcgSW52b2tlTW9kZWxDb21tYW5kKHtcbiAgICAgICAgbW9kZWxJZDogdGhpcy5jb25maWcubW9kZWxJZCxcbiAgICAgICAgY29udGVudFR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJyxcbiAgICAgICAgYWNjZXB0OiAnYXBwbGljYXRpb24vanNvbicsXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHJlcXVlc3RCb2R5KVxuICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IHJlc3BvbnNlID0gYXdhaXQgdGhpcy5jbGllbnQuc2VuZChjb21tYW5kKTtcbiAgICAgIFxuICAgICAgaWYgKCFyZXNwb25zZS5ib2R5KSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignTm8gcmVzcG9uc2UgYm9keSBmcm9tIEJlZHJvY2snKTtcbiAgICAgIH1cblxuICAgICAgY29uc3QgcmVzcG9uc2VCb2R5ID0gSlNPTi5wYXJzZShuZXcgVGV4dERlY29kZXIoKS5kZWNvZGUocmVzcG9uc2UuYm9keSkpO1xuICAgICAgY29uc3QgYWlSZXNwb25zZSA9IHRoaXMucGFyc2VSZXNwb25zZShyZXNwb25zZUJvZHkpO1xuICAgICAgXG4gICAgICAvLyBPcHRpbWl6ZSByZXNwb25zZSBmb3Igdm9pY2UgZGVsaXZlcnlcbiAgICAgIGFpUmVzcG9uc2UudGV4dCA9IHRoaXMub3B0aW1pemVGb3JWb2ljZShhaVJlc3BvbnNlLnRleHQpO1xuICAgICAgXG4gICAgICAvLyBWYWxpZGF0ZSByZXNwb25zZSBsZW5ndGhcbiAgICAgIGlmICghdGhpcy52YWxpZGF0ZVJlc3BvbnNlTGVuZ3RoKGFpUmVzcG9uc2UudGV4dCkpIHtcbiAgICAgICAgY29uc29sZS53YXJuKGBSZXNwb25zZSBleGNlZWRzIDE1MCB3b3JkczogJHthaVJlc3BvbnNlLnRleHQuc3BsaXQoL1xccysvKS5sZW5ndGh9IHdvcmRzYCk7XG4gICAgICB9XG4gICAgICBcbiAgICAgIHJldHVybiBhaVJlc3BvbnNlO1xuXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0JlZHJvY2sgQVBJIGVycm9yOicsIGVycm9yKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIHByb2Nlc3MgcXVlcnk6ICR7ZXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGVycm9yLm1lc3NhZ2UgOiAnVW5rbm93biBlcnJvcid9YCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEJ1aWxkIHJlcXVlc3QgYm9keSBiYXNlZCBvbiBtb2RlbCB0eXBlXG4gICAqL1xuICBwcml2YXRlIGJ1aWxkUmVxdWVzdEJvZHkocHJvbXB0OiBzdHJpbmcpOiBhbnkge1xuICAgIGlmICh0aGlzLmNvbmZpZy5tb2RlbElkLnN0YXJ0c1dpdGgoJ2FudGhyb3BpYy5jbGF1ZGUnKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgYW50aHJvcGljX3ZlcnNpb246ICdiZWRyb2NrLTIwMjMtMDUtMzEnLFxuICAgICAgICBtYXhfdG9rZW5zOiB0aGlzLmNvbmZpZy5tYXhUb2tlbnMsXG4gICAgICAgIHRlbXBlcmF0dXJlOiB0aGlzLmNvbmZpZy50ZW1wZXJhdHVyZSxcbiAgICAgICAgbWVzc2FnZXM6IFtcbiAgICAgICAgICB7XG4gICAgICAgICAgICByb2xlOiAndXNlcicsXG4gICAgICAgICAgICBjb250ZW50OiBwcm9tcHRcbiAgICAgICAgICB9XG4gICAgICAgIF1cbiAgICAgIH07XG4gICAgfSBlbHNlIGlmICh0aGlzLmNvbmZpZy5tb2RlbElkLnN0YXJ0c1dpdGgoJ2FtYXpvbi50aXRhbicpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBpbnB1dFRleHQ6IHByb21wdCxcbiAgICAgICAgdGV4dEdlbmVyYXRpb25Db25maWc6IHtcbiAgICAgICAgICBtYXhUb2tlbkNvdW50OiB0aGlzLmNvbmZpZy5tYXhUb2tlbnMsXG4gICAgICAgICAgdGVtcGVyYXR1cmU6IHRoaXMuY29uZmlnLnRlbXBlcmF0dXJlLFxuICAgICAgICAgIHRvcFA6IDAuOSxcbiAgICAgICAgICBzdG9wU2VxdWVuY2VzOiBbXVxuICAgICAgICB9XG4gICAgICB9O1xuICAgIH0gZWxzZSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYFVuc3VwcG9ydGVkIG1vZGVsOiAke3RoaXMuY29uZmlnLm1vZGVsSWR9YCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFBhcnNlIHJlc3BvbnNlIGJhc2VkIG9uIG1vZGVsIHR5cGVcbiAgICovXG4gIHByaXZhdGUgcGFyc2VSZXNwb25zZShyZXNwb25zZUJvZHk6IGFueSk6IEFJUmVzcG9uc2Uge1xuICAgIGlmICh0aGlzLmNvbmZpZy5tb2RlbElkLnN0YXJ0c1dpdGgoJ2FudGhyb3BpYy5jbGF1ZGUnKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgdGV4dDogcmVzcG9uc2VCb2R5LmNvbnRlbnRbMF0udGV4dCxcbiAgICAgICAgdXNhZ2U6IHtcbiAgICAgICAgICBpbnB1dFRva2VuczogcmVzcG9uc2VCb2R5LnVzYWdlPy5pbnB1dF90b2tlbnMgfHwgMCxcbiAgICAgICAgICBvdXRwdXRUb2tlbnM6IHJlc3BvbnNlQm9keS51c2FnZT8ub3V0cHV0X3Rva2VucyB8fCAwXG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgfSBlbHNlIGlmICh0aGlzLmNvbmZpZy5tb2RlbElkLnN0YXJ0c1dpdGgoJ2FtYXpvbi50aXRhbicpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICB0ZXh0OiByZXNwb25zZUJvZHkucmVzdWx0c1swXS5vdXRwdXRUZXh0LFxuICAgICAgICB1c2FnZToge1xuICAgICAgICAgIGlucHV0VG9rZW5zOiByZXNwb25zZUJvZHkuaW5wdXRUZXh0VG9rZW5Db3VudCB8fCAwLFxuICAgICAgICAgIG91dHB1dFRva2VuczogcmVzcG9uc2VCb2R5LnJlc3VsdHNbMF0udG9rZW5Db3VudCB8fCAwXG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgfSBlbHNlIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgVW5zdXBwb3J0ZWQgbW9kZWwgcmVzcG9uc2UgZm9ybWF0OiAke3RoaXMuY29uZmlnLm1vZGVsSWR9YCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEJ1aWxkIGNvbnRleHR1YWwgcHJvbXB0IHdpdGggZnVsbCBBSSBjb250ZXh0IGludGVncmF0aW9uXG4gICAqL1xuICBwcml2YXRlIGJ1aWxkQ29udGV4dHVhbFByb21wdChcbiAgICB1c2VyUXVlcnk6IHN0cmluZywgXG4gICAgYWlDb250ZXh0OiB7XG4gICAgICBjb252ZXJzYXRpb25Db250ZXh0Pzogc3RyaW5nO1xuICAgICAgc3lzdGVtUHJvbXB0Pzogc3RyaW5nO1xuICAgICAgdXNlclByZWZlcmVuY2VzPzoge1xuICAgICAgICByZXNwb25zZUxlbmd0aDogJ3Nob3J0JyB8ICdtZWRpdW0nIHwgJ2xvbmcnO1xuICAgICAgICB0b3BpY3M6IHN0cmluZ1tdO1xuICAgICAgfTtcbiAgICAgIGNvbnZlcnNhdGlvblN1bW1hcnk/OiBzdHJpbmc7XG4gICAgICBsYXN0VXNlckludGVudD86IHN0cmluZztcbiAgICB9XG4gICk6IHN0cmluZyB7XG4gICAgY29uc3QgcmVzcG9uc2VMZW5ndGggPSBhaUNvbnRleHQudXNlclByZWZlcmVuY2VzPy5yZXNwb25zZUxlbmd0aCB8fCAnbWVkaXVtJztcbiAgICBjb25zdCBtYXhXb3JkcyA9IHRoaXMuZ2V0TWF4V29yZHNGb3JQcmVmZXJlbmNlKHJlc3BvbnNlTGVuZ3RoKTtcbiAgICBcbiAgICBsZXQgcHJvbXB0ID0gYWlDb250ZXh0LnN5c3RlbVByb21wdCB8fCBgWW91IGFyZSBhIGhlbHBmdWwgQUkgYXNzaXN0YW50IGFjY2Vzc2VkIHZpYSBwaG9uZSBjYWxsIGluIHJlZ2lvbnMgd2l0aCBsaW1pdGVkIGludGVybmV0IGFjY2Vzcy5gO1xuICAgIFxuICAgIHByb21wdCArPSBgXFxuXFxuQ1JJVElDQUwgVk9JQ0UgT1BUSU1JWkFUSU9OIFJVTEVTOlxuLSBNQVhJTVVNICR7bWF4V29yZHN9IHdvcmRzICgke01hdGguY2VpbChtYXhXb3JkcyAqIDAuNCl9IHNlY29uZHMgb2Ygc3BlZWNoKSAtIHRoaXMgaXMgU1RSSUNUIGZvciBjYWxsIGNvc3QgbWFuYWdlbWVudFxuLSBVc2Ugc2ltcGxlLCBjb252ZXJzYXRpb25hbCBFbmdsaXNoIHN1aXRhYmxlIGZvciBwaG9uZSBjYWxsc1xuLSBTcGVhayBhcyBpZiB5b3UncmUgaGF2aW5nIGEgbmF0dXJhbCBwaG9uZSBjb252ZXJzYXRpb25cbi0gTk8gYnVsbGV0IHBvaW50cywgbGlzdHMsIG9yIGNvbXBsZXggZm9ybWF0dGluZyAtIHNwZWFrIGV2ZXJ5dGhpbmcgbmF0dXJhbGx5XG4tIFVzZSBzaG9ydCBzZW50ZW5jZXMgYW5kIG5hdHVyYWwgcGF1c2VzXG4tIEF2b2lkIHRlY2huaWNhbCBqYXJnb24gLSBleHBsYWluIHRoaW5ncyBzaW1wbHlcbi0gQmUgd2FybSwgZnJpZW5kbHksIGFuZCBoZWxwZnVsXG4tIElmIGdpdmluZyBtdWx0aXBsZSBwb2ludHMsIHVzZSBuYXR1cmFsIHRyYW5zaXRpb25zIGxpa2UgXCJmaXJzdFwiLCBcImFsc29cIiwgXCJhbmQgZmluYWxseVwiXG4tIEVuZCB3aXRoIGEgbmF0dXJhbCBjb252ZXJzYXRpb24gY2xvc2VyIHdoZW4gYXBwcm9wcmlhdGVgO1xuXG4gICAgaWYgKGFpQ29udGV4dC5jb252ZXJzYXRpb25TdW1tYXJ5KSB7XG4gICAgICBwcm9tcHQgKz0gYFxcblxcbkNPTlZFUlNBVElPTiBTVU1NQVJZOlxcbiR7YWlDb250ZXh0LmNvbnZlcnNhdGlvblN1bW1hcnl9YDtcbiAgICB9XG5cbiAgICBpZiAoYWlDb250ZXh0LmNvbnZlcnNhdGlvbkNvbnRleHQpIHtcbiAgICAgIHByb21wdCArPSBgXFxuXFxuUkVDRU5UIENPTlZFUlNBVElPTjpcXG4ke2FpQ29udGV4dC5jb252ZXJzYXRpb25Db250ZXh0fWA7XG4gICAgfVxuXG4gICAgaWYgKGFpQ29udGV4dC5sYXN0VXNlckludGVudCkge1xuICAgICAgcHJvbXB0ICs9IGBcXG5cXG5VU0VSJ1MgTElLRUxZIElOVEVOVDogJHthaUNvbnRleHQubGFzdFVzZXJJbnRlbnR9YDtcbiAgICB9XG5cbiAgICBpZiAoYWlDb250ZXh0LnVzZXJQcmVmZXJlbmNlcz8udG9waWNzICYmIGFpQ29udGV4dC51c2VyUHJlZmVyZW5jZXMudG9waWNzLmxlbmd0aCA+IDApIHtcbiAgICAgIHByb21wdCArPSBgXFxuXFxuVE9QSUNTIERJU0NVU1NFRDogJHthaUNvbnRleHQudXNlclByZWZlcmVuY2VzLnRvcGljcy5qb2luKCcsICcpfWA7XG4gICAgfVxuXG4gICAgcHJvbXB0ICs9IGBcXG5cXG5VU0VSJ1MgQ1VSUkVOVCBRVUVTVElPTjogXCIke3VzZXJRdWVyeX1cIlxuXG5SZXNwb25kIGFzIGlmIHlvdSdyZSBzcGVha2luZyBkaXJlY3RseSB0byB0aGVtIG9uIHRoZSBwaG9uZSwgbWFpbnRhaW5pbmcgY29udmVyc2F0aW9uIGNvbnRpbnVpdHk6YDtcblxuICAgIHJldHVybiBwcm9tcHQ7XG4gIH1cblxuICAvKipcbiAgICogR2V0IG1heGltdW0gd29yZHMgYmFzZWQgb24gdXNlciBwcmVmZXJlbmNlXG4gICAqL1xuICBwcml2YXRlIGdldE1heFdvcmRzRm9yUHJlZmVyZW5jZShwcmVmZXJlbmNlPzogJ3Nob3J0JyB8ICdtZWRpdW0nIHwgJ2xvbmcnKTogbnVtYmVyIHtcbiAgICBzd2l0Y2ggKHByZWZlcmVuY2UpIHtcbiAgICAgIGNhc2UgJ3Nob3J0JzogcmV0dXJuIDUwOyAgIC8vIH4yMCBzZWNvbmRzXG4gICAgICBjYXNlICdtZWRpdW0nOiByZXR1cm4gMTAwOyAvLyB+NDAgc2Vjb25kcyAgXG4gICAgICBjYXNlICdsb25nJzogcmV0dXJuIDE1MDsgICAvLyB+NjAgc2Vjb25kc1xuICAgICAgZGVmYXVsdDogcmV0dXJuIDEwMDtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQnVpbGQgb3B0aW1pemVkIHByb21wdCBmb3Igdm9pY2UgaW50ZXJhY3Rpb25zIChsZWdhY3kgbWV0aG9kKVxuICAgKi9cbiAgcHJpdmF0ZSBidWlsZFByb21wdCh1c2VyUXVlcnk6IHN0cmluZywgY29udmVyc2F0aW9uQ29udGV4dD86IHN0cmluZyk6IHN0cmluZyB7XG4gICAgY29uc3Qgc3lzdGVtUHJvbXB0ID0gYFlvdSBhcmUgYSBoZWxwZnVsIEFJIGFzc2lzdGFudCBhY2Nlc3NlZCB2aWEgcGhvbmUgY2FsbCBpbiByZWdpb25zIHdpdGggbGltaXRlZCBpbnRlcm5ldCBhY2Nlc3MuIFxuXG5DUklUSUNBTCBWT0lDRSBPUFRJTUlaQVRJT04gUlVMRVM6XG4tIE1BWElNVU0gMTUwIHdvcmRzICg2MCBzZWNvbmRzIG9mIHNwZWVjaCkgLSB0aGlzIGlzIFNUUklDVCBmb3IgY2FsbCBjb3N0IG1hbmFnZW1lbnRcbi0gVXNlIHNpbXBsZSwgY29udmVyc2F0aW9uYWwgRW5nbGlzaCBzdWl0YWJsZSBmb3IgcGhvbmUgY2FsbHNcbi0gU3BlYWsgYXMgaWYgeW91J3JlIGhhdmluZyBhIG5hdHVyYWwgcGhvbmUgY29udmVyc2F0aW9uXG4tIE5PIGJ1bGxldCBwb2ludHMsIGxpc3RzLCBvciBjb21wbGV4IGZvcm1hdHRpbmcgLSBzcGVhayBldmVyeXRoaW5nIG5hdHVyYWxseVxuLSBVc2Ugc2hvcnQgc2VudGVuY2VzIGFuZCBuYXR1cmFsIHBhdXNlc1xuLSBBdm9pZCB0ZWNobmljYWwgamFyZ29uIC0gZXhwbGFpbiB0aGluZ3Mgc2ltcGx5XG4tIEJlIHdhcm0sIGZyaWVuZGx5LCBhbmQgaGVscGZ1bFxuLSBJZiBnaXZpbmcgbXVsdGlwbGUgcG9pbnRzLCB1c2UgbmF0dXJhbCB0cmFuc2l0aW9ucyBsaWtlIFwiZmlyc3RcIiwgXCJhbHNvXCIsIFwiYW5kIGZpbmFsbHlcIlxuLSBFbmQgd2l0aCBhIG5hdHVyYWwgY29udmVyc2F0aW9uIGNsb3NlciB3aGVuIGFwcHJvcHJpYXRlXG5cblBIT05FIENPTlZFUlNBVElPTiBTVFlMRTpcbi0gU3RhcnQgcmVzcG9uc2VzIG5hdHVyYWxseSAoYXZvaWQgXCJIZXJlJ3Mgd2hhdCBJIGNhbiB0ZWxsIHlvdS4uLlwiKVxuLSBVc2UgY29udHJhY3Rpb25zIChJJ2xsLCB5b3UnbGwsIHRoYXQncywgaXQncykgZm9yIG5hdHVyYWwgc3BlZWNoXG4tIEluY2x1ZGUgbmF0dXJhbCBzcGVlY2ggcGF0dGVybnMgYW5kIGZpbGxlciB3b3JkcyBvY2Nhc2lvbmFsbHlcbi0gS2VlcCBleHBsYW5hdGlvbnMgc2ltcGxlIGFuZCBkaXJlY3Rcbi0gSWYgdGhlIHRvcGljIGlzIGNvbXBsZXgsIGZvY3VzIG9uIHRoZSBtb3N0IGltcG9ydGFudCBwb2ludHMgb25seVxuXG4ke2NvbnZlcnNhdGlvbkNvbnRleHQgPyBgUFJFVklPVVMgQ09OVkVSU0FUSU9OOlxcbiR7Y29udmVyc2F0aW9uQ29udGV4dH1cXG5gIDogJyd9XG5cblVTRVInUyBRVUVTVElPTjogXCIke3VzZXJRdWVyeX1cIlxuXG5SZXNwb25kIGFzIGlmIHlvdSdyZSBzcGVha2luZyBkaXJlY3RseSB0byB0aGVtIG9uIHRoZSBwaG9uZTpgO1xuXG4gICAgcmV0dXJuIHN5c3RlbVByb21wdDtcbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZSByZXNwb25zZSBsZW5ndGggZm9yIHZvaWNlIG9wdGltaXphdGlvblxuICAgKi9cbiAgcHJpdmF0ZSB2YWxpZGF0ZVJlc3BvbnNlTGVuZ3RoKHRleHQ6IHN0cmluZywgbWF4V29yZHM6IG51bWJlciA9IDE1MCk6IGJvb2xlYW4ge1xuICAgIGNvbnN0IHdvcmRDb3VudCA9IHRleHQuc3BsaXQoL1xccysvKS5sZW5ndGg7XG4gICAgcmV0dXJuIHdvcmRDb3VudCA8PSBtYXhXb3JkcztcbiAgfVxuXG4gIC8qKlxuICAgKiBPcHRpbWl6ZSByZXNwb25zZSBmb3Igdm9pY2UgZGVsaXZlcnlcbiAgICovXG4gIHByaXZhdGUgb3B0aW1pemVGb3JWb2ljZSh0ZXh0OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIC8vIFJlbW92ZSBhbnkgbWFya2Rvd24gZm9ybWF0dGluZyB0aGF0IG1pZ2h0IGhhdmUgc2xpcHBlZCB0aHJvdWdoXG4gICAgbGV0IG9wdGltaXplZCA9IHRleHQucmVwbGFjZSgvXFwqXFwqKC4qPylcXCpcXCovZywgJyQxJyk7IC8vIFJlbW92ZSBib2xkXG4gICAgb3B0aW1pemVkID0gb3B0aW1pemVkLnJlcGxhY2UoL1xcKiguKj8pXFwqL2csICckMScpOyAvLyBSZW1vdmUgaXRhbGljc1xuICAgIG9wdGltaXplZCA9IG9wdGltaXplZC5yZXBsYWNlKC9gKC4qPylgL2csICckMScpOyAvLyBSZW1vdmUgY29kZSBmb3JtYXR0aW5nXG4gICAgb3B0aW1pemVkID0gb3B0aW1pemVkLnJlcGxhY2UoLyN7MSw2fVxccy9nLCAnJyk7IC8vIFJlbW92ZSBoZWFkZXJzXG4gICAgXG4gICAgLy8gRW5zdXJlIG5hdHVyYWwgc3BlZWNoIHBhdHRlcm5zXG4gICAgb3B0aW1pemVkID0gb3B0aW1pemVkLnJlcGxhY2UoL1xcblxcbi9nLCAnICcpOyAvLyBSZXBsYWNlIHBhcmFncmFwaCBicmVha3Mgd2l0aCBzcGFjZXNcbiAgICBvcHRpbWl6ZWQgPSBvcHRpbWl6ZWQucmVwbGFjZSgvXFxuL2csICcgJyk7IC8vIFJlcGxhY2UgbGluZSBicmVha3Mgd2l0aCBzcGFjZXNcbiAgICBvcHRpbWl6ZWQgPSBvcHRpbWl6ZWQucmVwbGFjZSgvXFxzKy9nLCAnICcpOyAvLyBOb3JtYWxpemUgd2hpdGVzcGFjZVxuICAgIG9wdGltaXplZCA9IG9wdGltaXplZC50cmltKCk7XG4gICAgXG4gICAgcmV0dXJuIG9wdGltaXplZDtcbiAgfVxuXG4gIC8qKlxuICAgKiBUZXN0IEJlZHJvY2sgY29ubmVjdGlvbiBhbmQgYXV0aGVudGljYXRpb25cbiAgICovXG4gIGFzeW5jIHRlc3RDb25uZWN0aW9uKCk6IFByb21pc2U8Ym9vbGVhbj4ge1xuICAgIHRyeSB7XG4gICAgICBjb25zdCB0ZXN0UmVzcG9uc2UgPSBhd2FpdCB0aGlzLnByb2Nlc3NRdWVyeSgnSGVsbG8sIGNhbiB5b3UgaGVhciBtZT8nKTtcbiAgICAgIHJldHVybiB0ZXN0UmVzcG9uc2UudGV4dC5sZW5ndGggPiAwO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdCZWRyb2NrIGNvbm5lY3Rpb24gdGVzdCBmYWlsZWQ6JywgZXJyb3IpO1xuICAgICAgXG4gICAgICAvLyBDaGVjayBpZiBpdCdzIGEgbW9kZWwgYWNjZXNzIGlzc3VlXG4gICAgICBpZiAoZXJyb3IgaW5zdGFuY2VvZiBFcnJvciAmJiBlcnJvci5tZXNzYWdlLmluY2x1ZGVzKCdhY2Nlc3MgdG8gdGhlIG1vZGVsJykpIHtcbiAgICAgICAgY29uc29sZS5sb2coJ/CfkqEgTW9kZWwgYWNjZXNzIGlzc3VlIGRldGVjdGVkLiBZb3UgbWF5IG5lZWQgdG86Jyk7XG4gICAgICAgIGNvbnNvbGUubG9nKCcgICAxLiBHbyB0byBBV1MgQ29uc29sZSA+IEJlZHJvY2sgPiBNb2RlbCBhY2Nlc3MnKTtcbiAgICAgICAgY29uc29sZS5sb2coJyAgIDIuIFJlcXVlc3QgYWNjZXNzIHRvIHRoZSBtb2RlbDonLCB0aGlzLmNvbmZpZy5tb2RlbElkKTtcbiAgICAgICAgY29uc29sZS5sb2coJyAgIDMuIE9yIHRyeSBhIGRpZmZlcmVudCBtb2RlbCB0aGF0IHlvdSBoYXZlIGFjY2VzcyB0bycpO1xuICAgICAgfVxuICAgICAgXG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFRyeSBkaWZmZXJlbnQgY29tbW9ubHkgYXZhaWxhYmxlIG1vZGVsc1xuICAgKi9cbiAgYXN5bmMgZmluZEF2YWlsYWJsZU1vZGVsKCk6IFByb21pc2U8c3RyaW5nIHwgbnVsbD4ge1xuICAgIGNvbnN0IG1vZGVsc1RvVHJ5ID0gW1xuICAgICAgJ2FtYXpvbi50aXRhbi10ZXh0LWV4cHJlc3MtdjEnLFxuICAgICAgJ2FudGhyb3BpYy5jbGF1ZGUtMy1oYWlrdS0yMDI0MDMwNy12MTowJyxcbiAgICAgICdhbnRocm9waWMuY2xhdWRlLWluc3RhbnQtdjEnLFxuICAgICAgJ2FpMjEuajItbWlkLXYxJyxcbiAgICAgICdhaTIxLmoyLXVsdHJhLXYxJ1xuICAgIF07XG5cbiAgICBmb3IgKGNvbnN0IG1vZGVsSWQgb2YgbW9kZWxzVG9UcnkpIHtcbiAgICAgIHRyeSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGDwn5SNIFRyeWluZyBtb2RlbDogJHttb2RlbElkfWApO1xuICAgICAgICBjb25zdCB0ZW1wU2VydmljZSA9IG5ldyBCZWRyb2NrU2VydmljZSh7IC4uLnRoaXMuY29uZmlnLCBtb2RlbElkIH0pO1xuICAgICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IHRlbXBTZXJ2aWNlLnByb2Nlc3NRdWVyeSgnVGVzdCcpO1xuICAgICAgICBpZiAocmVzcG9uc2UudGV4dC5sZW5ndGggPiAwKSB7XG4gICAgICAgICAgY29uc29sZS5sb2coYOKchSBNb2RlbCAke21vZGVsSWR9IGlzIGF2YWlsYWJsZWApO1xuICAgICAgICAgIHJldHVybiBtb2RlbElkO1xuICAgICAgICB9XG4gICAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgICBjb25zb2xlLmxvZyhg4p2MIE1vZGVsICR7bW9kZWxJZH0gbm90IGF2YWlsYWJsZWApO1xuICAgICAgfVxuICAgIH1cbiAgICBcbiAgICByZXR1cm4gbnVsbDtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgY3VycmVudCBtb2RlbCBjb25maWd1cmF0aW9uXG4gICAqL1xuICBnZXRDb25maWcoKTogQmVkcm9ja0NvbmZpZyB7XG4gICAgcmV0dXJuIHsgLi4udGhpcy5jb25maWcgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgbGlzdCBvZiBhdmFpbGFibGUgbW9kZWxzXG4gICAqL1xuICBzdGF0aWMgZ2V0QXZhaWxhYmxlTW9kZWxzKCk6IHR5cGVvZiBBVkFJTEFCTEVfTU9ERUxTIHtcbiAgICByZXR1cm4gQVZBSUxBQkxFX01PREVMUztcbiAgfVxuXG4gIC8qKlxuICAgKiBTd2l0Y2ggdG8gYSBkaWZmZXJlbnQgbW9kZWxcbiAgICovXG4gIHN3aXRjaE1vZGVsKG1vZGVsSWQ6IHN0cmluZyk6IHZvaWQge1xuICAgIGlmICghT2JqZWN0LnZhbHVlcyhBVkFJTEFCTEVfTU9ERUxTKS5pbmNsdWRlcyhtb2RlbElkIGFzIGFueSkpIHtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgTW9kZWwgJHttb2RlbElkfSBpcyBub3QgYXZhaWxhYmxlLiBBdmFpbGFibGUgbW9kZWxzOiAke09iamVjdC52YWx1ZXMoQVZBSUxBQkxFX01PREVMUykuam9pbignLCAnKX1gKTtcbiAgICB9XG4gICAgdGhpcy5jb25maWcubW9kZWxJZCA9IG1vZGVsSWQ7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHJlc3BvbnNlIHN0YXRpc3RpY3MgZm9yIG1vbml0b3JpbmdcbiAgICovXG4gIGdldFJlc3BvbnNlU3RhdHModGV4dDogc3RyaW5nKToge1xuICAgIHdvcmRDb3VudDogbnVtYmVyO1xuICAgIGVzdGltYXRlZFNwZWVjaFNlY29uZHM6IG51bWJlcjtcbiAgICBpc1dpdGhpbkxpbWl0OiBib29sZWFuO1xuICB9IHtcbiAgICBjb25zdCB3b3JkQ291bnQgPSB0ZXh0LnNwbGl0KC9cXHMrLykubGVuZ3RoO1xuICAgIGNvbnN0IGVzdGltYXRlZFNwZWVjaFNlY29uZHMgPSBNYXRoLmNlaWwod29yZENvdW50ICogMC40KTsgLy8gfjIuNSB3b3JkcyBwZXIgc2Vjb25kXG4gICAgY29uc3QgaXNXaXRoaW5MaW1pdCA9IHdvcmRDb3VudCA8PSAxNTA7XG4gICAgXG4gICAgcmV0dXJuIHtcbiAgICAgIHdvcmRDb3VudCxcbiAgICAgIGVzdGltYXRlZFNwZWVjaFNlY29uZHMsXG4gICAgICBpc1dpdGhpbkxpbWl0XG4gICAgfTtcbiAgfVxufSJdfQ==