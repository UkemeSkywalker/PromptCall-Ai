/**
 * DTMF Service for handling keypad input during phone calls
 * Supports "1" for submit and "0" for end call
 */
export interface DTMFInput {
    digits: string;
    callSid: string;
    from: string;
    to: string;
}
export interface DTMFResponse {
    action: 'submit' | 'end_call' | 'invalid' | 'help';
    message?: string;
    shouldContinue: boolean;
}
export declare class DTMFService {
    /**
     * Process DTMF input and determine the appropriate action
     */
    processDTMFInput(input: DTMFInput): DTMFResponse;
    /**
     * Generate TwiML for DTMF gathering
     */
    generateGatherTwiML(options: {
        action: string;
        timeout?: number;
        numDigits?: number;
        finishOnKey?: string;
        prompt?: string;
    }): string;
    /**
     * Generate TwiML for recording with DTMF controls
     * Note: Record and Gather cannot be nested, so we use Record with timeout
     * and then follow with Gather for DTMF input
     */
    generateRecordWithDTMFTwiML(options: {
        speechAction: string;
        dtmfAction: string;
        maxLength?: number;
        timeout?: number;
        prompt?: string;
    }): string;
    /**
     * Generate welcome message with DTMF instructions
     */
    generateWelcomeWithInstructions(): string;
    /**
     * Generate reminder message for DTMF controls
     */
    generateControlsReminder(): string;
}
