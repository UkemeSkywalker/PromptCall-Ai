/**
 * Transcription Processor for handling speech-to-text conversion and validation
 */
import { S3Service } from './s3-service';
export interface TranscriptionResult {
    text: string;
    confidence: number;
    jobName: string;
    status: 'COMPLETED' | 'FAILED' | 'IN_PROGRESS';
    isRetry?: boolean;
    originalConfidence?: number;
}
import { LanguageCode, MediaFormat } from '@aws-sdk/client-transcribe';
export interface TranscriptionConfig {
    region?: string;
    languageCode?: LanguageCode;
    mediaFormat?: MediaFormat;
    mediaSampleRateHertz?: number;
    confidenceThreshold?: number;
    maxRetries?: number;
}
export declare class TranscriptionProcessor {
    private transcribeService;
    private s3Service;
    private config;
    constructor(s3Service: S3Service, config?: TranscriptionConfig);
    /**
     * Process audio from Twilio recording URL
     */
    processAudioFromUrl(recordingUrl: string, sessionId: string, callSid?: string): Promise<TranscriptionResult>;
    /**
     * Validate transcription confidence and retry if needed
     */
    private validateAndRetryIfNeeded;
    /**
     * Check if transcription result is acceptable
     */
    isTranscriptionAcceptable(result: TranscriptionResult): boolean;
    /**
     * Get user-friendly message for transcription issues
     */
    getTranscriptionIssueMessage(result: TranscriptionResult): string;
    /**
     * Validate audio quality for transcription
     */
    validateAudioQuality(audioInfo: {
        url: string;
        duration?: number;
    }): {
        isValid: boolean;
        issues: string[];
    };
    /**
     * Process transcription with full pipeline from S3 URI
     */
    processTranscription(audioS3Uri: string, sessionId: string): Promise<TranscriptionResult>;
    /**
     * Get confidence threshold
     */
    getConfidenceThreshold(): number;
    /**
     * Format transcription result for logging
     */
    formatResultForLogging(result: TranscriptionResult): string;
}
