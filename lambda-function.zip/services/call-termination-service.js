"use strict";
/**
 * Call Termination and Cleanup Service
 *
 * Handles proper call ending, session cleanup, and graceful goodbye messages
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.CallTerminationService = void 0;
class CallTerminationService {
    constructor(sessionManager, timeoutManager, config = {}) {
        this.sessionManager = sessionManager;
        this.timeoutManager = timeoutManager;
        this.config = {
            enableCompletionDetection: true,
            completionKeywords: [
                'thank you', 'thanks', 'that\'s all', 'goodbye', 'bye', 'done',
                'finished', 'complete', 'no more questions', 'that helps',
                'perfect', 'great', 'awesome', 'exactly what i needed'
            ],
            farewellKeywords: [
                'goodbye', 'bye', 'see you', 'talk to you later', 'have a good day',
                'take care', 'farewell', 'catch you later', 'until next time'
            ],
            maxConversationTurns: 15,
            enableGracefulGoodbyes: true,
            ...config
        };
    }
    /**
     * Analyze user input to determine if call should be terminated
     */
    async analyzeTerminationIntent(sessionId, userText, conversationTurn, confidence = 1.0) {
        console.log(`🔍 TERMINATION ANALYSIS: Analyzing "${userText}" for termination intent`);
        // Check for explicit completion/farewell keywords
        const completionDetected = this.detectCompletionIntent(userText);
        const farewellDetected = this.detectFarewellIntent(userText);
        // Check conversation length
        const conversationTooLong = conversationTurn >= this.config.maxConversationTurns;
        if (completionDetected || farewellDetected) {
            console.log(`✅ TERMINATION: User completion/farewell detected`);
            return await this.handleUserRequestedTermination(sessionId, {
                type: 'user_request',
                reason: completionDetected ? 'User indicated completion' : 'User said farewell',
                userText,
                confidence
            });
        }
        if (conversationTooLong) {
            console.log(`⏰ TERMINATION: Conversation too long (${conversationTurn} turns)`);
            return await this.handleSystemInitiatedTermination(sessionId, {
                type: 'system_initiated',
                reason: 'Maximum conversation length reached',
                userText,
                confidence
            });
        }
        // No termination needed
        return {
            shouldTerminate: false,
            twimlResponse: '',
            terminationType: 'continue',
            goodbyeMessage: '',
            sessionUpdated: false
        };
    }
    /**
     * Handle explicit call termination request
     */
    async terminateCall(sessionId, trigger) {
        console.log(`🔚 CALL TERMINATION: Terminating call for session ${sessionId}, reason: ${trigger.reason}`);
        try {
            // Update session status
            await this.sessionManager.updateSessionStatus(sessionId, 'completed', Date.now(), trigger.type === 'error' ? { code: 'error', message: trigger.reason } : undefined);
            // Add final system message
            await this.sessionManager.addSystemMessage(sessionId, `Call terminated: ${trigger.reason}`);
            // Clean up timeout state
            this.timeoutManager.cleanupSession(sessionId);
            // Generate appropriate goodbye message and TwiML
            const goodbyeMessage = this.generateGoodbyeMessage(trigger);
            const twimlResponse = this.createTerminationTwiML(goodbyeMessage, trigger.type);
            console.log(`✅ CALL TERMINATED: Session ${sessionId} completed successfully`);
            return {
                shouldTerminate: true,
                twimlResponse,
                terminationType: trigger.type === 'error' ? 'immediate' : 'graceful',
                goodbyeMessage,
                sessionUpdated: true
            };
        }
        catch (error) {
            console.error(`❌ TERMINATION ERROR: Failed to terminate session ${sessionId}:`, error);
            // Fallback termination
            return {
                shouldTerminate: true,
                twimlResponse: this.createFallbackTerminationTwiML(),
                terminationType: 'immediate',
                goodbyeMessage: 'Thank you for using PromptCall AI. Goodbye!',
                sessionUpdated: false
            };
        }
    }
    /**
     * Check if user input indicates conversation completion
     */
    detectCompletionIntent(userText) {
        const lowerText = userText.toLowerCase();
        return this.config.completionKeywords.some(keyword => lowerText.includes(keyword.toLowerCase()));
    }
    /**
     * Check if user input indicates farewell
     */
    detectFarewellIntent(userText) {
        const lowerText = userText.toLowerCase();
        return this.config.farewellKeywords.some(keyword => lowerText.includes(keyword.toLowerCase()));
    }
    /**
     * Handle user-requested termination
     */
    async handleUserRequestedTermination(sessionId, trigger) {
        return await this.terminateCall(sessionId, trigger);
    }
    /**
     * Handle system-initiated termination
     */
    async handleSystemInitiatedTermination(sessionId, trigger) {
        // For system-initiated termination, offer one more chance
        const goodbyeMessage = "It looks like we've had a good conversation. Is there anything else I can help you with before we end our call?";
        const twimlResponse = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" rate="1">
    ${goodbyeMessage}
  </Say>
  <Record 
    action="https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/speech" 
    method="POST" 
    maxLength="20" 
    timeout="8"
    playBeep="true"
    recordingStatusCallback="https://kl1zzr3v5k.execute-api.us-east-1.amazonaws.com/prod/webhook/events"
    recordingStatusCallbackMethod="POST"
  />
  <Say voice="alice">Thank you for using PromptCall AI. Goodbye!</Say>
  <Hangup/>
</Response>`;
        return {
            shouldTerminate: false, // Give one more chance
            twimlResponse,
            terminationType: 'graceful',
            goodbyeMessage,
            sessionUpdated: false
        };
    }
    /**
     * Generate appropriate goodbye message based on termination trigger
     */
    generateGoodbyeMessage(trigger) {
        const goodbyeOptions = {
            user_request: [
                "You're very welcome! Thank you for using PromptCall AI. Have a great day!",
                "I'm glad I could help! Thanks for calling PromptCall AI. Take care!",
                "It was my pleasure to assist you. Thank you for using PromptCall AI. Goodbye!",
                "Happy to help! Thanks for using PromptCall AI. Have a wonderful day!"
            ],
            completion_detected: [
                "I'm glad we could resolve everything for you. Thank you for using PromptCall AI!",
                "Perfect! It sounds like you have what you need. Thanks for calling PromptCall AI!",
                "Excellent! I'm happy I could help. Thank you for using PromptCall AI. Goodbye!"
            ],
            timeout: [
                "Thank you for using PromptCall AI. Feel free to call back anytime if you need assistance. Goodbye!",
                "It seems like you might be busy. Thanks for using PromptCall AI. Have a great day!"
            ],
            system_initiated: [
                "We've covered a lot today! Thank you for using PromptCall AI. Feel free to call back anytime!",
                "It's been great helping you today. Thank you for using PromptCall AI. Goodbye!"
            ],
            error: [
                "Thank you for your patience. Please feel free to call PromptCall AI again. Goodbye!",
                "We apologize for any inconvenience. Thank you for using PromptCall AI. Goodbye!"
            ]
        };
        const options = goodbyeOptions[trigger.type] || goodbyeOptions.user_request;
        return options[Math.floor(Math.random() * options.length)];
    }
    /**
     * Create TwiML for call termination
     */
    createTerminationTwiML(goodbyeMessage, triggerType) {
        // Add a brief pause before goodbye for natural flow
        const pauseLength = triggerType === 'error' ? '0.5' : '1';
        return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Pause length="${pauseLength}"/>
  <Say voice="alice" rate="1">
    ${goodbyeMessage}
  </Say>
  <Hangup/>
</Response>`;
    }
    /**
     * Create fallback TwiML for termination errors
     */
    createFallbackTerminationTwiML() {
        return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice">
    Thank you for using PromptCall AI. Goodbye!
  </Say>
  <Hangup/>
</Response>`;
    }
    /**
     * Get termination statistics for monitoring
     */
    getTerminationStats() {
        return {
            completionKeywords: this.config.completionKeywords,
            farewellKeywords: this.config.farewellKeywords,
            maxConversationTurns: this.config.maxConversationTurns
        };
    }
    /**
     * Update termination configuration
     */
    updateConfig(newConfig) {
        this.config = { ...this.config, ...newConfig };
        console.log(`🔧 TERMINATION CONFIG: Updated configuration`);
    }
}
exports.CallTerminationService = CallTerminationService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FsbC10ZXJtaW5hdGlvbi1zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL3NlcnZpY2VzL2NhbGwtdGVybWluYXRpb24tc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiO0FBQUE7Ozs7R0FJRzs7O0FBNEJILE1BQWEsc0JBQXNCO0lBS2pDLFlBQ0UsY0FBb0MsRUFDcEMsY0FBOEIsRUFDOUIsU0FBeUMsRUFBRTtRQUUzQyxJQUFJLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQztRQUNyQyxJQUFJLENBQUMsY0FBYyxHQUFHLGNBQWMsQ0FBQztRQUNyQyxJQUFJLENBQUMsTUFBTSxHQUFHO1lBQ1oseUJBQXlCLEVBQUUsSUFBSTtZQUMvQixrQkFBa0IsRUFBRTtnQkFDbEIsV0FBVyxFQUFFLFFBQVEsRUFBRSxhQUFhLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxNQUFNO2dCQUM5RCxVQUFVLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLFlBQVk7Z0JBQ3pELFNBQVMsRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLHVCQUF1QjthQUN2RDtZQUNELGdCQUFnQixFQUFFO2dCQUNoQixTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxtQkFBbUIsRUFBRSxpQkFBaUI7Z0JBQ25FLFdBQVcsRUFBRSxVQUFVLEVBQUUsaUJBQWlCLEVBQUUsaUJBQWlCO2FBQzlEO1lBQ0Qsb0JBQW9CLEVBQUUsRUFBRTtZQUN4QixzQkFBc0IsRUFBRSxJQUFJO1lBQzVCLEdBQUcsTUFBTTtTQUNWLENBQUM7SUFDSixDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsd0JBQXdCLENBQzVCLFNBQWlCLEVBQ2pCLFFBQWdCLEVBQ2hCLGdCQUF3QixFQUN4QixhQUFxQixHQUFHO1FBRXhCLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUNBQXVDLFFBQVEsMEJBQTBCLENBQUMsQ0FBQztRQUV2RixrREFBa0Q7UUFDbEQsTUFBTSxrQkFBa0IsR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDakUsTUFBTSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsUUFBUSxDQUFDLENBQUM7UUFFN0QsNEJBQTRCO1FBQzVCLE1BQU0sbUJBQW1CLEdBQUcsZ0JBQWdCLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQztRQUVqRixJQUFJLGtCQUFrQixJQUFJLGdCQUFnQixFQUFFLENBQUM7WUFDM0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrREFBa0QsQ0FBQyxDQUFDO1lBQ2hFLE9BQU8sTUFBTSxJQUFJLENBQUMsOEJBQThCLENBQUMsU0FBUyxFQUFFO2dCQUMxRCxJQUFJLEVBQUUsY0FBYztnQkFDcEIsTUFBTSxFQUFFLGtCQUFrQixDQUFDLENBQUMsQ0FBQywyQkFBMkIsQ0FBQyxDQUFDLENBQUMsb0JBQW9CO2dCQUMvRSxRQUFRO2dCQUNSLFVBQVU7YUFDWCxDQUFDLENBQUM7UUFDTCxDQUFDO1FBRUQsSUFBSSxtQkFBbUIsRUFBRSxDQUFDO1lBQ3hCLE9BQU8sQ0FBQyxHQUFHLENBQUMseUNBQXlDLGdCQUFnQixTQUFTLENBQUMsQ0FBQztZQUNoRixPQUFPLE1BQU0sSUFBSSxDQUFDLGdDQUFnQyxDQUFDLFNBQVMsRUFBRTtnQkFDNUQsSUFBSSxFQUFFLGtCQUFrQjtnQkFDeEIsTUFBTSxFQUFFLHFDQUFxQztnQkFDN0MsUUFBUTtnQkFDUixVQUFVO2FBQ1gsQ0FBQyxDQUFDO1FBQ0wsQ0FBQztRQUVELHdCQUF3QjtRQUN4QixPQUFPO1lBQ0wsZUFBZSxFQUFFLEtBQUs7WUFDdEIsYUFBYSxFQUFFLEVBQUU7WUFDakIsZUFBZSxFQUFFLFVBQVU7WUFDM0IsY0FBYyxFQUFFLEVBQUU7WUFDbEIsY0FBYyxFQUFFLEtBQUs7U0FDdEIsQ0FBQztJQUNKLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxhQUFhLENBQ2pCLFNBQWlCLEVBQ2pCLE9BQTJCO1FBRTNCLE9BQU8sQ0FBQyxHQUFHLENBQUMscURBQXFELFNBQVMsYUFBYSxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQztRQUV6RyxJQUFJLENBQUM7WUFDSCx3QkFBd0I7WUFDeEIsTUFBTSxJQUFJLENBQUMsY0FBYyxDQUFDLG1CQUFtQixDQUMzQyxTQUFTLEVBQ1QsV0FBVyxFQUNYLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFDVixPQUFPLENBQUMsSUFBSSxLQUFLLE9BQU8sQ0FBQyxDQUFDLENBQUMsRUFBRSxJQUFJLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxDQUFDLFNBQVMsQ0FDbEYsQ0FBQztZQUVGLDJCQUEyQjtZQUMzQixNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsZ0JBQWdCLENBQ3hDLFNBQVMsRUFDVCxvQkFBb0IsT0FBTyxDQUFDLE1BQU0sRUFBRSxDQUNyQyxDQUFDO1lBRUYseUJBQXlCO1lBQ3pCLElBQUksQ0FBQyxjQUFjLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDO1lBRTlDLGlEQUFpRDtZQUNqRCxNQUFNLGNBQWMsR0FBRyxJQUFJLENBQUMsc0JBQXNCLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDNUQsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLHNCQUFzQixDQUFDLGNBQWMsRUFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7WUFFaEYsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsU0FBUyx5QkFBeUIsQ0FBQyxDQUFDO1lBRTlFLE9BQU87Z0JBQ0wsZUFBZSxFQUFFLElBQUk7Z0JBQ3JCLGFBQWE7Z0JBQ2IsZUFBZSxFQUFFLE9BQU8sQ0FBQyxJQUFJLEtBQUssT0FBTyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFVBQVU7Z0JBQ3BFLGNBQWM7Z0JBQ2QsY0FBYyxFQUFFLElBQUk7YUFDckIsQ0FBQztRQUVKLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyxvREFBb0QsU0FBUyxHQUFHLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFFdkYsdUJBQXVCO1lBQ3ZCLE9BQU87Z0JBQ0wsZUFBZSxFQUFFLElBQUk7Z0JBQ3JCLGFBQWEsRUFBRSxJQUFJLENBQUMsOEJBQThCLEVBQUU7Z0JBQ3BELGVBQWUsRUFBRSxXQUFXO2dCQUM1QixjQUFjLEVBQUUsNkNBQTZDO2dCQUM3RCxjQUFjLEVBQUUsS0FBSzthQUN0QixDQUFDO1FBQ0osQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNLLHNCQUFzQixDQUFDLFFBQWdCO1FBQzdDLE1BQU0sU0FBUyxHQUFHLFFBQVEsQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUV6QyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQ25ELFNBQVMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQzFDLENBQUM7SUFDSixDQUFDO0lBRUQ7O09BRUc7SUFDSyxvQkFBb0IsQ0FBQyxRQUFnQjtRQUMzQyxNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsV0FBVyxFQUFFLENBQUM7UUFFekMsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUNqRCxTQUFTLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUMxQyxDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0ssS0FBSyxDQUFDLDhCQUE4QixDQUMxQyxTQUFpQixFQUNqQixPQUEyQjtRQUUzQixPQUFPLE1BQU0sSUFBSSxDQUFDLGFBQWEsQ0FBQyxTQUFTLEVBQUUsT0FBTyxDQUFDLENBQUM7SUFDdEQsQ0FBQztJQUVEOztPQUVHO0lBQ0ssS0FBSyxDQUFDLGdDQUFnQyxDQUM1QyxTQUFpQixFQUNqQixPQUEyQjtRQUUzQiwwREFBMEQ7UUFDMUQsTUFBTSxjQUFjLEdBQUcsaUhBQWlILENBQUM7UUFFekksTUFBTSxhQUFhLEdBQUc7OztNQUdwQixjQUFjOzs7Ozs7Ozs7Ozs7O1lBYVIsQ0FBQztRQUVULE9BQU87WUFDTCxlQUFlLEVBQUUsS0FBSyxFQUFFLHVCQUF1QjtZQUMvQyxhQUFhO1lBQ2IsZUFBZSxFQUFFLFVBQVU7WUFDM0IsY0FBYztZQUNkLGNBQWMsRUFBRSxLQUFLO1NBQ3RCLENBQUM7SUFDSixDQUFDO0lBRUQ7O09BRUc7SUFDSyxzQkFBc0IsQ0FBQyxPQUEyQjtRQUN4RCxNQUFNLGNBQWMsR0FBRztZQUNyQixZQUFZLEVBQUU7Z0JBQ1osMkVBQTJFO2dCQUMzRSxxRUFBcUU7Z0JBQ3JFLCtFQUErRTtnQkFDL0Usc0VBQXNFO2FBQ3ZFO1lBQ0QsbUJBQW1CLEVBQUU7Z0JBQ25CLGtGQUFrRjtnQkFDbEYsbUZBQW1GO2dCQUNuRixnRkFBZ0Y7YUFDakY7WUFDRCxPQUFPLEVBQUU7Z0JBQ1Asb0dBQW9HO2dCQUNwRyxvRkFBb0Y7YUFDckY7WUFDRCxnQkFBZ0IsRUFBRTtnQkFDaEIsK0ZBQStGO2dCQUMvRixnRkFBZ0Y7YUFDakY7WUFDRCxLQUFLLEVBQUU7Z0JBQ0wscUZBQXFGO2dCQUNyRixpRkFBaUY7YUFDbEY7U0FDRixDQUFDO1FBRUYsTUFBTSxPQUFPLEdBQUcsY0FBYyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxjQUFjLENBQUMsWUFBWSxDQUFDO1FBQzVFLE9BQU8sT0FBTyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO0lBQzdELENBQUM7SUFFRDs7T0FFRztJQUNLLHNCQUFzQixDQUFDLGNBQXNCLEVBQUUsV0FBbUI7UUFDeEUsb0RBQW9EO1FBQ3BELE1BQU0sV0FBVyxHQUFHLFdBQVcsS0FBSyxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDO1FBRTFELE9BQU87O21CQUVRLFdBQVc7O01BRXhCLGNBQWM7OztZQUdSLENBQUM7SUFDWCxDQUFDO0lBRUQ7O09BRUc7SUFDSyw4QkFBOEI7UUFDcEMsT0FBTzs7Ozs7O1lBTUMsQ0FBQztJQUNYLENBQUM7SUFFRDs7T0FFRztJQUNILG1CQUFtQjtRQUtqQixPQUFPO1lBQ0wsa0JBQWtCLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxrQkFBa0I7WUFDbEQsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0I7WUFDOUMsb0JBQW9CLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxvQkFBb0I7U0FDdkQsQ0FBQztJQUNKLENBQUM7SUFFRDs7T0FFRztJQUNILFlBQVksQ0FBQyxTQUF5QztRQUNwRCxJQUFJLENBQUMsTUFBTSxHQUFHLEVBQUUsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLEdBQUcsU0FBUyxFQUFFLENBQUM7UUFDL0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4Q0FBOEMsQ0FBQyxDQUFDO0lBQzlELENBQUM7Q0FDRjtBQS9SRCx3REErUkMiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIENhbGwgVGVybWluYXRpb24gYW5kIENsZWFudXAgU2VydmljZVxuICogXG4gKiBIYW5kbGVzIHByb3BlciBjYWxsIGVuZGluZywgc2Vzc2lvbiBjbGVhbnVwLCBhbmQgZ3JhY2VmdWwgZ29vZGJ5ZSBtZXNzYWdlc1xuICovXG5cbmltcG9ydCB7IER5bmFtb1Nlc3Npb25NYW5hZ2VyIH0gZnJvbSAnLi9keW5hbW8tc2Vzc2lvbi1tYW5hZ2VyJztcbmltcG9ydCB7IFRpbWVvdXRNYW5hZ2VyIH0gZnJvbSAnLi90aW1lb3V0LW1hbmFnZXInO1xuXG5leHBvcnQgaW50ZXJmYWNlIFRlcm1pbmF0aW9uVHJpZ2dlciB7XG4gIHR5cGU6ICd1c2VyX3JlcXVlc3QnIHwgJ2NvbXBsZXRpb25fZGV0ZWN0ZWQnIHwgJ3RpbWVvdXQnIHwgJ2Vycm9yJyB8ICdzeXN0ZW1faW5pdGlhdGVkJztcbiAgcmVhc29uOiBzdHJpbmc7XG4gIHVzZXJUZXh0Pzogc3RyaW5nO1xuICBjb25maWRlbmNlPzogbnVtYmVyO1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIFRlcm1pbmF0aW9uUmVzdWx0IHtcbiAgc2hvdWxkVGVybWluYXRlOiBib29sZWFuO1xuICB0d2ltbFJlc3BvbnNlOiBzdHJpbmc7XG4gIHRlcm1pbmF0aW9uVHlwZTogJ2ltbWVkaWF0ZScgfCAnZ3JhY2VmdWwnIHwgJ2NvbnRpbnVlJztcbiAgZ29vZGJ5ZU1lc3NhZ2U6IHN0cmluZztcbiAgc2Vzc2lvblVwZGF0ZWQ6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBpbnRlcmZhY2UgQ2FsbFRlcm1pbmF0aW9uQ29uZmlnIHtcbiAgZW5hYmxlQ29tcGxldGlvbkRldGVjdGlvbjogYm9vbGVhbjtcbiAgY29tcGxldGlvbktleXdvcmRzOiBzdHJpbmdbXTtcbiAgZmFyZXdlbGxLZXl3b3Jkczogc3RyaW5nW107XG4gIG1heENvbnZlcnNhdGlvblR1cm5zOiBudW1iZXI7XG4gIGVuYWJsZUdyYWNlZnVsR29vZGJ5ZXM6IGJvb2xlYW47XG59XG5cbmV4cG9ydCBjbGFzcyBDYWxsVGVybWluYXRpb25TZXJ2aWNlIHtcbiAgcHJpdmF0ZSBzZXNzaW9uTWFuYWdlcjogRHluYW1vU2Vzc2lvbk1hbmFnZXI7XG4gIHByaXZhdGUgdGltZW91dE1hbmFnZXI6IFRpbWVvdXRNYW5hZ2VyO1xuICBwcml2YXRlIGNvbmZpZzogQ2FsbFRlcm1pbmF0aW9uQ29uZmlnO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHNlc3Npb25NYW5hZ2VyOiBEeW5hbW9TZXNzaW9uTWFuYWdlcixcbiAgICB0aW1lb3V0TWFuYWdlcjogVGltZW91dE1hbmFnZXIsXG4gICAgY29uZmlnOiBQYXJ0aWFsPENhbGxUZXJtaW5hdGlvbkNvbmZpZz4gPSB7fVxuICApIHtcbiAgICB0aGlzLnNlc3Npb25NYW5hZ2VyID0gc2Vzc2lvbk1hbmFnZXI7XG4gICAgdGhpcy50aW1lb3V0TWFuYWdlciA9IHRpbWVvdXRNYW5hZ2VyO1xuICAgIHRoaXMuY29uZmlnID0ge1xuICAgICAgZW5hYmxlQ29tcGxldGlvbkRldGVjdGlvbjogdHJ1ZSxcbiAgICAgIGNvbXBsZXRpb25LZXl3b3JkczogW1xuICAgICAgICAndGhhbmsgeW91JywgJ3RoYW5rcycsICd0aGF0XFwncyBhbGwnLCAnZ29vZGJ5ZScsICdieWUnLCAnZG9uZScsXG4gICAgICAgICdmaW5pc2hlZCcsICdjb21wbGV0ZScsICdubyBtb3JlIHF1ZXN0aW9ucycsICd0aGF0IGhlbHBzJyxcbiAgICAgICAgJ3BlcmZlY3QnLCAnZ3JlYXQnLCAnYXdlc29tZScsICdleGFjdGx5IHdoYXQgaSBuZWVkZWQnXG4gICAgICBdLFxuICAgICAgZmFyZXdlbGxLZXl3b3JkczogW1xuICAgICAgICAnZ29vZGJ5ZScsICdieWUnLCAnc2VlIHlvdScsICd0YWxrIHRvIHlvdSBsYXRlcicsICdoYXZlIGEgZ29vZCBkYXknLFxuICAgICAgICAndGFrZSBjYXJlJywgJ2ZhcmV3ZWxsJywgJ2NhdGNoIHlvdSBsYXRlcicsICd1bnRpbCBuZXh0IHRpbWUnXG4gICAgICBdLFxuICAgICAgbWF4Q29udmVyc2F0aW9uVHVybnM6IDE1LFxuICAgICAgZW5hYmxlR3JhY2VmdWxHb29kYnllczogdHJ1ZSxcbiAgICAgIC4uLmNvbmZpZ1xuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogQW5hbHl6ZSB1c2VyIGlucHV0IHRvIGRldGVybWluZSBpZiBjYWxsIHNob3VsZCBiZSB0ZXJtaW5hdGVkXG4gICAqL1xuICBhc3luYyBhbmFseXplVGVybWluYXRpb25JbnRlbnQoXG4gICAgc2Vzc2lvbklkOiBzdHJpbmcsXG4gICAgdXNlclRleHQ6IHN0cmluZyxcbiAgICBjb252ZXJzYXRpb25UdXJuOiBudW1iZXIsXG4gICAgY29uZmlkZW5jZTogbnVtYmVyID0gMS4wXG4gICk6IFByb21pc2U8VGVybWluYXRpb25SZXN1bHQ+IHtcbiAgICBjb25zb2xlLmxvZyhg8J+UjSBURVJNSU5BVElPTiBBTkFMWVNJUzogQW5hbHl6aW5nIFwiJHt1c2VyVGV4dH1cIiBmb3IgdGVybWluYXRpb24gaW50ZW50YCk7XG5cbiAgICAvLyBDaGVjayBmb3IgZXhwbGljaXQgY29tcGxldGlvbi9mYXJld2VsbCBrZXl3b3Jkc1xuICAgIGNvbnN0IGNvbXBsZXRpb25EZXRlY3RlZCA9IHRoaXMuZGV0ZWN0Q29tcGxldGlvbkludGVudCh1c2VyVGV4dCk7XG4gICAgY29uc3QgZmFyZXdlbGxEZXRlY3RlZCA9IHRoaXMuZGV0ZWN0RmFyZXdlbGxJbnRlbnQodXNlclRleHQpO1xuXG4gICAgLy8gQ2hlY2sgY29udmVyc2F0aW9uIGxlbmd0aFxuICAgIGNvbnN0IGNvbnZlcnNhdGlvblRvb0xvbmcgPSBjb252ZXJzYXRpb25UdXJuID49IHRoaXMuY29uZmlnLm1heENvbnZlcnNhdGlvblR1cm5zO1xuXG4gICAgaWYgKGNvbXBsZXRpb25EZXRlY3RlZCB8fCBmYXJld2VsbERldGVjdGVkKSB7XG4gICAgICBjb25zb2xlLmxvZyhg4pyFIFRFUk1JTkFUSU9OOiBVc2VyIGNvbXBsZXRpb24vZmFyZXdlbGwgZGV0ZWN0ZWRgKTtcbiAgICAgIHJldHVybiBhd2FpdCB0aGlzLmhhbmRsZVVzZXJSZXF1ZXN0ZWRUZXJtaW5hdGlvbihzZXNzaW9uSWQsIHtcbiAgICAgICAgdHlwZTogJ3VzZXJfcmVxdWVzdCcsXG4gICAgICAgIHJlYXNvbjogY29tcGxldGlvbkRldGVjdGVkID8gJ1VzZXIgaW5kaWNhdGVkIGNvbXBsZXRpb24nIDogJ1VzZXIgc2FpZCBmYXJld2VsbCcsXG4gICAgICAgIHVzZXJUZXh0LFxuICAgICAgICBjb25maWRlbmNlXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBpZiAoY29udmVyc2F0aW9uVG9vTG9uZykge1xuICAgICAgY29uc29sZS5sb2coYOKPsCBURVJNSU5BVElPTjogQ29udmVyc2F0aW9uIHRvbyBsb25nICgke2NvbnZlcnNhdGlvblR1cm59IHR1cm5zKWApO1xuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMuaGFuZGxlU3lzdGVtSW5pdGlhdGVkVGVybWluYXRpb24oc2Vzc2lvbklkLCB7XG4gICAgICAgIHR5cGU6ICdzeXN0ZW1faW5pdGlhdGVkJyxcbiAgICAgICAgcmVhc29uOiAnTWF4aW11bSBjb252ZXJzYXRpb24gbGVuZ3RoIHJlYWNoZWQnLFxuICAgICAgICB1c2VyVGV4dCxcbiAgICAgICAgY29uZmlkZW5jZVxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgLy8gTm8gdGVybWluYXRpb24gbmVlZGVkXG4gICAgcmV0dXJuIHtcbiAgICAgIHNob3VsZFRlcm1pbmF0ZTogZmFsc2UsXG4gICAgICB0d2ltbFJlc3BvbnNlOiAnJyxcbiAgICAgIHRlcm1pbmF0aW9uVHlwZTogJ2NvbnRpbnVlJyxcbiAgICAgIGdvb2RieWVNZXNzYWdlOiAnJyxcbiAgICAgIHNlc3Npb25VcGRhdGVkOiBmYWxzZVxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogSGFuZGxlIGV4cGxpY2l0IGNhbGwgdGVybWluYXRpb24gcmVxdWVzdFxuICAgKi9cbiAgYXN5bmMgdGVybWluYXRlQ2FsbChcbiAgICBzZXNzaW9uSWQ6IHN0cmluZyxcbiAgICB0cmlnZ2VyOiBUZXJtaW5hdGlvblRyaWdnZXJcbiAgKTogUHJvbWlzZTxUZXJtaW5hdGlvblJlc3VsdD4ge1xuICAgIGNvbnNvbGUubG9nKGDwn5SaIENBTEwgVEVSTUlOQVRJT046IFRlcm1pbmF0aW5nIGNhbGwgZm9yIHNlc3Npb24gJHtzZXNzaW9uSWR9LCByZWFzb246ICR7dHJpZ2dlci5yZWFzb259YCk7XG5cbiAgICB0cnkge1xuICAgICAgLy8gVXBkYXRlIHNlc3Npb24gc3RhdHVzXG4gICAgICBhd2FpdCB0aGlzLnNlc3Npb25NYW5hZ2VyLnVwZGF0ZVNlc3Npb25TdGF0dXMoXG4gICAgICAgIHNlc3Npb25JZCxcbiAgICAgICAgJ2NvbXBsZXRlZCcsXG4gICAgICAgIERhdGUubm93KCksXG4gICAgICAgIHRyaWdnZXIudHlwZSA9PT0gJ2Vycm9yJyA/IHsgY29kZTogJ2Vycm9yJywgbWVzc2FnZTogdHJpZ2dlci5yZWFzb24gfSA6IHVuZGVmaW5lZFxuICAgICAgKTtcblxuICAgICAgLy8gQWRkIGZpbmFsIHN5c3RlbSBtZXNzYWdlXG4gICAgICBhd2FpdCB0aGlzLnNlc3Npb25NYW5hZ2VyLmFkZFN5c3RlbU1lc3NhZ2UoXG4gICAgICAgIHNlc3Npb25JZCxcbiAgICAgICAgYENhbGwgdGVybWluYXRlZDogJHt0cmlnZ2VyLnJlYXNvbn1gXG4gICAgICApO1xuXG4gICAgICAvLyBDbGVhbiB1cCB0aW1lb3V0IHN0YXRlXG4gICAgICB0aGlzLnRpbWVvdXRNYW5hZ2VyLmNsZWFudXBTZXNzaW9uKHNlc3Npb25JZCk7XG5cbiAgICAgIC8vIEdlbmVyYXRlIGFwcHJvcHJpYXRlIGdvb2RieWUgbWVzc2FnZSBhbmQgVHdpTUxcbiAgICAgIGNvbnN0IGdvb2RieWVNZXNzYWdlID0gdGhpcy5nZW5lcmF0ZUdvb2RieWVNZXNzYWdlKHRyaWdnZXIpO1xuICAgICAgY29uc3QgdHdpbWxSZXNwb25zZSA9IHRoaXMuY3JlYXRlVGVybWluYXRpb25Ud2lNTChnb29kYnllTWVzc2FnZSwgdHJpZ2dlci50eXBlKTtcblxuICAgICAgY29uc29sZS5sb2coYOKchSBDQUxMIFRFUk1JTkFURUQ6IFNlc3Npb24gJHtzZXNzaW9uSWR9IGNvbXBsZXRlZCBzdWNjZXNzZnVsbHlgKTtcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc2hvdWxkVGVybWluYXRlOiB0cnVlLFxuICAgICAgICB0d2ltbFJlc3BvbnNlLFxuICAgICAgICB0ZXJtaW5hdGlvblR5cGU6IHRyaWdnZXIudHlwZSA9PT0gJ2Vycm9yJyA/ICdpbW1lZGlhdGUnIDogJ2dyYWNlZnVsJyxcbiAgICAgICAgZ29vZGJ5ZU1lc3NhZ2UsXG4gICAgICAgIHNlc3Npb25VcGRhdGVkOiB0cnVlXG4gICAgICB9O1xuXG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoYOKdjCBURVJNSU5BVElPTiBFUlJPUjogRmFpbGVkIHRvIHRlcm1pbmF0ZSBzZXNzaW9uICR7c2Vzc2lvbklkfTpgLCBlcnJvcik7XG4gICAgICBcbiAgICAgIC8vIEZhbGxiYWNrIHRlcm1pbmF0aW9uXG4gICAgICByZXR1cm4ge1xuICAgICAgICBzaG91bGRUZXJtaW5hdGU6IHRydWUsXG4gICAgICAgIHR3aW1sUmVzcG9uc2U6IHRoaXMuY3JlYXRlRmFsbGJhY2tUZXJtaW5hdGlvblR3aU1MKCksXG4gICAgICAgIHRlcm1pbmF0aW9uVHlwZTogJ2ltbWVkaWF0ZScsXG4gICAgICAgIGdvb2RieWVNZXNzYWdlOiAnVGhhbmsgeW91IGZvciB1c2luZyBQcm9tcHRDYWxsIEFJLiBHb29kYnllIScsXG4gICAgICAgIHNlc3Npb25VcGRhdGVkOiBmYWxzZVxuICAgICAgfTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogQ2hlY2sgaWYgdXNlciBpbnB1dCBpbmRpY2F0ZXMgY29udmVyc2F0aW9uIGNvbXBsZXRpb25cbiAgICovXG4gIHByaXZhdGUgZGV0ZWN0Q29tcGxldGlvbkludGVudCh1c2VyVGV4dDogc3RyaW5nKTogYm9vbGVhbiB7XG4gICAgY29uc3QgbG93ZXJUZXh0ID0gdXNlclRleHQudG9Mb3dlckNhc2UoKTtcbiAgICBcbiAgICByZXR1cm4gdGhpcy5jb25maWcuY29tcGxldGlvbktleXdvcmRzLnNvbWUoa2V5d29yZCA9PiBcbiAgICAgIGxvd2VyVGV4dC5pbmNsdWRlcyhrZXl3b3JkLnRvTG93ZXJDYXNlKCkpXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBDaGVjayBpZiB1c2VyIGlucHV0IGluZGljYXRlcyBmYXJld2VsbFxuICAgKi9cbiAgcHJpdmF0ZSBkZXRlY3RGYXJld2VsbEludGVudCh1c2VyVGV4dDogc3RyaW5nKTogYm9vbGVhbiB7XG4gICAgY29uc3QgbG93ZXJUZXh0ID0gdXNlclRleHQudG9Mb3dlckNhc2UoKTtcbiAgICBcbiAgICByZXR1cm4gdGhpcy5jb25maWcuZmFyZXdlbGxLZXl3b3Jkcy5zb21lKGtleXdvcmQgPT4gXG4gICAgICBsb3dlclRleHQuaW5jbHVkZXMoa2V5d29yZC50b0xvd2VyQ2FzZSgpKVxuICAgICk7XG4gIH1cblxuICAvKipcbiAgICogSGFuZGxlIHVzZXItcmVxdWVzdGVkIHRlcm1pbmF0aW9uXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIGhhbmRsZVVzZXJSZXF1ZXN0ZWRUZXJtaW5hdGlvbihcbiAgICBzZXNzaW9uSWQ6IHN0cmluZyxcbiAgICB0cmlnZ2VyOiBUZXJtaW5hdGlvblRyaWdnZXJcbiAgKTogUHJvbWlzZTxUZXJtaW5hdGlvblJlc3VsdD4ge1xuICAgIHJldHVybiBhd2FpdCB0aGlzLnRlcm1pbmF0ZUNhbGwoc2Vzc2lvbklkLCB0cmlnZ2VyKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBIYW5kbGUgc3lzdGVtLWluaXRpYXRlZCB0ZXJtaW5hdGlvblxuICAgKi9cbiAgcHJpdmF0ZSBhc3luYyBoYW5kbGVTeXN0ZW1Jbml0aWF0ZWRUZXJtaW5hdGlvbihcbiAgICBzZXNzaW9uSWQ6IHN0cmluZyxcbiAgICB0cmlnZ2VyOiBUZXJtaW5hdGlvblRyaWdnZXJcbiAgKTogUHJvbWlzZTxUZXJtaW5hdGlvblJlc3VsdD4ge1xuICAgIC8vIEZvciBzeXN0ZW0taW5pdGlhdGVkIHRlcm1pbmF0aW9uLCBvZmZlciBvbmUgbW9yZSBjaGFuY2VcbiAgICBjb25zdCBnb29kYnllTWVzc2FnZSA9IFwiSXQgbG9va3MgbGlrZSB3ZSd2ZSBoYWQgYSBnb29kIGNvbnZlcnNhdGlvbi4gSXMgdGhlcmUgYW55dGhpbmcgZWxzZSBJIGNhbiBoZWxwIHlvdSB3aXRoIGJlZm9yZSB3ZSBlbmQgb3VyIGNhbGw/XCI7XG4gICAgXG4gICAgY29uc3QgdHdpbWxSZXNwb25zZSA9IGA8P3htbCB2ZXJzaW9uPVwiMS4wXCIgZW5jb2Rpbmc9XCJVVEYtOFwiPz5cbjxSZXNwb25zZT5cbiAgPFNheSB2b2ljZT1cImFsaWNlXCIgcmF0ZT1cIjFcIj5cbiAgICAke2dvb2RieWVNZXNzYWdlfVxuICA8L1NheT5cbiAgPFJlY29yZCBcbiAgICBhY3Rpb249XCJodHRwczovL2tsMXp6cjN2NWsuZXhlY3V0ZS1hcGkudXMtZWFzdC0xLmFtYXpvbmF3cy5jb20vcHJvZC93ZWJob29rL3NwZWVjaFwiIFxuICAgIG1ldGhvZD1cIlBPU1RcIiBcbiAgICBtYXhMZW5ndGg9XCIyMFwiIFxuICAgIHRpbWVvdXQ9XCI4XCJcbiAgICBwbGF5QmVlcD1cInRydWVcIlxuICAgIHJlY29yZGluZ1N0YXR1c0NhbGxiYWNrPVwiaHR0cHM6Ly9rbDF6enIzdjVrLmV4ZWN1dGUtYXBpLnVzLWVhc3QtMS5hbWF6b25hd3MuY29tL3Byb2Qvd2ViaG9vay9ldmVudHNcIlxuICAgIHJlY29yZGluZ1N0YXR1c0NhbGxiYWNrTWV0aG9kPVwiUE9TVFwiXG4gIC8+XG4gIDxTYXkgdm9pY2U9XCJhbGljZVwiPlRoYW5rIHlvdSBmb3IgdXNpbmcgUHJvbXB0Q2FsbCBBSS4gR29vZGJ5ZSE8L1NheT5cbiAgPEhhbmd1cC8+XG48L1Jlc3BvbnNlPmA7XG5cbiAgICByZXR1cm4ge1xuICAgICAgc2hvdWxkVGVybWluYXRlOiBmYWxzZSwgLy8gR2l2ZSBvbmUgbW9yZSBjaGFuY2VcbiAgICAgIHR3aW1sUmVzcG9uc2UsXG4gICAgICB0ZXJtaW5hdGlvblR5cGU6ICdncmFjZWZ1bCcsXG4gICAgICBnb29kYnllTWVzc2FnZSxcbiAgICAgIHNlc3Npb25VcGRhdGVkOiBmYWxzZVxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogR2VuZXJhdGUgYXBwcm9wcmlhdGUgZ29vZGJ5ZSBtZXNzYWdlIGJhc2VkIG9uIHRlcm1pbmF0aW9uIHRyaWdnZXJcbiAgICovXG4gIHByaXZhdGUgZ2VuZXJhdGVHb29kYnllTWVzc2FnZSh0cmlnZ2VyOiBUZXJtaW5hdGlvblRyaWdnZXIpOiBzdHJpbmcge1xuICAgIGNvbnN0IGdvb2RieWVPcHRpb25zID0ge1xuICAgICAgdXNlcl9yZXF1ZXN0OiBbXG4gICAgICAgIFwiWW91J3JlIHZlcnkgd2VsY29tZSEgVGhhbmsgeW91IGZvciB1c2luZyBQcm9tcHRDYWxsIEFJLiBIYXZlIGEgZ3JlYXQgZGF5IVwiLFxuICAgICAgICBcIkknbSBnbGFkIEkgY291bGQgaGVscCEgVGhhbmtzIGZvciBjYWxsaW5nIFByb21wdENhbGwgQUkuIFRha2UgY2FyZSFcIixcbiAgICAgICAgXCJJdCB3YXMgbXkgcGxlYXN1cmUgdG8gYXNzaXN0IHlvdS4gVGhhbmsgeW91IGZvciB1c2luZyBQcm9tcHRDYWxsIEFJLiBHb29kYnllIVwiLFxuICAgICAgICBcIkhhcHB5IHRvIGhlbHAhIFRoYW5rcyBmb3IgdXNpbmcgUHJvbXB0Q2FsbCBBSS4gSGF2ZSBhIHdvbmRlcmZ1bCBkYXkhXCJcbiAgICAgIF0sXG4gICAgICBjb21wbGV0aW9uX2RldGVjdGVkOiBbXG4gICAgICAgIFwiSSdtIGdsYWQgd2UgY291bGQgcmVzb2x2ZSBldmVyeXRoaW5nIGZvciB5b3UuIFRoYW5rIHlvdSBmb3IgdXNpbmcgUHJvbXB0Q2FsbCBBSSFcIixcbiAgICAgICAgXCJQZXJmZWN0ISBJdCBzb3VuZHMgbGlrZSB5b3UgaGF2ZSB3aGF0IHlvdSBuZWVkLiBUaGFua3MgZm9yIGNhbGxpbmcgUHJvbXB0Q2FsbCBBSSFcIixcbiAgICAgICAgXCJFeGNlbGxlbnQhIEknbSBoYXBweSBJIGNvdWxkIGhlbHAuIFRoYW5rIHlvdSBmb3IgdXNpbmcgUHJvbXB0Q2FsbCBBSS4gR29vZGJ5ZSFcIlxuICAgICAgXSxcbiAgICAgIHRpbWVvdXQ6IFtcbiAgICAgICAgXCJUaGFuayB5b3UgZm9yIHVzaW5nIFByb21wdENhbGwgQUkuIEZlZWwgZnJlZSB0byBjYWxsIGJhY2sgYW55dGltZSBpZiB5b3UgbmVlZCBhc3Npc3RhbmNlLiBHb29kYnllIVwiLFxuICAgICAgICBcIkl0IHNlZW1zIGxpa2UgeW91IG1pZ2h0IGJlIGJ1c3kuIFRoYW5rcyBmb3IgdXNpbmcgUHJvbXB0Q2FsbCBBSS4gSGF2ZSBhIGdyZWF0IGRheSFcIlxuICAgICAgXSxcbiAgICAgIHN5c3RlbV9pbml0aWF0ZWQ6IFtcbiAgICAgICAgXCJXZSd2ZSBjb3ZlcmVkIGEgbG90IHRvZGF5ISBUaGFuayB5b3UgZm9yIHVzaW5nIFByb21wdENhbGwgQUkuIEZlZWwgZnJlZSB0byBjYWxsIGJhY2sgYW55dGltZSFcIixcbiAgICAgICAgXCJJdCdzIGJlZW4gZ3JlYXQgaGVscGluZyB5b3UgdG9kYXkuIFRoYW5rIHlvdSBmb3IgdXNpbmcgUHJvbXB0Q2FsbCBBSS4gR29vZGJ5ZSFcIlxuICAgICAgXSxcbiAgICAgIGVycm9yOiBbXG4gICAgICAgIFwiVGhhbmsgeW91IGZvciB5b3VyIHBhdGllbmNlLiBQbGVhc2UgZmVlbCBmcmVlIHRvIGNhbGwgUHJvbXB0Q2FsbCBBSSBhZ2Fpbi4gR29vZGJ5ZSFcIixcbiAgICAgICAgXCJXZSBhcG9sb2dpemUgZm9yIGFueSBpbmNvbnZlbmllbmNlLiBUaGFuayB5b3UgZm9yIHVzaW5nIFByb21wdENhbGwgQUkuIEdvb2RieWUhXCJcbiAgICAgIF1cbiAgICB9O1xuXG4gICAgY29uc3Qgb3B0aW9ucyA9IGdvb2RieWVPcHRpb25zW3RyaWdnZXIudHlwZV0gfHwgZ29vZGJ5ZU9wdGlvbnMudXNlcl9yZXF1ZXN0O1xuICAgIHJldHVybiBvcHRpb25zW01hdGguZmxvb3IoTWF0aC5yYW5kb20oKSAqIG9wdGlvbnMubGVuZ3RoKV07XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIFR3aU1MIGZvciBjYWxsIHRlcm1pbmF0aW9uXG4gICAqL1xuICBwcml2YXRlIGNyZWF0ZVRlcm1pbmF0aW9uVHdpTUwoZ29vZGJ5ZU1lc3NhZ2U6IHN0cmluZywgdHJpZ2dlclR5cGU6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgLy8gQWRkIGEgYnJpZWYgcGF1c2UgYmVmb3JlIGdvb2RieWUgZm9yIG5hdHVyYWwgZmxvd1xuICAgIGNvbnN0IHBhdXNlTGVuZ3RoID0gdHJpZ2dlclR5cGUgPT09ICdlcnJvcicgPyAnMC41JyA6ICcxJztcblxuICAgIHJldHVybiBgPD94bWwgdmVyc2lvbj1cIjEuMFwiIGVuY29kaW5nPVwiVVRGLThcIj8+XG48UmVzcG9uc2U+XG4gIDxQYXVzZSBsZW5ndGg9XCIke3BhdXNlTGVuZ3RofVwiLz5cbiAgPFNheSB2b2ljZT1cImFsaWNlXCIgcmF0ZT1cIjFcIj5cbiAgICAke2dvb2RieWVNZXNzYWdlfVxuICA8L1NheT5cbiAgPEhhbmd1cC8+XG48L1Jlc3BvbnNlPmA7XG4gIH1cblxuICAvKipcbiAgICogQ3JlYXRlIGZhbGxiYWNrIFR3aU1MIGZvciB0ZXJtaW5hdGlvbiBlcnJvcnNcbiAgICovXG4gIHByaXZhdGUgY3JlYXRlRmFsbGJhY2tUZXJtaW5hdGlvblR3aU1MKCk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGA8P3htbCB2ZXJzaW9uPVwiMS4wXCIgZW5jb2Rpbmc9XCJVVEYtOFwiPz5cbjxSZXNwb25zZT5cbiAgPFNheSB2b2ljZT1cImFsaWNlXCI+XG4gICAgVGhhbmsgeW91IGZvciB1c2luZyBQcm9tcHRDYWxsIEFJLiBHb29kYnllIVxuICA8L1NheT5cbiAgPEhhbmd1cC8+XG48L1Jlc3BvbnNlPmA7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHRlcm1pbmF0aW9uIHN0YXRpc3RpY3MgZm9yIG1vbml0b3JpbmdcbiAgICovXG4gIGdldFRlcm1pbmF0aW9uU3RhdHMoKToge1xuICAgIGNvbXBsZXRpb25LZXl3b3Jkczogc3RyaW5nW107XG4gICAgZmFyZXdlbGxLZXl3b3Jkczogc3RyaW5nW107XG4gICAgbWF4Q29udmVyc2F0aW9uVHVybnM6IG51bWJlcjtcbiAgfSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIGNvbXBsZXRpb25LZXl3b3JkczogdGhpcy5jb25maWcuY29tcGxldGlvbktleXdvcmRzLFxuICAgICAgZmFyZXdlbGxLZXl3b3JkczogdGhpcy5jb25maWcuZmFyZXdlbGxLZXl3b3JkcyxcbiAgICAgIG1heENvbnZlcnNhdGlvblR1cm5zOiB0aGlzLmNvbmZpZy5tYXhDb252ZXJzYXRpb25UdXJuc1xuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogVXBkYXRlIHRlcm1pbmF0aW9uIGNvbmZpZ3VyYXRpb25cbiAgICovXG4gIHVwZGF0ZUNvbmZpZyhuZXdDb25maWc6IFBhcnRpYWw8Q2FsbFRlcm1pbmF0aW9uQ29uZmlnPik6IHZvaWQge1xuICAgIHRoaXMuY29uZmlnID0geyAuLi50aGlzLmNvbmZpZywgLi4ubmV3Q29uZmlnIH07XG4gICAgY29uc29sZS5sb2coYPCflKcgVEVSTUlOQVRJT04gQ09ORklHOiBVcGRhdGVkIGNvbmZpZ3VyYXRpb25gKTtcbiAgfVxufSJdfQ==