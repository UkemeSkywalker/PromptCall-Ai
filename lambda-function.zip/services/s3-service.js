"use strict";
/**
 * S3 Service for handling audio file storage and retrieval
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.S3Service = void 0;
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
class S3Service {
    constructor(config) {
        this.bucketName = config.bucketName;
        this.s3Client = new client_s3_1.S3Client({
            region: config.region || process.env.AWS_REGION || 'us-east-1'
        });
    }
    /**
     * Upload audio file to S3
     */
    async uploadAudio(audioBuffer, key, contentType = 'audio/wav') {
        const command = new client_s3_1.PutObjectCommand({
            Bucket: this.bucketName,
            Key: key,
            Body: audioBuffer,
            ContentType: contentType
        });
        await this.s3Client.send(command);
        return {
            key,
            url: `s3://${this.bucketName}/${key}`,
            bucket: this.bucketName
        };
    }
    /**
     * Upload audio file to S3 with metadata
     */
    async uploadAudioWithMetadata(audioBuffer, key, metadata, contentType = 'audio/wav') {
        const command = new client_s3_1.PutObjectCommand({
            Bucket: this.bucketName,
            Key: key,
            Body: audioBuffer,
            ContentType: contentType,
            Metadata: metadata
        });
        await this.s3Client.send(command);
        return {
            key,
            url: `s3://${this.bucketName}/${key}`,
            bucket: this.bucketName
        };
    }
    /**
     * Get signed URL for audio file access
     */
    async getSignedUrl(key, expiresIn = 3600) {
        const command = new client_s3_1.GetObjectCommand({
            Bucket: this.bucketName,
            Key: key
        });
        return await (0, s3_request_presigner_1.getSignedUrl)(this.s3Client, command, { expiresIn });
    }
    /**
     * Delete audio file from S3
     */
    async deleteAudio(key) {
        const command = new client_s3_1.DeleteObjectCommand({
            Bucket: this.bucketName,
            Key: key
        });
        await this.s3Client.send(command);
    }
    /**
     * Upload audio file from URL (e.g., Twilio recording URL)
     */
    async uploadAudioFromUrl(url, sessionId, callSid) {
        try {
            // Prepare authentication for Twilio URLs
            const headers = {};
            // Add Twilio authentication if this is a Twilio URL
            if (url.includes('api.twilio.com')) {
                const accountSid = process.env.TWILIO_ACCOUNT_SID;
                const authToken = process.env.TWILIO_AUTH_TOKEN;
                if (accountSid && authToken) {
                    const credentials = Buffer.from(`${accountSid}:${authToken}`).toString('base64');
                    headers['Authorization'] = `Basic ${credentials}`;
                    console.log('Added Twilio authentication for recording URL');
                }
                else {
                    console.warn('Twilio credentials not found in environment variables');
                }
            }
            // Fetch audio data from Twilio URL with authentication
            const response = await fetch(url, { headers });
            if (!response.ok) {
                throw new Error(`Failed to fetch audio from URL: ${response.status} ${response.statusText}`);
            }
            const audioBuffer = Buffer.from(await response.arrayBuffer());
            const timestamp = Date.now();
            const key = this.generateAudioKey(sessionId, timestamp, 'input');
            // Add metadata to the upload
            const result = await this.uploadAudioWithMetadata(audioBuffer, key, {
                sessionId,
                callSid: callSid || 'unknown',
                sourceUrl: url,
                uploadTimestamp: timestamp.toString(),
                audioType: 'user-input'
            });
            console.log(`Successfully uploaded audio from Twilio URL to S3: ${key}`);
            return result;
        }
        catch (error) {
            console.error('Error uploading audio from URL:', error);
            throw new Error(`Failed to upload audio from URL: ${error instanceof Error ? error.message : 'Unknown error'}`);
        }
    }
    /**
     * Upload audio file buffer
     */
    async uploadAudioFile(audioBuffer, key, contentType = 'audio/wav') {
        const result = await this.uploadAudio(audioBuffer, key, contentType);
        return result.url;
    }
    /**
     * Get telephony-optimized playback URL
     */
    async getTelephonyPlaybackUrl(key) {
        return await this.getSignedUrl(key, 3600); // 1 hour expiry
    }
    /**
     * Generate S3 key for audio file
     */
    generateAudioKey(sessionId, timestamp, type) {
        return `audio/${sessionId}/${type}-${timestamp}.wav`;
    }
    /**
     * Get S3 URI for Transcribe service
     */
    getS3Uri(key) {
        return `s3://${this.bucketName}/${key}`;
    }
    /**
     * Get public HTTPS URL for audio file
     */
    getPublicUrl(key) {
        return `https://${this.bucketName}.s3.amazonaws.com/${key}`;
    }
}
exports.S3Service = S3Service;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiczMtc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9zZXJ2aWNlcy9zMy1zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7R0FFRzs7O0FBRUgsa0RBQXVHO0FBQ3ZHLHdFQUE2RDtBQWE3RCxNQUFhLFNBQVM7SUFJcEIsWUFBWSxNQUF1QjtRQUNqQyxJQUFJLENBQUMsVUFBVSxHQUFHLE1BQU0sQ0FBQyxVQUFVLENBQUM7UUFDcEMsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLG9CQUFRLENBQUM7WUFDM0IsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLElBQUksV0FBVztTQUMvRCxDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsV0FBVyxDQUFDLFdBQW1CLEVBQUUsR0FBVyxFQUFFLGNBQXNCLFdBQVc7UUFDbkYsTUFBTSxPQUFPLEdBQUcsSUFBSSw0QkFBZ0IsQ0FBQztZQUNuQyxNQUFNLEVBQUUsSUFBSSxDQUFDLFVBQVU7WUFDdkIsR0FBRyxFQUFFLEdBQUc7WUFDUixJQUFJLEVBQUUsV0FBVztZQUNqQixXQUFXLEVBQUUsV0FBVztTQUN6QixDQUFDLENBQUM7UUFFSCxNQUFNLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBRWxDLE9BQU87WUFDTCxHQUFHO1lBQ0gsR0FBRyxFQUFFLFFBQVEsSUFBSSxDQUFDLFVBQVUsSUFBSSxHQUFHLEVBQUU7WUFDckMsTUFBTSxFQUFFLElBQUksQ0FBQyxVQUFVO1NBQ3hCLENBQUM7SUFDSixDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsdUJBQXVCLENBQzNCLFdBQW1CLEVBQ25CLEdBQVcsRUFDWCxRQUFnQyxFQUNoQyxjQUFzQixXQUFXO1FBRWpDLE1BQU0sT0FBTyxHQUFHLElBQUksNEJBQWdCLENBQUM7WUFDbkMsTUFBTSxFQUFFLElBQUksQ0FBQyxVQUFVO1lBQ3ZCLEdBQUcsRUFBRSxHQUFHO1lBQ1IsSUFBSSxFQUFFLFdBQVc7WUFDakIsV0FBVyxFQUFFLFdBQVc7WUFDeEIsUUFBUSxFQUFFLFFBQVE7U0FDbkIsQ0FBQyxDQUFDO1FBRUgsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUVsQyxPQUFPO1lBQ0wsR0FBRztZQUNILEdBQUcsRUFBRSxRQUFRLElBQUksQ0FBQyxVQUFVLElBQUksR0FBRyxFQUFFO1lBQ3JDLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBVTtTQUN4QixDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLFlBQVksQ0FBQyxHQUFXLEVBQUUsWUFBb0IsSUFBSTtRQUN0RCxNQUFNLE9BQU8sR0FBRyxJQUFJLDRCQUFnQixDQUFDO1lBQ25DLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBVTtZQUN2QixHQUFHLEVBQUUsR0FBRztTQUNULENBQUMsQ0FBQztRQUVILE9BQU8sTUFBTSxJQUFBLG1DQUFZLEVBQUMsSUFBSSxDQUFDLFFBQVEsRUFBRSxPQUFPLEVBQUUsRUFBRSxTQUFTLEVBQUUsQ0FBQyxDQUFDO0lBQ25FLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxXQUFXLENBQUMsR0FBVztRQUMzQixNQUFNLE9BQU8sR0FBRyxJQUFJLCtCQUFtQixDQUFDO1lBQ3RDLE1BQU0sRUFBRSxJQUFJLENBQUMsVUFBVTtZQUN2QixHQUFHLEVBQUUsR0FBRztTQUNULENBQUMsQ0FBQztRQUVILE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7SUFDcEMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGtCQUFrQixDQUFDLEdBQVcsRUFBRSxTQUFpQixFQUFFLE9BQWdCO1FBQ3ZFLElBQUksQ0FBQztZQUNILHlDQUF5QztZQUN6QyxNQUFNLE9BQU8sR0FBMkIsRUFBRSxDQUFDO1lBRTNDLG9EQUFvRDtZQUNwRCxJQUFJLEdBQUcsQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsRUFBRSxDQUFDO2dCQUNuQyxNQUFNLFVBQVUsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLGtCQUFrQixDQUFDO2dCQUNsRCxNQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixDQUFDO2dCQUVoRCxJQUFJLFVBQVUsSUFBSSxTQUFTLEVBQUUsQ0FBQztvQkFDNUIsTUFBTSxXQUFXLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLFVBQVUsSUFBSSxTQUFTLEVBQUUsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztvQkFDakYsT0FBTyxDQUFDLGVBQWUsQ0FBQyxHQUFHLFNBQVMsV0FBVyxFQUFFLENBQUM7b0JBQ2xELE9BQU8sQ0FBQyxHQUFHLENBQUMsK0NBQStDLENBQUMsQ0FBQztnQkFDL0QsQ0FBQztxQkFBTSxDQUFDO29CQUNOLE9BQU8sQ0FBQyxJQUFJLENBQUMsdURBQXVELENBQUMsQ0FBQztnQkFDeEUsQ0FBQztZQUNILENBQUM7WUFFRCx1REFBdUQ7WUFDdkQsTUFBTSxRQUFRLEdBQUcsTUFBTSxLQUFLLENBQUMsR0FBRyxFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUMvQyxJQUFJLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxDQUFDO2dCQUNqQixNQUFNLElBQUksS0FBSyxDQUFDLG1DQUFtQyxRQUFRLENBQUMsTUFBTSxJQUFJLFFBQVEsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFDO1lBQy9GLENBQUM7WUFFRCxNQUFNLFdBQVcsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sUUFBUSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUM7WUFDOUQsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEdBQUcsRUFBRSxDQUFDO1lBQzdCLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsU0FBUyxFQUFFLE9BQU8sQ0FBQyxDQUFDO1lBRWpFLDZCQUE2QjtZQUM3QixNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxXQUFXLEVBQUUsR0FBRyxFQUFFO2dCQUNsRSxTQUFTO2dCQUNULE9BQU8sRUFBRSxPQUFPLElBQUksU0FBUztnQkFDN0IsU0FBUyxFQUFFLEdBQUc7Z0JBQ2QsZUFBZSxFQUFFLFNBQVMsQ0FBQyxRQUFRLEVBQUU7Z0JBQ3JDLFNBQVMsRUFBRSxZQUFZO2FBQ3hCLENBQUMsQ0FBQztZQUVILE9BQU8sQ0FBQyxHQUFHLENBQUMsc0RBQXNELEdBQUcsRUFBRSxDQUFDLENBQUM7WUFDekUsT0FBTyxNQUFNLENBQUM7UUFFaEIsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGlDQUFpQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3hELE1BQU0sSUFBSSxLQUFLLENBQUMsb0NBQW9DLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLGVBQWUsRUFBRSxDQUFDLENBQUM7UUFDbEgsQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxlQUFlLENBQUMsV0FBbUIsRUFBRSxHQUFXLEVBQUUsY0FBc0IsV0FBVztRQUN2RixNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsV0FBVyxFQUFFLEdBQUcsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUNyRSxPQUFPLE1BQU0sQ0FBQyxHQUFHLENBQUM7SUFDcEIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLHVCQUF1QixDQUFDLEdBQVc7UUFDdkMsT0FBTyxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsZ0JBQWdCO0lBQzdELENBQUM7SUFFRDs7T0FFRztJQUNILGdCQUFnQixDQUFDLFNBQWlCLEVBQUUsU0FBaUIsRUFBRSxJQUF3QjtRQUM3RSxPQUFPLFNBQVMsU0FBUyxJQUFJLElBQUksSUFBSSxTQUFTLE1BQU0sQ0FBQztJQUN2RCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxRQUFRLENBQUMsR0FBVztRQUNsQixPQUFPLFFBQVEsSUFBSSxDQUFDLFVBQVUsSUFBSSxHQUFHLEVBQUUsQ0FBQztJQUMxQyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxZQUFZLENBQUMsR0FBVztRQUN0QixPQUFPLFdBQVcsSUFBSSxDQUFDLFVBQVUscUJBQXFCLEdBQUcsRUFBRSxDQUFDO0lBQzlELENBQUM7Q0FDRjtBQXRLRCw4QkFzS0MiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIFMzIFNlcnZpY2UgZm9yIGhhbmRsaW5nIGF1ZGlvIGZpbGUgc3RvcmFnZSBhbmQgcmV0cmlldmFsXG4gKi9cblxuaW1wb3J0IHsgUzNDbGllbnQsIFB1dE9iamVjdENvbW1hbmQsIEdldE9iamVjdENvbW1hbmQsIERlbGV0ZU9iamVjdENvbW1hbmQgfSBmcm9tICdAYXdzLXNkay9jbGllbnQtczMnO1xuaW1wb3J0IHsgZ2V0U2lnbmVkVXJsIH0gZnJvbSAnQGF3cy1zZGsvczMtcmVxdWVzdC1wcmVzaWduZXInO1xuXG5leHBvcnQgaW50ZXJmYWNlIFMzVXBsb2FkUmVzdWx0IHtcbiAga2V5OiBzdHJpbmc7XG4gIHVybDogc3RyaW5nO1xuICBidWNrZXQ6IHN0cmluZztcbn1cblxuZXhwb3J0IGludGVyZmFjZSBTM1NlcnZpY2VDb25maWcge1xuICBidWNrZXROYW1lOiBzdHJpbmc7XG4gIHJlZ2lvbj86IHN0cmluZztcbn1cblxuZXhwb3J0IGNsYXNzIFMzU2VydmljZSB7XG4gIHByaXZhdGUgczNDbGllbnQ6IFMzQ2xpZW50O1xuICBwcml2YXRlIGJ1Y2tldE5hbWU6IHN0cmluZztcblxuICBjb25zdHJ1Y3Rvcihjb25maWc6IFMzU2VydmljZUNvbmZpZykge1xuICAgIHRoaXMuYnVja2V0TmFtZSA9IGNvbmZpZy5idWNrZXROYW1lO1xuICAgIHRoaXMuczNDbGllbnQgPSBuZXcgUzNDbGllbnQoe1xuICAgICAgcmVnaW9uOiBjb25maWcucmVnaW9uIHx8IHByb2Nlc3MuZW52LkFXU19SRUdJT04gfHwgJ3VzLWVhc3QtMSdcbiAgICB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBVcGxvYWQgYXVkaW8gZmlsZSB0byBTM1xuICAgKi9cbiAgYXN5bmMgdXBsb2FkQXVkaW8oYXVkaW9CdWZmZXI6IEJ1ZmZlciwga2V5OiBzdHJpbmcsIGNvbnRlbnRUeXBlOiBzdHJpbmcgPSAnYXVkaW8vd2F2Jyk6IFByb21pc2U8UzNVcGxvYWRSZXN1bHQ+IHtcbiAgICBjb25zdCBjb21tYW5kID0gbmV3IFB1dE9iamVjdENvbW1hbmQoe1xuICAgICAgQnVja2V0OiB0aGlzLmJ1Y2tldE5hbWUsXG4gICAgICBLZXk6IGtleSxcbiAgICAgIEJvZHk6IGF1ZGlvQnVmZmVyLFxuICAgICAgQ29udGVudFR5cGU6IGNvbnRlbnRUeXBlXG4gICAgfSk7XG5cbiAgICBhd2FpdCB0aGlzLnMzQ2xpZW50LnNlbmQoY29tbWFuZCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAga2V5LFxuICAgICAgdXJsOiBgczM6Ly8ke3RoaXMuYnVja2V0TmFtZX0vJHtrZXl9YCxcbiAgICAgIGJ1Y2tldDogdGhpcy5idWNrZXROYW1lXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBVcGxvYWQgYXVkaW8gZmlsZSB0byBTMyB3aXRoIG1ldGFkYXRhXG4gICAqL1xuICBhc3luYyB1cGxvYWRBdWRpb1dpdGhNZXRhZGF0YShcbiAgICBhdWRpb0J1ZmZlcjogQnVmZmVyLCBcbiAgICBrZXk6IHN0cmluZywgXG4gICAgbWV0YWRhdGE6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4sXG4gICAgY29udGVudFR5cGU6IHN0cmluZyA9ICdhdWRpby93YXYnXG4gICk6IFByb21pc2U8UzNVcGxvYWRSZXN1bHQ+IHtcbiAgICBjb25zdCBjb21tYW5kID0gbmV3IFB1dE9iamVjdENvbW1hbmQoe1xuICAgICAgQnVja2V0OiB0aGlzLmJ1Y2tldE5hbWUsXG4gICAgICBLZXk6IGtleSxcbiAgICAgIEJvZHk6IGF1ZGlvQnVmZmVyLFxuICAgICAgQ29udGVudFR5cGU6IGNvbnRlbnRUeXBlLFxuICAgICAgTWV0YWRhdGE6IG1ldGFkYXRhXG4gICAgfSk7XG5cbiAgICBhd2FpdCB0aGlzLnMzQ2xpZW50LnNlbmQoY29tbWFuZCk7XG5cbiAgICByZXR1cm4ge1xuICAgICAga2V5LFxuICAgICAgdXJsOiBgczM6Ly8ke3RoaXMuYnVja2V0TmFtZX0vJHtrZXl9YCxcbiAgICAgIGJ1Y2tldDogdGhpcy5idWNrZXROYW1lXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXQgc2lnbmVkIFVSTCBmb3IgYXVkaW8gZmlsZSBhY2Nlc3NcbiAgICovXG4gIGFzeW5jIGdldFNpZ25lZFVybChrZXk6IHN0cmluZywgZXhwaXJlc0luOiBudW1iZXIgPSAzNjAwKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBjb21tYW5kID0gbmV3IEdldE9iamVjdENvbW1hbmQoe1xuICAgICAgQnVja2V0OiB0aGlzLmJ1Y2tldE5hbWUsXG4gICAgICBLZXk6IGtleVxuICAgIH0pO1xuXG4gICAgcmV0dXJuIGF3YWl0IGdldFNpZ25lZFVybCh0aGlzLnMzQ2xpZW50LCBjb21tYW5kLCB7IGV4cGlyZXNJbiB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBEZWxldGUgYXVkaW8gZmlsZSBmcm9tIFMzXG4gICAqL1xuICBhc3luYyBkZWxldGVBdWRpbyhrZXk6IHN0cmluZyk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGNvbW1hbmQgPSBuZXcgRGVsZXRlT2JqZWN0Q29tbWFuZCh7XG4gICAgICBCdWNrZXQ6IHRoaXMuYnVja2V0TmFtZSxcbiAgICAgIEtleToga2V5XG4gICAgfSk7XG5cbiAgICBhd2FpdCB0aGlzLnMzQ2xpZW50LnNlbmQoY29tbWFuZCk7XG4gIH1cblxuICAvKipcbiAgICogVXBsb2FkIGF1ZGlvIGZpbGUgZnJvbSBVUkwgKGUuZy4sIFR3aWxpbyByZWNvcmRpbmcgVVJMKVxuICAgKi9cbiAgYXN5bmMgdXBsb2FkQXVkaW9Gcm9tVXJsKHVybDogc3RyaW5nLCBzZXNzaW9uSWQ6IHN0cmluZywgY2FsbFNpZD86IHN0cmluZyk6IFByb21pc2U8UzNVcGxvYWRSZXN1bHQ+IHtcbiAgICB0cnkge1xuICAgICAgLy8gUHJlcGFyZSBhdXRoZW50aWNhdGlvbiBmb3IgVHdpbGlvIFVSTHNcbiAgICAgIGNvbnN0IGhlYWRlcnM6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4gPSB7fTtcbiAgICAgIFxuICAgICAgLy8gQWRkIFR3aWxpbyBhdXRoZW50aWNhdGlvbiBpZiB0aGlzIGlzIGEgVHdpbGlvIFVSTFxuICAgICAgaWYgKHVybC5pbmNsdWRlcygnYXBpLnR3aWxpby5jb20nKSkge1xuICAgICAgICBjb25zdCBhY2NvdW50U2lkID0gcHJvY2Vzcy5lbnYuVFdJTElPX0FDQ09VTlRfU0lEO1xuICAgICAgICBjb25zdCBhdXRoVG9rZW4gPSBwcm9jZXNzLmVudi5UV0lMSU9fQVVUSF9UT0tFTjtcbiAgICAgICAgXG4gICAgICAgIGlmIChhY2NvdW50U2lkICYmIGF1dGhUb2tlbikge1xuICAgICAgICAgIGNvbnN0IGNyZWRlbnRpYWxzID0gQnVmZmVyLmZyb20oYCR7YWNjb3VudFNpZH06JHthdXRoVG9rZW59YCkudG9TdHJpbmcoJ2Jhc2U2NCcpO1xuICAgICAgICAgIGhlYWRlcnNbJ0F1dGhvcml6YXRpb24nXSA9IGBCYXNpYyAke2NyZWRlbnRpYWxzfWA7XG4gICAgICAgICAgY29uc29sZS5sb2coJ0FkZGVkIFR3aWxpbyBhdXRoZW50aWNhdGlvbiBmb3IgcmVjb3JkaW5nIFVSTCcpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIGNvbnNvbGUud2FybignVHdpbGlvIGNyZWRlbnRpYWxzIG5vdCBmb3VuZCBpbiBlbnZpcm9ubWVudCB2YXJpYWJsZXMnKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgXG4gICAgICAvLyBGZXRjaCBhdWRpbyBkYXRhIGZyb20gVHdpbGlvIFVSTCB3aXRoIGF1dGhlbnRpY2F0aW9uXG4gICAgICBjb25zdCByZXNwb25zZSA9IGF3YWl0IGZldGNoKHVybCwgeyBoZWFkZXJzIH0pO1xuICAgICAgaWYgKCFyZXNwb25zZS5vaykge1xuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBmZXRjaCBhdWRpbyBmcm9tIFVSTDogJHtyZXNwb25zZS5zdGF0dXN9ICR7cmVzcG9uc2Uuc3RhdHVzVGV4dH1gKTtcbiAgICAgIH1cbiAgICAgIFxuICAgICAgY29uc3QgYXVkaW9CdWZmZXIgPSBCdWZmZXIuZnJvbShhd2FpdCByZXNwb25zZS5hcnJheUJ1ZmZlcigpKTtcbiAgICAgIGNvbnN0IHRpbWVzdGFtcCA9IERhdGUubm93KCk7XG4gICAgICBjb25zdCBrZXkgPSB0aGlzLmdlbmVyYXRlQXVkaW9LZXkoc2Vzc2lvbklkLCB0aW1lc3RhbXAsICdpbnB1dCcpO1xuICAgICAgXG4gICAgICAvLyBBZGQgbWV0YWRhdGEgdG8gdGhlIHVwbG9hZFxuICAgICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy51cGxvYWRBdWRpb1dpdGhNZXRhZGF0YShhdWRpb0J1ZmZlciwga2V5LCB7XG4gICAgICAgIHNlc3Npb25JZCxcbiAgICAgICAgY2FsbFNpZDogY2FsbFNpZCB8fCAndW5rbm93bicsXG4gICAgICAgIHNvdXJjZVVybDogdXJsLFxuICAgICAgICB1cGxvYWRUaW1lc3RhbXA6IHRpbWVzdGFtcC50b1N0cmluZygpLFxuICAgICAgICBhdWRpb1R5cGU6ICd1c2VyLWlucHV0J1xuICAgICAgfSk7XG4gICAgICBcbiAgICAgIGNvbnNvbGUubG9nKGBTdWNjZXNzZnVsbHkgdXBsb2FkZWQgYXVkaW8gZnJvbSBUd2lsaW8gVVJMIHRvIFMzOiAke2tleX1gKTtcbiAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICBcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgdXBsb2FkaW5nIGF1ZGlvIGZyb20gVVJMOicsIGVycm9yKTtcbiAgICAgIHRocm93IG5ldyBFcnJvcihgRmFpbGVkIHRvIHVwbG9hZCBhdWRpbyBmcm9tIFVSTDogJHtlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6ICdVbmtub3duIGVycm9yJ31gKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVXBsb2FkIGF1ZGlvIGZpbGUgYnVmZmVyXG4gICAqL1xuICBhc3luYyB1cGxvYWRBdWRpb0ZpbGUoYXVkaW9CdWZmZXI6IEJ1ZmZlciwga2V5OiBzdHJpbmcsIGNvbnRlbnRUeXBlOiBzdHJpbmcgPSAnYXVkaW8vd2F2Jyk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXdhaXQgdGhpcy51cGxvYWRBdWRpbyhhdWRpb0J1ZmZlciwga2V5LCBjb250ZW50VHlwZSk7XG4gICAgcmV0dXJuIHJlc3VsdC51cmw7XG4gIH1cblxuICAvKipcbiAgICogR2V0IHRlbGVwaG9ueS1vcHRpbWl6ZWQgcGxheWJhY2sgVVJMXG4gICAqL1xuICBhc3luYyBnZXRUZWxlcGhvbnlQbGF5YmFja1VybChrZXk6IHN0cmluZyk6IFByb21pc2U8c3RyaW5nPiB7XG4gICAgcmV0dXJuIGF3YWl0IHRoaXMuZ2V0U2lnbmVkVXJsKGtleSwgMzYwMCk7IC8vIDEgaG91ciBleHBpcnlcbiAgfVxuXG4gIC8qKlxuICAgKiBHZW5lcmF0ZSBTMyBrZXkgZm9yIGF1ZGlvIGZpbGVcbiAgICovXG4gIGdlbmVyYXRlQXVkaW9LZXkoc2Vzc2lvbklkOiBzdHJpbmcsIHRpbWVzdGFtcDogbnVtYmVyLCB0eXBlOiAnaW5wdXQnIHwgJ291dHB1dCcpOiBzdHJpbmcge1xuICAgIHJldHVybiBgYXVkaW8vJHtzZXNzaW9uSWR9LyR7dHlwZX0tJHt0aW1lc3RhbXB9LndhdmA7XG4gIH1cblxuICAvKipcbiAgICogR2V0IFMzIFVSSSBmb3IgVHJhbnNjcmliZSBzZXJ2aWNlXG4gICAqL1xuICBnZXRTM1VyaShrZXk6IHN0cmluZyk6IHN0cmluZyB7XG4gICAgcmV0dXJuIGBzMzovLyR7dGhpcy5idWNrZXROYW1lfS8ke2tleX1gO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldCBwdWJsaWMgSFRUUFMgVVJMIGZvciBhdWRpbyBmaWxlXG4gICAqL1xuICBnZXRQdWJsaWNVcmwoa2V5OiBzdHJpbmcpOiBzdHJpbmcge1xuICAgIHJldHVybiBgaHR0cHM6Ly8ke3RoaXMuYnVja2V0TmFtZX0uczMuYW1hem9uYXdzLmNvbS8ke2tleX1gO1xuICB9XG59Il19