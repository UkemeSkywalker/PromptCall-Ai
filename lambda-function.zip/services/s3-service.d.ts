/**
 * S3 Service for handling audio file storage and retrieval
 */
export interface S3UploadResult {
    key: string;
    url: string;
    bucket: string;
}
export interface S3ServiceConfig {
    bucketName: string;
    region?: string;
}
export declare class S3Service {
    private s3Client;
    private bucketName;
    constructor(config: S3ServiceConfig);
    /**
     * Upload audio file to S3
     */
    uploadAudio(audioBuffer: Buffer, key: string, contentType?: string): Promise<S3UploadResult>;
    /**
     * Upload audio file to S3 with metadata
     */
    uploadAudioWithMetadata(audioBuffer: Buffer, key: string, metadata: Record<string, string>, contentType?: string): Promise<S3UploadResult>;
    /**
     * Get signed URL for audio file access
     */
    getSignedUrl(key: string, expiresIn?: number): Promise<string>;
    /**
     * Delete audio file from S3
     */
    deleteAudio(key: string): Promise<void>;
    /**
     * Upload audio file from URL (e.g., Twilio recording URL)
     */
    uploadAudioFromUrl(url: string, sessionId: string, callSid?: string): Promise<S3UploadResult>;
    /**
     * Upload audio file buffer
     */
    uploadAudioFile(audioBuffer: Buffer, key: string, contentType?: string): Promise<string>;
    /**
     * Get telephony-optimized playback URL
     */
    getTelephonyPlaybackUrl(key: string): Promise<string>;
    /**
     * Generate S3 key for audio file
     */
    generateAudioKey(sessionId: string, timestamp: number, type: 'input' | 'output'): string;
    /**
     * Get S3 URI for Transcribe service
     */
    getS3Uri(key: string): string;
    /**
     * Get public HTTPS URL for audio file
     */
    getPublicUrl(key: string): string;
}
