"use strict";
/**
 * AI Conversation Service for handling AI interactions via AWS Bedrock
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.AIConversationService = void 0;
const client_bedrock_runtime_1 = require("@aws-sdk/client-bedrock-runtime");
class AIConversationService {
    constructor(config = {}) {
        this.config = {
            region: config.region || process.env.AWS_REGION || 'us-east-1',
            model: config.model || 'anthropic.claude-3-haiku-20240307-v1:0',
            maxTokens: config.maxTokens || 150, // Limit for voice responses
            temperature: config.temperature || 0.7
        };
        this.bedrockClient = new client_bedrock_runtime_1.BedrockRuntimeClient({
            region: this.config.region
        });
    }
    /**
     * Generate AI response for user query
     */
    async generateResponse(userQuery, conversationHistory = []) {
        const systemPrompt = this.buildSystemPrompt();
        const contextPrompt = this.buildContextPrompt(conversationHistory);
        const fullPrompt = `${systemPrompt}\n\n${contextPrompt}\n\nUser: ${userQuery}\n\nAssistant:`;
        const payload = {
            anthropic_version: "bedrock-2023-05-31",
            max_tokens: this.config.maxTokens,
            temperature: this.config.temperature,
            messages: [
                {
                    role: "user",
                    content: fullPrompt
                }
            ]
        };
        const command = new client_bedrock_runtime_1.InvokeModelCommand({
            modelId: this.config.model,
            body: JSON.stringify(payload),
            contentType: 'application/json'
        });
        const response = await this.bedrockClient.send(command);
        const responseBody = JSON.parse(new TextDecoder().decode(response.body));
        return {
            text: responseBody.content[0].text,
            model: this.config.model,
            usage: {
                inputTokens: responseBody.usage?.input_tokens || 0,
                outputTokens: responseBody.usage?.output_tokens || 0
            }
        };
    }
    /**
     * Build system prompt optimized for voice interactions
     */
    buildSystemPrompt() {
        return `You are an AI assistant for PromptCall AI, a voice-based AI service accessed via phone calls. 

Key guidelines:
- Keep responses concise (under 60 seconds of speech, approximately 150 words)
- Use clear, simple language suitable for phone conversations
- Be helpful and direct
- Avoid complex formatting or lists that don't work well in speech
- If you need to provide multiple points, use natural speech patterns
- Always end with a clear conclusion or next step`;
    }
    /**
     * Build context prompt from conversation history
     */
    buildContextPrompt(conversationHistory) {
        if (conversationHistory.length === 0) {
            return 'This is the start of a new conversation.';
        }
        return `Previous conversation context:\n${conversationHistory.join('\n')}`;
    }
    /**
     * Process user message with full conversation context
     */
    async processUserMessage(userQuery, sessionId, conversationHistory = []) {
        const response = await this.generateResponse(userQuery, conversationHistory);
        response.text = this.optimizeForVoice(response.text);
        return response;
    }
    /**
     * Optimize response for voice delivery
     */
    optimizeForVoice(text) {
        // Remove markdown formatting
        let optimized = text.replace(/[*_`]/g, '');
        // Replace bullet points with natural speech
        optimized = optimized.replace(/^[-*]\s+/gm, 'First, ');
        optimized = optimized.replace(/\n[-*]\s+/g, '. Next, ');
        // Ensure proper sentence endings
        if (!optimized.endsWith('.') && !optimized.endsWith('!') && !optimized.endsWith('?')) {
            optimized += '.';
        }
        return optimized;
    }
}
exports.AIConversationService = AIConversationService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYWktY29udmVyc2F0aW9uLXNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvc2VydmljZXMvYWktY29udmVyc2F0aW9uLXNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IjtBQUFBOztHQUVHOzs7QUFFSCw0RUFBMkY7QUFrQjNGLE1BQWEscUJBQXFCO0lBSWhDLFlBQVksU0FBK0IsRUFBRTtRQUMzQyxJQUFJLENBQUMsTUFBTSxHQUFHO1lBQ1osTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLElBQUksV0FBVztZQUM5RCxLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUssSUFBSSx3Q0FBd0M7WUFDL0QsU0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTLElBQUksR0FBRyxFQUFFLDRCQUE0QjtZQUNoRSxXQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVcsSUFBSSxHQUFHO1NBQ3ZDLENBQUM7UUFFRixJQUFJLENBQUMsYUFBYSxHQUFHLElBQUksNkNBQW9CLENBQUM7WUFDNUMsTUFBTSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTTtTQUMzQixDQUFDLENBQUM7SUFDTCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsZ0JBQWdCLENBQUMsU0FBaUIsRUFBRSxzQkFBZ0MsRUFBRTtRQUMxRSxNQUFNLFlBQVksR0FBRyxJQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQztRQUM5QyxNQUFNLGFBQWEsR0FBRyxJQUFJLENBQUMsa0JBQWtCLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUVuRSxNQUFNLFVBQVUsR0FBRyxHQUFHLFlBQVksT0FBTyxhQUFhLGFBQWEsU0FBUyxnQkFBZ0IsQ0FBQztRQUU3RixNQUFNLE9BQU8sR0FBRztZQUNkLGlCQUFpQixFQUFFLG9CQUFvQjtZQUN2QyxVQUFVLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTO1lBQ2pDLFdBQVcsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVc7WUFDcEMsUUFBUSxFQUFFO2dCQUNSO29CQUNFLElBQUksRUFBRSxNQUFNO29CQUNaLE9BQU8sRUFBRSxVQUFVO2lCQUNwQjthQUNGO1NBQ0YsQ0FBQztRQUVGLE1BQU0sT0FBTyxHQUFHLElBQUksMkNBQWtCLENBQUM7WUFDckMsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSztZQUMxQixJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUM7WUFDN0IsV0FBVyxFQUFFLGtCQUFrQjtTQUNoQyxDQUFDLENBQUM7UUFFSCxNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ3hELE1BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxXQUFXLEVBQUUsQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUM7UUFFekUsT0FBTztZQUNMLElBQUksRUFBRSxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7WUFDbEMsS0FBSyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBTTtZQUN6QixLQUFLLEVBQUU7Z0JBQ0wsV0FBVyxFQUFFLFlBQVksQ0FBQyxLQUFLLEVBQUUsWUFBWSxJQUFJLENBQUM7Z0JBQ2xELFlBQVksRUFBRSxZQUFZLENBQUMsS0FBSyxFQUFFLGFBQWEsSUFBSSxDQUFDO2FBQ3JEO1NBQ0YsQ0FBQztJQUNKLENBQUM7SUFFRDs7T0FFRztJQUNLLGlCQUFpQjtRQUN2QixPQUFPOzs7Ozs7OztrREFRdUMsQ0FBQztJQUNqRCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxrQkFBa0IsQ0FBQyxtQkFBNkI7UUFDdEQsSUFBSSxtQkFBbUIsQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7WUFDckMsT0FBTywwQ0FBMEMsQ0FBQztRQUNwRCxDQUFDO1FBRUQsT0FBTyxtQ0FBbUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7SUFDN0UsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGtCQUFrQixDQUFDLFNBQWlCLEVBQUUsU0FBaUIsRUFBRSxzQkFBZ0MsRUFBRTtRQUMvRixNQUFNLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLEVBQUUsbUJBQW1CLENBQUMsQ0FBQztRQUM3RSxRQUFRLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7UUFDckQsT0FBTyxRQUFRLENBQUM7SUFDbEIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsZ0JBQWdCLENBQUMsSUFBWTtRQUMzQiw2QkFBNkI7UUFDN0IsSUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFFM0MsNENBQTRDO1FBQzVDLFNBQVMsR0FBRyxTQUFTLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxTQUFTLENBQUMsQ0FBQztRQUN2RCxTQUFTLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFFeEQsaUNBQWlDO1FBQ2pDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNyRixTQUFTLElBQUksR0FBRyxDQUFDO1FBQ25CLENBQUM7UUFFRCxPQUFPLFNBQVMsQ0FBQztJQUNuQixDQUFDO0NBQ0Y7QUE5R0Qsc0RBOEdDIiwic291cmNlc0NvbnRlbnQiOlsiLyoqXG4gKiBBSSBDb252ZXJzYXRpb24gU2VydmljZSBmb3IgaGFuZGxpbmcgQUkgaW50ZXJhY3Rpb25zIHZpYSBBV1MgQmVkcm9ja1xuICovXG5cbmltcG9ydCB7IEJlZHJvY2tSdW50aW1lQ2xpZW50LCBJbnZva2VNb2RlbENvbW1hbmQgfSBmcm9tICdAYXdzLXNkay9jbGllbnQtYmVkcm9jay1ydW50aW1lJztcblxuZXhwb3J0IGludGVyZmFjZSBBSVJlc3BvbnNlIHtcbiAgdGV4dDogc3RyaW5nO1xuICBtb2RlbDogc3RyaW5nO1xuICB1c2FnZT86IHtcbiAgICBpbnB1dFRva2VuczogbnVtYmVyO1xuICAgIG91dHB1dFRva2VuczogbnVtYmVyO1xuICB9O1xufVxuXG5leHBvcnQgaW50ZXJmYWNlIEFJQ29udmVyc2F0aW9uQ29uZmlnIHtcbiAgcmVnaW9uPzogc3RyaW5nO1xuICBtb2RlbD86IHN0cmluZztcbiAgbWF4VG9rZW5zPzogbnVtYmVyO1xuICB0ZW1wZXJhdHVyZT86IG51bWJlcjtcbn1cblxuZXhwb3J0IGNsYXNzIEFJQ29udmVyc2F0aW9uU2VydmljZSB7XG4gIHByaXZhdGUgYmVkcm9ja0NsaWVudDogQmVkcm9ja1J1bnRpbWVDbGllbnQ7XG4gIHByaXZhdGUgY29uZmlnOiBBSUNvbnZlcnNhdGlvbkNvbmZpZztcblxuICBjb25zdHJ1Y3Rvcihjb25maWc6IEFJQ29udmVyc2F0aW9uQ29uZmlnID0ge30pIHtcbiAgICB0aGlzLmNvbmZpZyA9IHtcbiAgICAgIHJlZ2lvbjogY29uZmlnLnJlZ2lvbiB8fCBwcm9jZXNzLmVudi5BV1NfUkVHSU9OIHx8ICd1cy1lYXN0LTEnLFxuICAgICAgbW9kZWw6IGNvbmZpZy5tb2RlbCB8fCAnYW50aHJvcGljLmNsYXVkZS0zLWhhaWt1LTIwMjQwMzA3LXYxOjAnLFxuICAgICAgbWF4VG9rZW5zOiBjb25maWcubWF4VG9rZW5zIHx8IDE1MCwgLy8gTGltaXQgZm9yIHZvaWNlIHJlc3BvbnNlc1xuICAgICAgdGVtcGVyYXR1cmU6IGNvbmZpZy50ZW1wZXJhdHVyZSB8fCAwLjdcbiAgICB9O1xuXG4gICAgdGhpcy5iZWRyb2NrQ2xpZW50ID0gbmV3IEJlZHJvY2tSdW50aW1lQ2xpZW50KHtcbiAgICAgIHJlZ2lvbjogdGhpcy5jb25maWcucmVnaW9uXG4gICAgfSk7XG4gIH1cblxuICAvKipcbiAgICogR2VuZXJhdGUgQUkgcmVzcG9uc2UgZm9yIHVzZXIgcXVlcnlcbiAgICovXG4gIGFzeW5jIGdlbmVyYXRlUmVzcG9uc2UodXNlclF1ZXJ5OiBzdHJpbmcsIGNvbnZlcnNhdGlvbkhpc3Rvcnk6IHN0cmluZ1tdID0gW10pOiBQcm9taXNlPEFJUmVzcG9uc2U+IHtcbiAgICBjb25zdCBzeXN0ZW1Qcm9tcHQgPSB0aGlzLmJ1aWxkU3lzdGVtUHJvbXB0KCk7XG4gICAgY29uc3QgY29udGV4dFByb21wdCA9IHRoaXMuYnVpbGRDb250ZXh0UHJvbXB0KGNvbnZlcnNhdGlvbkhpc3RvcnkpO1xuICAgIFxuICAgIGNvbnN0IGZ1bGxQcm9tcHQgPSBgJHtzeXN0ZW1Qcm9tcHR9XFxuXFxuJHtjb250ZXh0UHJvbXB0fVxcblxcblVzZXI6ICR7dXNlclF1ZXJ5fVxcblxcbkFzc2lzdGFudDpgO1xuXG4gICAgY29uc3QgcGF5bG9hZCA9IHtcbiAgICAgIGFudGhyb3BpY192ZXJzaW9uOiBcImJlZHJvY2stMjAyMy0wNS0zMVwiLFxuICAgICAgbWF4X3Rva2VuczogdGhpcy5jb25maWcubWF4VG9rZW5zLFxuICAgICAgdGVtcGVyYXR1cmU6IHRoaXMuY29uZmlnLnRlbXBlcmF0dXJlLFxuICAgICAgbWVzc2FnZXM6IFtcbiAgICAgICAge1xuICAgICAgICAgIHJvbGU6IFwidXNlclwiLFxuICAgICAgICAgIGNvbnRlbnQ6IGZ1bGxQcm9tcHRcbiAgICAgICAgfVxuICAgICAgXVxuICAgIH07XG5cbiAgICBjb25zdCBjb21tYW5kID0gbmV3IEludm9rZU1vZGVsQ29tbWFuZCh7XG4gICAgICBtb2RlbElkOiB0aGlzLmNvbmZpZy5tb2RlbCxcbiAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHBheWxvYWQpLFxuICAgICAgY29udGVudFR5cGU6ICdhcHBsaWNhdGlvbi9qc29uJ1xuICAgIH0pO1xuXG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLmJlZHJvY2tDbGllbnQuc2VuZChjb21tYW5kKTtcbiAgICBjb25zdCByZXNwb25zZUJvZHkgPSBKU09OLnBhcnNlKG5ldyBUZXh0RGVjb2RlcigpLmRlY29kZShyZXNwb25zZS5ib2R5KSk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgdGV4dDogcmVzcG9uc2VCb2R5LmNvbnRlbnRbMF0udGV4dCxcbiAgICAgIG1vZGVsOiB0aGlzLmNvbmZpZy5tb2RlbCEsXG4gICAgICB1c2FnZToge1xuICAgICAgICBpbnB1dFRva2VuczogcmVzcG9uc2VCb2R5LnVzYWdlPy5pbnB1dF90b2tlbnMgfHwgMCxcbiAgICAgICAgb3V0cHV0VG9rZW5zOiByZXNwb25zZUJvZHkudXNhZ2U/Lm91dHB1dF90b2tlbnMgfHwgMFxuICAgICAgfVxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogQnVpbGQgc3lzdGVtIHByb21wdCBvcHRpbWl6ZWQgZm9yIHZvaWNlIGludGVyYWN0aW9uc1xuICAgKi9cbiAgcHJpdmF0ZSBidWlsZFN5c3RlbVByb21wdCgpOiBzdHJpbmcge1xuICAgIHJldHVybiBgWW91IGFyZSBhbiBBSSBhc3Npc3RhbnQgZm9yIFByb21wdENhbGwgQUksIGEgdm9pY2UtYmFzZWQgQUkgc2VydmljZSBhY2Nlc3NlZCB2aWEgcGhvbmUgY2FsbHMuIFxuXG5LZXkgZ3VpZGVsaW5lczpcbi0gS2VlcCByZXNwb25zZXMgY29uY2lzZSAodW5kZXIgNjAgc2Vjb25kcyBvZiBzcGVlY2gsIGFwcHJveGltYXRlbHkgMTUwIHdvcmRzKVxuLSBVc2UgY2xlYXIsIHNpbXBsZSBsYW5ndWFnZSBzdWl0YWJsZSBmb3IgcGhvbmUgY29udmVyc2F0aW9uc1xuLSBCZSBoZWxwZnVsIGFuZCBkaXJlY3Rcbi0gQXZvaWQgY29tcGxleCBmb3JtYXR0aW5nIG9yIGxpc3RzIHRoYXQgZG9uJ3Qgd29yayB3ZWxsIGluIHNwZWVjaFxuLSBJZiB5b3UgbmVlZCB0byBwcm92aWRlIG11bHRpcGxlIHBvaW50cywgdXNlIG5hdHVyYWwgc3BlZWNoIHBhdHRlcm5zXG4tIEFsd2F5cyBlbmQgd2l0aCBhIGNsZWFyIGNvbmNsdXNpb24gb3IgbmV4dCBzdGVwYDtcbiAgfVxuXG4gIC8qKlxuICAgKiBCdWlsZCBjb250ZXh0IHByb21wdCBmcm9tIGNvbnZlcnNhdGlvbiBoaXN0b3J5XG4gICAqL1xuICBwcml2YXRlIGJ1aWxkQ29udGV4dFByb21wdChjb252ZXJzYXRpb25IaXN0b3J5OiBzdHJpbmdbXSk6IHN0cmluZyB7XG4gICAgaWYgKGNvbnZlcnNhdGlvbkhpc3RvcnkubGVuZ3RoID09PSAwKSB7XG4gICAgICByZXR1cm4gJ1RoaXMgaXMgdGhlIHN0YXJ0IG9mIGEgbmV3IGNvbnZlcnNhdGlvbi4nO1xuICAgIH1cblxuICAgIHJldHVybiBgUHJldmlvdXMgY29udmVyc2F0aW9uIGNvbnRleHQ6XFxuJHtjb252ZXJzYXRpb25IaXN0b3J5LmpvaW4oJ1xcbicpfWA7XG4gIH1cblxuICAvKipcbiAgICogUHJvY2VzcyB1c2VyIG1lc3NhZ2Ugd2l0aCBmdWxsIGNvbnZlcnNhdGlvbiBjb250ZXh0XG4gICAqL1xuICBhc3luYyBwcm9jZXNzVXNlck1lc3NhZ2UodXNlclF1ZXJ5OiBzdHJpbmcsIHNlc3Npb25JZDogc3RyaW5nLCBjb252ZXJzYXRpb25IaXN0b3J5OiBzdHJpbmdbXSA9IFtdKTogUHJvbWlzZTxBSVJlc3BvbnNlPiB7XG4gICAgY29uc3QgcmVzcG9uc2UgPSBhd2FpdCB0aGlzLmdlbmVyYXRlUmVzcG9uc2UodXNlclF1ZXJ5LCBjb252ZXJzYXRpb25IaXN0b3J5KTtcbiAgICByZXNwb25zZS50ZXh0ID0gdGhpcy5vcHRpbWl6ZUZvclZvaWNlKHJlc3BvbnNlLnRleHQpO1xuICAgIHJldHVybiByZXNwb25zZTtcbiAgfVxuXG4gIC8qKlxuICAgKiBPcHRpbWl6ZSByZXNwb25zZSBmb3Igdm9pY2UgZGVsaXZlcnlcbiAgICovXG4gIG9wdGltaXplRm9yVm9pY2UodGV4dDogc3RyaW5nKTogc3RyaW5nIHtcbiAgICAvLyBSZW1vdmUgbWFya2Rvd24gZm9ybWF0dGluZ1xuICAgIGxldCBvcHRpbWl6ZWQgPSB0ZXh0LnJlcGxhY2UoL1sqX2BdL2csICcnKTtcbiAgICBcbiAgICAvLyBSZXBsYWNlIGJ1bGxldCBwb2ludHMgd2l0aCBuYXR1cmFsIHNwZWVjaFxuICAgIG9wdGltaXplZCA9IG9wdGltaXplZC5yZXBsYWNlKC9eWy0qXVxccysvZ20sICdGaXJzdCwgJyk7XG4gICAgb3B0aW1pemVkID0gb3B0aW1pemVkLnJlcGxhY2UoL1xcblstKl1cXHMrL2csICcuIE5leHQsICcpO1xuICAgIFxuICAgIC8vIEVuc3VyZSBwcm9wZXIgc2VudGVuY2UgZW5kaW5nc1xuICAgIGlmICghb3B0aW1pemVkLmVuZHNXaXRoKCcuJykgJiYgIW9wdGltaXplZC5lbmRzV2l0aCgnIScpICYmICFvcHRpbWl6ZWQuZW5kc1dpdGgoJz8nKSkge1xuICAgICAgb3B0aW1pemVkICs9ICcuJztcbiAgICB9XG5cbiAgICByZXR1cm4gb3B0aW1pemVkO1xuICB9XG59Il19