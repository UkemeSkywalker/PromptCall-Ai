/**
 * Conversation Pipeline Orchestrator
 *
 * Orchestrates the complete conversation pipeline:
 * Speech-to-Text → AI Processing → Text-to-Speech
 */
import { DynamoSessionManager } from './dynamo-session-manager';
import { S3Service } from './s3-service';
import { TranscriptionProcessor } from './transcription-processor';
import { AIConversationService } from './ai-conversation-service';
import { PollyService } from './polly-service';
import { TimeoutManager } from './timeout-manager';
export interface PipelineResult {
    success: boolean;
    twimlResponse: string;
    error?: string;
    processingTimeMs?: number;
    conversationTurn?: number;
    isFollowUpExpected?: boolean;
    conversationPhase?: 'greeting' | 'conversation' | 'clarification' | 'closing';
}
export declare class ConversationPipelineOrchestrator {
    private sessionManager;
    private s3Service;
    private transcriptionProcessor;
    private aiConversationService;
    private pollyService;
    private terminationService?;
    constructor(sessionManager: DynamoSessionManager, s3Service: S3Service, transcriptionProcessor: TranscriptionProcessor, aiConversationService: AIConversationService, pollyService: PollyService, timeoutManager?: TimeoutManager);
    /**
     * Process complete conversation pipeline from audio input to TwiML response
     */
    processConversationTurn(recordingUrl: string, callSid: string, recordingDuration?: string): Promise<PipelineResult>;
    private calculateConversationTurn;
    private determineConversationPhase;
    private detectFollowUpExpectation;
    private generateResponseTwiML;
    private createTranscriptionFailureResponse;
    private generateFollowUpText;
    private createConversationTwiML;
    private createFallbackConversationTwiML;
    private createErrorTwiML;
}
