"use strict";
/**
 * DynamoDB Session Manager for PromptCall AI MVP
 * Handles CRUD operations for call sessions with conversation history
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.DynamoSessionManager = void 0;
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const util_dynamodb_1 = require("@aws-sdk/util-dynamodb");
const session_1 = require("../types/session");
class DynamoSessionManager {
    constructor(config) {
        this.client = new client_dynamodb_1.DynamoDBClient({
            region: config.region || process.env.AWS_REGION || 'us-east-1',
        });
        this.tableName = config.tableName;
        this.sessionConfig = config.sessionConfig || session_1.DEFAULT_SESSION_CONFIG;
    }
    /**
     * Creates a new call session in DynamoDB
     */
    async createSession(callSid, phoneNumber) {
        const session = (0, session_1.createCallSession)(callSid, phoneNumber, this.sessionConfig);
        const command = new client_dynamodb_1.PutItemCommand({
            TableName: this.tableName,
            Item: (0, util_dynamodb_1.marshall)(session, { removeUndefinedValues: true }),
            ConditionExpression: 'attribute_not_exists(sessionId)', // Prevent overwrites
        });
        try {
            await this.client.send(command);
            console.log(`Created session: ${session.sessionId} for call: ${callSid}`);
            return session;
        }
        catch (error) {
            console.error('Error creating session:', error);
            throw new Error(`Failed to create session: ${error}`);
        }
    }
    /**
     * Retrieves a session by session ID
     */
    async getSession(sessionId) {
        const command = new client_dynamodb_1.GetItemCommand({
            TableName: this.tableName,
            Key: (0, util_dynamodb_1.marshall)({ sessionId }),
        });
        try {
            const result = await this.client.send(command);
            if (!result.Item) {
                console.log(`Session not found: ${sessionId}`);
                return null;
            }
            const session = (0, util_dynamodb_1.unmarshall)(result.Item);
            if (!(0, session_1.validateCallSession)(session)) {
                console.error(`Invalid session data for: ${sessionId}`);
                return null;
            }
            return session;
        }
        catch (error) {
            console.error('Error retrieving session:', error);
            throw new Error(`Failed to retrieve session: ${error}`);
        }
    }
    /**
     * Retrieves a session by Twilio Call SID
     */
    async getSessionByCallSid(callSid) {
        // Note: This requires a GSI on callSid for efficient querying
        // For now, we'll use a scan operation (not ideal for production)
        const command = new client_dynamodb_1.ScanCommand({
            TableName: this.tableName,
            FilterExpression: 'callSid = :callSid',
            ExpressionAttributeValues: (0, util_dynamodb_1.marshall)({
                ':callSid': callSid,
            }, { removeUndefinedValues: true }),
        });
        try {
            const result = await this.client.send(command);
            if (!result.Items || result.Items.length === 0) {
                console.log(`Session not found for call: ${callSid}`);
                return null;
            }
            const session = (0, util_dynamodb_1.unmarshall)(result.Items[0]);
            if (!(0, session_1.validateCallSession)(session)) {
                console.error(`Invalid session data for call: ${callSid}`);
                return null;
            }
            return session;
        }
        catch (error) {
            console.error('Error retrieving session by call SID:', error);
            throw new Error(`Failed to retrieve session by call SID: ${error}`);
        }
    }
    /**
     * Updates session status and metadata
     */
    async updateSessionStatus(sessionId, status, endTime, errorInfo) {
        const updateExpression = ['SET #status = :status, lastActivity = :lastActivity'];
        const expressionAttributeNames = {
            '#status': 'status',
        };
        const expressionAttributeValues = {
            ':status': status,
            ':lastActivity': Date.now(),
        };
        if (endTime) {
            updateExpression.push('endTime = :endTime');
            expressionAttributeValues[':endTime'] = endTime;
        }
        if (errorInfo) {
            updateExpression.push('errorInfo = :errorInfo');
            expressionAttributeValues[':errorInfo'] = {
                ...errorInfo,
                timestamp: Date.now(),
            };
        }
        const command = new client_dynamodb_1.UpdateItemCommand({
            TableName: this.tableName,
            Key: (0, util_dynamodb_1.marshall)({ sessionId }),
            UpdateExpression: updateExpression.join(', '),
            ExpressionAttributeNames: expressionAttributeNames,
            ExpressionAttributeValues: (0, util_dynamodb_1.marshall)(expressionAttributeValues, { removeUndefinedValues: true }),
            ConditionExpression: 'attribute_exists(sessionId)', // Ensure session exists
        });
        try {
            await this.client.send(command);
            console.log(`Updated session status: ${sessionId} -> ${status}`);
        }
        catch (error) {
            console.error('Error updating session status:', error);
            throw new Error(`Failed to update session status: ${error}`);
        }
    }
    /**
     * Appends a conversation entry to the session history using atomic update
     */
    async appendConversationEntry(sessionId, entry) {
        const command = new client_dynamodb_1.UpdateItemCommand({
            TableName: this.tableName,
            Key: (0, util_dynamodb_1.marshall)({ sessionId }),
            UpdateExpression: 'SET conversationHistory = list_append(if_not_exists(conversationHistory, :empty_list), :new_entry), lastActivity = :lastActivity',
            ExpressionAttributeValues: (0, util_dynamodb_1.marshall)({
                ':new_entry': [entry],
                ':empty_list': [],
                ':lastActivity': Date.now(),
            }, { removeUndefinedValues: true }),
            ConditionExpression: 'attribute_exists(sessionId)', // Ensure session exists
        });
        try {
            await this.client.send(command);
            console.log(`Added conversation entry to session: ${sessionId}, type: ${entry.type}`);
        }
        catch (error) {
            console.error('Error appending conversation entry:', error);
            throw new Error(`Failed to append conversation entry: ${error}`);
        }
    }
    /**
     * Adds a user message to the conversation
     */
    async addUserMessage(sessionId, text, audioUrl, confidence) {
        const entry = (0, session_1.createConversationEntry)('user', text, audioUrl, confidence);
        await this.appendConversationEntry(sessionId, entry);
    }
    /**
     * Adds an AI response to the conversation
     */
    async addAiResponse(sessionId, text, audioUrl, processingDuration) {
        const entry = (0, session_1.createConversationEntry)('ai', text, audioUrl);
        if (processingDuration) {
            entry.processingDuration = processingDuration;
        }
        await this.appendConversationEntry(sessionId, entry);
    }
    /**
     * Updates a conversation entry with audio URL
     */
    async updateConversationEntryWithAudio(sessionId, entryIndex, audioUrl) {
        const command = new client_dynamodb_1.UpdateItemCommand({
            TableName: this.tableName,
            Key: (0, util_dynamodb_1.marshall)({ sessionId }),
            UpdateExpression: `SET conversationHistory[${entryIndex}].audioUrl = :audioUrl, lastActivity = :lastActivity`,
            ExpressionAttributeValues: (0, util_dynamodb_1.marshall)({
                ':audioUrl': audioUrl,
                ':lastActivity': Date.now(),
            }, { removeUndefinedValues: true }),
            ConditionExpression: 'attribute_exists(sessionId)',
        });
        try {
            await this.client.send(command);
            console.log(`Updated conversation entry ${entryIndex} with audio URL for session: ${sessionId}`);
        }
        catch (error) {
            console.error('Error updating conversation entry with audio:', error);
            throw new Error(`Failed to update conversation entry with audio: ${error}`);
        }
    }
    /**
     * Adds a system message to the conversation
     */
    async addSystemMessage(sessionId, text) {
        const entry = (0, session_1.createConversationEntry)('system', text);
        await this.appendConversationEntry(sessionId, entry);
    }
    /**
     * Updates the total call duration
     */
    async updateCallDuration(sessionId, durationSeconds) {
        const command = new client_dynamodb_1.UpdateItemCommand({
            TableName: this.tableName,
            Key: (0, util_dynamodb_1.marshall)({ sessionId }),
            UpdateExpression: 'SET totalDuration = :duration, lastActivity = :lastActivity',
            ExpressionAttributeValues: (0, util_dynamodb_1.marshall)({
                ':duration': durationSeconds,
                ':lastActivity': Date.now(),
            }, { removeUndefinedValues: true }),
            ConditionExpression: 'attribute_exists(sessionId)',
        });
        try {
            await this.client.send(command);
            console.log(`Updated call duration: ${sessionId} -> ${durationSeconds}s`);
        }
        catch (error) {
            console.error('Error updating call duration:', error);
            throw new Error(`Failed to update call duration: ${error}`);
        }
    }
    /**
     * Deletes a session (for cleanup or testing)
     */
    async deleteSession(sessionId) {
        const command = new client_dynamodb_1.DeleteItemCommand({
            TableName: this.tableName,
            Key: (0, util_dynamodb_1.marshall)({ sessionId }),
        });
        try {
            await this.client.send(command);
            console.log(`Deleted session: ${sessionId}`);
        }
        catch (error) {
            console.error('Error deleting session:', error);
            throw new Error(`Failed to delete session: ${error}`);
        }
    }
    /**
     * Lists active sessions (for monitoring/debugging)
     */
    async listActiveSessions(limit = 50) {
        const command = new client_dynamodb_1.ScanCommand({
            TableName: this.tableName,
            FilterExpression: '#status = :status',
            ExpressionAttributeNames: {
                '#status': 'status',
            },
            ExpressionAttributeValues: (0, util_dynamodb_1.marshall)({
                ':status': 'active',
            }, { removeUndefinedValues: true }),
            Limit: limit,
        });
        try {
            const result = await this.client.send(command);
            if (!result.Items) {
                return [];
            }
            const sessions = result.Items
                .map(item => (0, util_dynamodb_1.unmarshall)(item))
                .filter(session => (0, session_1.validateCallSession)(session));
            return sessions;
        }
        catch (error) {
            console.error('Error listing active sessions:', error);
            throw new Error(`Failed to list active sessions: ${error}`);
        }
    }
    /**
     * Gets conversation history for a session
     */
    async getConversationHistory(sessionId) {
        const session = await this.getSession(sessionId);
        return session?.conversationHistory || [];
    }
    /**
     * Builds conversation context string for AI processing
     */
    async buildConversationContext(sessionId, maxEntries = 10) {
        const history = await this.getConversationHistory(sessionId);
        // Get the most recent entries
        const recentHistory = history.slice(-maxEntries);
        // Build context string
        const contextLines = recentHistory.map(entry => {
            const speaker = entry.type === 'user' ? 'User' : entry.type === 'ai' ? 'Assistant' : 'System';
            return `${speaker}: ${entry.text}`;
        });
        return contextLines.join('\n');
    }
    /**
     * Health check method to verify DynamoDB connectivity
     */
    async healthCheck() {
        try {
            // Try to scan the table with a limit of 1 to test connectivity
            const command = new client_dynamodb_1.ScanCommand({
                TableName: this.tableName,
                Limit: 1,
            });
            await this.client.send(command);
            return true;
        }
        catch (error) {
            console.error('DynamoDB health check failed:', error);
            return false;
        }
    }
}
exports.DynamoSessionManager = DynamoSessionManager;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHluYW1vLXNlc3Npb24tbWFuYWdlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9zZXJ2aWNlcy9keW5hbW8tc2Vzc2lvbi1tYW5hZ2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7O0dBR0c7OztBQUVILDhEQVFrQztBQUNsQywwREFBOEQ7QUFDOUQsOENBUzBCO0FBUTFCLE1BQWEsb0JBQW9CO0lBSy9CLFlBQVksTUFBa0M7UUFDNUMsSUFBSSxDQUFDLE1BQU0sR0FBRyxJQUFJLGdDQUFjLENBQUM7WUFDL0IsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLElBQUksT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLElBQUksV0FBVztTQUMvRCxDQUFDLENBQUM7UUFDSCxJQUFJLENBQUMsU0FBUyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUM7UUFDbEMsSUFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNLENBQUMsYUFBYSxJQUFJLGdDQUFzQixDQUFDO0lBQ3RFLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxhQUFhLENBQUMsT0FBZSxFQUFFLFdBQW1CO1FBQ3RELE1BQU0sT0FBTyxHQUFHLElBQUEsMkJBQWlCLEVBQUMsT0FBTyxFQUFFLFdBQVcsRUFBRSxJQUFJLENBQUMsYUFBYSxDQUFDLENBQUM7UUFFNUUsTUFBTSxPQUFPLEdBQUcsSUFBSSxnQ0FBYyxDQUFDO1lBQ2pDLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztZQUN6QixJQUFJLEVBQUUsSUFBQSx3QkFBUSxFQUFDLE9BQU8sRUFBRSxFQUFFLHFCQUFxQixFQUFFLElBQUksRUFBRSxDQUFDO1lBQ3hELG1CQUFtQixFQUFFLGlDQUFpQyxFQUFFLHFCQUFxQjtTQUM5RSxDQUFDLENBQUM7UUFFSCxJQUFJLENBQUM7WUFDSCxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2hDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLE9BQU8sQ0FBQyxTQUFTLGNBQWMsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUMxRSxPQUFPLE9BQU8sQ0FBQztRQUNqQixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMseUJBQXlCLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDaEQsTUFBTSxJQUFJLEtBQUssQ0FBQyw2QkFBNkIsS0FBSyxFQUFFLENBQUMsQ0FBQztRQUN4RCxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLFVBQVUsQ0FBQyxTQUFpQjtRQUNoQyxNQUFNLE9BQU8sR0FBRyxJQUFJLGdDQUFjLENBQUM7WUFDakMsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO1lBQ3pCLEdBQUcsRUFBRSxJQUFBLHdCQUFRLEVBQUMsRUFBRSxTQUFTLEVBQUUsQ0FBQztTQUM3QixDQUFDLENBQUM7UUFFSCxJQUFJLENBQUM7WUFDSCxNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBRS9DLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLENBQUM7Z0JBQ2pCLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLFNBQVMsRUFBRSxDQUFDLENBQUM7Z0JBQy9DLE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztZQUVELE1BQU0sT0FBTyxHQUFHLElBQUEsMEJBQVUsRUFBQyxNQUFNLENBQUMsSUFBSSxDQUFnQixDQUFDO1lBRXZELElBQUksQ0FBQyxJQUFBLDZCQUFtQixFQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7Z0JBQ2xDLE9BQU8sQ0FBQyxLQUFLLENBQUMsNkJBQTZCLFNBQVMsRUFBRSxDQUFDLENBQUM7Z0JBQ3hELE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztZQUVELE9BQU8sT0FBTyxDQUFDO1FBQ2pCLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQywyQkFBMkIsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNsRCxNQUFNLElBQUksS0FBSyxDQUFDLCtCQUErQixLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBQzFELENBQUM7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsbUJBQW1CLENBQUMsT0FBZTtRQUN2Qyw4REFBOEQ7UUFDOUQsaUVBQWlFO1FBQ2pFLE1BQU0sT0FBTyxHQUFHLElBQUksNkJBQVcsQ0FBQztZQUM5QixTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7WUFDekIsZ0JBQWdCLEVBQUUsb0JBQW9CO1lBQ3RDLHlCQUF5QixFQUFFLElBQUEsd0JBQVEsRUFBQztnQkFDbEMsVUFBVSxFQUFFLE9BQU87YUFDcEIsRUFBRSxFQUFFLHFCQUFxQixFQUFFLElBQUksRUFBRSxDQUFDO1NBQ3BDLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQztZQUNILE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFL0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLElBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFLENBQUM7Z0JBQy9DLE9BQU8sQ0FBQyxHQUFHLENBQUMsK0JBQStCLE9BQU8sRUFBRSxDQUFDLENBQUM7Z0JBQ3RELE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztZQUVELE1BQU0sT0FBTyxHQUFHLElBQUEsMEJBQVUsRUFBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFnQixDQUFDO1lBRTNELElBQUksQ0FBQyxJQUFBLDZCQUFtQixFQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUM7Z0JBQ2xDLE9BQU8sQ0FBQyxLQUFLLENBQUMsa0NBQWtDLE9BQU8sRUFBRSxDQUFDLENBQUM7Z0JBQzNELE9BQU8sSUFBSSxDQUFDO1lBQ2QsQ0FBQztZQUVELE9BQU8sT0FBTyxDQUFDO1FBQ2pCLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyx1Q0FBdUMsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUM5RCxNQUFNLElBQUksS0FBSyxDQUFDLDJDQUEyQyxLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBQ3RFLENBQUM7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsbUJBQW1CLENBQ3ZCLFNBQWlCLEVBQ2pCLE1BQXFCLEVBQ3JCLE9BQWdCLEVBQ2hCLFNBQTZDO1FBRTdDLE1BQU0sZ0JBQWdCLEdBQUcsQ0FBQyxxREFBcUQsQ0FBQyxDQUFDO1FBQ2pGLE1BQU0sd0JBQXdCLEdBQTJCO1lBQ3ZELFNBQVMsRUFBRSxRQUFRO1NBQ3BCLENBQUM7UUFDRixNQUFNLHlCQUF5QixHQUF3QjtZQUNyRCxTQUFTLEVBQUUsTUFBTTtZQUNqQixlQUFlLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRTtTQUM1QixDQUFDO1FBRUYsSUFBSSxPQUFPLEVBQUUsQ0FBQztZQUNaLGdCQUFnQixDQUFDLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO1lBQzVDLHlCQUF5QixDQUFDLFVBQVUsQ0FBQyxHQUFHLE9BQU8sQ0FBQztRQUNsRCxDQUFDO1FBRUQsSUFBSSxTQUFTLEVBQUUsQ0FBQztZQUNkLGdCQUFnQixDQUFDLElBQUksQ0FBQyx3QkFBd0IsQ0FBQyxDQUFDO1lBQ2hELHlCQUF5QixDQUFDLFlBQVksQ0FBQyxHQUFHO2dCQUN4QyxHQUFHLFNBQVM7Z0JBQ1osU0FBUyxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUU7YUFDdEIsQ0FBQztRQUNKLENBQUM7UUFFRCxNQUFNLE9BQU8sR0FBRyxJQUFJLG1DQUFpQixDQUFDO1lBQ3BDLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztZQUN6QixHQUFHLEVBQUUsSUFBQSx3QkFBUSxFQUFDLEVBQUUsU0FBUyxFQUFFLENBQUM7WUFDNUIsZ0JBQWdCLEVBQUUsZ0JBQWdCLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztZQUM3Qyx3QkFBd0IsRUFBRSx3QkFBd0I7WUFDbEQseUJBQXlCLEVBQUUsSUFBQSx3QkFBUSxFQUFDLHlCQUF5QixFQUFFLEVBQUUscUJBQXFCLEVBQUUsSUFBSSxFQUFFLENBQUM7WUFDL0YsbUJBQW1CLEVBQUUsNkJBQTZCLEVBQUUsd0JBQXdCO1NBQzdFLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQztZQUNILE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDaEMsT0FBTyxDQUFDLEdBQUcsQ0FBQywyQkFBMkIsU0FBUyxPQUFPLE1BQU0sRUFBRSxDQUFDLENBQUM7UUFDbkUsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGdDQUFnQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3ZELE1BQU0sSUFBSSxLQUFLLENBQUMsb0NBQW9DLEtBQUssRUFBRSxDQUFDLENBQUM7UUFDL0QsQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyx1QkFBdUIsQ0FDM0IsU0FBaUIsRUFDakIsS0FBd0I7UUFFeEIsTUFBTSxPQUFPLEdBQUcsSUFBSSxtQ0FBaUIsQ0FBQztZQUNwQyxTQUFTLEVBQUUsSUFBSSxDQUFDLFNBQVM7WUFDekIsR0FBRyxFQUFFLElBQUEsd0JBQVEsRUFBQyxFQUFFLFNBQVMsRUFBRSxDQUFDO1lBQzVCLGdCQUFnQixFQUFFLGtJQUFrSTtZQUNwSix5QkFBeUIsRUFBRSxJQUFBLHdCQUFRLEVBQUM7Z0JBQ2xDLFlBQVksRUFBRSxDQUFDLEtBQUssQ0FBQztnQkFDckIsYUFBYSxFQUFFLEVBQUU7Z0JBQ2pCLGVBQWUsRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFO2FBQzVCLEVBQUUsRUFBRSxxQkFBcUIsRUFBRSxJQUFJLEVBQUUsQ0FBQztZQUNuQyxtQkFBbUIsRUFBRSw2QkFBNkIsRUFBRSx3QkFBd0I7U0FDN0UsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDO1lBQ0gsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNoQyxPQUFPLENBQUMsR0FBRyxDQUFDLHdDQUF3QyxTQUFTLFdBQVcsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUM7UUFDeEYsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLHFDQUFxQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQzVELE1BQU0sSUFBSSxLQUFLLENBQUMsd0NBQXdDLEtBQUssRUFBRSxDQUFDLENBQUM7UUFDbkUsQ0FBQztJQUNILENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxjQUFjLENBQ2xCLFNBQWlCLEVBQ2pCLElBQVksRUFDWixRQUFpQixFQUNqQixVQUFtQjtRQUVuQixNQUFNLEtBQUssR0FBRyxJQUFBLGlDQUF1QixFQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBQzFFLE1BQU0sSUFBSSxDQUFDLHVCQUF1QixDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsYUFBYSxDQUNqQixTQUFpQixFQUNqQixJQUFZLEVBQ1osUUFBaUIsRUFDakIsa0JBQTJCO1FBRTNCLE1BQU0sS0FBSyxHQUFHLElBQUEsaUNBQXVCLEVBQUMsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLENBQUMsQ0FBQztRQUM1RCxJQUFJLGtCQUFrQixFQUFFLENBQUM7WUFDdkIsS0FBSyxDQUFDLGtCQUFrQixHQUFHLGtCQUFrQixDQUFDO1FBQ2hELENBQUM7UUFDRCxNQUFNLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDLENBQUM7SUFDdkQsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGdDQUFnQyxDQUNwQyxTQUFpQixFQUNqQixVQUFrQixFQUNsQixRQUFnQjtRQUVoQixNQUFNLE9BQU8sR0FBRyxJQUFJLG1DQUFpQixDQUFDO1lBQ3BDLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztZQUN6QixHQUFHLEVBQUUsSUFBQSx3QkFBUSxFQUFDLEVBQUUsU0FBUyxFQUFFLENBQUM7WUFDNUIsZ0JBQWdCLEVBQUUsMkJBQTJCLFVBQVUsc0RBQXNEO1lBQzdHLHlCQUF5QixFQUFFLElBQUEsd0JBQVEsRUFBQztnQkFDbEMsV0FBVyxFQUFFLFFBQVE7Z0JBQ3JCLGVBQWUsRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFO2FBQzVCLEVBQUUsRUFBRSxxQkFBcUIsRUFBRSxJQUFJLEVBQUUsQ0FBQztZQUNuQyxtQkFBbUIsRUFBRSw2QkFBNkI7U0FDbkQsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDO1lBQ0gsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNoQyxPQUFPLENBQUMsR0FBRyxDQUFDLDhCQUE4QixVQUFVLGdDQUFnQyxTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQ25HLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQywrQ0FBK0MsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUN0RSxNQUFNLElBQUksS0FBSyxDQUFDLG1EQUFtRCxLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBQzlFLENBQUM7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsZ0JBQWdCLENBQUMsU0FBaUIsRUFBRSxJQUFZO1FBQ3BELE1BQU0sS0FBSyxHQUFHLElBQUEsaUNBQXVCLEVBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ3RELE1BQU0sSUFBSSxDQUFDLHVCQUF1QixDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUMsQ0FBQztJQUN2RCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsa0JBQWtCLENBQUMsU0FBaUIsRUFBRSxlQUF1QjtRQUNqRSxNQUFNLE9BQU8sR0FBRyxJQUFJLG1DQUFpQixDQUFDO1lBQ3BDLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztZQUN6QixHQUFHLEVBQUUsSUFBQSx3QkFBUSxFQUFDLEVBQUUsU0FBUyxFQUFFLENBQUM7WUFDNUIsZ0JBQWdCLEVBQUUsNkRBQTZEO1lBQy9FLHlCQUF5QixFQUFFLElBQUEsd0JBQVEsRUFBQztnQkFDbEMsV0FBVyxFQUFFLGVBQWU7Z0JBQzVCLGVBQWUsRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFO2FBQzVCLEVBQUUsRUFBRSxxQkFBcUIsRUFBRSxJQUFJLEVBQUUsQ0FBQztZQUNuQyxtQkFBbUIsRUFBRSw2QkFBNkI7U0FDbkQsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDO1lBQ0gsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNoQyxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixTQUFTLE9BQU8sZUFBZSxHQUFHLENBQUMsQ0FBQztRQUM1RSxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsK0JBQStCLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDdEQsTUFBTSxJQUFJLEtBQUssQ0FBQyxtQ0FBbUMsS0FBSyxFQUFFLENBQUMsQ0FBQztRQUM5RCxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGFBQWEsQ0FBQyxTQUFpQjtRQUNuQyxNQUFNLE9BQU8sR0FBRyxJQUFJLG1DQUFpQixDQUFDO1lBQ3BDLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztZQUN6QixHQUFHLEVBQUUsSUFBQSx3QkFBUSxFQUFDLEVBQUUsU0FBUyxFQUFFLENBQUM7U0FDN0IsQ0FBQyxDQUFDO1FBRUgsSUFBSSxDQUFDO1lBQ0gsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUNoQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9CQUFvQixTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQy9DLENBQUM7UUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1lBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQyx5QkFBeUIsRUFBRSxLQUFLLENBQUMsQ0FBQztZQUNoRCxNQUFNLElBQUksS0FBSyxDQUFDLDZCQUE2QixLQUFLLEVBQUUsQ0FBQyxDQUFDO1FBQ3hELENBQUM7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsa0JBQWtCLENBQUMsUUFBZ0IsRUFBRTtRQUN6QyxNQUFNLE9BQU8sR0FBRyxJQUFJLDZCQUFXLENBQUM7WUFDOUIsU0FBUyxFQUFFLElBQUksQ0FBQyxTQUFTO1lBQ3pCLGdCQUFnQixFQUFFLG1CQUFtQjtZQUNyQyx3QkFBd0IsRUFBRTtnQkFDeEIsU0FBUyxFQUFFLFFBQVE7YUFDcEI7WUFDRCx5QkFBeUIsRUFBRSxJQUFBLHdCQUFRLEVBQUM7Z0JBQ2xDLFNBQVMsRUFBRSxRQUFRO2FBQ3BCLEVBQUUsRUFBRSxxQkFBcUIsRUFBRSxJQUFJLEVBQUUsQ0FBQztZQUNuQyxLQUFLLEVBQUUsS0FBSztTQUNiLENBQUMsQ0FBQztRQUVILElBQUksQ0FBQztZQUNILE1BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7WUFFL0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQztnQkFDbEIsT0FBTyxFQUFFLENBQUM7WUFDWixDQUFDO1lBRUQsTUFBTSxRQUFRLEdBQUcsTUFBTSxDQUFDLEtBQUs7aUJBQzFCLEdBQUcsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLElBQUEsMEJBQVUsRUFBQyxJQUFJLENBQWdCLENBQUM7aUJBQzVDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLElBQUEsNkJBQW1CLEVBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQztZQUVuRCxPQUFPLFFBQVEsQ0FBQztRQUNsQixDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsZ0NBQWdDLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDdkQsTUFBTSxJQUFJLEtBQUssQ0FBQyxtQ0FBbUMsS0FBSyxFQUFFLENBQUMsQ0FBQztRQUM5RCxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLHNCQUFzQixDQUFDLFNBQWlCO1FBQzVDLE1BQU0sT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNqRCxPQUFPLE9BQU8sRUFBRSxtQkFBbUIsSUFBSSxFQUFFLENBQUM7SUFDNUMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLHdCQUF3QixDQUFDLFNBQWlCLEVBQUUsYUFBcUIsRUFBRTtRQUN2RSxNQUFNLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUU3RCw4QkFBOEI7UUFDOUIsTUFBTSxhQUFhLEdBQUcsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDLFVBQVUsQ0FBQyxDQUFDO1FBRWpELHVCQUF1QjtRQUN2QixNQUFNLFlBQVksR0FBRyxhQUFhLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxFQUFFO1lBQzdDLE1BQU0sT0FBTyxHQUFHLEtBQUssQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztZQUM5RixPQUFPLEdBQUcsT0FBTyxLQUFLLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQztRQUNyQyxDQUFDLENBQUMsQ0FBQztRQUVILE9BQU8sWUFBWSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNqQyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsV0FBVztRQUNmLElBQUksQ0FBQztZQUNILCtEQUErRDtZQUMvRCxNQUFNLE9BQU8sR0FBRyxJQUFJLDZCQUFXLENBQUM7Z0JBQzlCLFNBQVMsRUFBRSxJQUFJLENBQUMsU0FBUztnQkFDekIsS0FBSyxFQUFFLENBQUM7YUFDVCxDQUFDLENBQUM7WUFFSCxNQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1lBQ2hDLE9BQU8sSUFBSSxDQUFDO1FBQ2QsQ0FBQztRQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7WUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLCtCQUErQixFQUFFLEtBQUssQ0FBQyxDQUFDO1lBQ3RELE9BQU8sS0FBSyxDQUFDO1FBQ2YsQ0FBQztJQUNILENBQUM7Q0FDRjtBQTVXRCxvREE0V0MiLCJzb3VyY2VzQ29udGVudCI6WyIvKipcbiAqIER5bmFtb0RCIFNlc3Npb24gTWFuYWdlciBmb3IgUHJvbXB0Q2FsbCBBSSBNVlBcbiAqIEhhbmRsZXMgQ1JVRCBvcGVyYXRpb25zIGZvciBjYWxsIHNlc3Npb25zIHdpdGggY29udmVyc2F0aW9uIGhpc3RvcnlcbiAqL1xuXG5pbXBvcnQge1xuICBEeW5hbW9EQkNsaWVudCxcbiAgR2V0SXRlbUNvbW1hbmQsXG4gIFB1dEl0ZW1Db21tYW5kLFxuICBVcGRhdGVJdGVtQ29tbWFuZCxcbiAgRGVsZXRlSXRlbUNvbW1hbmQsXG4gIFF1ZXJ5Q29tbWFuZCxcbiAgU2NhbkNvbW1hbmQsXG59IGZyb20gJ0Bhd3Mtc2RrL2NsaWVudC1keW5hbW9kYic7XG5pbXBvcnQgeyBtYXJzaGFsbCwgdW5tYXJzaGFsbCB9IGZyb20gJ0Bhd3Mtc2RrL3V0aWwtZHluYW1vZGInO1xuaW1wb3J0IHtcbiAgQ2FsbFNlc3Npb24sXG4gIENvbnZlcnNhdGlvbkVudHJ5LFxuICBTZXNzaW9uU3RhdHVzLFxuICB2YWxpZGF0ZUNhbGxTZXNzaW9uLFxuICBjcmVhdGVDYWxsU2Vzc2lvbixcbiAgY3JlYXRlQ29udmVyc2F0aW9uRW50cnksXG4gIFNlc3Npb25Db25maWcsXG4gIERFRkFVTFRfU0VTU0lPTl9DT05GSUcsXG59IGZyb20gJy4uL3R5cGVzL3Nlc3Npb24nO1xuXG5leHBvcnQgaW50ZXJmYWNlIER5bmFtb1Nlc3Npb25NYW5hZ2VyQ29uZmlnIHtcbiAgdGFibGVOYW1lOiBzdHJpbmc7XG4gIHJlZ2lvbj86IHN0cmluZztcbiAgc2Vzc2lvbkNvbmZpZz86IFNlc3Npb25Db25maWc7XG59XG5cbmV4cG9ydCBjbGFzcyBEeW5hbW9TZXNzaW9uTWFuYWdlciB7XG4gIHByaXZhdGUgY2xpZW50OiBEeW5hbW9EQkNsaWVudDtcbiAgcHJpdmF0ZSB0YWJsZU5hbWU6IHN0cmluZztcbiAgcHJpdmF0ZSBzZXNzaW9uQ29uZmlnOiBTZXNzaW9uQ29uZmlnO1xuXG4gIGNvbnN0cnVjdG9yKGNvbmZpZzogRHluYW1vU2Vzc2lvbk1hbmFnZXJDb25maWcpIHtcbiAgICB0aGlzLmNsaWVudCA9IG5ldyBEeW5hbW9EQkNsaWVudCh7XG4gICAgICByZWdpb246IGNvbmZpZy5yZWdpb24gfHwgcHJvY2Vzcy5lbnYuQVdTX1JFR0lPTiB8fCAndXMtZWFzdC0xJyxcbiAgICB9KTtcbiAgICB0aGlzLnRhYmxlTmFtZSA9IGNvbmZpZy50YWJsZU5hbWU7XG4gICAgdGhpcy5zZXNzaW9uQ29uZmlnID0gY29uZmlnLnNlc3Npb25Db25maWcgfHwgREVGQVVMVF9TRVNTSU9OX0NPTkZJRztcbiAgfVxuXG4gIC8qKlxuICAgKiBDcmVhdGVzIGEgbmV3IGNhbGwgc2Vzc2lvbiBpbiBEeW5hbW9EQlxuICAgKi9cbiAgYXN5bmMgY3JlYXRlU2Vzc2lvbihjYWxsU2lkOiBzdHJpbmcsIHBob25lTnVtYmVyOiBzdHJpbmcpOiBQcm9taXNlPENhbGxTZXNzaW9uPiB7XG4gICAgY29uc3Qgc2Vzc2lvbiA9IGNyZWF0ZUNhbGxTZXNzaW9uKGNhbGxTaWQsIHBob25lTnVtYmVyLCB0aGlzLnNlc3Npb25Db25maWcpO1xuXG4gICAgY29uc3QgY29tbWFuZCA9IG5ldyBQdXRJdGVtQ29tbWFuZCh7XG4gICAgICBUYWJsZU5hbWU6IHRoaXMudGFibGVOYW1lLFxuICAgICAgSXRlbTogbWFyc2hhbGwoc2Vzc2lvbiwgeyByZW1vdmVVbmRlZmluZWRWYWx1ZXM6IHRydWUgfSksXG4gICAgICBDb25kaXRpb25FeHByZXNzaW9uOiAnYXR0cmlidXRlX25vdF9leGlzdHMoc2Vzc2lvbklkKScsIC8vIFByZXZlbnQgb3ZlcndyaXRlc1xuICAgIH0pO1xuXG4gICAgdHJ5IHtcbiAgICAgIGF3YWl0IHRoaXMuY2xpZW50LnNlbmQoY29tbWFuZCk7XG4gICAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBzZXNzaW9uOiAke3Nlc3Npb24uc2Vzc2lvbklkfSBmb3IgY2FsbDogJHtjYWxsU2lkfWApO1xuICAgICAgcmV0dXJuIHNlc3Npb247XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGNyZWF0aW5nIHNlc3Npb246JywgZXJyb3IpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gY3JlYXRlIHNlc3Npb246ICR7ZXJyb3J9YCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFJldHJpZXZlcyBhIHNlc3Npb24gYnkgc2Vzc2lvbiBJRFxuICAgKi9cbiAgYXN5bmMgZ2V0U2Vzc2lvbihzZXNzaW9uSWQ6IHN0cmluZyk6IFByb21pc2U8Q2FsbFNlc3Npb24gfCBudWxsPiB7XG4gICAgY29uc3QgY29tbWFuZCA9IG5ldyBHZXRJdGVtQ29tbWFuZCh7XG4gICAgICBUYWJsZU5hbWU6IHRoaXMudGFibGVOYW1lLFxuICAgICAgS2V5OiBtYXJzaGFsbCh7IHNlc3Npb25JZCB9KSxcbiAgICB9KTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLmNsaWVudC5zZW5kKGNvbW1hbmQpO1xuXG4gICAgICBpZiAoIXJlc3VsdC5JdGVtKSB7XG4gICAgICAgIGNvbnNvbGUubG9nKGBTZXNzaW9uIG5vdCBmb3VuZDogJHtzZXNzaW9uSWR9YCk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBzZXNzaW9uID0gdW5tYXJzaGFsbChyZXN1bHQuSXRlbSkgYXMgQ2FsbFNlc3Npb247XG5cbiAgICAgIGlmICghdmFsaWRhdGVDYWxsU2Vzc2lvbihzZXNzaW9uKSkge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBJbnZhbGlkIHNlc3Npb24gZGF0YSBmb3I6ICR7c2Vzc2lvbklkfWApO1xuICAgICAgICByZXR1cm4gbnVsbDtcbiAgICAgIH1cblxuICAgICAgcmV0dXJuIHNlc3Npb247XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHJldHJpZXZpbmcgc2Vzc2lvbjonLCBlcnJvcik7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byByZXRyaWV2ZSBzZXNzaW9uOiAke2Vycm9yfWApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBSZXRyaWV2ZXMgYSBzZXNzaW9uIGJ5IFR3aWxpbyBDYWxsIFNJRFxuICAgKi9cbiAgYXN5bmMgZ2V0U2Vzc2lvbkJ5Q2FsbFNpZChjYWxsU2lkOiBzdHJpbmcpOiBQcm9taXNlPENhbGxTZXNzaW9uIHwgbnVsbD4ge1xuICAgIC8vIE5vdGU6IFRoaXMgcmVxdWlyZXMgYSBHU0kgb24gY2FsbFNpZCBmb3IgZWZmaWNpZW50IHF1ZXJ5aW5nXG4gICAgLy8gRm9yIG5vdywgd2UnbGwgdXNlIGEgc2NhbiBvcGVyYXRpb24gKG5vdCBpZGVhbCBmb3IgcHJvZHVjdGlvbilcbiAgICBjb25zdCBjb21tYW5kID0gbmV3IFNjYW5Db21tYW5kKHtcbiAgICAgIFRhYmxlTmFtZTogdGhpcy50YWJsZU5hbWUsXG4gICAgICBGaWx0ZXJFeHByZXNzaW9uOiAnY2FsbFNpZCA9IDpjYWxsU2lkJyxcbiAgICAgIEV4cHJlc3Npb25BdHRyaWJ1dGVWYWx1ZXM6IG1hcnNoYWxsKHtcbiAgICAgICAgJzpjYWxsU2lkJzogY2FsbFNpZCxcbiAgICAgIH0sIHsgcmVtb3ZlVW5kZWZpbmVkVmFsdWVzOiB0cnVlIH0pLFxuICAgIH0pO1xuXG4gICAgdHJ5IHtcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IHRoaXMuY2xpZW50LnNlbmQoY29tbWFuZCk7XG5cbiAgICAgIGlmICghcmVzdWx0Lkl0ZW1zIHx8IHJlc3VsdC5JdGVtcy5sZW5ndGggPT09IDApIHtcbiAgICAgICAgY29uc29sZS5sb2coYFNlc3Npb24gbm90IGZvdW5kIGZvciBjYWxsOiAke2NhbGxTaWR9YCk7XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgICAgfVxuXG4gICAgICBjb25zdCBzZXNzaW9uID0gdW5tYXJzaGFsbChyZXN1bHQuSXRlbXNbMF0pIGFzIENhbGxTZXNzaW9uO1xuXG4gICAgICBpZiAoIXZhbGlkYXRlQ2FsbFNlc3Npb24oc2Vzc2lvbikpIHtcbiAgICAgICAgY29uc29sZS5lcnJvcihgSW52YWxpZCBzZXNzaW9uIGRhdGEgZm9yIGNhbGw6ICR7Y2FsbFNpZH1gKTtcbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgICB9XG5cbiAgICAgIHJldHVybiBzZXNzaW9uO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciByZXRyaWV2aW5nIHNlc3Npb24gYnkgY2FsbCBTSUQ6JywgZXJyb3IpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gcmV0cmlldmUgc2Vzc2lvbiBieSBjYWxsIFNJRDogJHtlcnJvcn1gKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogVXBkYXRlcyBzZXNzaW9uIHN0YXR1cyBhbmQgbWV0YWRhdGFcbiAgICovXG4gIGFzeW5jIHVwZGF0ZVNlc3Npb25TdGF0dXMoXG4gICAgc2Vzc2lvbklkOiBzdHJpbmcsXG4gICAgc3RhdHVzOiBTZXNzaW9uU3RhdHVzLFxuICAgIGVuZFRpbWU/OiBudW1iZXIsXG4gICAgZXJyb3JJbmZvPzogeyBjb2RlOiBzdHJpbmc7IG1lc3NhZ2U6IHN0cmluZyB9XG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IHVwZGF0ZUV4cHJlc3Npb24gPSBbJ1NFVCAjc3RhdHVzID0gOnN0YXR1cywgbGFzdEFjdGl2aXR5ID0gOmxhc3RBY3Rpdml0eSddO1xuICAgIGNvbnN0IGV4cHJlc3Npb25BdHRyaWJ1dGVOYW1lczogUmVjb3JkPHN0cmluZywgc3RyaW5nPiA9IHtcbiAgICAgICcjc3RhdHVzJzogJ3N0YXR1cycsXG4gICAgfTtcbiAgICBjb25zdCBleHByZXNzaW9uQXR0cmlidXRlVmFsdWVzOiBSZWNvcmQ8c3RyaW5nLCBhbnk+ID0ge1xuICAgICAgJzpzdGF0dXMnOiBzdGF0dXMsXG4gICAgICAnOmxhc3RBY3Rpdml0eSc6IERhdGUubm93KCksXG4gICAgfTtcblxuICAgIGlmIChlbmRUaW1lKSB7XG4gICAgICB1cGRhdGVFeHByZXNzaW9uLnB1c2goJ2VuZFRpbWUgPSA6ZW5kVGltZScpO1xuICAgICAgZXhwcmVzc2lvbkF0dHJpYnV0ZVZhbHVlc1snOmVuZFRpbWUnXSA9IGVuZFRpbWU7XG4gICAgfVxuXG4gICAgaWYgKGVycm9ySW5mbykge1xuICAgICAgdXBkYXRlRXhwcmVzc2lvbi5wdXNoKCdlcnJvckluZm8gPSA6ZXJyb3JJbmZvJyk7XG4gICAgICBleHByZXNzaW9uQXR0cmlidXRlVmFsdWVzWyc6ZXJyb3JJbmZvJ10gPSB7XG4gICAgICAgIC4uLmVycm9ySW5mbyxcbiAgICAgICAgdGltZXN0YW1wOiBEYXRlLm5vdygpLFxuICAgICAgfTtcbiAgICB9XG5cbiAgICBjb25zdCBjb21tYW5kID0gbmV3IFVwZGF0ZUl0ZW1Db21tYW5kKHtcbiAgICAgIFRhYmxlTmFtZTogdGhpcy50YWJsZU5hbWUsXG4gICAgICBLZXk6IG1hcnNoYWxsKHsgc2Vzc2lvbklkIH0pLFxuICAgICAgVXBkYXRlRXhwcmVzc2lvbjogdXBkYXRlRXhwcmVzc2lvbi5qb2luKCcsICcpLFxuICAgICAgRXhwcmVzc2lvbkF0dHJpYnV0ZU5hbWVzOiBleHByZXNzaW9uQXR0cmlidXRlTmFtZXMsXG4gICAgICBFeHByZXNzaW9uQXR0cmlidXRlVmFsdWVzOiBtYXJzaGFsbChleHByZXNzaW9uQXR0cmlidXRlVmFsdWVzLCB7IHJlbW92ZVVuZGVmaW5lZFZhbHVlczogdHJ1ZSB9KSxcbiAgICAgIENvbmRpdGlvbkV4cHJlc3Npb246ICdhdHRyaWJ1dGVfZXhpc3RzKHNlc3Npb25JZCknLCAvLyBFbnN1cmUgc2Vzc2lvbiBleGlzdHNcbiAgICB9KTtcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmNsaWVudC5zZW5kKGNvbW1hbmQpO1xuICAgICAgY29uc29sZS5sb2coYFVwZGF0ZWQgc2Vzc2lvbiBzdGF0dXM6ICR7c2Vzc2lvbklkfSAtPiAke3N0YXR1c31gKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgdXBkYXRpbmcgc2Vzc2lvbiBzdGF0dXM6JywgZXJyb3IpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gdXBkYXRlIHNlc3Npb24gc3RhdHVzOiAke2Vycm9yfWApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBBcHBlbmRzIGEgY29udmVyc2F0aW9uIGVudHJ5IHRvIHRoZSBzZXNzaW9uIGhpc3RvcnkgdXNpbmcgYXRvbWljIHVwZGF0ZVxuICAgKi9cbiAgYXN5bmMgYXBwZW5kQ29udmVyc2F0aW9uRW50cnkoXG4gICAgc2Vzc2lvbklkOiBzdHJpbmcsXG4gICAgZW50cnk6IENvbnZlcnNhdGlvbkVudHJ5XG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGNvbW1hbmQgPSBuZXcgVXBkYXRlSXRlbUNvbW1hbmQoe1xuICAgICAgVGFibGVOYW1lOiB0aGlzLnRhYmxlTmFtZSxcbiAgICAgIEtleTogbWFyc2hhbGwoeyBzZXNzaW9uSWQgfSksXG4gICAgICBVcGRhdGVFeHByZXNzaW9uOiAnU0VUIGNvbnZlcnNhdGlvbkhpc3RvcnkgPSBsaXN0X2FwcGVuZChpZl9ub3RfZXhpc3RzKGNvbnZlcnNhdGlvbkhpc3RvcnksIDplbXB0eV9saXN0KSwgOm5ld19lbnRyeSksIGxhc3RBY3Rpdml0eSA9IDpsYXN0QWN0aXZpdHknLFxuICAgICAgRXhwcmVzc2lvbkF0dHJpYnV0ZVZhbHVlczogbWFyc2hhbGwoe1xuICAgICAgICAnOm5ld19lbnRyeSc6IFtlbnRyeV0sXG4gICAgICAgICc6ZW1wdHlfbGlzdCc6IFtdLFxuICAgICAgICAnOmxhc3RBY3Rpdml0eSc6IERhdGUubm93KCksXG4gICAgICB9LCB7IHJlbW92ZVVuZGVmaW5lZFZhbHVlczogdHJ1ZSB9KSxcbiAgICAgIENvbmRpdGlvbkV4cHJlc3Npb246ICdhdHRyaWJ1dGVfZXhpc3RzKHNlc3Npb25JZCknLCAvLyBFbnN1cmUgc2Vzc2lvbiBleGlzdHNcbiAgICB9KTtcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmNsaWVudC5zZW5kKGNvbW1hbmQpO1xuICAgICAgY29uc29sZS5sb2coYEFkZGVkIGNvbnZlcnNhdGlvbiBlbnRyeSB0byBzZXNzaW9uOiAke3Nlc3Npb25JZH0sIHR5cGU6ICR7ZW50cnkudHlwZX1gKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgYXBwZW5kaW5nIGNvbnZlcnNhdGlvbiBlbnRyeTonLCBlcnJvcik7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byBhcHBlbmQgY29udmVyc2F0aW9uIGVudHJ5OiAke2Vycm9yfWApO1xuICAgIH1cbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGEgdXNlciBtZXNzYWdlIHRvIHRoZSBjb252ZXJzYXRpb25cbiAgICovXG4gIGFzeW5jIGFkZFVzZXJNZXNzYWdlKFxuICAgIHNlc3Npb25JZDogc3RyaW5nLFxuICAgIHRleHQ6IHN0cmluZyxcbiAgICBhdWRpb1VybD86IHN0cmluZyxcbiAgICBjb25maWRlbmNlPzogbnVtYmVyXG4gICk6IFByb21pc2U8dm9pZD4ge1xuICAgIGNvbnN0IGVudHJ5ID0gY3JlYXRlQ29udmVyc2F0aW9uRW50cnkoJ3VzZXInLCB0ZXh0LCBhdWRpb1VybCwgY29uZmlkZW5jZSk7XG4gICAgYXdhaXQgdGhpcy5hcHBlbmRDb252ZXJzYXRpb25FbnRyeShzZXNzaW9uSWQsIGVudHJ5KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBBZGRzIGFuIEFJIHJlc3BvbnNlIHRvIHRoZSBjb252ZXJzYXRpb25cbiAgICovXG4gIGFzeW5jIGFkZEFpUmVzcG9uc2UoXG4gICAgc2Vzc2lvbklkOiBzdHJpbmcsXG4gICAgdGV4dDogc3RyaW5nLFxuICAgIGF1ZGlvVXJsPzogc3RyaW5nLFxuICAgIHByb2Nlc3NpbmdEdXJhdGlvbj86IG51bWJlclxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBlbnRyeSA9IGNyZWF0ZUNvbnZlcnNhdGlvbkVudHJ5KCdhaScsIHRleHQsIGF1ZGlvVXJsKTtcbiAgICBpZiAocHJvY2Vzc2luZ0R1cmF0aW9uKSB7XG4gICAgICBlbnRyeS5wcm9jZXNzaW5nRHVyYXRpb24gPSBwcm9jZXNzaW5nRHVyYXRpb247XG4gICAgfVxuICAgIGF3YWl0IHRoaXMuYXBwZW5kQ29udmVyc2F0aW9uRW50cnkoc2Vzc2lvbklkLCBlbnRyeSk7XG4gIH1cblxuICAvKipcbiAgICogVXBkYXRlcyBhIGNvbnZlcnNhdGlvbiBlbnRyeSB3aXRoIGF1ZGlvIFVSTFxuICAgKi9cbiAgYXN5bmMgdXBkYXRlQ29udmVyc2F0aW9uRW50cnlXaXRoQXVkaW8oXG4gICAgc2Vzc2lvbklkOiBzdHJpbmcsXG4gICAgZW50cnlJbmRleDogbnVtYmVyLFxuICAgIGF1ZGlvVXJsOiBzdHJpbmdcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgY29tbWFuZCA9IG5ldyBVcGRhdGVJdGVtQ29tbWFuZCh7XG4gICAgICBUYWJsZU5hbWU6IHRoaXMudGFibGVOYW1lLFxuICAgICAgS2V5OiBtYXJzaGFsbCh7IHNlc3Npb25JZCB9KSxcbiAgICAgIFVwZGF0ZUV4cHJlc3Npb246IGBTRVQgY29udmVyc2F0aW9uSGlzdG9yeVske2VudHJ5SW5kZXh9XS5hdWRpb1VybCA9IDphdWRpb1VybCwgbGFzdEFjdGl2aXR5ID0gOmxhc3RBY3Rpdml0eWAsXG4gICAgICBFeHByZXNzaW9uQXR0cmlidXRlVmFsdWVzOiBtYXJzaGFsbCh7XG4gICAgICAgICc6YXVkaW9VcmwnOiBhdWRpb1VybCxcbiAgICAgICAgJzpsYXN0QWN0aXZpdHknOiBEYXRlLm5vdygpLFxuICAgICAgfSwgeyByZW1vdmVVbmRlZmluZWRWYWx1ZXM6IHRydWUgfSksXG4gICAgICBDb25kaXRpb25FeHByZXNzaW9uOiAnYXR0cmlidXRlX2V4aXN0cyhzZXNzaW9uSWQpJyxcbiAgICB9KTtcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmNsaWVudC5zZW5kKGNvbW1hbmQpO1xuICAgICAgY29uc29sZS5sb2coYFVwZGF0ZWQgY29udmVyc2F0aW9uIGVudHJ5ICR7ZW50cnlJbmRleH0gd2l0aCBhdWRpbyBVUkwgZm9yIHNlc3Npb246ICR7c2Vzc2lvbklkfWApO1xuICAgIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgICBjb25zb2xlLmVycm9yKCdFcnJvciB1cGRhdGluZyBjb252ZXJzYXRpb24gZW50cnkgd2l0aCBhdWRpbzonLCBlcnJvcik7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byB1cGRhdGUgY29udmVyc2F0aW9uIGVudHJ5IHdpdGggYXVkaW86ICR7ZXJyb3J9YCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEFkZHMgYSBzeXN0ZW0gbWVzc2FnZSB0byB0aGUgY29udmVyc2F0aW9uXG4gICAqL1xuICBhc3luYyBhZGRTeXN0ZW1NZXNzYWdlKHNlc3Npb25JZDogc3RyaW5nLCB0ZXh0OiBzdHJpbmcpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBlbnRyeSA9IGNyZWF0ZUNvbnZlcnNhdGlvbkVudHJ5KCdzeXN0ZW0nLCB0ZXh0KTtcbiAgICBhd2FpdCB0aGlzLmFwcGVuZENvbnZlcnNhdGlvbkVudHJ5KHNlc3Npb25JZCwgZW50cnkpO1xuICB9XG5cbiAgLyoqXG4gICAqIFVwZGF0ZXMgdGhlIHRvdGFsIGNhbGwgZHVyYXRpb25cbiAgICovXG4gIGFzeW5jIHVwZGF0ZUNhbGxEdXJhdGlvbihzZXNzaW9uSWQ6IHN0cmluZywgZHVyYXRpb25TZWNvbmRzOiBudW1iZXIpOiBQcm9taXNlPHZvaWQ+IHtcbiAgICBjb25zdCBjb21tYW5kID0gbmV3IFVwZGF0ZUl0ZW1Db21tYW5kKHtcbiAgICAgIFRhYmxlTmFtZTogdGhpcy50YWJsZU5hbWUsXG4gICAgICBLZXk6IG1hcnNoYWxsKHsgc2Vzc2lvbklkIH0pLFxuICAgICAgVXBkYXRlRXhwcmVzc2lvbjogJ1NFVCB0b3RhbER1cmF0aW9uID0gOmR1cmF0aW9uLCBsYXN0QWN0aXZpdHkgPSA6bGFzdEFjdGl2aXR5JyxcbiAgICAgIEV4cHJlc3Npb25BdHRyaWJ1dGVWYWx1ZXM6IG1hcnNoYWxsKHtcbiAgICAgICAgJzpkdXJhdGlvbic6IGR1cmF0aW9uU2Vjb25kcyxcbiAgICAgICAgJzpsYXN0QWN0aXZpdHknOiBEYXRlLm5vdygpLFxuICAgICAgfSwgeyByZW1vdmVVbmRlZmluZWRWYWx1ZXM6IHRydWUgfSksXG4gICAgICBDb25kaXRpb25FeHByZXNzaW9uOiAnYXR0cmlidXRlX2V4aXN0cyhzZXNzaW9uSWQpJyxcbiAgICB9KTtcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmNsaWVudC5zZW5kKGNvbW1hbmQpO1xuICAgICAgY29uc29sZS5sb2coYFVwZGF0ZWQgY2FsbCBkdXJhdGlvbjogJHtzZXNzaW9uSWR9IC0+ICR7ZHVyYXRpb25TZWNvbmRzfXNgKTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgdXBkYXRpbmcgY2FsbCBkdXJhdGlvbjonLCBlcnJvcik7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYEZhaWxlZCB0byB1cGRhdGUgY2FsbCBkdXJhdGlvbjogJHtlcnJvcn1gKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogRGVsZXRlcyBhIHNlc3Npb24gKGZvciBjbGVhbnVwIG9yIHRlc3RpbmcpXG4gICAqL1xuICBhc3luYyBkZWxldGVTZXNzaW9uKHNlc3Npb25JZDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgY29tbWFuZCA9IG5ldyBEZWxldGVJdGVtQ29tbWFuZCh7XG4gICAgICBUYWJsZU5hbWU6IHRoaXMudGFibGVOYW1lLFxuICAgICAgS2V5OiBtYXJzaGFsbCh7IHNlc3Npb25JZCB9KSxcbiAgICB9KTtcblxuICAgIHRyeSB7XG4gICAgICBhd2FpdCB0aGlzLmNsaWVudC5zZW5kKGNvbW1hbmQpO1xuICAgICAgY29uc29sZS5sb2coYERlbGV0ZWQgc2Vzc2lvbjogJHtzZXNzaW9uSWR9YCk7XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIGRlbGV0aW5nIHNlc3Npb246JywgZXJyb3IpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gZGVsZXRlIHNlc3Npb246ICR7ZXJyb3J9YCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIExpc3RzIGFjdGl2ZSBzZXNzaW9ucyAoZm9yIG1vbml0b3JpbmcvZGVidWdnaW5nKVxuICAgKi9cbiAgYXN5bmMgbGlzdEFjdGl2ZVNlc3Npb25zKGxpbWl0OiBudW1iZXIgPSA1MCk6IFByb21pc2U8Q2FsbFNlc3Npb25bXT4ge1xuICAgIGNvbnN0IGNvbW1hbmQgPSBuZXcgU2NhbkNvbW1hbmQoe1xuICAgICAgVGFibGVOYW1lOiB0aGlzLnRhYmxlTmFtZSxcbiAgICAgIEZpbHRlckV4cHJlc3Npb246ICcjc3RhdHVzID0gOnN0YXR1cycsXG4gICAgICBFeHByZXNzaW9uQXR0cmlidXRlTmFtZXM6IHtcbiAgICAgICAgJyNzdGF0dXMnOiAnc3RhdHVzJyxcbiAgICAgIH0sXG4gICAgICBFeHByZXNzaW9uQXR0cmlidXRlVmFsdWVzOiBtYXJzaGFsbCh7XG4gICAgICAgICc6c3RhdHVzJzogJ2FjdGl2ZScsXG4gICAgICB9LCB7IHJlbW92ZVVuZGVmaW5lZFZhbHVlczogdHJ1ZSB9KSxcbiAgICAgIExpbWl0OiBsaW1pdCxcbiAgICB9KTtcblxuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCB0aGlzLmNsaWVudC5zZW5kKGNvbW1hbmQpO1xuXG4gICAgICBpZiAoIXJlc3VsdC5JdGVtcykge1xuICAgICAgICByZXR1cm4gW107XG4gICAgICB9XG5cbiAgICAgIGNvbnN0IHNlc3Npb25zID0gcmVzdWx0Lkl0ZW1zXG4gICAgICAgIC5tYXAoaXRlbSA9PiB1bm1hcnNoYWxsKGl0ZW0pIGFzIENhbGxTZXNzaW9uKVxuICAgICAgICAuZmlsdGVyKHNlc3Npb24gPT4gdmFsaWRhdGVDYWxsU2Vzc2lvbihzZXNzaW9uKSk7XG5cbiAgICAgIHJldHVybiBzZXNzaW9ucztcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRXJyb3IgbGlzdGluZyBhY3RpdmUgc2Vzc2lvbnM6JywgZXJyb3IpO1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBGYWlsZWQgdG8gbGlzdCBhY3RpdmUgc2Vzc2lvbnM6ICR7ZXJyb3J9YCk7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdldHMgY29udmVyc2F0aW9uIGhpc3RvcnkgZm9yIGEgc2Vzc2lvblxuICAgKi9cbiAgYXN5bmMgZ2V0Q29udmVyc2F0aW9uSGlzdG9yeShzZXNzaW9uSWQ6IHN0cmluZyk6IFByb21pc2U8Q29udmVyc2F0aW9uRW50cnlbXT4ge1xuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCB0aGlzLmdldFNlc3Npb24oc2Vzc2lvbklkKTtcbiAgICByZXR1cm4gc2Vzc2lvbj8uY29udmVyc2F0aW9uSGlzdG9yeSB8fCBbXTtcbiAgfVxuXG4gIC8qKlxuICAgKiBCdWlsZHMgY29udmVyc2F0aW9uIGNvbnRleHQgc3RyaW5nIGZvciBBSSBwcm9jZXNzaW5nXG4gICAqL1xuICBhc3luYyBidWlsZENvbnZlcnNhdGlvbkNvbnRleHQoc2Vzc2lvbklkOiBzdHJpbmcsIG1heEVudHJpZXM6IG51bWJlciA9IDEwKTogUHJvbWlzZTxzdHJpbmc+IHtcbiAgICBjb25zdCBoaXN0b3J5ID0gYXdhaXQgdGhpcy5nZXRDb252ZXJzYXRpb25IaXN0b3J5KHNlc3Npb25JZCk7XG5cbiAgICAvLyBHZXQgdGhlIG1vc3QgcmVjZW50IGVudHJpZXNcbiAgICBjb25zdCByZWNlbnRIaXN0b3J5ID0gaGlzdG9yeS5zbGljZSgtbWF4RW50cmllcyk7XG5cbiAgICAvLyBCdWlsZCBjb250ZXh0IHN0cmluZ1xuICAgIGNvbnN0IGNvbnRleHRMaW5lcyA9IHJlY2VudEhpc3RvcnkubWFwKGVudHJ5ID0+IHtcbiAgICAgIGNvbnN0IHNwZWFrZXIgPSBlbnRyeS50eXBlID09PSAndXNlcicgPyAnVXNlcicgOiBlbnRyeS50eXBlID09PSAnYWknID8gJ0Fzc2lzdGFudCcgOiAnU3lzdGVtJztcbiAgICAgIHJldHVybiBgJHtzcGVha2VyfTogJHtlbnRyeS50ZXh0fWA7XG4gICAgfSk7XG5cbiAgICByZXR1cm4gY29udGV4dExpbmVzLmpvaW4oJ1xcbicpO1xuICB9XG5cbiAgLyoqXG4gICAqIEhlYWx0aCBjaGVjayBtZXRob2QgdG8gdmVyaWZ5IER5bmFtb0RCIGNvbm5lY3Rpdml0eVxuICAgKi9cbiAgYXN5bmMgaGVhbHRoQ2hlY2soKTogUHJvbWlzZTxib29sZWFuPiB7XG4gICAgdHJ5IHtcbiAgICAgIC8vIFRyeSB0byBzY2FuIHRoZSB0YWJsZSB3aXRoIGEgbGltaXQgb2YgMSB0byB0ZXN0IGNvbm5lY3Rpdml0eVxuICAgICAgY29uc3QgY29tbWFuZCA9IG5ldyBTY2FuQ29tbWFuZCh7XG4gICAgICAgIFRhYmxlTmFtZTogdGhpcy50YWJsZU5hbWUsXG4gICAgICAgIExpbWl0OiAxLFxuICAgICAgfSk7XG5cbiAgICAgIGF3YWl0IHRoaXMuY2xpZW50LnNlbmQoY29tbWFuZCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9IGNhdGNoIChlcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignRHluYW1vREIgaGVhbHRoIGNoZWNrIGZhaWxlZDonLCBlcnJvcik7XG4gICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICB9XG59Il19