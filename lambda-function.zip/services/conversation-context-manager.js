"use strict";
/**
 * Conversation Context Manager for PromptCall AI MVP
 * Manages conversation context, AI prompts, and session state for optimal AI interactions
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConversationContextManager = exports.DEFAULT_CONTEXT_CONFIG = void 0;
const session_1 = require("../types/session");
/**
 * Default configuration for conversation context
 */
exports.DEFAULT_CONTEXT_CONFIG = {
    maxContextEntries: 10, // Keep last 10 conversation turns
    maxContextLength: 2000, // Max characters in context string
    summaryThreshold: 15, // Summarize after 15 entries
    responseWordLimit: 150, // Max words in AI response (for 60-second speech)
    sessionConfig: session_1.DEFAULT_SESSION_CONFIG,
};
class ConversationContextManager {
    constructor(sessionManager, config = exports.DEFAULT_CONTEXT_CONFIG) {
        this.sessionManager = sessionManager;
        this.config = config;
    }
    /**
     * Initializes a new conversation session with greeting phase
     */
    async initializeConversation(callSid, phoneNumber, userPreferences) {
        // Create new session
        const session = await this.sessionManager.createSession(callSid, phoneNumber);
        // Add system message for conversation start
        await this.sessionManager.addSystemMessage(session.sessionId, 'Conversation initialized - greeting phase');
        // Build initial AI context
        const context = await this.buildAIContext(session.sessionId, userPreferences);
        return { session, context };
    }
    /**
     * Processes a user message and updates conversation context
     */
    async processUserMessage(sessionId, userText, audioUrl, confidence) {
        // Add user message to session
        await this.sessionManager.addUserMessage(sessionId, userText, audioUrl, confidence);
        // Update session state
        await this.updateSessionState(sessionId, {
            isWaitingForUser: false,
            lastActivity: Date.now(),
        });
        // Build updated AI context
        return this.buildAIContext(sessionId);
    }
    /**
     * Processes an AI response and updates conversation context
     */
    async processAIResponse(sessionId, aiText, audioUrl, processingDuration) {
        // Add AI response to session
        await this.sessionManager.addAiResponse(sessionId, aiText, audioUrl, processingDuration);
        // Update session state
        await this.updateSessionState(sessionId, {
            isWaitingForUser: true,
            lastActivity: Date.now(),
        });
        // Update conversation phase based on content
        await this.updateConversationPhase(sessionId, aiText);
    }
    /**
     * Builds comprehensive AI context for processing user queries
     */
    async buildAIContext(sessionId, userPreferences) {
        const session = await this.sessionManager.getSession(sessionId);
        if (!session) {
            throw new Error(`Session not found: ${sessionId}`);
        }
        // Get conversation history with context window
        const contextWindow = this.getContextWindow(session.conversationHistory);
        // Build conversation context string
        const conversationContext = this.buildContextString(contextWindow);
        // Determine user preferences
        const preferences = this.buildUserPreferences(session, userPreferences);
        // Generate system prompt based on conversation phase
        const systemPrompt = this.generateSystemPrompt(session, preferences);
        // Extract conversation summary and user intent
        const conversationSummary = this.generateConversationSummary(contextWindow);
        const lastUserIntent = this.extractUserIntent(contextWindow);
        return {
            sessionId,
            conversationContext,
            userPreferences: preferences,
            systemPrompt,
            conversationSummary,
            lastUserIntent,
            contextWindow,
        };
    }
    /**
     * Gets the relevant context window from conversation history
     */
    getContextWindow(conversationHistory) {
        // Get the most recent entries within limits
        const recentEntries = conversationHistory.slice(-this.config.maxContextEntries);
        // Filter out system messages for AI context (keep user and AI only)
        return recentEntries.filter(entry => entry.type === 'user' || entry.type === 'ai');
    }
    /**
     * Builds a formatted context string for AI processing
     */
    buildContextString(contextWindow) {
        if (contextWindow.length === 0) {
            return 'This is the start of a new conversation.';
        }
        const contextLines = contextWindow.map(entry => {
            const speaker = entry.type === 'user' ? 'User' : 'Assistant';
            const timestamp = new Date(entry.timestamp).toISOString();
            return `[${timestamp}] ${speaker}: ${entry.text}`;
        });
        let contextString = contextLines.join('\n');
        // Truncate if too long
        if (contextString.length > this.config.maxContextLength) {
            contextString = contextString.substring(0, this.config.maxContextLength) + '...';
        }
        return contextString;
    }
    /**
     * Builds user preferences from session data and overrides
     */
    buildUserPreferences(session, overrides) {
        // Default preferences
        const defaults = {
            responseLength: 'medium',
            topics: [],
            language: 'en',
            voiceSpeed: 'normal',
        };
        // Infer preferences from conversation history
        const inferred = this.inferUserPreferences(session.conversationHistory);
        // Merge defaults, inferred, and overrides
        return {
            ...defaults,
            ...inferred,
            ...overrides,
        };
    }
    /**
     * Infers user preferences from conversation patterns
     */
    inferUserPreferences(conversationHistory) {
        const preferences = {};
        // Analyze conversation length preferences
        const userMessages = conversationHistory.filter(entry => entry.type === 'user');
        const avgUserMessageLength = userMessages.reduce((sum, msg) => sum + msg.text.length, 0) / userMessages.length;
        if (avgUserMessageLength < 50) {
            preferences.responseLength = 'short';
        }
        else if (avgUserMessageLength > 150) {
            preferences.responseLength = 'long';
        }
        else {
            preferences.responseLength = 'medium';
        }
        // Extract topics from conversation
        const topics = this.extractTopics(conversationHistory);
        if (topics.length > 0) {
            preferences.topics = topics;
        }
        return preferences;
    }
    /**
     * Generates system prompt based on conversation phase and preferences
     */
    generateSystemPrompt(session, preferences) {
        const basePrompt = `You are a helpful AI assistant accessible via phone call. 
You are speaking to someone who called a phone number to get AI assistance.
Keep responses conversational, clear, and optimized for voice communication.`;
        const lengthGuidance = {
            short: 'Keep responses very brief (1-2 sentences, max 50 words).',
            medium: 'Keep responses concise but complete (2-4 sentences, max 100 words).',
            long: 'Provide detailed responses when needed (max 150 words for 60-second speech limit).',
        };
        const phaseGuidance = this.getPhaseGuidance(session);
        return `${basePrompt}

${lengthGuidance[preferences.responseLength]}

${phaseGuidance}

Important guidelines:
- Speak naturally as if having a phone conversation
- Use simple, clear language that's easy to understand over the phone
- Ask clarifying questions if the user's request is unclear
- Be helpful and supportive
- Remember this is a voice-only interaction - no visual elements
- Keep track of the conversation context and refer back to previous topics when relevant`;
    }
    /**
     * Gets phase-specific guidance for the system prompt
     */
    getPhaseGuidance(session) {
        const turnCount = session.conversationHistory.filter(entry => entry.type === 'user').length;
        if (turnCount === 0) {
            return 'This is the start of the conversation. Greet the user warmly and ask how you can help them today.';
        }
        else if (turnCount < 3) {
            return 'You are in the early conversation phase. Focus on understanding what the user needs help with.';
        }
        else if (turnCount < 10) {
            return 'You are in an active conversation. Provide helpful responses and maintain engagement.';
        }
        else {
            return 'This is an extended conversation. Consider summarizing key points and checking if the user needs anything else.';
        }
    }
    /**
     * Generates a conversation summary for context
     */
    generateConversationSummary(contextWindow) {
        if (contextWindow.length === 0) {
            return 'No conversation history yet.';
        }
        const userMessages = contextWindow.filter(entry => entry.type === 'user');
        const aiMessages = contextWindow.filter(entry => entry.type === 'ai');
        if (userMessages.length === 0) {
            return 'User has not spoken yet.';
        }
        const topics = this.extractTopics(contextWindow);
        const topicSummary = topics.length > 0 ? `Topics discussed: ${topics.join(', ')}` : 'General conversation';
        return `Conversation with ${userMessages.length} user messages and ${aiMessages.length} AI responses. ${topicSummary}`;
    }
    /**
     * Extracts the user's likely intent from recent messages
     */
    extractUserIntent(contextWindow) {
        const recentUserMessages = contextWindow
            .filter(entry => entry.type === 'user')
            .slice(-2); // Last 2 user messages
        if (recentUserMessages.length === 0) {
            return 'unknown';
        }
        const lastMessage = recentUserMessages[recentUserMessages.length - 1].text.toLowerCase();
        // Simple intent classification
        if (lastMessage.includes('help') || lastMessage.includes('how')) {
            return 'seeking_help';
        }
        else if (lastMessage.includes('thank') || lastMessage.includes('bye')) {
            return 'ending_conversation';
        }
        else if (lastMessage.includes('?')) {
            return 'asking_question';
        }
        else if (lastMessage.includes('tell me') || lastMessage.includes('what is')) {
            return 'requesting_information';
        }
        else {
            return 'general_conversation';
        }
    }
    /**
     * Extracts topics from conversation history
     */
    extractTopics(conversationHistory) {
        const topics = [];
        const text = conversationHistory.map(entry => entry.text).join(' ').toLowerCase();
        // Simple keyword-based topic extraction
        const topicKeywords = {
            weather: ['weather', 'temperature', 'rain', 'sunny', 'cloudy'],
            technology: ['computer', 'software', 'app', 'website', 'tech'],
            health: ['health', 'doctor', 'medicine', 'sick', 'pain'],
            travel: ['travel', 'trip', 'vacation', 'flight', 'hotel'],
            food: ['food', 'recipe', 'cooking', 'restaurant', 'eat'],
            business: ['business', 'work', 'job', 'career', 'company'],
        };
        for (const [topic, keywords] of Object.entries(topicKeywords)) {
            if (keywords.some(keyword => text.includes(keyword))) {
                topics.push(topic);
            }
        }
        return topics;
    }
    /**
     * Updates session state with new information
     */
    async updateSessionState(sessionId, stateUpdates) {
        // This would typically update a separate session state record
        // For now, we'll use the session's lastActivity field
        if (stateUpdates.lastActivity) {
            // The session manager already updates lastActivity in conversation methods
            // Additional state management could be added here
        }
    }
    /**
     * Updates conversation phase based on AI response content
     */
    async updateConversationPhase(sessionId, aiText) {
        const lowerText = aiText.toLowerCase();
        if (lowerText.includes('hello') || lowerText.includes('welcome')) {
            // Still in greeting phase
        }
        else if (lowerText.includes('goodbye') || lowerText.includes('thank you for calling')) {
            // Moving to closing phase
        }
        else if (lowerText.includes('could you clarify') || lowerText.includes('what do you mean')) {
            // In clarification phase
        }
        else {
            // Active conversation phase
        }
        // Add system message to track phase changes
        // This could be enhanced with more sophisticated phase tracking
    }
    /**
     * Checks if session needs attention (timeout, errors, etc.)
     */
    async checkSessionHealth(sessionId) {
        const session = await this.sessionManager.getSession(sessionId);
        if (!session) {
            return {
                needsAttention: true,
                reasons: ['Session not found'],
                recommendations: ['Create new session'],
            };
        }
        const reasons = [];
        const recommendations = [];
        // Check for timeout
        if ((0, session_1.isSessionTimedOut)(session, this.config.sessionConfig)) {
            reasons.push('Session timed out due to inactivity');
            recommendations.push('Send timeout prompt or end session gracefully');
        }
        // Check for duration limit
        if ((0, session_1.isSessionOverDuration)(session, this.config.sessionConfig)) {
            reasons.push('Session exceeded maximum duration');
            recommendations.push('Suggest wrapping up the conversation');
        }
        // Check conversation length
        if (session.conversationHistory.length > this.config.summaryThreshold) {
            reasons.push('Long conversation may need summarization');
            recommendations.push('Provide conversation summary and check if user needs more help');
        }
        // Check for repeated errors
        const recentErrors = session.conversationHistory
            .filter(entry => entry.type === 'system' && entry.text.includes('error'))
            .slice(-3);
        if (recentErrors.length >= 2) {
            reasons.push('Multiple recent errors detected');
            recommendations.push('Apologize for technical difficulties and offer alternative assistance');
        }
        return {
            needsAttention: reasons.length > 0,
            reasons,
            recommendations,
        };
    }
    /**
     * Validates AI response before sending to user
     */
    validateAIResponse(response, preferences) {
        const issues = [];
        const suggestions = [];
        // Check word count
        const wordCount = response.split(/\s+/).length;
        const maxWords = this.config.responseWordLimit;
        if (wordCount > maxWords) {
            issues.push(`Response too long: ${wordCount} words (max: ${maxWords})`);
            suggestions.push('Shorten response or split into multiple parts');
        }
        // Check for phone-inappropriate content
        if (response.includes('click') || response.includes('see') || response.includes('look')) {
            issues.push('Response contains visual references inappropriate for phone calls');
            suggestions.push('Replace visual references with audio-appropriate language');
        }
        // Check response length preference
        const expectedLength = {
            short: 50,
            medium: 100,
            long: 150,
        }[preferences.responseLength];
        if (wordCount > expectedLength * 1.5) {
            issues.push(`Response longer than user preference (${preferences.responseLength})`);
            suggestions.push(`Adjust response to match ${preferences.responseLength} preference`);
        }
        return {
            isValid: issues.length === 0,
            issues,
            suggestions,
        };
    }
    /**
     * Gets conversation statistics for monitoring
     */
    async getConversationStats(sessionId) {
        const session = await this.sessionManager.getSession(sessionId);
        if (!session) {
            throw new Error(`Session not found: ${sessionId}`);
        }
        const userMessages = session.conversationHistory.filter(entry => entry.type === 'user');
        const aiMessages = session.conversationHistory.filter(entry => entry.type === 'ai');
        const duration = session.endTime
            ? session.endTime - session.startTime
            : Date.now() - session.startTime;
        const averageResponseLength = aiMessages.length > 0
            ? aiMessages.reduce((sum, msg) => sum + msg.text.length, 0) / aiMessages.length
            : 0;
        const topicsDiscussed = this.extractTopics(session.conversationHistory);
        // Simple engagement calculation
        const engagementScore = userMessages.length / Math.max(1, duration / 60000); // messages per minute
        const userEngagement = engagementScore > 2 ? 'high' : engagementScore > 0.5 ? 'medium' : 'low';
        return {
            turnCount: userMessages.length,
            duration: Math.round(duration / 1000), // seconds
            averageResponseLength: Math.round(averageResponseLength),
            topicsDiscussed,
            userEngagement,
        };
    }
}
exports.ConversationContextManager = ConversationContextManager;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29udmVyc2F0aW9uLWNvbnRleHQtbWFuYWdlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9zZXJ2aWNlcy9jb252ZXJzYXRpb24tY29udGV4dC1tYW5hZ2VyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7QUFBQTs7O0dBR0c7OztBQUVILDhDQVEwQjtBQW9EMUI7O0dBRUc7QUFDVSxRQUFBLHNCQUFzQixHQUE4QjtJQUMvRCxpQkFBaUIsRUFBRSxFQUFFLEVBQUUsa0NBQWtDO0lBQ3pELGdCQUFnQixFQUFFLElBQUksRUFBRSxtQ0FBbUM7SUFDM0QsZ0JBQWdCLEVBQUUsRUFBRSxFQUFFLDZCQUE2QjtJQUNuRCxpQkFBaUIsRUFBRSxHQUFHLEVBQUUsa0RBQWtEO0lBQzFFLGFBQWEsRUFBRSxnQ0FBc0I7Q0FDdEMsQ0FBQztBQUVGLE1BQWEsMEJBQTBCO0lBSXJDLFlBQ0UsY0FBb0MsRUFDcEMsU0FBb0MsOEJBQXNCO1FBRTFELElBQUksQ0FBQyxjQUFjLEdBQUcsY0FBYyxDQUFDO1FBQ3JDLElBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTSxDQUFDO0lBQ3ZCLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxzQkFBc0IsQ0FDMUIsT0FBZSxFQUNmLFdBQW1CLEVBQ25CLGVBQTBDO1FBRTFDLHFCQUFxQjtRQUNyQixNQUFNLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQztRQUU5RSw0Q0FBNEM7UUFDNUMsTUFBTSxJQUFJLENBQUMsY0FBYyxDQUFDLGdCQUFnQixDQUN4QyxPQUFPLENBQUMsU0FBUyxFQUNqQiwyQ0FBMkMsQ0FDNUMsQ0FBQztRQUVGLDJCQUEyQjtRQUMzQixNQUFNLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxlQUFlLENBQUMsQ0FBQztRQUU5RSxPQUFPLEVBQUUsT0FBTyxFQUFFLE9BQU8sRUFBRSxDQUFDO0lBQzlCLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxrQkFBa0IsQ0FDdEIsU0FBaUIsRUFDakIsUUFBZ0IsRUFDaEIsUUFBaUIsRUFDakIsVUFBbUI7UUFFbkIsOEJBQThCO1FBQzlCLE1BQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxjQUFjLENBQUMsU0FBUyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsVUFBVSxDQUFDLENBQUM7UUFFcEYsdUJBQXVCO1FBQ3ZCLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsRUFBRTtZQUN2QyxnQkFBZ0IsRUFBRSxLQUFLO1lBQ3ZCLFlBQVksRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFO1NBQ3pCLENBQUMsQ0FBQztRQUVILDJCQUEyQjtRQUMzQixPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUM7SUFDeEMsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGlCQUFpQixDQUNyQixTQUFpQixFQUNqQixNQUFjLEVBQ2QsUUFBaUIsRUFDakIsa0JBQTJCO1FBRTNCLDZCQUE2QjtRQUM3QixNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsYUFBYSxDQUFDLFNBQVMsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLGtCQUFrQixDQUFDLENBQUM7UUFFekYsdUJBQXVCO1FBQ3ZCLE1BQU0sSUFBSSxDQUFDLGtCQUFrQixDQUFDLFNBQVMsRUFBRTtZQUN2QyxnQkFBZ0IsRUFBRSxJQUFJO1lBQ3RCLFlBQVksRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFO1NBQ3pCLENBQUMsQ0FBQztRQUVILDZDQUE2QztRQUM3QyxNQUFNLElBQUksQ0FBQyx1QkFBdUIsQ0FBQyxTQUFTLEVBQUUsTUFBTSxDQUFDLENBQUM7SUFDeEQsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGNBQWMsQ0FDbEIsU0FBaUIsRUFDakIsZUFBMEM7UUFFMUMsTUFBTSxPQUFPLEdBQUcsTUFBTSxJQUFJLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQztRQUNoRSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDYixNQUFNLElBQUksS0FBSyxDQUFDLHNCQUFzQixTQUFTLEVBQUUsQ0FBQyxDQUFDO1FBQ3JELENBQUM7UUFFRCwrQ0FBK0M7UUFDL0MsTUFBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBRXpFLG9DQUFvQztRQUNwQyxNQUFNLG1CQUFtQixHQUFHLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxhQUFhLENBQUMsQ0FBQztRQUVuRSw2QkFBNkI7UUFDN0IsTUFBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sRUFBRSxlQUFlLENBQUMsQ0FBQztRQUV4RSxxREFBcUQ7UUFDckQsTUFBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLG9CQUFvQixDQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsQ0FBQztRQUVyRSwrQ0FBK0M7UUFDL0MsTUFBTSxtQkFBbUIsR0FBRyxJQUFJLENBQUMsMkJBQTJCLENBQUMsYUFBYSxDQUFDLENBQUM7UUFDNUUsTUFBTSxjQUFjLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBRTdELE9BQU87WUFDTCxTQUFTO1lBQ1QsbUJBQW1CO1lBQ25CLGVBQWUsRUFBRSxXQUFXO1lBQzVCLFlBQVk7WUFDWixtQkFBbUI7WUFDbkIsY0FBYztZQUNkLGFBQWE7U0FDZCxDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0ssZ0JBQWdCLENBQUMsbUJBQXdDO1FBQy9ELDRDQUE0QztRQUM1QyxNQUFNLGFBQWEsR0FBRyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDLENBQUM7UUFFaEYsb0VBQW9FO1FBQ3BFLE9BQU8sYUFBYSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssTUFBTSxJQUFJLEtBQUssQ0FBQyxJQUFJLEtBQUssSUFBSSxDQUFDLENBQUM7SUFDckYsQ0FBQztJQUVEOztPQUVHO0lBQ0ssa0JBQWtCLENBQUMsYUFBa0M7UUFDM0QsSUFBSSxhQUFhLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQy9CLE9BQU8sMENBQTBDLENBQUM7UUFDcEQsQ0FBQztRQUVELE1BQU0sWUFBWSxHQUFHLGFBQWEsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUU7WUFDN0MsTUFBTSxPQUFPLEdBQUcsS0FBSyxDQUFDLElBQUksS0FBSyxNQUFNLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDO1lBQzdELE1BQU0sU0FBUyxHQUFHLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztZQUMxRCxPQUFPLElBQUksU0FBUyxLQUFLLE9BQU8sS0FBSyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUM7UUFDcEQsQ0FBQyxDQUFDLENBQUM7UUFFSCxJQUFJLGFBQWEsR0FBRyxZQUFZLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO1FBRTVDLHVCQUF1QjtRQUN2QixJQUFJLGFBQWEsQ0FBQyxNQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO1lBQ3hELGFBQWEsR0FBRyxhQUFhLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLGdCQUFnQixDQUFDLEdBQUcsS0FBSyxDQUFDO1FBQ25GLENBQUM7UUFFRCxPQUFPLGFBQWEsQ0FBQztJQUN2QixDQUFDO0lBRUQ7O09BRUc7SUFDSyxvQkFBb0IsQ0FDMUIsT0FBb0IsRUFDcEIsU0FBb0M7UUFFcEMsc0JBQXNCO1FBQ3RCLE1BQU0sUUFBUSxHQUFvQjtZQUNoQyxjQUFjLEVBQUUsUUFBUTtZQUN4QixNQUFNLEVBQUUsRUFBRTtZQUNWLFFBQVEsRUFBRSxJQUFJO1lBQ2QsVUFBVSxFQUFFLFFBQVE7U0FDckIsQ0FBQztRQUVGLDhDQUE4QztRQUM5QyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsb0JBQW9CLENBQUMsT0FBTyxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFFeEUsMENBQTBDO1FBQzFDLE9BQU87WUFDTCxHQUFHLFFBQVE7WUFDWCxHQUFHLFFBQVE7WUFDWCxHQUFHLFNBQVM7U0FDYixDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0ssb0JBQW9CLENBQUMsbUJBQXdDO1FBQ25FLE1BQU0sV0FBVyxHQUE2QixFQUFFLENBQUM7UUFFakQsMENBQTBDO1FBQzFDLE1BQU0sWUFBWSxHQUFHLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssTUFBTSxDQUFDLENBQUM7UUFDaEYsTUFBTSxvQkFBb0IsR0FBRyxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsR0FBRyxFQUFFLEdBQUcsRUFBRSxFQUFFLENBQUMsR0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsQ0FBQyxHQUFHLFlBQVksQ0FBQyxNQUFNLENBQUM7UUFFL0csSUFBSSxvQkFBb0IsR0FBRyxFQUFFLEVBQUUsQ0FBQztZQUM5QixXQUFXLENBQUMsY0FBYyxHQUFHLE9BQU8sQ0FBQztRQUN2QyxDQUFDO2FBQU0sSUFBSSxvQkFBb0IsR0FBRyxHQUFHLEVBQUUsQ0FBQztZQUN0QyxXQUFXLENBQUMsY0FBYyxHQUFHLE1BQU0sQ0FBQztRQUN0QyxDQUFDO2FBQU0sQ0FBQztZQUNOLFdBQVcsQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDO1FBQ3hDLENBQUM7UUFFRCxtQ0FBbUM7UUFDbkMsTUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDO1FBQ3ZELElBQUksTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUN0QixXQUFXLENBQUMsTUFBTSxHQUFHLE1BQU0sQ0FBQztRQUM5QixDQUFDO1FBRUQsT0FBTyxXQUFXLENBQUM7SUFDckIsQ0FBQztJQUVEOztPQUVHO0lBQ0ssb0JBQW9CLENBQUMsT0FBb0IsRUFBRSxXQUE0QjtRQUM3RSxNQUFNLFVBQVUsR0FBRzs7NkVBRXNELENBQUM7UUFFMUUsTUFBTSxjQUFjLEdBQUc7WUFDckIsS0FBSyxFQUFFLDBEQUEwRDtZQUNqRSxNQUFNLEVBQUUscUVBQXFFO1lBQzdFLElBQUksRUFBRSxvRkFBb0Y7U0FDM0YsQ0FBQztRQUVGLE1BQU0sYUFBYSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUVyRCxPQUFPLEdBQUcsVUFBVTs7RUFFdEIsY0FBYyxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUM7O0VBRTFDLGFBQWE7Ozs7Ozs7O3lGQVEwRSxDQUFDO0lBQ3hGLENBQUM7SUFFRDs7T0FFRztJQUNLLGdCQUFnQixDQUFDLE9BQW9CO1FBQzNDLE1BQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUU1RixJQUFJLFNBQVMsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNwQixPQUFPLG1HQUFtRyxDQUFDO1FBQzdHLENBQUM7YUFBTSxJQUFJLFNBQVMsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUN6QixPQUFPLGdHQUFnRyxDQUFDO1FBQzFHLENBQUM7YUFBTSxJQUFJLFNBQVMsR0FBRyxFQUFFLEVBQUUsQ0FBQztZQUMxQixPQUFPLHVGQUF1RixDQUFDO1FBQ2pHLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxpSEFBaUgsQ0FBQztRQUMzSCxDQUFDO0lBQ0gsQ0FBQztJQUVEOztPQUVHO0lBQ0ssMkJBQTJCLENBQUMsYUFBa0M7UUFDcEUsSUFBSSxhQUFhLENBQUMsTUFBTSxLQUFLLENBQUMsRUFBRSxDQUFDO1lBQy9CLE9BQU8sOEJBQThCLENBQUM7UUFDeEMsQ0FBQztRQUVELE1BQU0sWUFBWSxHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDO1FBQzFFLE1BQU0sVUFBVSxHQUFHLGFBQWEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxDQUFDO1FBRXRFLElBQUksWUFBWSxDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUM5QixPQUFPLDBCQUEwQixDQUFDO1FBQ3BDLENBQUM7UUFFRCxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLGFBQWEsQ0FBQyxDQUFDO1FBQ2pELE1BQU0sWUFBWSxHQUFHLE1BQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxxQkFBcUIsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxzQkFBc0IsQ0FBQztRQUUzRyxPQUFPLHFCQUFxQixZQUFZLENBQUMsTUFBTSxzQkFBc0IsVUFBVSxDQUFDLE1BQU0sa0JBQWtCLFlBQVksRUFBRSxDQUFDO0lBQ3pILENBQUM7SUFFRDs7T0FFRztJQUNLLGlCQUFpQixDQUFDLGFBQWtDO1FBQzFELE1BQU0sa0JBQWtCLEdBQUcsYUFBYTthQUNyQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQzthQUN0QyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLHVCQUF1QjtRQUVyQyxJQUFJLGtCQUFrQixDQUFDLE1BQU0sS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNwQyxPQUFPLFNBQVMsQ0FBQztRQUNuQixDQUFDO1FBRUQsTUFBTSxXQUFXLEdBQUcsa0JBQWtCLENBQUMsa0JBQWtCLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUV6RiwrQkFBK0I7UUFDL0IsSUFBSSxXQUFXLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUNoRSxPQUFPLGNBQWMsQ0FBQztRQUN4QixDQUFDO2FBQU0sSUFBSSxXQUFXLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLFdBQVcsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztZQUN4RSxPQUFPLHFCQUFxQixDQUFDO1FBQy9CLENBQUM7YUFBTSxJQUFJLFdBQVcsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQztZQUNyQyxPQUFPLGlCQUFpQixDQUFDO1FBQzNCLENBQUM7YUFBTSxJQUFJLFdBQVcsQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLElBQUksV0FBVyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO1lBQzlFLE9BQU8sd0JBQXdCLENBQUM7UUFDbEMsQ0FBQzthQUFNLENBQUM7WUFDTixPQUFPLHNCQUFzQixDQUFDO1FBQ2hDLENBQUM7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxhQUFhLENBQUMsbUJBQXdDO1FBQzVELE1BQU0sTUFBTSxHQUFhLEVBQUUsQ0FBQztRQUM1QixNQUFNLElBQUksR0FBRyxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsRUFBRSxDQUFDO1FBRWxGLHdDQUF3QztRQUN4QyxNQUFNLGFBQWEsR0FBRztZQUNwQixPQUFPLEVBQUUsQ0FBQyxTQUFTLEVBQUUsYUFBYSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsUUFBUSxDQUFDO1lBQzlELFVBQVUsRUFBRSxDQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxNQUFNLENBQUM7WUFDOUQsTUFBTSxFQUFFLENBQUMsUUFBUSxFQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQztZQUN4RCxNQUFNLEVBQUUsQ0FBQyxRQUFRLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsT0FBTyxDQUFDO1lBQ3pELElBQUksRUFBRSxDQUFDLE1BQU0sRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxLQUFLLENBQUM7WUFDeEQsUUFBUSxFQUFFLENBQUMsVUFBVSxFQUFFLE1BQU0sRUFBRSxLQUFLLEVBQUUsUUFBUSxFQUFFLFNBQVMsQ0FBQztTQUMzRCxDQUFDO1FBRUYsS0FBSyxNQUFNLENBQUMsS0FBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJLE1BQU0sQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQztZQUM5RCxJQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEVBQUUsQ0FBQztnQkFDckQsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNyQixDQUFDO1FBQ0gsQ0FBQztRQUVELE9BQU8sTUFBTSxDQUFDO0lBQ2hCLENBQUM7SUFFRDs7T0FFRztJQUNLLEtBQUssQ0FBQyxrQkFBa0IsQ0FDOUIsU0FBaUIsRUFDakIsWUFBbUM7UUFFbkMsOERBQThEO1FBQzlELHNEQUFzRDtRQUN0RCxJQUFJLFlBQVksQ0FBQyxZQUFZLEVBQUUsQ0FBQztZQUM5QiwyRUFBMkU7WUFDM0Usa0RBQWtEO1FBQ3BELENBQUM7SUFDSCxDQUFDO0lBRUQ7O09BRUc7SUFDSyxLQUFLLENBQUMsdUJBQXVCLENBQUMsU0FBaUIsRUFBRSxNQUFjO1FBQ3JFLE1BQU0sU0FBUyxHQUFHLE1BQU0sQ0FBQyxXQUFXLEVBQUUsQ0FBQztRQUV2QyxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsRUFBRSxDQUFDO1lBQ2pFLDBCQUEwQjtRQUM1QixDQUFDO2FBQU0sSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLFNBQVMsQ0FBQyxRQUFRLENBQUMsdUJBQXVCLENBQUMsRUFBRSxDQUFDO1lBQ3hGLDBCQUEwQjtRQUM1QixDQUFDO2FBQU0sSUFBSSxTQUFTLENBQUMsUUFBUSxDQUFDLG1CQUFtQixDQUFDLElBQUksU0FBUyxDQUFDLFFBQVEsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFFLENBQUM7WUFDN0YseUJBQXlCO1FBQzNCLENBQUM7YUFBTSxDQUFDO1lBQ04sNEJBQTRCO1FBQzlCLENBQUM7UUFFRCw0Q0FBNEM7UUFDNUMsZ0VBQWdFO0lBQ2xFLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxrQkFBa0IsQ0FBQyxTQUFpQjtRQUt4QyxNQUFNLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2hFLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNiLE9BQU87Z0JBQ0wsY0FBYyxFQUFFLElBQUk7Z0JBQ3BCLE9BQU8sRUFBRSxDQUFDLG1CQUFtQixDQUFDO2dCQUM5QixlQUFlLEVBQUUsQ0FBQyxvQkFBb0IsQ0FBQzthQUN4QyxDQUFDO1FBQ0osQ0FBQztRQUVELE1BQU0sT0FBTyxHQUFhLEVBQUUsQ0FBQztRQUM3QixNQUFNLGVBQWUsR0FBYSxFQUFFLENBQUM7UUFFckMsb0JBQW9CO1FBQ3BCLElBQUksSUFBQSwyQkFBaUIsRUFBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQUMsRUFBRSxDQUFDO1lBQzFELE9BQU8sQ0FBQyxJQUFJLENBQUMscUNBQXFDLENBQUMsQ0FBQztZQUNwRCxlQUFlLENBQUMsSUFBSSxDQUFDLCtDQUErQyxDQUFDLENBQUM7UUFDeEUsQ0FBQztRQUVELDJCQUEyQjtRQUMzQixJQUFJLElBQUEsK0JBQXFCLEVBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsYUFBYSxDQUFDLEVBQUUsQ0FBQztZQUM5RCxPQUFPLENBQUMsSUFBSSxDQUFDLG1DQUFtQyxDQUFDLENBQUM7WUFDbEQsZUFBZSxDQUFDLElBQUksQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDO1FBQy9ELENBQUM7UUFFRCw0QkFBNEI7UUFDNUIsSUFBSSxPQUFPLENBQUMsbUJBQW1CLENBQUMsTUFBTSxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQztZQUN0RSxPQUFPLENBQUMsSUFBSSxDQUFDLDBDQUEwQyxDQUFDLENBQUM7WUFDekQsZUFBZSxDQUFDLElBQUksQ0FBQyxnRUFBZ0UsQ0FBQyxDQUFDO1FBQ3pGLENBQUM7UUFFRCw0QkFBNEI7UUFDNUIsTUFBTSxZQUFZLEdBQUcsT0FBTyxDQUFDLG1CQUFtQjthQUM3QyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLFFBQVEsSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQzthQUN4RSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUViLElBQUksWUFBWSxDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUUsQ0FBQztZQUM3QixPQUFPLENBQUMsSUFBSSxDQUFDLGlDQUFpQyxDQUFDLENBQUM7WUFDaEQsZUFBZSxDQUFDLElBQUksQ0FBQyx1RUFBdUUsQ0FBQyxDQUFDO1FBQ2hHLENBQUM7UUFFRCxPQUFPO1lBQ0wsY0FBYyxFQUFFLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQztZQUNsQyxPQUFPO1lBQ1AsZUFBZTtTQUNoQixDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0gsa0JBQWtCLENBQUMsUUFBZ0IsRUFBRSxXQUE0QjtRQUsvRCxNQUFNLE1BQU0sR0FBYSxFQUFFLENBQUM7UUFDNUIsTUFBTSxXQUFXLEdBQWEsRUFBRSxDQUFDO1FBRWpDLG1CQUFtQjtRQUNuQixNQUFNLFNBQVMsR0FBRyxRQUFRLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUMvQyxNQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLGlCQUFpQixDQUFDO1FBRS9DLElBQUksU0FBUyxHQUFHLFFBQVEsRUFBRSxDQUFDO1lBQ3pCLE1BQU0sQ0FBQyxJQUFJLENBQUMsc0JBQXNCLFNBQVMsZ0JBQWdCLFFBQVEsR0FBRyxDQUFDLENBQUM7WUFDeEUsV0FBVyxDQUFDLElBQUksQ0FBQywrQ0FBK0MsQ0FBQyxDQUFDO1FBQ3BFLENBQUM7UUFFRCx3Q0FBd0M7UUFDeEMsSUFBSSxRQUFRLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxJQUFJLFFBQVEsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksUUFBUSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1lBQ3hGLE1BQU0sQ0FBQyxJQUFJLENBQUMsbUVBQW1FLENBQUMsQ0FBQztZQUNqRixXQUFXLENBQUMsSUFBSSxDQUFDLDJEQUEyRCxDQUFDLENBQUM7UUFDaEYsQ0FBQztRQUVELG1DQUFtQztRQUNuQyxNQUFNLGNBQWMsR0FBRztZQUNyQixLQUFLLEVBQUUsRUFBRTtZQUNULE1BQU0sRUFBRSxHQUFHO1lBQ1gsSUFBSSxFQUFFLEdBQUc7U0FDVixDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsQ0FBQztRQUU5QixJQUFJLFNBQVMsR0FBRyxjQUFjLEdBQUcsR0FBRyxFQUFFLENBQUM7WUFDckMsTUFBTSxDQUFDLElBQUksQ0FBQyx5Q0FBeUMsV0FBVyxDQUFDLGNBQWMsR0FBRyxDQUFDLENBQUM7WUFDcEYsV0FBVyxDQUFDLElBQUksQ0FBQyw0QkFBNEIsV0FBVyxDQUFDLGNBQWMsYUFBYSxDQUFDLENBQUM7UUFDeEYsQ0FBQztRQUVELE9BQU87WUFDTCxPQUFPLEVBQUUsTUFBTSxDQUFDLE1BQU0sS0FBSyxDQUFDO1lBQzVCLE1BQU07WUFDTixXQUFXO1NBQ1osQ0FBQztJQUNKLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxTQUFpQjtRQU8xQyxNQUFNLE9BQU8sR0FBRyxNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxDQUFDO1FBQ2hFLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQztZQUNiLE1BQU0sSUFBSSxLQUFLLENBQUMsc0JBQXNCLFNBQVMsRUFBRSxDQUFDLENBQUM7UUFDckQsQ0FBQztRQUVELE1BQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLE1BQU0sQ0FBQyxDQUFDO1FBQ3hGLE1BQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLElBQUksQ0FBQyxDQUFDO1FBRXBGLE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxPQUFPO1lBQzlCLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQyxTQUFTO1lBQ3JDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQztRQUVuQyxNQUFNLHFCQUFxQixHQUFHLFVBQVUsQ0FBQyxNQUFNLEdBQUcsQ0FBQztZQUNqRCxDQUFDLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLEVBQUUsRUFBRSxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsTUFBTTtZQUMvRSxDQUFDLENBQUMsQ0FBQyxDQUFDO1FBRU4sTUFBTSxlQUFlLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsbUJBQW1CLENBQUMsQ0FBQztRQUV4RSxnQ0FBZ0M7UUFDaEMsTUFBTSxlQUFlLEdBQUcsWUFBWSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxRQUFRLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxzQkFBc0I7UUFDbkcsTUFBTSxjQUFjLEdBQUcsZUFBZSxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxlQUFlLEdBQUcsR0FBRyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQztRQUUvRixPQUFPO1lBQ0wsU0FBUyxFQUFFLFlBQVksQ0FBQyxNQUFNO1lBQzlCLFFBQVEsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsRUFBRSxVQUFVO1lBQ2pELHFCQUFxQixFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMscUJBQXFCLENBQUM7WUFDeEQsZUFBZTtZQUNmLGNBQWM7U0FDZixDQUFDO0lBQ0osQ0FBQztDQUNGO0FBeGZELGdFQXdmQyIsInNvdXJjZXNDb250ZW50IjpbIi8qKlxuICogQ29udmVyc2F0aW9uIENvbnRleHQgTWFuYWdlciBmb3IgUHJvbXB0Q2FsbCBBSSBNVlBcbiAqIE1hbmFnZXMgY29udmVyc2F0aW9uIGNvbnRleHQsIEFJIHByb21wdHMsIGFuZCBzZXNzaW9uIHN0YXRlIGZvciBvcHRpbWFsIEFJIGludGVyYWN0aW9uc1xuICovXG5cbmltcG9ydCB7XG4gIENhbGxTZXNzaW9uLFxuICBDb252ZXJzYXRpb25FbnRyeSxcbiAgU2Vzc2lvblN0YXR1cyxcbiAgaXNTZXNzaW9uVGltZWRPdXQsXG4gIGlzU2Vzc2lvbk92ZXJEdXJhdGlvbixcbiAgU2Vzc2lvbkNvbmZpZyxcbiAgREVGQVVMVF9TRVNTSU9OX0NPTkZJRyxcbn0gZnJvbSAnLi4vdHlwZXMvc2Vzc2lvbic7XG5pbXBvcnQgeyBEeW5hbW9TZXNzaW9uTWFuYWdlciB9IGZyb20gJy4vZHluYW1vLXNlc3Npb24tbWFuYWdlcic7XG5cbi8qKlxuICogVXNlciBwcmVmZXJlbmNlcyBmb3IgY29udmVyc2F0aW9uIG1hbmFnZW1lbnRcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBVc2VyUHJlZmVyZW5jZXMge1xuICByZXNwb25zZUxlbmd0aDogJ3Nob3J0JyB8ICdtZWRpdW0nIHwgJ2xvbmcnO1xuICB0b3BpY3M6IHN0cmluZ1tdO1xuICBsYW5ndWFnZTogc3RyaW5nO1xuICB2b2ljZVNwZWVkOiAnc2xvdycgfCAnbm9ybWFsJyB8ICdmYXN0Jztcbn1cblxuLyoqXG4gKiBBSSBDb250ZXh0IGZvciBwcm9jZXNzaW5nIHVzZXIgcXVlcmllc1xuICovXG5leHBvcnQgaW50ZXJmYWNlIEFJQ29udGV4dCB7XG4gIHNlc3Npb25JZDogc3RyaW5nO1xuICBjb252ZXJzYXRpb25Db250ZXh0OiBzdHJpbmc7XG4gIHVzZXJQcmVmZXJlbmNlczogVXNlclByZWZlcmVuY2VzO1xuICBzeXN0ZW1Qcm9tcHQ6IHN0cmluZztcbiAgY29udmVyc2F0aW9uU3VtbWFyeT86IHN0cmluZztcbiAgbGFzdFVzZXJJbnRlbnQ/OiBzdHJpbmc7XG4gIGNvbnRleHRXaW5kb3c6IENvbnZlcnNhdGlvbkVudHJ5W107XG59XG5cbi8qKlxuICogU2Vzc2lvbiBzdGF0ZSBpbmZvcm1hdGlvbiBiZXlvbmQgYmFzaWMgc3RhdHVzXG4gKi9cbmV4cG9ydCBpbnRlcmZhY2UgU2Vzc2lvblN0YXRlIHtcbiAgc3RhdHVzOiBTZXNzaW9uU3RhdHVzO1xuICBwaGFzZTogJ2dyZWV0aW5nJyB8ICdjb252ZXJzYXRpb24nIHwgJ2NsYXJpZmljYXRpb24nIHwgJ2Nsb3NpbmcnO1xuICB0dXJuQ291bnQ6IG51bWJlcjtcbiAgbGFzdEFjdGl2aXR5OiBudW1iZXI7XG4gIGlzV2FpdGluZ0ZvclVzZXI6IGJvb2xlYW47XG4gIGhhc0Vycm9yczogYm9vbGVhbjtcbiAgZXJyb3JDb3VudDogbnVtYmVyO1xuICBhdmVyYWdlUmVzcG9uc2VUaW1lOiBudW1iZXI7XG4gIHVzZXJFbmdhZ2VtZW50OiAnaGlnaCcgfCAnbWVkaXVtJyB8ICdsb3cnO1xufVxuXG4vKipcbiAqIENvbmZpZ3VyYXRpb24gZm9yIGNvbnZlcnNhdGlvbiBjb250ZXh0IG1hbmFnZW1lbnRcbiAqL1xuZXhwb3J0IGludGVyZmFjZSBDb252ZXJzYXRpb25Db250ZXh0Q29uZmlnIHtcbiAgbWF4Q29udGV4dEVudHJpZXM6IG51bWJlcjtcbiAgbWF4Q29udGV4dExlbmd0aDogbnVtYmVyO1xuICBzdW1tYXJ5VGhyZXNob2xkOiBudW1iZXI7XG4gIHJlc3BvbnNlV29yZExpbWl0OiBudW1iZXI7XG4gIHNlc3Npb25Db25maWc6IFNlc3Npb25Db25maWc7XG59XG5cbi8qKlxuICogRGVmYXVsdCBjb25maWd1cmF0aW9uIGZvciBjb252ZXJzYXRpb24gY29udGV4dFxuICovXG5leHBvcnQgY29uc3QgREVGQVVMVF9DT05URVhUX0NPTkZJRzogQ29udmVyc2F0aW9uQ29udGV4dENvbmZpZyA9IHtcbiAgbWF4Q29udGV4dEVudHJpZXM6IDEwLCAvLyBLZWVwIGxhc3QgMTAgY29udmVyc2F0aW9uIHR1cm5zXG4gIG1heENvbnRleHRMZW5ndGg6IDIwMDAsIC8vIE1heCBjaGFyYWN0ZXJzIGluIGNvbnRleHQgc3RyaW5nXG4gIHN1bW1hcnlUaHJlc2hvbGQ6IDE1LCAvLyBTdW1tYXJpemUgYWZ0ZXIgMTUgZW50cmllc1xuICByZXNwb25zZVdvcmRMaW1pdDogMTUwLCAvLyBNYXggd29yZHMgaW4gQUkgcmVzcG9uc2UgKGZvciA2MC1zZWNvbmQgc3BlZWNoKVxuICBzZXNzaW9uQ29uZmlnOiBERUZBVUxUX1NFU1NJT05fQ09ORklHLFxufTtcblxuZXhwb3J0IGNsYXNzIENvbnZlcnNhdGlvbkNvbnRleHRNYW5hZ2VyIHtcbiAgcHJpdmF0ZSBzZXNzaW9uTWFuYWdlcjogRHluYW1vU2Vzc2lvbk1hbmFnZXI7XG4gIHByaXZhdGUgY29uZmlnOiBDb252ZXJzYXRpb25Db250ZXh0Q29uZmlnO1xuXG4gIGNvbnN0cnVjdG9yKFxuICAgIHNlc3Npb25NYW5hZ2VyOiBEeW5hbW9TZXNzaW9uTWFuYWdlcixcbiAgICBjb25maWc6IENvbnZlcnNhdGlvbkNvbnRleHRDb25maWcgPSBERUZBVUxUX0NPTlRFWFRfQ09ORklHXG4gICkge1xuICAgIHRoaXMuc2Vzc2lvbk1hbmFnZXIgPSBzZXNzaW9uTWFuYWdlcjtcbiAgICB0aGlzLmNvbmZpZyA9IGNvbmZpZztcbiAgfVxuXG4gIC8qKlxuICAgKiBJbml0aWFsaXplcyBhIG5ldyBjb252ZXJzYXRpb24gc2Vzc2lvbiB3aXRoIGdyZWV0aW5nIHBoYXNlXG4gICAqL1xuICBhc3luYyBpbml0aWFsaXplQ29udmVyc2F0aW9uKFxuICAgIGNhbGxTaWQ6IHN0cmluZyxcbiAgICBwaG9uZU51bWJlcjogc3RyaW5nLFxuICAgIHVzZXJQcmVmZXJlbmNlcz86IFBhcnRpYWw8VXNlclByZWZlcmVuY2VzPlxuICApOiBQcm9taXNlPHsgc2Vzc2lvbjogQ2FsbFNlc3Npb247IGNvbnRleHQ6IEFJQ29udGV4dCB9PiB7XG4gICAgLy8gQ3JlYXRlIG5ldyBzZXNzaW9uXG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IHRoaXMuc2Vzc2lvbk1hbmFnZXIuY3JlYXRlU2Vzc2lvbihjYWxsU2lkLCBwaG9uZU51bWJlcik7XG5cbiAgICAvLyBBZGQgc3lzdGVtIG1lc3NhZ2UgZm9yIGNvbnZlcnNhdGlvbiBzdGFydFxuICAgIGF3YWl0IHRoaXMuc2Vzc2lvbk1hbmFnZXIuYWRkU3lzdGVtTWVzc2FnZShcbiAgICAgIHNlc3Npb24uc2Vzc2lvbklkLFxuICAgICAgJ0NvbnZlcnNhdGlvbiBpbml0aWFsaXplZCAtIGdyZWV0aW5nIHBoYXNlJ1xuICAgICk7XG5cbiAgICAvLyBCdWlsZCBpbml0aWFsIEFJIGNvbnRleHRcbiAgICBjb25zdCBjb250ZXh0ID0gYXdhaXQgdGhpcy5idWlsZEFJQ29udGV4dChzZXNzaW9uLnNlc3Npb25JZCwgdXNlclByZWZlcmVuY2VzKTtcblxuICAgIHJldHVybiB7IHNlc3Npb24sIGNvbnRleHQgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBQcm9jZXNzZXMgYSB1c2VyIG1lc3NhZ2UgYW5kIHVwZGF0ZXMgY29udmVyc2F0aW9uIGNvbnRleHRcbiAgICovXG4gIGFzeW5jIHByb2Nlc3NVc2VyTWVzc2FnZShcbiAgICBzZXNzaW9uSWQ6IHN0cmluZyxcbiAgICB1c2VyVGV4dDogc3RyaW5nLFxuICAgIGF1ZGlvVXJsPzogc3RyaW5nLFxuICAgIGNvbmZpZGVuY2U/OiBudW1iZXJcbiAgKTogUHJvbWlzZTxBSUNvbnRleHQ+IHtcbiAgICAvLyBBZGQgdXNlciBtZXNzYWdlIHRvIHNlc3Npb25cbiAgICBhd2FpdCB0aGlzLnNlc3Npb25NYW5hZ2VyLmFkZFVzZXJNZXNzYWdlKHNlc3Npb25JZCwgdXNlclRleHQsIGF1ZGlvVXJsLCBjb25maWRlbmNlKTtcblxuICAgIC8vIFVwZGF0ZSBzZXNzaW9uIHN0YXRlXG4gICAgYXdhaXQgdGhpcy51cGRhdGVTZXNzaW9uU3RhdGUoc2Vzc2lvbklkLCB7XG4gICAgICBpc1dhaXRpbmdGb3JVc2VyOiBmYWxzZSxcbiAgICAgIGxhc3RBY3Rpdml0eTogRGF0ZS5ub3coKSxcbiAgICB9KTtcblxuICAgIC8vIEJ1aWxkIHVwZGF0ZWQgQUkgY29udGV4dFxuICAgIHJldHVybiB0aGlzLmJ1aWxkQUlDb250ZXh0KHNlc3Npb25JZCk7XG4gIH1cblxuICAvKipcbiAgICogUHJvY2Vzc2VzIGFuIEFJIHJlc3BvbnNlIGFuZCB1cGRhdGVzIGNvbnZlcnNhdGlvbiBjb250ZXh0XG4gICAqL1xuICBhc3luYyBwcm9jZXNzQUlSZXNwb25zZShcbiAgICBzZXNzaW9uSWQ6IHN0cmluZyxcbiAgICBhaVRleHQ6IHN0cmluZyxcbiAgICBhdWRpb1VybD86IHN0cmluZyxcbiAgICBwcm9jZXNzaW5nRHVyYXRpb24/OiBudW1iZXJcbiAgKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgLy8gQWRkIEFJIHJlc3BvbnNlIHRvIHNlc3Npb25cbiAgICBhd2FpdCB0aGlzLnNlc3Npb25NYW5hZ2VyLmFkZEFpUmVzcG9uc2Uoc2Vzc2lvbklkLCBhaVRleHQsIGF1ZGlvVXJsLCBwcm9jZXNzaW5nRHVyYXRpb24pO1xuXG4gICAgLy8gVXBkYXRlIHNlc3Npb24gc3RhdGVcbiAgICBhd2FpdCB0aGlzLnVwZGF0ZVNlc3Npb25TdGF0ZShzZXNzaW9uSWQsIHtcbiAgICAgIGlzV2FpdGluZ0ZvclVzZXI6IHRydWUsXG4gICAgICBsYXN0QWN0aXZpdHk6IERhdGUubm93KCksXG4gICAgfSk7XG5cbiAgICAvLyBVcGRhdGUgY29udmVyc2F0aW9uIHBoYXNlIGJhc2VkIG9uIGNvbnRlbnRcbiAgICBhd2FpdCB0aGlzLnVwZGF0ZUNvbnZlcnNhdGlvblBoYXNlKHNlc3Npb25JZCwgYWlUZXh0KTtcbiAgfVxuXG4gIC8qKlxuICAgKiBCdWlsZHMgY29tcHJlaGVuc2l2ZSBBSSBjb250ZXh0IGZvciBwcm9jZXNzaW5nIHVzZXIgcXVlcmllc1xuICAgKi9cbiAgYXN5bmMgYnVpbGRBSUNvbnRleHQoXG4gICAgc2Vzc2lvbklkOiBzdHJpbmcsXG4gICAgdXNlclByZWZlcmVuY2VzPzogUGFydGlhbDxVc2VyUHJlZmVyZW5jZXM+XG4gICk6IFByb21pc2U8QUlDb250ZXh0PiB7XG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IHRoaXMuc2Vzc2lvbk1hbmFnZXIuZ2V0U2Vzc2lvbihzZXNzaW9uSWQpO1xuICAgIGlmICghc2Vzc2lvbikge1xuICAgICAgdGhyb3cgbmV3IEVycm9yKGBTZXNzaW9uIG5vdCBmb3VuZDogJHtzZXNzaW9uSWR9YCk7XG4gICAgfVxuXG4gICAgLy8gR2V0IGNvbnZlcnNhdGlvbiBoaXN0b3J5IHdpdGggY29udGV4dCB3aW5kb3dcbiAgICBjb25zdCBjb250ZXh0V2luZG93ID0gdGhpcy5nZXRDb250ZXh0V2luZG93KHNlc3Npb24uY29udmVyc2F0aW9uSGlzdG9yeSk7XG5cbiAgICAvLyBCdWlsZCBjb252ZXJzYXRpb24gY29udGV4dCBzdHJpbmdcbiAgICBjb25zdCBjb252ZXJzYXRpb25Db250ZXh0ID0gdGhpcy5idWlsZENvbnRleHRTdHJpbmcoY29udGV4dFdpbmRvdyk7XG5cbiAgICAvLyBEZXRlcm1pbmUgdXNlciBwcmVmZXJlbmNlc1xuICAgIGNvbnN0IHByZWZlcmVuY2VzID0gdGhpcy5idWlsZFVzZXJQcmVmZXJlbmNlcyhzZXNzaW9uLCB1c2VyUHJlZmVyZW5jZXMpO1xuXG4gICAgLy8gR2VuZXJhdGUgc3lzdGVtIHByb21wdCBiYXNlZCBvbiBjb252ZXJzYXRpb24gcGhhc2VcbiAgICBjb25zdCBzeXN0ZW1Qcm9tcHQgPSB0aGlzLmdlbmVyYXRlU3lzdGVtUHJvbXB0KHNlc3Npb24sIHByZWZlcmVuY2VzKTtcblxuICAgIC8vIEV4dHJhY3QgY29udmVyc2F0aW9uIHN1bW1hcnkgYW5kIHVzZXIgaW50ZW50XG4gICAgY29uc3QgY29udmVyc2F0aW9uU3VtbWFyeSA9IHRoaXMuZ2VuZXJhdGVDb252ZXJzYXRpb25TdW1tYXJ5KGNvbnRleHRXaW5kb3cpO1xuICAgIGNvbnN0IGxhc3RVc2VySW50ZW50ID0gdGhpcy5leHRyYWN0VXNlckludGVudChjb250ZXh0V2luZG93KTtcblxuICAgIHJldHVybiB7XG4gICAgICBzZXNzaW9uSWQsXG4gICAgICBjb252ZXJzYXRpb25Db250ZXh0LFxuICAgICAgdXNlclByZWZlcmVuY2VzOiBwcmVmZXJlbmNlcyxcbiAgICAgIHN5c3RlbVByb21wdCxcbiAgICAgIGNvbnZlcnNhdGlvblN1bW1hcnksXG4gICAgICBsYXN0VXNlckludGVudCxcbiAgICAgIGNvbnRleHRXaW5kb3csXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBHZXRzIHRoZSByZWxldmFudCBjb250ZXh0IHdpbmRvdyBmcm9tIGNvbnZlcnNhdGlvbiBoaXN0b3J5XG4gICAqL1xuICBwcml2YXRlIGdldENvbnRleHRXaW5kb3coY29udmVyc2F0aW9uSGlzdG9yeTogQ29udmVyc2F0aW9uRW50cnlbXSk6IENvbnZlcnNhdGlvbkVudHJ5W10ge1xuICAgIC8vIEdldCB0aGUgbW9zdCByZWNlbnQgZW50cmllcyB3aXRoaW4gbGltaXRzXG4gICAgY29uc3QgcmVjZW50RW50cmllcyA9IGNvbnZlcnNhdGlvbkhpc3Rvcnkuc2xpY2UoLXRoaXMuY29uZmlnLm1heENvbnRleHRFbnRyaWVzKTtcblxuICAgIC8vIEZpbHRlciBvdXQgc3lzdGVtIG1lc3NhZ2VzIGZvciBBSSBjb250ZXh0IChrZWVwIHVzZXIgYW5kIEFJIG9ubHkpXG4gICAgcmV0dXJuIHJlY2VudEVudHJpZXMuZmlsdGVyKGVudHJ5ID0+IGVudHJ5LnR5cGUgPT09ICd1c2VyJyB8fCBlbnRyeS50eXBlID09PSAnYWknKTtcbiAgfVxuXG4gIC8qKlxuICAgKiBCdWlsZHMgYSBmb3JtYXR0ZWQgY29udGV4dCBzdHJpbmcgZm9yIEFJIHByb2Nlc3NpbmdcbiAgICovXG4gIHByaXZhdGUgYnVpbGRDb250ZXh0U3RyaW5nKGNvbnRleHRXaW5kb3c6IENvbnZlcnNhdGlvbkVudHJ5W10pOiBzdHJpbmcge1xuICAgIGlmIChjb250ZXh0V2luZG93Lmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuICdUaGlzIGlzIHRoZSBzdGFydCBvZiBhIG5ldyBjb252ZXJzYXRpb24uJztcbiAgICB9XG5cbiAgICBjb25zdCBjb250ZXh0TGluZXMgPSBjb250ZXh0V2luZG93Lm1hcChlbnRyeSA9PiB7XG4gICAgICBjb25zdCBzcGVha2VyID0gZW50cnkudHlwZSA9PT0gJ3VzZXInID8gJ1VzZXInIDogJ0Fzc2lzdGFudCc7XG4gICAgICBjb25zdCB0aW1lc3RhbXAgPSBuZXcgRGF0ZShlbnRyeS50aW1lc3RhbXApLnRvSVNPU3RyaW5nKCk7XG4gICAgICByZXR1cm4gYFske3RpbWVzdGFtcH1dICR7c3BlYWtlcn06ICR7ZW50cnkudGV4dH1gO1xuICAgIH0pO1xuXG4gICAgbGV0IGNvbnRleHRTdHJpbmcgPSBjb250ZXh0TGluZXMuam9pbignXFxuJyk7XG5cbiAgICAvLyBUcnVuY2F0ZSBpZiB0b28gbG9uZ1xuICAgIGlmIChjb250ZXh0U3RyaW5nLmxlbmd0aCA+IHRoaXMuY29uZmlnLm1heENvbnRleHRMZW5ndGgpIHtcbiAgICAgIGNvbnRleHRTdHJpbmcgPSBjb250ZXh0U3RyaW5nLnN1YnN0cmluZygwLCB0aGlzLmNvbmZpZy5tYXhDb250ZXh0TGVuZ3RoKSArICcuLi4nO1xuICAgIH1cblxuICAgIHJldHVybiBjb250ZXh0U3RyaW5nO1xuICB9XG5cbiAgLyoqXG4gICAqIEJ1aWxkcyB1c2VyIHByZWZlcmVuY2VzIGZyb20gc2Vzc2lvbiBkYXRhIGFuZCBvdmVycmlkZXNcbiAgICovXG4gIHByaXZhdGUgYnVpbGRVc2VyUHJlZmVyZW5jZXMoXG4gICAgc2Vzc2lvbjogQ2FsbFNlc3Npb24sXG4gICAgb3ZlcnJpZGVzPzogUGFydGlhbDxVc2VyUHJlZmVyZW5jZXM+XG4gICk6IFVzZXJQcmVmZXJlbmNlcyB7XG4gICAgLy8gRGVmYXVsdCBwcmVmZXJlbmNlc1xuICAgIGNvbnN0IGRlZmF1bHRzOiBVc2VyUHJlZmVyZW5jZXMgPSB7XG4gICAgICByZXNwb25zZUxlbmd0aDogJ21lZGl1bScsXG4gICAgICB0b3BpY3M6IFtdLFxuICAgICAgbGFuZ3VhZ2U6ICdlbicsXG4gICAgICB2b2ljZVNwZWVkOiAnbm9ybWFsJyxcbiAgICB9O1xuXG4gICAgLy8gSW5mZXIgcHJlZmVyZW5jZXMgZnJvbSBjb252ZXJzYXRpb24gaGlzdG9yeVxuICAgIGNvbnN0IGluZmVycmVkID0gdGhpcy5pbmZlclVzZXJQcmVmZXJlbmNlcyhzZXNzaW9uLmNvbnZlcnNhdGlvbkhpc3RvcnkpO1xuXG4gICAgLy8gTWVyZ2UgZGVmYXVsdHMsIGluZmVycmVkLCBhbmQgb3ZlcnJpZGVzXG4gICAgcmV0dXJuIHtcbiAgICAgIC4uLmRlZmF1bHRzLFxuICAgICAgLi4uaW5mZXJyZWQsXG4gICAgICAuLi5vdmVycmlkZXMsXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBJbmZlcnMgdXNlciBwcmVmZXJlbmNlcyBmcm9tIGNvbnZlcnNhdGlvbiBwYXR0ZXJuc1xuICAgKi9cbiAgcHJpdmF0ZSBpbmZlclVzZXJQcmVmZXJlbmNlcyhjb252ZXJzYXRpb25IaXN0b3J5OiBDb252ZXJzYXRpb25FbnRyeVtdKTogUGFydGlhbDxVc2VyUHJlZmVyZW5jZXM+IHtcbiAgICBjb25zdCBwcmVmZXJlbmNlczogUGFydGlhbDxVc2VyUHJlZmVyZW5jZXM+ID0ge307XG5cbiAgICAvLyBBbmFseXplIGNvbnZlcnNhdGlvbiBsZW5ndGggcHJlZmVyZW5jZXNcbiAgICBjb25zdCB1c2VyTWVzc2FnZXMgPSBjb252ZXJzYXRpb25IaXN0b3J5LmZpbHRlcihlbnRyeSA9PiBlbnRyeS50eXBlID09PSAndXNlcicpO1xuICAgIGNvbnN0IGF2Z1VzZXJNZXNzYWdlTGVuZ3RoID0gdXNlck1lc3NhZ2VzLnJlZHVjZSgoc3VtLCBtc2cpID0+IHN1bSArIG1zZy50ZXh0Lmxlbmd0aCwgMCkgLyB1c2VyTWVzc2FnZXMubGVuZ3RoO1xuXG4gICAgaWYgKGF2Z1VzZXJNZXNzYWdlTGVuZ3RoIDwgNTApIHtcbiAgICAgIHByZWZlcmVuY2VzLnJlc3BvbnNlTGVuZ3RoID0gJ3Nob3J0JztcbiAgICB9IGVsc2UgaWYgKGF2Z1VzZXJNZXNzYWdlTGVuZ3RoID4gMTUwKSB7XG4gICAgICBwcmVmZXJlbmNlcy5yZXNwb25zZUxlbmd0aCA9ICdsb25nJztcbiAgICB9IGVsc2Uge1xuICAgICAgcHJlZmVyZW5jZXMucmVzcG9uc2VMZW5ndGggPSAnbWVkaXVtJztcbiAgICB9XG5cbiAgICAvLyBFeHRyYWN0IHRvcGljcyBmcm9tIGNvbnZlcnNhdGlvblxuICAgIGNvbnN0IHRvcGljcyA9IHRoaXMuZXh0cmFjdFRvcGljcyhjb252ZXJzYXRpb25IaXN0b3J5KTtcbiAgICBpZiAodG9waWNzLmxlbmd0aCA+IDApIHtcbiAgICAgIHByZWZlcmVuY2VzLnRvcGljcyA9IHRvcGljcztcbiAgICB9XG5cbiAgICByZXR1cm4gcHJlZmVyZW5jZXM7XG4gIH1cblxuICAvKipcbiAgICogR2VuZXJhdGVzIHN5c3RlbSBwcm9tcHQgYmFzZWQgb24gY29udmVyc2F0aW9uIHBoYXNlIGFuZCBwcmVmZXJlbmNlc1xuICAgKi9cbiAgcHJpdmF0ZSBnZW5lcmF0ZVN5c3RlbVByb21wdChzZXNzaW9uOiBDYWxsU2Vzc2lvbiwgcHJlZmVyZW5jZXM6IFVzZXJQcmVmZXJlbmNlcyk6IHN0cmluZyB7XG4gICAgY29uc3QgYmFzZVByb21wdCA9IGBZb3UgYXJlIGEgaGVscGZ1bCBBSSBhc3Npc3RhbnQgYWNjZXNzaWJsZSB2aWEgcGhvbmUgY2FsbC4gXG5Zb3UgYXJlIHNwZWFraW5nIHRvIHNvbWVvbmUgd2hvIGNhbGxlZCBhIHBob25lIG51bWJlciB0byBnZXQgQUkgYXNzaXN0YW5jZS5cbktlZXAgcmVzcG9uc2VzIGNvbnZlcnNhdGlvbmFsLCBjbGVhciwgYW5kIG9wdGltaXplZCBmb3Igdm9pY2UgY29tbXVuaWNhdGlvbi5gO1xuXG4gICAgY29uc3QgbGVuZ3RoR3VpZGFuY2UgPSB7XG4gICAgICBzaG9ydDogJ0tlZXAgcmVzcG9uc2VzIHZlcnkgYnJpZWYgKDEtMiBzZW50ZW5jZXMsIG1heCA1MCB3b3JkcykuJyxcbiAgICAgIG1lZGl1bTogJ0tlZXAgcmVzcG9uc2VzIGNvbmNpc2UgYnV0IGNvbXBsZXRlICgyLTQgc2VudGVuY2VzLCBtYXggMTAwIHdvcmRzKS4nLFxuICAgICAgbG9uZzogJ1Byb3ZpZGUgZGV0YWlsZWQgcmVzcG9uc2VzIHdoZW4gbmVlZGVkIChtYXggMTUwIHdvcmRzIGZvciA2MC1zZWNvbmQgc3BlZWNoIGxpbWl0KS4nLFxuICAgIH07XG5cbiAgICBjb25zdCBwaGFzZUd1aWRhbmNlID0gdGhpcy5nZXRQaGFzZUd1aWRhbmNlKHNlc3Npb24pO1xuXG4gICAgcmV0dXJuIGAke2Jhc2VQcm9tcHR9XG5cbiR7bGVuZ3RoR3VpZGFuY2VbcHJlZmVyZW5jZXMucmVzcG9uc2VMZW5ndGhdfVxuXG4ke3BoYXNlR3VpZGFuY2V9XG5cbkltcG9ydGFudCBndWlkZWxpbmVzOlxuLSBTcGVhayBuYXR1cmFsbHkgYXMgaWYgaGF2aW5nIGEgcGhvbmUgY29udmVyc2F0aW9uXG4tIFVzZSBzaW1wbGUsIGNsZWFyIGxhbmd1YWdlIHRoYXQncyBlYXN5IHRvIHVuZGVyc3RhbmQgb3ZlciB0aGUgcGhvbmVcbi0gQXNrIGNsYXJpZnlpbmcgcXVlc3Rpb25zIGlmIHRoZSB1c2VyJ3MgcmVxdWVzdCBpcyB1bmNsZWFyXG4tIEJlIGhlbHBmdWwgYW5kIHN1cHBvcnRpdmVcbi0gUmVtZW1iZXIgdGhpcyBpcyBhIHZvaWNlLW9ubHkgaW50ZXJhY3Rpb24gLSBubyB2aXN1YWwgZWxlbWVudHNcbi0gS2VlcCB0cmFjayBvZiB0aGUgY29udmVyc2F0aW9uIGNvbnRleHQgYW5kIHJlZmVyIGJhY2sgdG8gcHJldmlvdXMgdG9waWNzIHdoZW4gcmVsZXZhbnRgO1xuICB9XG5cbiAgLyoqXG4gICAqIEdldHMgcGhhc2Utc3BlY2lmaWMgZ3VpZGFuY2UgZm9yIHRoZSBzeXN0ZW0gcHJvbXB0XG4gICAqL1xuICBwcml2YXRlIGdldFBoYXNlR3VpZGFuY2Uoc2Vzc2lvbjogQ2FsbFNlc3Npb24pOiBzdHJpbmcge1xuICAgIGNvbnN0IHR1cm5Db3VudCA9IHNlc3Npb24uY29udmVyc2F0aW9uSGlzdG9yeS5maWx0ZXIoZW50cnkgPT4gZW50cnkudHlwZSA9PT0gJ3VzZXInKS5sZW5ndGg7XG5cbiAgICBpZiAodHVybkNvdW50ID09PSAwKSB7XG4gICAgICByZXR1cm4gJ1RoaXMgaXMgdGhlIHN0YXJ0IG9mIHRoZSBjb252ZXJzYXRpb24uIEdyZWV0IHRoZSB1c2VyIHdhcm1seSBhbmQgYXNrIGhvdyB5b3UgY2FuIGhlbHAgdGhlbSB0b2RheS4nO1xuICAgIH0gZWxzZSBpZiAodHVybkNvdW50IDwgMykge1xuICAgICAgcmV0dXJuICdZb3UgYXJlIGluIHRoZSBlYXJseSBjb252ZXJzYXRpb24gcGhhc2UuIEZvY3VzIG9uIHVuZGVyc3RhbmRpbmcgd2hhdCB0aGUgdXNlciBuZWVkcyBoZWxwIHdpdGguJztcbiAgICB9IGVsc2UgaWYgKHR1cm5Db3VudCA8IDEwKSB7XG4gICAgICByZXR1cm4gJ1lvdSBhcmUgaW4gYW4gYWN0aXZlIGNvbnZlcnNhdGlvbi4gUHJvdmlkZSBoZWxwZnVsIHJlc3BvbnNlcyBhbmQgbWFpbnRhaW4gZW5nYWdlbWVudC4nO1xuICAgIH0gZWxzZSB7XG4gICAgICByZXR1cm4gJ1RoaXMgaXMgYW4gZXh0ZW5kZWQgY29udmVyc2F0aW9uLiBDb25zaWRlciBzdW1tYXJpemluZyBrZXkgcG9pbnRzIGFuZCBjaGVja2luZyBpZiB0aGUgdXNlciBuZWVkcyBhbnl0aGluZyBlbHNlLic7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEdlbmVyYXRlcyBhIGNvbnZlcnNhdGlvbiBzdW1tYXJ5IGZvciBjb250ZXh0XG4gICAqL1xuICBwcml2YXRlIGdlbmVyYXRlQ29udmVyc2F0aW9uU3VtbWFyeShjb250ZXh0V2luZG93OiBDb252ZXJzYXRpb25FbnRyeVtdKTogc3RyaW5nIHtcbiAgICBpZiAoY29udGV4dFdpbmRvdy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiAnTm8gY29udmVyc2F0aW9uIGhpc3RvcnkgeWV0Lic7XG4gICAgfVxuXG4gICAgY29uc3QgdXNlck1lc3NhZ2VzID0gY29udGV4dFdpbmRvdy5maWx0ZXIoZW50cnkgPT4gZW50cnkudHlwZSA9PT0gJ3VzZXInKTtcbiAgICBjb25zdCBhaU1lc3NhZ2VzID0gY29udGV4dFdpbmRvdy5maWx0ZXIoZW50cnkgPT4gZW50cnkudHlwZSA9PT0gJ2FpJyk7XG5cbiAgICBpZiAodXNlck1lc3NhZ2VzLmxlbmd0aCA9PT0gMCkge1xuICAgICAgcmV0dXJuICdVc2VyIGhhcyBub3Qgc3Bva2VuIHlldC4nO1xuICAgIH1cblxuICAgIGNvbnN0IHRvcGljcyA9IHRoaXMuZXh0cmFjdFRvcGljcyhjb250ZXh0V2luZG93KTtcbiAgICBjb25zdCB0b3BpY1N1bW1hcnkgPSB0b3BpY3MubGVuZ3RoID4gMCA/IGBUb3BpY3MgZGlzY3Vzc2VkOiAke3RvcGljcy5qb2luKCcsICcpfWAgOiAnR2VuZXJhbCBjb252ZXJzYXRpb24nO1xuXG4gICAgcmV0dXJuIGBDb252ZXJzYXRpb24gd2l0aCAke3VzZXJNZXNzYWdlcy5sZW5ndGh9IHVzZXIgbWVzc2FnZXMgYW5kICR7YWlNZXNzYWdlcy5sZW5ndGh9IEFJIHJlc3BvbnNlcy4gJHt0b3BpY1N1bW1hcnl9YDtcbiAgfVxuXG4gIC8qKlxuICAgKiBFeHRyYWN0cyB0aGUgdXNlcidzIGxpa2VseSBpbnRlbnQgZnJvbSByZWNlbnQgbWVzc2FnZXNcbiAgICovXG4gIHByaXZhdGUgZXh0cmFjdFVzZXJJbnRlbnQoY29udGV4dFdpbmRvdzogQ29udmVyc2F0aW9uRW50cnlbXSk6IHN0cmluZyB7XG4gICAgY29uc3QgcmVjZW50VXNlck1lc3NhZ2VzID0gY29udGV4dFdpbmRvd1xuICAgICAgLmZpbHRlcihlbnRyeSA9PiBlbnRyeS50eXBlID09PSAndXNlcicpXG4gICAgICAuc2xpY2UoLTIpOyAvLyBMYXN0IDIgdXNlciBtZXNzYWdlc1xuXG4gICAgaWYgKHJlY2VudFVzZXJNZXNzYWdlcy5sZW5ndGggPT09IDApIHtcbiAgICAgIHJldHVybiAndW5rbm93bic7XG4gICAgfVxuXG4gICAgY29uc3QgbGFzdE1lc3NhZ2UgPSByZWNlbnRVc2VyTWVzc2FnZXNbcmVjZW50VXNlck1lc3NhZ2VzLmxlbmd0aCAtIDFdLnRleHQudG9Mb3dlckNhc2UoKTtcblxuICAgIC8vIFNpbXBsZSBpbnRlbnQgY2xhc3NpZmljYXRpb25cbiAgICBpZiAobGFzdE1lc3NhZ2UuaW5jbHVkZXMoJ2hlbHAnKSB8fCBsYXN0TWVzc2FnZS5pbmNsdWRlcygnaG93JykpIHtcbiAgICAgIHJldHVybiAnc2Vla2luZ19oZWxwJztcbiAgICB9IGVsc2UgaWYgKGxhc3RNZXNzYWdlLmluY2x1ZGVzKCd0aGFuaycpIHx8IGxhc3RNZXNzYWdlLmluY2x1ZGVzKCdieWUnKSkge1xuICAgICAgcmV0dXJuICdlbmRpbmdfY29udmVyc2F0aW9uJztcbiAgICB9IGVsc2UgaWYgKGxhc3RNZXNzYWdlLmluY2x1ZGVzKCc/JykpIHtcbiAgICAgIHJldHVybiAnYXNraW5nX3F1ZXN0aW9uJztcbiAgICB9IGVsc2UgaWYgKGxhc3RNZXNzYWdlLmluY2x1ZGVzKCd0ZWxsIG1lJykgfHwgbGFzdE1lc3NhZ2UuaW5jbHVkZXMoJ3doYXQgaXMnKSkge1xuICAgICAgcmV0dXJuICdyZXF1ZXN0aW5nX2luZm9ybWF0aW9uJztcbiAgICB9IGVsc2Uge1xuICAgICAgcmV0dXJuICdnZW5lcmFsX2NvbnZlcnNhdGlvbic7XG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIEV4dHJhY3RzIHRvcGljcyBmcm9tIGNvbnZlcnNhdGlvbiBoaXN0b3J5XG4gICAqL1xuICBwcml2YXRlIGV4dHJhY3RUb3BpY3MoY29udmVyc2F0aW9uSGlzdG9yeTogQ29udmVyc2F0aW9uRW50cnlbXSk6IHN0cmluZ1tdIHtcbiAgICBjb25zdCB0b3BpY3M6IHN0cmluZ1tdID0gW107XG4gICAgY29uc3QgdGV4dCA9IGNvbnZlcnNhdGlvbkhpc3RvcnkubWFwKGVudHJ5ID0+IGVudHJ5LnRleHQpLmpvaW4oJyAnKS50b0xvd2VyQ2FzZSgpO1xuXG4gICAgLy8gU2ltcGxlIGtleXdvcmQtYmFzZWQgdG9waWMgZXh0cmFjdGlvblxuICAgIGNvbnN0IHRvcGljS2V5d29yZHMgPSB7XG4gICAgICB3ZWF0aGVyOiBbJ3dlYXRoZXInLCAndGVtcGVyYXR1cmUnLCAncmFpbicsICdzdW5ueScsICdjbG91ZHknXSxcbiAgICAgIHRlY2hub2xvZ3k6IFsnY29tcHV0ZXInLCAnc29mdHdhcmUnLCAnYXBwJywgJ3dlYnNpdGUnLCAndGVjaCddLFxuICAgICAgaGVhbHRoOiBbJ2hlYWx0aCcsICdkb2N0b3InLCAnbWVkaWNpbmUnLCAnc2ljaycsICdwYWluJ10sXG4gICAgICB0cmF2ZWw6IFsndHJhdmVsJywgJ3RyaXAnLCAndmFjYXRpb24nLCAnZmxpZ2h0JywgJ2hvdGVsJ10sXG4gICAgICBmb29kOiBbJ2Zvb2QnLCAncmVjaXBlJywgJ2Nvb2tpbmcnLCAncmVzdGF1cmFudCcsICdlYXQnXSxcbiAgICAgIGJ1c2luZXNzOiBbJ2J1c2luZXNzJywgJ3dvcmsnLCAnam9iJywgJ2NhcmVlcicsICdjb21wYW55J10sXG4gICAgfTtcblxuICAgIGZvciAoY29uc3QgW3RvcGljLCBrZXl3b3Jkc10gb2YgT2JqZWN0LmVudHJpZXModG9waWNLZXl3b3JkcykpIHtcbiAgICAgIGlmIChrZXl3b3Jkcy5zb21lKGtleXdvcmQgPT4gdGV4dC5pbmNsdWRlcyhrZXl3b3JkKSkpIHtcbiAgICAgICAgdG9waWNzLnB1c2godG9waWMpO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB0b3BpY3M7XG4gIH1cblxuICAvKipcbiAgICogVXBkYXRlcyBzZXNzaW9uIHN0YXRlIHdpdGggbmV3IGluZm9ybWF0aW9uXG4gICAqL1xuICBwcml2YXRlIGFzeW5jIHVwZGF0ZVNlc3Npb25TdGF0ZShcbiAgICBzZXNzaW9uSWQ6IHN0cmluZyxcbiAgICBzdGF0ZVVwZGF0ZXM6IFBhcnRpYWw8U2Vzc2lvblN0YXRlPlxuICApOiBQcm9taXNlPHZvaWQ+IHtcbiAgICAvLyBUaGlzIHdvdWxkIHR5cGljYWxseSB1cGRhdGUgYSBzZXBhcmF0ZSBzZXNzaW9uIHN0YXRlIHJlY29yZFxuICAgIC8vIEZvciBub3csIHdlJ2xsIHVzZSB0aGUgc2Vzc2lvbidzIGxhc3RBY3Rpdml0eSBmaWVsZFxuICAgIGlmIChzdGF0ZVVwZGF0ZXMubGFzdEFjdGl2aXR5KSB7XG4gICAgICAvLyBUaGUgc2Vzc2lvbiBtYW5hZ2VyIGFscmVhZHkgdXBkYXRlcyBsYXN0QWN0aXZpdHkgaW4gY29udmVyc2F0aW9uIG1ldGhvZHNcbiAgICAgIC8vIEFkZGl0aW9uYWwgc3RhdGUgbWFuYWdlbWVudCBjb3VsZCBiZSBhZGRlZCBoZXJlXG4gICAgfVxuICB9XG5cbiAgLyoqXG4gICAqIFVwZGF0ZXMgY29udmVyc2F0aW9uIHBoYXNlIGJhc2VkIG9uIEFJIHJlc3BvbnNlIGNvbnRlbnRcbiAgICovXG4gIHByaXZhdGUgYXN5bmMgdXBkYXRlQ29udmVyc2F0aW9uUGhhc2Uoc2Vzc2lvbklkOiBzdHJpbmcsIGFpVGV4dDogc3RyaW5nKTogUHJvbWlzZTx2b2lkPiB7XG4gICAgY29uc3QgbG93ZXJUZXh0ID0gYWlUZXh0LnRvTG93ZXJDYXNlKCk7XG5cbiAgICBpZiAobG93ZXJUZXh0LmluY2x1ZGVzKCdoZWxsbycpIHx8IGxvd2VyVGV4dC5pbmNsdWRlcygnd2VsY29tZScpKSB7XG4gICAgICAvLyBTdGlsbCBpbiBncmVldGluZyBwaGFzZVxuICAgIH0gZWxzZSBpZiAobG93ZXJUZXh0LmluY2x1ZGVzKCdnb29kYnllJykgfHwgbG93ZXJUZXh0LmluY2x1ZGVzKCd0aGFuayB5b3UgZm9yIGNhbGxpbmcnKSkge1xuICAgICAgLy8gTW92aW5nIHRvIGNsb3NpbmcgcGhhc2VcbiAgICB9IGVsc2UgaWYgKGxvd2VyVGV4dC5pbmNsdWRlcygnY291bGQgeW91IGNsYXJpZnknKSB8fCBsb3dlclRleHQuaW5jbHVkZXMoJ3doYXQgZG8geW91IG1lYW4nKSkge1xuICAgICAgLy8gSW4gY2xhcmlmaWNhdGlvbiBwaGFzZVxuICAgIH0gZWxzZSB7XG4gICAgICAvLyBBY3RpdmUgY29udmVyc2F0aW9uIHBoYXNlXG4gICAgfVxuXG4gICAgLy8gQWRkIHN5c3RlbSBtZXNzYWdlIHRvIHRyYWNrIHBoYXNlIGNoYW5nZXNcbiAgICAvLyBUaGlzIGNvdWxkIGJlIGVuaGFuY2VkIHdpdGggbW9yZSBzb3BoaXN0aWNhdGVkIHBoYXNlIHRyYWNraW5nXG4gIH1cblxuICAvKipcbiAgICogQ2hlY2tzIGlmIHNlc3Npb24gbmVlZHMgYXR0ZW50aW9uICh0aW1lb3V0LCBlcnJvcnMsIGV0Yy4pXG4gICAqL1xuICBhc3luYyBjaGVja1Nlc3Npb25IZWFsdGgoc2Vzc2lvbklkOiBzdHJpbmcpOiBQcm9taXNlPHtcbiAgICBuZWVkc0F0dGVudGlvbjogYm9vbGVhbjtcbiAgICByZWFzb25zOiBzdHJpbmdbXTtcbiAgICByZWNvbW1lbmRhdGlvbnM6IHN0cmluZ1tdO1xuICB9PiB7XG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IHRoaXMuc2Vzc2lvbk1hbmFnZXIuZ2V0U2Vzc2lvbihzZXNzaW9uSWQpO1xuICAgIGlmICghc2Vzc2lvbikge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgbmVlZHNBdHRlbnRpb246IHRydWUsXG4gICAgICAgIHJlYXNvbnM6IFsnU2Vzc2lvbiBub3QgZm91bmQnXSxcbiAgICAgICAgcmVjb21tZW5kYXRpb25zOiBbJ0NyZWF0ZSBuZXcgc2Vzc2lvbiddLFxuICAgICAgfTtcbiAgICB9XG5cbiAgICBjb25zdCByZWFzb25zOiBzdHJpbmdbXSA9IFtdO1xuICAgIGNvbnN0IHJlY29tbWVuZGF0aW9uczogc3RyaW5nW10gPSBbXTtcblxuICAgIC8vIENoZWNrIGZvciB0aW1lb3V0XG4gICAgaWYgKGlzU2Vzc2lvblRpbWVkT3V0KHNlc3Npb24sIHRoaXMuY29uZmlnLnNlc3Npb25Db25maWcpKSB7XG4gICAgICByZWFzb25zLnB1c2goJ1Nlc3Npb24gdGltZWQgb3V0IGR1ZSB0byBpbmFjdGl2aXR5Jyk7XG4gICAgICByZWNvbW1lbmRhdGlvbnMucHVzaCgnU2VuZCB0aW1lb3V0IHByb21wdCBvciBlbmQgc2Vzc2lvbiBncmFjZWZ1bGx5Jyk7XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgZm9yIGR1cmF0aW9uIGxpbWl0XG4gICAgaWYgKGlzU2Vzc2lvbk92ZXJEdXJhdGlvbihzZXNzaW9uLCB0aGlzLmNvbmZpZy5zZXNzaW9uQ29uZmlnKSkge1xuICAgICAgcmVhc29ucy5wdXNoKCdTZXNzaW9uIGV4Y2VlZGVkIG1heGltdW0gZHVyYXRpb24nKTtcbiAgICAgIHJlY29tbWVuZGF0aW9ucy5wdXNoKCdTdWdnZXN0IHdyYXBwaW5nIHVwIHRoZSBjb252ZXJzYXRpb24nKTtcbiAgICB9XG5cbiAgICAvLyBDaGVjayBjb252ZXJzYXRpb24gbGVuZ3RoXG4gICAgaWYgKHNlc3Npb24uY29udmVyc2F0aW9uSGlzdG9yeS5sZW5ndGggPiB0aGlzLmNvbmZpZy5zdW1tYXJ5VGhyZXNob2xkKSB7XG4gICAgICByZWFzb25zLnB1c2goJ0xvbmcgY29udmVyc2F0aW9uIG1heSBuZWVkIHN1bW1hcml6YXRpb24nKTtcbiAgICAgIHJlY29tbWVuZGF0aW9ucy5wdXNoKCdQcm92aWRlIGNvbnZlcnNhdGlvbiBzdW1tYXJ5IGFuZCBjaGVjayBpZiB1c2VyIG5lZWRzIG1vcmUgaGVscCcpO1xuICAgIH1cblxuICAgIC8vIENoZWNrIGZvciByZXBlYXRlZCBlcnJvcnNcbiAgICBjb25zdCByZWNlbnRFcnJvcnMgPSBzZXNzaW9uLmNvbnZlcnNhdGlvbkhpc3RvcnlcbiAgICAgIC5maWx0ZXIoZW50cnkgPT4gZW50cnkudHlwZSA9PT0gJ3N5c3RlbScgJiYgZW50cnkudGV4dC5pbmNsdWRlcygnZXJyb3InKSlcbiAgICAgIC5zbGljZSgtMyk7XG5cbiAgICBpZiAocmVjZW50RXJyb3JzLmxlbmd0aCA+PSAyKSB7XG4gICAgICByZWFzb25zLnB1c2goJ011bHRpcGxlIHJlY2VudCBlcnJvcnMgZGV0ZWN0ZWQnKTtcbiAgICAgIHJlY29tbWVuZGF0aW9ucy5wdXNoKCdBcG9sb2dpemUgZm9yIHRlY2huaWNhbCBkaWZmaWN1bHRpZXMgYW5kIG9mZmVyIGFsdGVybmF0aXZlIGFzc2lzdGFuY2UnKTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgbmVlZHNBdHRlbnRpb246IHJlYXNvbnMubGVuZ3RoID4gMCxcbiAgICAgIHJlYXNvbnMsXG4gICAgICByZWNvbW1lbmRhdGlvbnMsXG4gICAgfTtcbiAgfVxuXG4gIC8qKlxuICAgKiBWYWxpZGF0ZXMgQUkgcmVzcG9uc2UgYmVmb3JlIHNlbmRpbmcgdG8gdXNlclxuICAgKi9cbiAgdmFsaWRhdGVBSVJlc3BvbnNlKHJlc3BvbnNlOiBzdHJpbmcsIHByZWZlcmVuY2VzOiBVc2VyUHJlZmVyZW5jZXMpOiB7XG4gICAgaXNWYWxpZDogYm9vbGVhbjtcbiAgICBpc3N1ZXM6IHN0cmluZ1tdO1xuICAgIHN1Z2dlc3Rpb25zOiBzdHJpbmdbXTtcbiAgfSB7XG4gICAgY29uc3QgaXNzdWVzOiBzdHJpbmdbXSA9IFtdO1xuICAgIGNvbnN0IHN1Z2dlc3Rpb25zOiBzdHJpbmdbXSA9IFtdO1xuXG4gICAgLy8gQ2hlY2sgd29yZCBjb3VudFxuICAgIGNvbnN0IHdvcmRDb3VudCA9IHJlc3BvbnNlLnNwbGl0KC9cXHMrLykubGVuZ3RoO1xuICAgIGNvbnN0IG1heFdvcmRzID0gdGhpcy5jb25maWcucmVzcG9uc2VXb3JkTGltaXQ7XG5cbiAgICBpZiAod29yZENvdW50ID4gbWF4V29yZHMpIHtcbiAgICAgIGlzc3Vlcy5wdXNoKGBSZXNwb25zZSB0b28gbG9uZzogJHt3b3JkQ291bnR9IHdvcmRzIChtYXg6ICR7bWF4V29yZHN9KWApO1xuICAgICAgc3VnZ2VzdGlvbnMucHVzaCgnU2hvcnRlbiByZXNwb25zZSBvciBzcGxpdCBpbnRvIG11bHRpcGxlIHBhcnRzJyk7XG4gICAgfVxuXG4gICAgLy8gQ2hlY2sgZm9yIHBob25lLWluYXBwcm9wcmlhdGUgY29udGVudFxuICAgIGlmIChyZXNwb25zZS5pbmNsdWRlcygnY2xpY2snKSB8fCByZXNwb25zZS5pbmNsdWRlcygnc2VlJykgfHwgcmVzcG9uc2UuaW5jbHVkZXMoJ2xvb2snKSkge1xuICAgICAgaXNzdWVzLnB1c2goJ1Jlc3BvbnNlIGNvbnRhaW5zIHZpc3VhbCByZWZlcmVuY2VzIGluYXBwcm9wcmlhdGUgZm9yIHBob25lIGNhbGxzJyk7XG4gICAgICBzdWdnZXN0aW9ucy5wdXNoKCdSZXBsYWNlIHZpc3VhbCByZWZlcmVuY2VzIHdpdGggYXVkaW8tYXBwcm9wcmlhdGUgbGFuZ3VhZ2UnKTtcbiAgICB9XG5cbiAgICAvLyBDaGVjayByZXNwb25zZSBsZW5ndGggcHJlZmVyZW5jZVxuICAgIGNvbnN0IGV4cGVjdGVkTGVuZ3RoID0ge1xuICAgICAgc2hvcnQ6IDUwLFxuICAgICAgbWVkaXVtOiAxMDAsXG4gICAgICBsb25nOiAxNTAsXG4gICAgfVtwcmVmZXJlbmNlcy5yZXNwb25zZUxlbmd0aF07XG5cbiAgICBpZiAod29yZENvdW50ID4gZXhwZWN0ZWRMZW5ndGggKiAxLjUpIHtcbiAgICAgIGlzc3Vlcy5wdXNoKGBSZXNwb25zZSBsb25nZXIgdGhhbiB1c2VyIHByZWZlcmVuY2UgKCR7cHJlZmVyZW5jZXMucmVzcG9uc2VMZW5ndGh9KWApO1xuICAgICAgc3VnZ2VzdGlvbnMucHVzaChgQWRqdXN0IHJlc3BvbnNlIHRvIG1hdGNoICR7cHJlZmVyZW5jZXMucmVzcG9uc2VMZW5ndGh9IHByZWZlcmVuY2VgKTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgaXNWYWxpZDogaXNzdWVzLmxlbmd0aCA9PT0gMCxcbiAgICAgIGlzc3VlcyxcbiAgICAgIHN1Z2dlc3Rpb25zLFxuICAgIH07XG4gIH1cblxuICAvKipcbiAgICogR2V0cyBjb252ZXJzYXRpb24gc3RhdGlzdGljcyBmb3IgbW9uaXRvcmluZ1xuICAgKi9cbiAgYXN5bmMgZ2V0Q29udmVyc2F0aW9uU3RhdHMoc2Vzc2lvbklkOiBzdHJpbmcpOiBQcm9taXNlPHtcbiAgICB0dXJuQ291bnQ6IG51bWJlcjtcbiAgICBkdXJhdGlvbjogbnVtYmVyO1xuICAgIGF2ZXJhZ2VSZXNwb25zZUxlbmd0aDogbnVtYmVyO1xuICAgIHRvcGljc0Rpc2N1c3NlZDogc3RyaW5nW107XG4gICAgdXNlckVuZ2FnZW1lbnQ6ICdoaWdoJyB8ICdtZWRpdW0nIHwgJ2xvdyc7XG4gIH0+IHtcbiAgICBjb25zdCBzZXNzaW9uID0gYXdhaXQgdGhpcy5zZXNzaW9uTWFuYWdlci5nZXRTZXNzaW9uKHNlc3Npb25JZCk7XG4gICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYFNlc3Npb24gbm90IGZvdW5kOiAke3Nlc3Npb25JZH1gKTtcbiAgICB9XG5cbiAgICBjb25zdCB1c2VyTWVzc2FnZXMgPSBzZXNzaW9uLmNvbnZlcnNhdGlvbkhpc3RvcnkuZmlsdGVyKGVudHJ5ID0+IGVudHJ5LnR5cGUgPT09ICd1c2VyJyk7XG4gICAgY29uc3QgYWlNZXNzYWdlcyA9IHNlc3Npb24uY29udmVyc2F0aW9uSGlzdG9yeS5maWx0ZXIoZW50cnkgPT4gZW50cnkudHlwZSA9PT0gJ2FpJyk7XG5cbiAgICBjb25zdCBkdXJhdGlvbiA9IHNlc3Npb24uZW5kVGltZSBcbiAgICAgID8gc2Vzc2lvbi5lbmRUaW1lIC0gc2Vzc2lvbi5zdGFydFRpbWUgXG4gICAgICA6IERhdGUubm93KCkgLSBzZXNzaW9uLnN0YXJ0VGltZTtcblxuICAgIGNvbnN0IGF2ZXJhZ2VSZXNwb25zZUxlbmd0aCA9IGFpTWVzc2FnZXMubGVuZ3RoID4gMFxuICAgICAgPyBhaU1lc3NhZ2VzLnJlZHVjZSgoc3VtLCBtc2cpID0+IHN1bSArIG1zZy50ZXh0Lmxlbmd0aCwgMCkgLyBhaU1lc3NhZ2VzLmxlbmd0aFxuICAgICAgOiAwO1xuXG4gICAgY29uc3QgdG9waWNzRGlzY3Vzc2VkID0gdGhpcy5leHRyYWN0VG9waWNzKHNlc3Npb24uY29udmVyc2F0aW9uSGlzdG9yeSk7XG5cbiAgICAvLyBTaW1wbGUgZW5nYWdlbWVudCBjYWxjdWxhdGlvblxuICAgIGNvbnN0IGVuZ2FnZW1lbnRTY29yZSA9IHVzZXJNZXNzYWdlcy5sZW5ndGggLyBNYXRoLm1heCgxLCBkdXJhdGlvbiAvIDYwMDAwKTsgLy8gbWVzc2FnZXMgcGVyIG1pbnV0ZVxuICAgIGNvbnN0IHVzZXJFbmdhZ2VtZW50ID0gZW5nYWdlbWVudFNjb3JlID4gMiA/ICdoaWdoJyA6IGVuZ2FnZW1lbnRTY29yZSA+IDAuNSA/ICdtZWRpdW0nIDogJ2xvdyc7XG5cbiAgICByZXR1cm4ge1xuICAgICAgdHVybkNvdW50OiB1c2VyTWVzc2FnZXMubGVuZ3RoLFxuICAgICAgZHVyYXRpb246IE1hdGgucm91bmQoZHVyYXRpb24gLyAxMDAwKSwgLy8gc2Vjb25kc1xuICAgICAgYXZlcmFnZVJlc3BvbnNlTGVuZ3RoOiBNYXRoLnJvdW5kKGF2ZXJhZ2VSZXNwb25zZUxlbmd0aCksXG4gICAgICB0b3BpY3NEaXNjdXNzZWQsXG4gICAgICB1c2VyRW5nYWdlbWVudCxcbiAgICB9O1xuICB9XG59Il19