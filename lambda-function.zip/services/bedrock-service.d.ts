/**
 * Configuration for Bedrock service
 */
export interface BedrockConfig {
    region?: string;
    modelId?: string;
    maxTokens?: number;
    temperature?: number;
}
/**
 * Available Bedrock models for PromptCall AI
 */
export declare const AVAILABLE_MODELS: {
    readonly CLAUDE_HAIKU: "anthropic.claude-3-haiku-20240307-v1:0";
    readonly CLAUDE_SONNET: "anthropic.claude-3-sonnet-20240229-v1:0";
    readonly TITAN_EXPRESS: "amazon.titan-text-express-v1";
};
/**
 * AI response from Bedrock
 */
export interface AIResponse {
    text: string;
    usage?: {
        inputTokens: number;
        outputTokens: number;
    };
}
/**
 * Service for interacting with AWS Bedrock AI models
 */
export declare class BedrockService {
    private client;
    private config;
    constructor(config?: BedrockConfig);
    /**
     * Process a user query with full conversation context integration
     */
    processQueryWithContext(userQuery: string, aiContext: {
        conversationContext?: string;
        systemPrompt?: string;
        userPreferences?: {
            responseLength: 'short' | 'medium' | 'long';
            topics: string[];
        };
        conversationSummary?: string;
        lastUserIntent?: string;
    }): Promise<AIResponse>;
    /**
     * Process a user query and generate AI response (legacy method)
     */
    processQuery(userQuery: string, conversationContext?: string): Promise<AIResponse>;
    /**
     * Build request body based on model type
     */
    private buildRequestBody;
    /**
     * Parse response based on model type
     */
    private parseResponse;
    /**
     * Build contextual prompt with full AI context integration
     */
    private buildContextualPrompt;
    /**
     * Get maximum words based on user preference
     */
    private getMaxWordsForPreference;
    /**
     * Build optimized prompt for voice interactions (legacy method)
     */
    private buildPrompt;
    /**
     * Validate response length for voice optimization
     */
    private validateResponseLength;
    /**
     * Optimize response for voice delivery
     */
    private optimizeForVoice;
    /**
     * Test Bedrock connection and authentication
     */
    testConnection(): Promise<boolean>;
    /**
     * Try different commonly available models
     */
    findAvailableModel(): Promise<string | null>;
    /**
     * Get current model configuration
     */
    getConfig(): BedrockConfig;
    /**
     * Get list of available models
     */
    static getAvailableModels(): typeof AVAILABLE_MODELS;
    /**
     * Switch to a different model
     */
    switchModel(modelId: string): void;
    /**
     * Get response statistics for monitoring
     */
    getResponseStats(text: string): {
        wordCount: number;
        estimatedSpeechSeconds: number;
        isWithinLimit: boolean;
    };
}
