/**
 * TwiML Service for generating Twilio XML responses
 * Provides utilities for creating valid TwiML responses for call control
 */
export interface TwiMLOptions {
    voice?: 'alice' | 'man' | 'woman';
    language?: string;
}
export interface RecordOptions {
    action?: string;
    method?: 'GET' | 'POST';
    maxLength?: number;
    timeout?: number;
    playBeep?: boolean;
    recordingStatusCallback?: string;
    recordingStatusCallbackMethod?: 'GET' | 'POST';
    voice?: 'alice' | 'man' | 'woman';
}
export interface GatherOptions {
    action?: string;
    method?: 'GET' | 'POST';
    timeout?: number;
    numDigits?: number;
    finishOnKey?: string;
    voice?: 'alice' | 'man' | 'woman';
}
export declare class TwiMLService {
    private defaultVoice;
    /**
     * Create a basic TwiML response with a Say verb
     */
    createSayResponse(message: string, options?: TwiMLOptions): string;
    /**
     * Create a TwiML response with welcome message and recording
     */
    createWelcomeWithRecording(welcomeMessage: string, recordOptions?: RecordOptions): string;
    /**
     * Create a TwiML response with Gather for DTMF input
     */
    createGatherResponse(prompt: string, gatherOptions?: GatherOptions): string;
    /**
     * Create a TwiML response that hangs up the call
     */
    createHangupResponse(goodbyeMessage?: string): string;
    /**
     * Create a TwiML response with pause
     */
    createPauseResponse(seconds: number): string;
    /**
     * Create a TwiML response that plays audio from URL
     */
    createPlayResponse(audioUrl: string, options?: TwiMLOptions): string;
    /**
     * Create a complex TwiML response with multiple verbs
     */
    createComplexResponse(verbs: string[]): string;
    /**
     * Create individual TwiML verbs for complex responses
     */
    createSayVerb(message: string, voice?: string): string;
    createRecordVerb(options?: RecordOptions): string;
    createGatherVerb(prompt: string, options?: GatherOptions): string;
    createPauseVerb(seconds: number): string;
    createPlayVerb(audioUrl: string): string;
    createHangupVerb(): string;
    /**
     * Validate TwiML XML structure
     */
    validateTwiML(twiml: string): boolean;
    /**
     * Escape XML special characters
     */
    private escapeXML;
    /**
     * Parse Twilio webhook parameters from form data
     */
    static parseWebhookParams(body: string): Record<string, string>;
    /**
     * Extract common Twilio parameters
     */
    static extractTwilioParams(params: Record<string, string>): {
        callSid: string;
        from: string;
        to: string;
        callStatus: string;
        direction: string;
        recordingUrl: string;
        recordingStatus: string;
        recordingDuration: string;
        digits: string;
        speechResult: string;
        confidence: string;
        callDuration: string;
    };
}
