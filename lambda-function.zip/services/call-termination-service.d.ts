/**
 * Call Termination and Cleanup Service
 *
 * Handles proper call ending, session cleanup, and graceful goodbye messages
 */
import { DynamoSessionManager } from './dynamo-session-manager';
import { TimeoutManager } from './timeout-manager';
export interface TerminationTrigger {
    type: 'user_request' | 'completion_detected' | 'timeout' | 'error' | 'system_initiated';
    reason: string;
    userText?: string;
    confidence?: number;
}
export interface TerminationResult {
    shouldTerminate: boolean;
    twimlResponse: string;
    terminationType: 'immediate' | 'graceful' | 'continue';
    goodbyeMessage: string;
    sessionUpdated: boolean;
}
export interface CallTerminationConfig {
    enableCompletionDetection: boolean;
    completionKeywords: string[];
    farewellKeywords: string[];
    maxConversationTurns: number;
    enableGracefulGoodbyes: boolean;
}
export declare class CallTerminationService {
    private sessionManager;
    private timeoutManager;
    private config;
    constructor(sessionManager: DynamoSessionManager, timeoutManager: TimeoutManager, config?: Partial<CallTerminationConfig>);
    /**
     * Analyze user input to determine if call should be terminated
     */
    analyzeTerminationIntent(sessionId: string, userText: string, conversationTurn: number, confidence?: number): Promise<TerminationResult>;
    /**
     * Handle explicit call termination request
     */
    terminateCall(sessionId: string, trigger: TerminationTrigger): Promise<TerminationResult>;
    /**
     * Check if user input indicates conversation completion
     */
    private detectCompletionIntent;
    /**
     * Check if user input indicates farewell
     */
    private detectFarewellIntent;
    /**
     * Handle user-requested termination
     */
    private handleUserRequestedTermination;
    /**
     * Handle system-initiated termination
     */
    private handleSystemInitiatedTermination;
    /**
     * Generate appropriate goodbye message based on termination trigger
     */
    private generateGoodbyeMessage;
    /**
     * Create TwiML for call termination
     */
    private createTerminationTwiML;
    /**
     * Create fallback TwiML for termination errors
     */
    private createFallbackTerminationTwiML;
    /**
     * Get termination statistics for monitoring
     */
    getTerminationStats(): {
        completionKeywords: string[];
        farewellKeywords: string[];
        maxConversationTurns: number;
    };
    /**
     * Update termination configuration
     */
    updateConfig(newConfig: Partial<CallTerminationConfig>): void;
}
