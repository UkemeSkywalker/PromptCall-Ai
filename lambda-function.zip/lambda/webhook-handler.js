"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = void 0;
console.log('=== LAMBDA INITIALIZATION START ===');
console.log('Environment variables:', {
    SESSION_TABLE_NAME: process.env.SESSION_TABLE_NAME,
    AUDIO_BUCKET_NAME: process.env.AUDIO_BUCKET_NAME,
    AWS_REGION: process.env.AWS_REGION,
    NODE_ENV: process.env.NODE_ENV
});
console.log('Attempting to import services...');
try {
    console.log('Importing services from ../services');
    const services = require('../services');
    console.log('Available services:', Object.keys(services));
    var { DTMFService, TwiMLService, DynamoSessionManager, S3Service, TranscriptionProcessor } = services;
    console.log('Services imported successfully');
}
catch (importError) {
    console.error('CRITICAL: Failed to import services:', importError);
    console.error('Import error stack:', importError instanceof Error ? importError.stack : 'No stack trace');
    throw importError;
}
console.log('Initializing service instances...');
try {
    var dtmfService = new DTMFService();
    console.log('DTMFService initialized');
    var twimlService = new TwiMLService();
    console.log('TwiMLService initialized');
    var sessionManager = new DynamoSessionManager({
        tableName: process.env.SESSION_TABLE_NAME || 'promptcall-sessions',
        region: process.env.AWS_REGION || 'us-east-1'
    });
    console.log('DynamoSessionManager initialized');
    var s3Service = new S3Service({
        bucketName: process.env.AUDIO_BUCKET_NAME || 'promptcall-audio-bucket',
        region: process.env.AWS_REGION || 'us-east-1'
    });
    console.log('S3Service initialized');
    var transcriptionProcessor = new TranscriptionProcessor(s3Service, {
        region: process.env.AWS_REGION || 'us-east-1',
        confidenceThreshold: 0.7,
        maxRetries: 2
    });
    console.log('TranscriptionProcessor initialized');
}
catch (initError) {
    console.error('CRITICAL: Failed to initialize services:', initError);
    console.error('Initialization error stack:', initError instanceof Error ? initError.stack : 'No stack trace');
    throw initError;
}
console.log('=== LAMBDA INITIALIZATION COMPLETE ===');
const handler = async (event) => {
    console.log('=== WEBHOOK REQUEST START ===');
    console.log('Request ID:', event.requestContext?.requestId);
    console.log('Path:', event.path);
    console.log('Method:', event.httpMethod);
    console.log('Headers:', JSON.stringify(event.headers, null, 2));
    console.log('Body:', event.body);
    console.log('=== WEBHOOK REQUEST DETAILS ===');
    const path = event.path;
    const httpMethod = event.httpMethod;
    try {
        console.log('Processing webhook request...');
        console.log('Request path:', path);
        console.log('HTTP method:', httpMethod);
        // Parse Twilio webhook parameters
        const body = event.body ? parseFormData(event.body) : {};
        console.log('Raw body:', event.body);
        console.log('Parsed webhook body:', JSON.stringify(body, null, 2));
        // Route to appropriate handler based on path
        console.log('Routing request...');
        console.log('Path matching check:', {
            path,
            voiceMatch: path.includes('/webhook/voice'),
            speechMatch: path.includes('/webhook/speech'),
            dtmfMatch: path.includes('/webhook/dtmf'),
            eventsMatch: path.includes('/webhook/events'),
            methodMatch: httpMethod === 'POST'
        });
        if (path.includes('/webhook/voice') && httpMethod === 'POST') {
            console.log('✅ Routing to voice webhook handler');
            return handleVoiceWebhook(body, event);
        }
        else if (path.includes('/webhook/speech') && httpMethod === 'POST') {
            console.log('✅ Routing to speech webhook handler - ENDPOINT REACHED');
            return handleSpeechWebhook(body, event);
        }
        else if (path.includes('/webhook/dtmf') && httpMethod === 'POST') {
            console.log('✅ Routing to DTMF webhook handler');
            return await handleDTMFWebhook(body, event);
        }
        else if (path.includes('/webhook/events') && httpMethod === 'POST') {
            console.log('✅ Routing to events webhook handler');
            return await handleEventsWebhook(body);
        }
        console.log('❌ No matching route found');
        console.log('Available routes should be: /webhook/voice, /webhook/speech, /webhook/dtmf, /webhook/events');
        console.log('Actual path received:', path);
        // Add a test endpoint for debugging
        if (path.includes('/test') || path === '/') {
            console.log('Test endpoint hit - Lambda is working');
            return {
                statusCode: 200,
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    message: 'Lambda is working',
                    timestamp: new Date().toISOString(),
                    path: path,
                    method: httpMethod
                })
            };
        }
        // Default response
        return createTwiMLResponse('Hello from PromptCall AI. Please try calling again.');
    }
    catch (error) {
        console.error('=== CRITICAL ERROR IN WEBHOOK HANDLER ===');
        console.error('Error type:', error instanceof Error ? error.constructor.name : typeof error);
        console.error('Error message:', error instanceof Error ? error.message : String(error));
        console.error('Error stack:', error instanceof Error ? error.stack : 'No stack trace');
        console.error('Request context:', {
            path: event.path,
            method: event.httpMethod,
            requestId: event.requestContext?.requestId
        });
        console.error('=== END CRITICAL ERROR ===');
        return {
            statusCode: 500,
            headers: {
                'Content-Type': 'application/xml'
            },
            body: '<?xml version="1.0" encoding="UTF-8"?><Response><Say>Sorry, there was an error. Please try again.</Say></Response>'
        };
    }
};
exports.handler = handler;
function parseFormData(body) {
    return TwiMLService.parseWebhookParams(body);
}
function getBaseUrl(event) {
    return `https://${event.headers.Host}${event.requestContext.stage ? `/${event.requestContext.stage}` : ''}`;
}
async function handleVoiceWebhook(body, event) {
    const { callSid, from, to, callStatus } = TwiMLService.extractTwilioParams(body);
    console.log(`Incoming call from ${from} to ${to}, CallSid: ${callSid}, Status: ${callStatus}`);
    try {
        // Create new session when call starts
        const session = await sessionManager.createSession(callSid, from);
        // Add system message to track call start
        await sessionManager.addSystemMessage(session.sessionId, `Call started from ${from} to ${to}, Status: ${callStatus}`);
        console.log(`Created session for CallSid: ${callSid}, SessionId: ${session.sessionId}`);
    }
    catch (error) {
        console.error('Error creating session:', error);
        // Continue with call even if session creation fails
    }
    // Create TwiML response with welcome message and recording
    const welcomeMessage = dtmfService.generateWelcomeWithInstructions();
    // Get the base URL from the event
    const baseUrl = getBaseUrl(event);
    const twiml = twimlService.createWelcomeWithRecording(welcomeMessage, {
        action: `${baseUrl}/webhook/speech`,
        method: 'POST',
        maxLength: 30,
        timeout: 10,
        playBeep: true,
        recordingStatusCallback: `${baseUrl}/webhook/events`,
        recordingStatusCallbackMethod: 'POST'
    });
    return {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/xml'
        },
        body: twiml
    };
}
async function handleSpeechWebhook(body, event) {
    console.log('=== SPEECH WEBHOOK HANDLER START ===');
    console.log('Speech endpoint reached successfully - no 403 error here');
    const { recordingUrl, callSid, recordingDuration } = TwiMLService.extractTwilioParams(body);
    console.log('Speech webhook parameters:', {
        callSid,
        recordingUrl,
        recordingDuration,
        allParams: body
    });
    console.log(`Speech recording received for CallSid: ${callSid}, URL: ${recordingUrl}, Duration: ${recordingDuration}s`);
    // Log environment and service status
    console.log('Service status check:', {
        sessionManagerExists: !!sessionManager,
        s3ServiceExists: !!s3Service,
        transcriptionProcessorExists: !!transcriptionProcessor,
        twimlServiceExists: !!twimlService
    });
    try {
        console.log('Attempting to find session by CallSid...');
        // Find session by CallSid
        const session = await sessionManager.getSessionByCallSid(callSid);
        console.log('Session lookup result:', session ? 'Found' : 'Not found');
        if (!session) {
            console.warn(`Session not found for CallSid: ${callSid}`);
            console.log('Returning error response due to missing session');
            // Continue with call even if session not found
            const twiml = twimlService.createSayResponse('Sorry, there was an error. Please try again.');
            return {
                statusCode: 200,
                headers: { 'Content-Type': 'application/xml' },
                body: twiml
            };
        }
        console.log('Session found:', {
            sessionId: session.sessionId,
            status: session.status,
            conversationCount: session.conversation?.length || 0
        });
        console.log('Validating audio quality...');
        // Validate audio quality
        const audioValidation = transcriptionProcessor.validateAudioQuality({
            url: recordingUrl,
            duration: recordingDuration ? parseFloat(recordingDuration) : undefined
        });
        console.log('Audio validation result:', {
            isValid: audioValidation.isValid,
            issues: audioValidation.issues
        });
        if (!audioValidation.isValid) {
            console.warn(`Audio quality issues for CallSid ${callSid}:`, audioValidation.issues);
            console.log('Adding system message about audio quality issues...');
            await sessionManager.addSystemMessage(session.sessionId, `Audio quality issues: ${audioValidation.issues.join(', ')}`);
            console.log('Generating audio quality retry response...');
            // Ask user to try again
            // Use existing welcome system for audio quality issues
            const baseUrl = getBaseUrl(event);
            const recordWithDTMF = dtmfService.generateRecordWithDTMFTwiML({
                speechAction: `${baseUrl}/webhook/speech`,
                dtmfAction: `${baseUrl}/webhook/dtmf`,
                maxLength: 30,
                timeout: 10,
                prompt: 'I had trouble with your audio. Please speak clearly.'
            });
            const twiml = twimlService.createComplexResponse([
                twimlService.createSayVerb('I had trouble with your audio. Please speak clearly.'),
                recordWithDTMF
            ]);
            console.log('Returning audio quality retry TwiML response');
            return {
                statusCode: 200,
                headers: { 'Content-Type': 'application/xml' },
                body: twiml
            };
        }
        console.log('Adding initial recording info to session...');
        // Add initial recording info to session
        await sessionManager.addUserMessage(session.sessionId, 'Speech recorded - processing transcription...', recordingUrl);
        console.log(`Updated session ${session.sessionId} with speech recording`);
        // Process transcription asynchronously but wait for result
        try {
            console.log(`Starting transcription for session ${session.sessionId}`);
            console.log('Transcription parameters:', {
                recordingUrl,
                sessionId: session.sessionId,
                callSid
            });
            const transcriptionResult = await transcriptionProcessor.processAudioFromUrl(recordingUrl, session.sessionId, callSid);
            console.log(`Transcription completed: ${transcriptionProcessor.formatResultForLogging(transcriptionResult)}`);
            console.log('Full transcription result:', {
                text: transcriptionResult.text,
                confidence: transcriptionResult.confidence,
                isAcceptable: transcriptionProcessor.isTranscriptionAcceptable(transcriptionResult)
            });
            // Update session with transcription result
            if (transcriptionProcessor.isTranscriptionAcceptable(transcriptionResult)) {
                console.log('Transcription is acceptable, updating session...');
                // Good transcription - update session with transcribed text
                await sessionManager.addUserMessage(session.sessionId, transcriptionResult.text, recordingUrl, transcriptionResult.confidence);
                console.log(`Successfully transcribed for session ${session.sessionId}: "${transcriptionResult.text}"`);
                console.log('Generating DTMF gather response...');
                // Continue to DTMF gathering for user to press 1 to submit
                const baseUrl = getBaseUrl(event);
                const twiml = twimlService.createGatherResponse('', {
                    action: `${baseUrl}/webhook/dtmf`,
                    timeout: 30,
                    numDigits: 1,
                    finishOnKey: ''
                });
                console.log('Returning successful transcription TwiML response');
                return {
                    statusCode: 200,
                    headers: { 'Content-Type': 'application/xml' },
                    body: twiml
                };
            }
            else {
                console.log('Transcription quality is poor, asking user to retry...');
                // Poor transcription - ask user to try again
                const issueMessage = transcriptionProcessor.getTranscriptionIssueMessage(transcriptionResult);
                await sessionManager.addSystemMessage(session.sessionId, `Transcription issue: ${issueMessage} (confidence: ${transcriptionResult.confidence})`);
                console.log(`Transcription quality issue for session ${session.sessionId}: confidence ${transcriptionResult.confidence}`);
                // Ask user to speak again using existing system
                const baseUrl = getBaseUrl(event);
                const recordWithDTMF = dtmfService.generateRecordWithDTMFTwiML({
                    speechAction: `${baseUrl}/webhook/speech`,
                    dtmfAction: `${baseUrl}/webhook/dtmf`,
                    maxLength: 30,
                    timeout: 10,
                    prompt: issueMessage
                });
                const twiml = twimlService.createComplexResponse([
                    twimlService.createSayVerb(issueMessage),
                    recordWithDTMF
                ]);
                return {
                    statusCode: 200,
                    headers: { 'Content-Type': 'application/xml' },
                    body: twiml
                };
            }
        }
        catch (transcriptionError) {
            console.error('Transcription processing failed:', transcriptionError);
            await sessionManager.addSystemMessage(session.sessionId, `Transcription failed: ${transcriptionError instanceof Error ? transcriptionError.message : 'Unknown error'}`);
            // Fallback - ask user to try again using existing system
            const baseUrl = getBaseUrl(event);
            const recordWithDTMF = dtmfService.generateRecordWithDTMFTwiML({
                speechAction: `${baseUrl}/webhook/speech`,
                dtmfAction: `${baseUrl}/webhook/dtmf`,
                maxLength: 30,
                timeout: 10,
                prompt: "I'm having trouble processing your speech. Please try speaking more clearly."
            });
            const twiml = twimlService.createComplexResponse([
                twimlService.createSayVerb("I'm having trouble processing your speech. Please try speaking more clearly."),
                recordWithDTMF
            ]);
            return {
                statusCode: 200,
                headers: { 'Content-Type': 'application/xml' },
                body: twiml
            };
        }
    }
    catch (error) {
        console.error('Error in speech webhook handler:', error);
        // Fallback response
        const twiml = twimlService.createSayResponse('Sorry, there was an error processing your speech. Please try calling again.');
        return {
            statusCode: 500,
            headers: { 'Content-Type': 'application/xml' },
            body: twiml
        };
    }
}
async function handleDTMFWebhook(body, event) {
    const { digits, callSid, from, to } = TwiMLService.extractTwilioParams(body);
    console.log(`DTMF input received: ${digits} for CallSid: ${callSid}`);
    try {
        // Find session by CallSid and track DTMF input
        const session = await sessionManager.getSessionByCallSid(callSid);
        if (session) {
            await sessionManager.addSystemMessage(session.sessionId, `DTMF input received: ${digits}`);
        }
        else {
            console.warn(`Session not found for CallSid: ${callSid}`);
        }
    }
    catch (error) {
        console.error('Error tracking DTMF input in session:', error);
    }
    const dtmfInput = {
        digits,
        callSid,
        from,
        to
    };
    const response = dtmfService.processDTMFInput(dtmfInput);
    const verbs = [];
    if (response.message) {
        verbs.push(twimlService.createSayVerb(response.message));
    }
    if (response.action === 'submit') {
        // User pressed "1" - process their spoken prompt
        verbs.push(twimlService.createSayVerb('Processing your request now. Please wait.'));
        // In later tasks, this will trigger AI processing
        verbs.push(twimlService.createSayVerb('This is a placeholder response. Your AI processing will be implemented in later tasks.'));
        verbs.push(twimlService.createPauseVerb(1));
        verbs.push(twimlService.createSayVerb('Is there anything else I can help you with?'));
        // Continue with another recording session
        const baseUrl = getBaseUrl(event);
        const recordWithDTMF = dtmfService.generateRecordWithDTMFTwiML({
            speechAction: `${baseUrl}/webhook/speech`,
            dtmfAction: `${baseUrl}/webhook/dtmf`,
            maxLength: 30,
            timeout: 10,
            prompt: dtmfService.generateControlsReminder()
        });
        verbs.push(recordWithDTMF);
    }
    else if (response.action === 'end_call') {
        // User pressed "0" - end the call gracefully
        try {
            // Find session by CallSid and update status to completed
            const session = await sessionManager.getSessionByCallSid(callSid);
            if (session) {
                await sessionManager.updateSessionStatus(session.sessionId, 'completed', Date.now());
                await sessionManager.addSystemMessage(session.sessionId, 'Call ended by user request (pressed 0)');
            }
            else {
                console.warn(`Session not found for CallSid: ${callSid}`);
            }
        }
        catch (error) {
            console.error('Error updating session on call end:', error);
        }
        verbs.push(twimlService.createHangupVerb());
    }
    else if (response.action === 'help') {
        // User pressed "*" - provide help
        verbs.push(twimlService.createPauseVerb(1));
        // Continue with recording after help
        const baseUrl = getBaseUrl(event);
        const recordWithDTMF = dtmfService.generateRecordWithDTMFTwiML({
            speechAction: `${baseUrl}/webhook/speech`,
            dtmfAction: `${baseUrl}/webhook/dtmf`,
            maxLength: 30,
            timeout: 10,
            prompt: 'Please speak your question after the beep.'
        });
        verbs.push(recordWithDTMF);
    }
    else {
        // Invalid input - provide guidance and continue
        verbs.push(twimlService.createPauseVerb(1));
        const baseUrl = getBaseUrl(event);
        const recordWithDTMF = dtmfService.generateRecordWithDTMFTwiML({
            speechAction: `${baseUrl}/webhook/speech`,
            dtmfAction: `${baseUrl}/webhook/dtmf`,
            maxLength: 30,
            timeout: 10,
            prompt: 'Please speak your question after the beep.'
        });
        verbs.push(recordWithDTMF);
    }
    const twiml = twimlService.createComplexResponse(verbs);
    return {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/xml'
        },
        body: twiml
    };
}
async function handleEventsWebhook(body) {
    const { recordingStatus, callSid, callStatus, callDuration } = TwiMLService.extractTwilioParams(body);
    console.log(`Event received for CallSid: ${callSid}, Recording Status: ${recordingStatus}, Call Status: ${callStatus}`);
    try {
        // Find session by CallSid
        const session = await sessionManager.getSessionByCallSid(callSid);
        if (!session) {
            console.warn(`Session not found for CallSid: ${callSid}`);
            // Continue processing even if session not found
        }
        else {
            // Handle different types of events
            if (recordingStatus) {
                // Recording status events
                await sessionManager.addSystemMessage(session.sessionId, `Recording status: ${recordingStatus}`);
                if (recordingStatus === 'completed') {
                    console.log(`Recording completed for CallSid: ${callSid}`);
                }
                else if (recordingStatus === 'failed') {
                    console.log(`Recording failed for CallSid: ${callSid}`);
                    await sessionManager.addSystemMessage(session.sessionId, 'Recording failed - audio may not be available');
                }
            }
            if (callStatus) {
                // Call status events
                await sessionManager.addSystemMessage(session.sessionId, `Call status: ${callStatus}`);
                if (callStatus === 'completed') {
                    // Call ended - update session
                    const duration = callDuration ? parseInt(callDuration) : 0;
                    await sessionManager.updateSessionStatus(session.sessionId, 'completed', Date.now());
                    if (duration > 0) {
                        await sessionManager.updateCallDuration(session.sessionId, duration);
                    }
                    console.log(`Call completed for CallSid: ${callSid}, Duration: ${duration}s`);
                }
                else if (callStatus === 'failed' || callStatus === 'busy' || callStatus === 'no-answer') {
                    // Call failed - update session with error
                    await sessionManager.updateSessionStatus(session.sessionId, 'failed', Date.now(), {
                        code: callStatus,
                        message: `Call ${callStatus}`
                    });
                    console.log(`Call failed for CallSid: ${callSid}, Status: ${callStatus}`);
                }
            }
        }
    }
    catch (error) {
        console.error('Error handling event webhook:', error);
        // Continue processing even if session update fails
    }
    const twiml = twimlService.createComplexResponse([]);
    return {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/xml'
        },
        body: twiml
    };
}
function createTwiMLResponse(message) {
    const twiml = twimlService.createSayResponse(message);
    return {
        statusCode: 200,
        headers: {
            'Content-Type': 'application/xml'
        },
        body: twiml
    };
}
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoid2ViaG9vay1oYW5kbGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL2xhbWJkYS93ZWJob29rLWhhbmRsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBRUEsT0FBTyxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFDO0FBQ25ELE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLEVBQUU7SUFDcEMsa0JBQWtCLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0I7SUFDbEQsaUJBQWlCLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxpQkFBaUI7SUFDaEQsVUFBVSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVTtJQUNsQyxRQUFRLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxRQUFRO0NBQy9CLENBQUMsQ0FBQztBQUVILE9BQU8sQ0FBQyxHQUFHLENBQUMsa0NBQWtDLENBQUMsQ0FBQztBQUNoRCxJQUFJLENBQUM7SUFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLHFDQUFxQyxDQUFDLENBQUM7SUFDbkQsTUFBTSxRQUFRLEdBQUcsT0FBTyxDQUFDLGFBQWEsQ0FBQyxDQUFDO0lBQ3hDLE9BQU8sQ0FBQyxHQUFHLENBQUMscUJBQXFCLEVBQUUsTUFBTSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDO0lBRTFELElBQUksRUFDRixXQUFXLEVBQ1gsWUFBWSxFQUNaLG9CQUFvQixFQUNwQixTQUFTLEVBQ1Qsc0JBQXNCLEVBQ3ZCLEdBQUcsUUFBUSxDQUFDO0lBRWIsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFDO0FBQ2hELENBQUM7QUFBQyxPQUFPLFdBQVcsRUFBRSxDQUFDO0lBQ3JCLE9BQU8sQ0FBQyxLQUFLLENBQUMsc0NBQXNDLEVBQUUsV0FBVyxDQUFDLENBQUM7SUFDbkUsT0FBTyxDQUFDLEtBQUssQ0FBQyxxQkFBcUIsRUFBRSxXQUFXLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzFHLE1BQU0sV0FBVyxDQUFDO0FBQ3BCLENBQUM7QUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLG1DQUFtQyxDQUFDLENBQUM7QUFDakQsSUFBSSxDQUFDO0lBQ0gsSUFBSSxXQUFXLEdBQUcsSUFBSSxXQUFXLEVBQUUsQ0FBQztJQUNwQyxPQUFPLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDLENBQUM7SUFFdkMsSUFBSSxZQUFZLEdBQUcsSUFBSSxZQUFZLEVBQUUsQ0FBQztJQUN0QyxPQUFPLENBQUMsR0FBRyxDQUFDLDBCQUEwQixDQUFDLENBQUM7SUFFeEMsSUFBSSxjQUFjLEdBQUcsSUFBSSxvQkFBb0IsQ0FBQztRQUM1QyxTQUFTLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsSUFBSSxxQkFBcUI7UUFDbEUsTUFBTSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsVUFBVSxJQUFJLFdBQVc7S0FDOUMsQ0FBQyxDQUFDO0lBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsQ0FBQyxDQUFDO0lBRWhELElBQUksU0FBUyxHQUFHLElBQUksU0FBUyxDQUFDO1FBQzVCLFVBQVUsRUFBRSxPQUFPLENBQUMsR0FBRyxDQUFDLGlCQUFpQixJQUFJLHlCQUF5QjtRQUN0RSxNQUFNLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLElBQUksV0FBVztLQUM5QyxDQUFDLENBQUM7SUFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixDQUFDLENBQUM7SUFFckMsSUFBSSxzQkFBc0IsR0FBRyxJQUFJLHNCQUFzQixDQUFDLFNBQVMsRUFBRTtRQUNqRSxNQUFNLEVBQUUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxVQUFVLElBQUksV0FBVztRQUM3QyxtQkFBbUIsRUFBRSxHQUFHO1FBQ3hCLFVBQVUsRUFBRSxDQUFDO0tBQ2QsQ0FBQyxDQUFDO0lBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO0FBRXBELENBQUM7QUFBQyxPQUFPLFNBQVMsRUFBRSxDQUFDO0lBQ25CLE9BQU8sQ0FBQyxLQUFLLENBQUMsMENBQTBDLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDckUsT0FBTyxDQUFDLEtBQUssQ0FBQyw2QkFBNkIsRUFBRSxTQUFTLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO0lBQzlHLE1BQU0sU0FBUyxDQUFDO0FBQ2xCLENBQUM7QUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLHdDQUF3QyxDQUFDLENBQUM7QUFFL0MsTUFBTSxPQUFPLEdBQUcsS0FBSyxFQUFFLEtBQTJCLEVBQWtDLEVBQUU7SUFDM0YsT0FBTyxDQUFDLEdBQUcsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO0lBQzdDLE9BQU8sQ0FBQyxHQUFHLENBQUMsYUFBYSxFQUFFLEtBQUssQ0FBQyxjQUFjLEVBQUUsU0FBUyxDQUFDLENBQUM7SUFDNUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2pDLE9BQU8sQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxVQUFVLENBQUMsQ0FBQztJQUN6QyxPQUFPLENBQUMsR0FBRyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7SUFDaEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxPQUFPLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2pDLE9BQU8sQ0FBQyxHQUFHLENBQUMsaUNBQWlDLENBQUMsQ0FBQztJQUUvQyxNQUFNLElBQUksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDO0lBQ3hCLE1BQU0sVUFBVSxHQUFHLEtBQUssQ0FBQyxVQUFVLENBQUM7SUFFcEMsSUFBSSxDQUFDO1FBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQywrQkFBK0IsQ0FBQyxDQUFDO1FBQzdDLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ25DLE9BQU8sQ0FBQyxHQUFHLENBQUMsY0FBYyxFQUFFLFVBQVUsQ0FBQyxDQUFDO1FBRXhDLGtDQUFrQztRQUNsQyxNQUFNLElBQUksR0FBRyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7UUFDekQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3JDLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFFbkUsNkNBQTZDO1FBQzdDLE9BQU8sQ0FBQyxHQUFHLENBQUMsb0JBQW9CLENBQUMsQ0FBQztRQUNsQyxPQUFPLENBQUMsR0FBRyxDQUFDLHNCQUFzQixFQUFFO1lBQ2xDLElBQUk7WUFDSixVQUFVLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQztZQUMzQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQztZQUM3QyxTQUFTLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUM7WUFDekMsV0FBVyxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUM7WUFDN0MsV0FBVyxFQUFFLFVBQVUsS0FBSyxNQUFNO1NBQ25DLENBQUMsQ0FBQztRQUVILElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxJQUFJLFVBQVUsS0FBSyxNQUFNLEVBQUUsQ0FBQztZQUM3RCxPQUFPLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7WUFDbEQsT0FBTyxrQkFBa0IsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDekMsQ0FBQzthQUFNLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLFVBQVUsS0FBSyxNQUFNLEVBQUUsQ0FBQztZQUNyRSxPQUFPLENBQUMsR0FBRyxDQUFDLHdEQUF3RCxDQUFDLENBQUM7WUFDdEUsT0FBTyxtQkFBbUIsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDMUMsQ0FBQzthQUFNLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxlQUFlLENBQUMsSUFBSSxVQUFVLEtBQUssTUFBTSxFQUFFLENBQUM7WUFDbkUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtQ0FBbUMsQ0FBQyxDQUFDO1lBQ2pELE9BQU8sTUFBTSxpQkFBaUIsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDOUMsQ0FBQzthQUFNLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLFVBQVUsS0FBSyxNQUFNLEVBQUUsQ0FBQztZQUNyRSxPQUFPLENBQUMsR0FBRyxDQUFDLHFDQUFxQyxDQUFDLENBQUM7WUFDbkQsT0FBTyxNQUFNLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO1FBQ3pDLENBQUM7UUFFRCxPQUFPLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLENBQUM7UUFDekMsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2RkFBNkYsQ0FBQyxDQUFDO1FBQzNHLE9BQU8sQ0FBQyxHQUFHLENBQUMsdUJBQXVCLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFM0Msb0NBQW9DO1FBQ3BDLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsSUFBSSxJQUFJLEtBQUssR0FBRyxFQUFFLENBQUM7WUFDM0MsT0FBTyxDQUFDLEdBQUcsQ0FBQyx1Q0FBdUMsQ0FBQyxDQUFDO1lBQ3JELE9BQU87Z0JBQ0wsVUFBVSxFQUFFLEdBQUc7Z0JBQ2YsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLGtCQUFrQixFQUFFO2dCQUMvQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFNBQVMsQ0FBQztvQkFDbkIsT0FBTyxFQUFFLG1CQUFtQjtvQkFDNUIsU0FBUyxFQUFFLElBQUksSUFBSSxFQUFFLENBQUMsV0FBVyxFQUFFO29CQUNuQyxJQUFJLEVBQUUsSUFBSTtvQkFDVixNQUFNLEVBQUUsVUFBVTtpQkFDbkIsQ0FBQzthQUNILENBQUM7UUFDSixDQUFDO1FBRUQsbUJBQW1CO1FBQ25CLE9BQU8sbUJBQW1CLENBQUMscURBQXFELENBQUMsQ0FBQztJQUVwRixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMsMkNBQTJDLENBQUMsQ0FBQztRQUMzRCxPQUFPLENBQUMsS0FBSyxDQUFDLGFBQWEsRUFBRSxLQUFLLFlBQVksS0FBSyxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsT0FBTyxLQUFLLENBQUMsQ0FBQztRQUM3RixPQUFPLENBQUMsS0FBSyxDQUFDLGdCQUFnQixFQUFFLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDO1FBQ3hGLE9BQU8sQ0FBQyxLQUFLLENBQUMsY0FBYyxFQUFFLEtBQUssWUFBWSxLQUFLLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLGdCQUFnQixDQUFDLENBQUM7UUFDdkYsT0FBTyxDQUFDLEtBQUssQ0FBQyxrQkFBa0IsRUFBRTtZQUNoQyxJQUFJLEVBQUUsS0FBSyxDQUFDLElBQUk7WUFDaEIsTUFBTSxFQUFFLEtBQUssQ0FBQyxVQUFVO1lBQ3hCLFNBQVMsRUFBRSxLQUFLLENBQUMsY0FBYyxFQUFFLFNBQVM7U0FDM0MsQ0FBQyxDQUFDO1FBQ0gsT0FBTyxDQUFDLEtBQUssQ0FBQyw0QkFBNEIsQ0FBQyxDQUFDO1FBRTVDLE9BQU87WUFDTCxVQUFVLEVBQUUsR0FBRztZQUNmLE9BQU8sRUFBRTtnQkFDUCxjQUFjLEVBQUUsaUJBQWlCO2FBQ2xDO1lBQ0QsSUFBSSxFQUFFLG9IQUFvSDtTQUMzSCxDQUFDO0lBQ0osQ0FBQztBQUNILENBQUMsQ0FBQztBQXpGVyxRQUFBLE9BQU8sV0F5RmxCO0FBRUYsU0FBUyxhQUFhLENBQUMsSUFBWTtJQUNqQyxPQUFPLFlBQVksQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMvQyxDQUFDO0FBRUQsU0FBUyxVQUFVLENBQUMsS0FBMkI7SUFDN0MsT0FBTyxXQUFXLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxHQUFHLEtBQUssQ0FBQyxjQUFjLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxJQUFJLEtBQUssQ0FBQyxjQUFjLENBQUMsS0FBSyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDO0FBQzlHLENBQUM7QUFFRCxLQUFLLFVBQVUsa0JBQWtCLENBQUMsSUFBNEIsRUFBRSxLQUEyQjtJQUN6RixNQUFNLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxFQUFFLEVBQUUsVUFBVSxFQUFFLEdBQUcsWUFBWSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBRWpGLE9BQU8sQ0FBQyxHQUFHLENBQUMsc0JBQXNCLElBQUksT0FBTyxFQUFFLGNBQWMsT0FBTyxhQUFhLFVBQVUsRUFBRSxDQUFDLENBQUM7SUFFL0YsSUFBSSxDQUFDO1FBQ0gsc0NBQXNDO1FBQ3RDLE1BQU0sT0FBTyxHQUFHLE1BQU0sY0FBYyxDQUFDLGFBQWEsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFbEUseUNBQXlDO1FBQ3pDLE1BQU0sY0FBYyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUscUJBQXFCLElBQUksT0FBTyxFQUFFLGFBQWEsVUFBVSxFQUFFLENBQUMsQ0FBQztRQUV0SCxPQUFPLENBQUMsR0FBRyxDQUFDLGdDQUFnQyxPQUFPLGdCQUFnQixPQUFPLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztJQUMxRixDQUFDO0lBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztRQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMseUJBQXlCLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDaEQsb0RBQW9EO0lBQ3RELENBQUM7SUFFRCwyREFBMkQ7SUFDM0QsTUFBTSxjQUFjLEdBQUcsV0FBVyxDQUFDLCtCQUErQixFQUFFLENBQUM7SUFFckUsa0NBQWtDO0lBQ2xDLE1BQU0sT0FBTyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUVsQyxNQUFNLEtBQUssR0FBRyxZQUFZLENBQUMsMEJBQTBCLENBQUMsY0FBYyxFQUFFO1FBQ3BFLE1BQU0sRUFBRSxHQUFHLE9BQU8saUJBQWlCO1FBQ25DLE1BQU0sRUFBRSxNQUFNO1FBQ2QsU0FBUyxFQUFFLEVBQUU7UUFDYixPQUFPLEVBQUUsRUFBRTtRQUNYLFFBQVEsRUFBRSxJQUFJO1FBQ2QsdUJBQXVCLEVBQUUsR0FBRyxPQUFPLGlCQUFpQjtRQUNwRCw2QkFBNkIsRUFBRSxNQUFNO0tBQ3RDLENBQUMsQ0FBQztJQUVILE9BQU87UUFDTCxVQUFVLEVBQUUsR0FBRztRQUNmLE9BQU8sRUFBRTtZQUNQLGNBQWMsRUFBRSxpQkFBaUI7U0FDbEM7UUFDRCxJQUFJLEVBQUUsS0FBSztLQUNaLENBQUM7QUFDSixDQUFDO0FBRUQsS0FBSyxVQUFVLG1CQUFtQixDQUFDLElBQTRCLEVBQUUsS0FBMkI7SUFDMUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDO0lBQ3BELE9BQU8sQ0FBQyxHQUFHLENBQUMsMERBQTBELENBQUMsQ0FBQztJQUV4RSxNQUFNLEVBQUUsWUFBWSxFQUFFLE9BQU8sRUFBRSxpQkFBaUIsRUFBRSxHQUFHLFlBQVksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUU1RixPQUFPLENBQUMsR0FBRyxDQUFDLDRCQUE0QixFQUFFO1FBQ3hDLE9BQU87UUFDUCxZQUFZO1FBQ1osaUJBQWlCO1FBQ2pCLFNBQVMsRUFBRSxJQUFJO0tBQ2hCLENBQUMsQ0FBQztJQUVILE9BQU8sQ0FBQyxHQUFHLENBQUMsMENBQTBDLE9BQU8sVUFBVSxZQUFZLGVBQWUsaUJBQWlCLEdBQUcsQ0FBQyxDQUFDO0lBRXhILHFDQUFxQztJQUNyQyxPQUFPLENBQUMsR0FBRyxDQUFDLHVCQUF1QixFQUFFO1FBQ25DLG9CQUFvQixFQUFFLENBQUMsQ0FBQyxjQUFjO1FBQ3RDLGVBQWUsRUFBRSxDQUFDLENBQUMsU0FBUztRQUM1Qiw0QkFBNEIsRUFBRSxDQUFDLENBQUMsc0JBQXNCO1FBQ3RELGtCQUFrQixFQUFFLENBQUMsQ0FBQyxZQUFZO0tBQ25DLENBQUMsQ0FBQztJQUVILElBQUksQ0FBQztRQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsMENBQTBDLENBQUMsQ0FBQztRQUN4RCwwQkFBMEI7UUFDMUIsTUFBTSxPQUFPLEdBQUcsTUFBTSxjQUFjLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLENBQUM7UUFDbEUsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3QkFBd0IsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLENBQUM7UUFFdkUsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQ2IsT0FBTyxDQUFDLElBQUksQ0FBQyxrQ0FBa0MsT0FBTyxFQUFFLENBQUMsQ0FBQztZQUMxRCxPQUFPLENBQUMsR0FBRyxDQUFDLGlEQUFpRCxDQUFDLENBQUM7WUFDL0QsK0NBQStDO1lBQy9DLE1BQU0sS0FBSyxHQUFHLFlBQVksQ0FBQyxpQkFBaUIsQ0FBQyw4Q0FBOEMsQ0FBQyxDQUFDO1lBQzdGLE9BQU87Z0JBQ0wsVUFBVSxFQUFFLEdBQUc7Z0JBQ2YsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLGlCQUFpQixFQUFFO2dCQUM5QyxJQUFJLEVBQUUsS0FBSzthQUNaLENBQUM7UUFDSixDQUFDO1FBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsRUFBRTtZQUM1QixTQUFTLEVBQUUsT0FBTyxDQUFDLFNBQVM7WUFDNUIsTUFBTSxFQUFFLE9BQU8sQ0FBQyxNQUFNO1lBQ3RCLGlCQUFpQixFQUFFLE9BQU8sQ0FBQyxZQUFZLEVBQUUsTUFBTSxJQUFJLENBQUM7U0FDckQsQ0FBQyxDQUFDO1FBRUgsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDO1FBQzNDLHlCQUF5QjtRQUN6QixNQUFNLGVBQWUsR0FBRyxzQkFBc0IsQ0FBQyxvQkFBb0IsQ0FBQztZQUNsRSxHQUFHLEVBQUUsWUFBWTtZQUNqQixRQUFRLEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxTQUFTO1NBQ3hFLENBQUMsQ0FBQztRQUVILE9BQU8sQ0FBQyxHQUFHLENBQUMsMEJBQTBCLEVBQUU7WUFDdEMsT0FBTyxFQUFFLGVBQWUsQ0FBQyxPQUFPO1lBQ2hDLE1BQU0sRUFBRSxlQUFlLENBQUMsTUFBTTtTQUMvQixDQUFDLENBQUM7UUFFSCxJQUFJLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxDQUFDO1lBQzdCLE9BQU8sQ0FBQyxJQUFJLENBQUMsb0NBQW9DLE9BQU8sR0FBRyxFQUFFLGVBQWUsQ0FBQyxNQUFNLENBQUMsQ0FBQztZQUNyRixPQUFPLENBQUMsR0FBRyxDQUFDLHFEQUFxRCxDQUFDLENBQUM7WUFDbkUsTUFBTSxjQUFjLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSx5QkFBeUIsZUFBZSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1lBRXZILE9BQU8sQ0FBQyxHQUFHLENBQUMsNENBQTRDLENBQUMsQ0FBQztZQUMxRCx3QkFBd0I7WUFDeEIsdURBQXVEO1lBQ3ZELE1BQU0sT0FBTyxHQUFHLFVBQVUsQ0FBQyxLQUFLLENBQUMsQ0FBQztZQUNsQyxNQUFNLGNBQWMsR0FBRyxXQUFXLENBQUMsMkJBQTJCLENBQUM7Z0JBQzdELFlBQVksRUFBRSxHQUFHLE9BQU8saUJBQWlCO2dCQUN6QyxVQUFVLEVBQUUsR0FBRyxPQUFPLGVBQWU7Z0JBQ3JDLFNBQVMsRUFBRSxFQUFFO2dCQUNiLE9BQU8sRUFBRSxFQUFFO2dCQUNYLE1BQU0sRUFBRSxzREFBc0Q7YUFDL0QsQ0FBQyxDQUFDO1lBRUgsTUFBTSxLQUFLLEdBQUcsWUFBWSxDQUFDLHFCQUFxQixDQUFDO2dCQUMvQyxZQUFZLENBQUMsYUFBYSxDQUFDLHNEQUFzRCxDQUFDO2dCQUNsRixjQUFjO2FBQ2YsQ0FBQyxDQUFDO1lBRUgsT0FBTyxDQUFDLEdBQUcsQ0FBQyw4Q0FBOEMsQ0FBQyxDQUFDO1lBQzVELE9BQU87Z0JBQ0wsVUFBVSxFQUFFLEdBQUc7Z0JBQ2YsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLGlCQUFpQixFQUFFO2dCQUM5QyxJQUFJLEVBQUUsS0FBSzthQUNaLENBQUM7UUFDSixDQUFDO1FBRUQsT0FBTyxDQUFDLEdBQUcsQ0FBQyw2Q0FBNkMsQ0FBQyxDQUFDO1FBQzNELHdDQUF3QztRQUN4QyxNQUFNLGNBQWMsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSwrQ0FBK0MsRUFBRSxZQUFZLENBQUMsQ0FBQztRQUN0SCxPQUFPLENBQUMsR0FBRyxDQUFDLG1CQUFtQixPQUFPLENBQUMsU0FBUyx3QkFBd0IsQ0FBQyxDQUFDO1FBRTFFLDJEQUEyRDtRQUMzRCxJQUFJLENBQUM7WUFDSCxPQUFPLENBQUMsR0FBRyxDQUFDLHNDQUFzQyxPQUFPLENBQUMsU0FBUyxFQUFFLENBQUMsQ0FBQztZQUN2RSxPQUFPLENBQUMsR0FBRyxDQUFDLDJCQUEyQixFQUFFO2dCQUN2QyxZQUFZO2dCQUNaLFNBQVMsRUFBRSxPQUFPLENBQUMsU0FBUztnQkFDNUIsT0FBTzthQUNSLENBQUMsQ0FBQztZQUVILE1BQU0sbUJBQW1CLEdBQUcsTUFBTSxzQkFBc0IsQ0FBQyxtQkFBbUIsQ0FDMUUsWUFBWSxFQUNaLE9BQU8sQ0FBQyxTQUFTLEVBQ2pCLE9BQU8sQ0FDUixDQUFDO1lBRUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsc0JBQXNCLENBQUMsc0JBQXNCLENBQUMsbUJBQW1CLENBQUMsRUFBRSxDQUFDLENBQUM7WUFDOUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsRUFBRTtnQkFDeEMsSUFBSSxFQUFFLG1CQUFtQixDQUFDLElBQUk7Z0JBQzlCLFVBQVUsRUFBRSxtQkFBbUIsQ0FBQyxVQUFVO2dCQUMxQyxZQUFZLEVBQUUsc0JBQXNCLENBQUMseUJBQXlCLENBQUMsbUJBQW1CLENBQUM7YUFDcEYsQ0FBQyxDQUFDO1lBRUgsMkNBQTJDO1lBQzNDLElBQUksc0JBQXNCLENBQUMseUJBQXlCLENBQUMsbUJBQW1CLENBQUMsRUFBRSxDQUFDO2dCQUMxRSxPQUFPLENBQUMsR0FBRyxDQUFDLGtEQUFrRCxDQUFDLENBQUM7Z0JBQ2hFLDREQUE0RDtnQkFDNUQsTUFBTSxjQUFjLENBQUMsY0FBYyxDQUNqQyxPQUFPLENBQUMsU0FBUyxFQUNqQixtQkFBbUIsQ0FBQyxJQUFJLEVBQ3hCLFlBQVksRUFDWixtQkFBbUIsQ0FBQyxVQUFVLENBQy9CLENBQUM7Z0JBRUYsT0FBTyxDQUFDLEdBQUcsQ0FBQyx3Q0FBd0MsT0FBTyxDQUFDLFNBQVMsTUFBTSxtQkFBbUIsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDO2dCQUV4RyxPQUFPLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxDQUFDLENBQUM7Z0JBQ2xELDJEQUEyRDtnQkFDM0QsTUFBTSxPQUFPLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO2dCQUNsQyxNQUFNLEtBQUssR0FBRyxZQUFZLENBQUMsb0JBQW9CLENBQUMsRUFBRSxFQUFFO29CQUNsRCxNQUFNLEVBQUUsR0FBRyxPQUFPLGVBQWU7b0JBQ2pDLE9BQU8sRUFBRSxFQUFFO29CQUNYLFNBQVMsRUFBRSxDQUFDO29CQUNaLFdBQVcsRUFBRSxFQUFFO2lCQUNoQixDQUFDLENBQUM7Z0JBRUgsT0FBTyxDQUFDLEdBQUcsQ0FBQyxtREFBbUQsQ0FBQyxDQUFDO2dCQUNqRSxPQUFPO29CQUNMLFVBQVUsRUFBRSxHQUFHO29CQUNmLE9BQU8sRUFBRSxFQUFFLGNBQWMsRUFBRSxpQkFBaUIsRUFBRTtvQkFDOUMsSUFBSSxFQUFFLEtBQUs7aUJBQ1osQ0FBQztZQUVKLENBQUM7aUJBQU0sQ0FBQztnQkFDTixPQUFPLENBQUMsR0FBRyxDQUFDLHdEQUF3RCxDQUFDLENBQUM7Z0JBQ3RFLDZDQUE2QztnQkFDN0MsTUFBTSxZQUFZLEdBQUcsc0JBQXNCLENBQUMsNEJBQTRCLENBQUMsbUJBQW1CLENBQUMsQ0FBQztnQkFFOUYsTUFBTSxjQUFjLENBQUMsZ0JBQWdCLENBQ25DLE9BQU8sQ0FBQyxTQUFTLEVBQ2pCLHdCQUF3QixZQUFZLGlCQUFpQixtQkFBbUIsQ0FBQyxVQUFVLEdBQUcsQ0FDdkYsQ0FBQztnQkFFRixPQUFPLENBQUMsR0FBRyxDQUFDLDJDQUEyQyxPQUFPLENBQUMsU0FBUyxnQkFBZ0IsbUJBQW1CLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQztnQkFFMUgsZ0RBQWdEO2dCQUNoRCxNQUFNLE9BQU8sR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7Z0JBQ2xDLE1BQU0sY0FBYyxHQUFHLFdBQVcsQ0FBQywyQkFBMkIsQ0FBQztvQkFDN0QsWUFBWSxFQUFFLEdBQUcsT0FBTyxpQkFBaUI7b0JBQ3pDLFVBQVUsRUFBRSxHQUFHLE9BQU8sZUFBZTtvQkFDckMsU0FBUyxFQUFFLEVBQUU7b0JBQ2IsT0FBTyxFQUFFLEVBQUU7b0JBQ1gsTUFBTSxFQUFFLFlBQVk7aUJBQ3JCLENBQUMsQ0FBQztnQkFFSCxNQUFNLEtBQUssR0FBRyxZQUFZLENBQUMscUJBQXFCLENBQUM7b0JBQy9DLFlBQVksQ0FBQyxhQUFhLENBQUMsWUFBWSxDQUFDO29CQUN4QyxjQUFjO2lCQUNmLENBQUMsQ0FBQztnQkFFSCxPQUFPO29CQUNMLFVBQVUsRUFBRSxHQUFHO29CQUNmLE9BQU8sRUFBRSxFQUFFLGNBQWMsRUFBRSxpQkFBaUIsRUFBRTtvQkFDOUMsSUFBSSxFQUFFLEtBQUs7aUJBQ1osQ0FBQztZQUNKLENBQUM7UUFFSCxDQUFDO1FBQUMsT0FBTyxrQkFBa0IsRUFBRSxDQUFDO1lBQzVCLE9BQU8sQ0FBQyxLQUFLLENBQUMsa0NBQWtDLEVBQUUsa0JBQWtCLENBQUMsQ0FBQztZQUV0RSxNQUFNLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FDbkMsT0FBTyxDQUFDLFNBQVMsRUFDakIseUJBQXlCLGtCQUFrQixZQUFZLEtBQUssQ0FBQyxDQUFDLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FDOUcsQ0FBQztZQUVGLHlEQUF5RDtZQUN6RCxNQUFNLE9BQU8sR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7WUFDbEMsTUFBTSxjQUFjLEdBQUcsV0FBVyxDQUFDLDJCQUEyQixDQUFDO2dCQUM3RCxZQUFZLEVBQUUsR0FBRyxPQUFPLGlCQUFpQjtnQkFDekMsVUFBVSxFQUFFLEdBQUcsT0FBTyxlQUFlO2dCQUNyQyxTQUFTLEVBQUUsRUFBRTtnQkFDYixPQUFPLEVBQUUsRUFBRTtnQkFDWCxNQUFNLEVBQUUsOEVBQThFO2FBQ3ZGLENBQUMsQ0FBQztZQUVILE1BQU0sS0FBSyxHQUFHLFlBQVksQ0FBQyxxQkFBcUIsQ0FBQztnQkFDL0MsWUFBWSxDQUFDLGFBQWEsQ0FBQyw4RUFBOEUsQ0FBQztnQkFDMUcsY0FBYzthQUNmLENBQUMsQ0FBQztZQUVILE9BQU87Z0JBQ0wsVUFBVSxFQUFFLEdBQUc7Z0JBQ2YsT0FBTyxFQUFFLEVBQUUsY0FBYyxFQUFFLGlCQUFpQixFQUFFO2dCQUM5QyxJQUFJLEVBQUUsS0FBSzthQUNaLENBQUM7UUFDSixDQUFDO0lBRUgsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLGtDQUFrQyxFQUFFLEtBQUssQ0FBQyxDQUFDO1FBRXpELG9CQUFvQjtRQUNwQixNQUFNLEtBQUssR0FBRyxZQUFZLENBQUMsaUJBQWlCLENBQUMsNkVBQTZFLENBQUMsQ0FBQztRQUM1SCxPQUFPO1lBQ0wsVUFBVSxFQUFFLEdBQUc7WUFDZixPQUFPLEVBQUUsRUFBRSxjQUFjLEVBQUUsaUJBQWlCLEVBQUU7WUFDOUMsSUFBSSxFQUFFLEtBQUs7U0FDWixDQUFDO0lBQ0osQ0FBQztBQUNILENBQUM7QUFFRCxLQUFLLFVBQVUsaUJBQWlCLENBQUMsSUFBNEIsRUFBRSxLQUEyQjtJQUN4RixNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLEdBQUcsWUFBWSxDQUFDLG1CQUFtQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBRTdFLE9BQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLE1BQU0saUJBQWlCLE9BQU8sRUFBRSxDQUFDLENBQUM7SUFFdEUsSUFBSSxDQUFDO1FBQ0gsK0NBQStDO1FBQy9DLE1BQU0sT0FBTyxHQUFHLE1BQU0sY0FBYyxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxDQUFDO1FBQ2xFLElBQUksT0FBTyxFQUFFLENBQUM7WUFDWixNQUFNLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLHdCQUF3QixNQUFNLEVBQUUsQ0FBQyxDQUFDO1FBQzdGLENBQUM7YUFBTSxDQUFDO1lBQ04sT0FBTyxDQUFDLElBQUksQ0FBQyxrQ0FBa0MsT0FBTyxFQUFFLENBQUMsQ0FBQztRQUM1RCxDQUFDO0lBQ0gsQ0FBQztJQUFDLE9BQU8sS0FBSyxFQUFFLENBQUM7UUFDZixPQUFPLENBQUMsS0FBSyxDQUFDLHVDQUF1QyxFQUFFLEtBQUssQ0FBQyxDQUFDO0lBQ2hFLENBQUM7SUFFRCxNQUFNLFNBQVMsR0FBRztRQUNoQixNQUFNO1FBQ04sT0FBTztRQUNQLElBQUk7UUFDSixFQUFFO0tBQ0gsQ0FBQztJQUVGLE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsQ0FBQztJQUV6RCxNQUFNLEtBQUssR0FBYSxFQUFFLENBQUM7SUFFM0IsSUFBSSxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUM7UUFDckIsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDO0lBQzNELENBQUM7SUFFRCxJQUFJLFFBQVEsQ0FBQyxNQUFNLEtBQUssUUFBUSxFQUFFLENBQUM7UUFDakMsaURBQWlEO1FBQ2pELEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQywyQ0FBMkMsQ0FBQyxDQUFDLENBQUM7UUFDcEYsa0RBQWtEO1FBQ2xELEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGFBQWEsQ0FBQyx3RkFBd0YsQ0FBQyxDQUFDLENBQUM7UUFDakksS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDNUMsS0FBSyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsYUFBYSxDQUFDLDZDQUE2QyxDQUFDLENBQUMsQ0FBQztRQUV0RiwwQ0FBMEM7UUFDMUMsTUFBTSxPQUFPLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2xDLE1BQU0sY0FBYyxHQUFHLFdBQVcsQ0FBQywyQkFBMkIsQ0FBQztZQUM3RCxZQUFZLEVBQUUsR0FBRyxPQUFPLGlCQUFpQjtZQUN6QyxVQUFVLEVBQUUsR0FBRyxPQUFPLGVBQWU7WUFDckMsU0FBUyxFQUFFLEVBQUU7WUFDYixPQUFPLEVBQUUsRUFBRTtZQUNYLE1BQU0sRUFBRSxXQUFXLENBQUMsd0JBQXdCLEVBQUU7U0FDL0MsQ0FBQyxDQUFDO1FBQ0gsS0FBSyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUU3QixDQUFDO1NBQU0sSUFBSSxRQUFRLENBQUMsTUFBTSxLQUFLLFVBQVUsRUFBRSxDQUFDO1FBQzFDLDZDQUE2QztRQUM3QyxJQUFJLENBQUM7WUFDSCx5REFBeUQ7WUFDekQsTUFBTSxPQUFPLEdBQUcsTUFBTSxjQUFjLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLENBQUM7WUFDbEUsSUFBSSxPQUFPLEVBQUUsQ0FBQztnQkFDWixNQUFNLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLFdBQVcsRUFBRSxJQUFJLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQztnQkFDckYsTUFBTSxjQUFjLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSx3Q0FBd0MsQ0FBQyxDQUFDO1lBQ3JHLENBQUM7aUJBQU0sQ0FBQztnQkFDTixPQUFPLENBQUMsSUFBSSxDQUFDLGtDQUFrQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQzVELENBQUM7UUFDSCxDQUFDO1FBQUMsT0FBTyxLQUFLLEVBQUUsQ0FBQztZQUNmLE9BQU8sQ0FBQyxLQUFLLENBQUMscUNBQXFDLEVBQUUsS0FBSyxDQUFDLENBQUM7UUFDOUQsQ0FBQztRQUNELEtBQUssQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLGdCQUFnQixFQUFFLENBQUMsQ0FBQztJQUU5QyxDQUFDO1NBQU0sSUFBSSxRQUFRLENBQUMsTUFBTSxLQUFLLE1BQU0sRUFBRSxDQUFDO1FBQ3RDLGtDQUFrQztRQUNsQyxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUU1QyxxQ0FBcUM7UUFDckMsTUFBTSxPQUFPLEdBQUcsVUFBVSxDQUFDLEtBQUssQ0FBQyxDQUFDO1FBQ2xDLE1BQU0sY0FBYyxHQUFHLFdBQVcsQ0FBQywyQkFBMkIsQ0FBQztZQUM3RCxZQUFZLEVBQUUsR0FBRyxPQUFPLGlCQUFpQjtZQUN6QyxVQUFVLEVBQUUsR0FBRyxPQUFPLGVBQWU7WUFDckMsU0FBUyxFQUFFLEVBQUU7WUFDYixPQUFPLEVBQUUsRUFBRTtZQUNYLE1BQU0sRUFBRSw0Q0FBNEM7U0FDckQsQ0FBQyxDQUFDO1FBQ0gsS0FBSyxDQUFDLElBQUksQ0FBQyxjQUFjLENBQUMsQ0FBQztJQUU3QixDQUFDO1NBQU0sQ0FBQztRQUNOLGdEQUFnRDtRQUNoRCxLQUFLLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztRQUU1QyxNQUFNLE9BQU8sR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLENBQUM7UUFDbEMsTUFBTSxjQUFjLEdBQUcsV0FBVyxDQUFDLDJCQUEyQixDQUFDO1lBQzdELFlBQVksRUFBRSxHQUFHLE9BQU8saUJBQWlCO1lBQ3pDLFVBQVUsRUFBRSxHQUFHLE9BQU8sZUFBZTtZQUNyQyxTQUFTLEVBQUUsRUFBRTtZQUNiLE9BQU8sRUFBRSxFQUFFO1lBQ1gsTUFBTSxFQUFFLDRDQUE0QztTQUNyRCxDQUFDLENBQUM7UUFDSCxLQUFLLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxDQUFDO0lBQzdCLENBQUM7SUFFRCxNQUFNLEtBQUssR0FBRyxZQUFZLENBQUMscUJBQXFCLENBQUMsS0FBSyxDQUFDLENBQUM7SUFFeEQsT0FBTztRQUNMLFVBQVUsRUFBRSxHQUFHO1FBQ2YsT0FBTyxFQUFFO1lBQ1AsY0FBYyxFQUFFLGlCQUFpQjtTQUNsQztRQUNELElBQUksRUFBRSxLQUFLO0tBQ1osQ0FBQztBQUNKLENBQUM7QUFFRCxLQUFLLFVBQVUsbUJBQW1CLENBQUMsSUFBNEI7SUFDN0QsTUFBTSxFQUFFLGVBQWUsRUFBRSxPQUFPLEVBQUUsVUFBVSxFQUFFLFlBQVksRUFBRSxHQUFHLFlBQVksQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUV0RyxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixPQUFPLHVCQUF1QixlQUFlLGtCQUFrQixVQUFVLEVBQUUsQ0FBQyxDQUFDO0lBRXhILElBQUksQ0FBQztRQUNILDBCQUEwQjtRQUMxQixNQUFNLE9BQU8sR0FBRyxNQUFNLGNBQWMsQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsQ0FBQztRQUNsRSxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7WUFDYixPQUFPLENBQUMsSUFBSSxDQUFDLGtDQUFrQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO1lBQzFELGdEQUFnRDtRQUNsRCxDQUFDO2FBQU0sQ0FBQztZQUNOLG1DQUFtQztZQUNuQyxJQUFJLGVBQWUsRUFBRSxDQUFDO2dCQUNwQiwwQkFBMEI7Z0JBQzFCLE1BQU0sY0FBYyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUscUJBQXFCLGVBQWUsRUFBRSxDQUFDLENBQUM7Z0JBRWpHLElBQUksZUFBZSxLQUFLLFdBQVcsRUFBRSxDQUFDO29CQUNwQyxPQUFPLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO2dCQUM3RCxDQUFDO3FCQUFNLElBQUksZUFBZSxLQUFLLFFBQVEsRUFBRSxDQUFDO29CQUN4QyxPQUFPLENBQUMsR0FBRyxDQUFDLGlDQUFpQyxPQUFPLEVBQUUsQ0FBQyxDQUFDO29CQUN4RCxNQUFNLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsU0FBUyxFQUFFLCtDQUErQyxDQUFDLENBQUM7Z0JBQzVHLENBQUM7WUFDSCxDQUFDO1lBRUQsSUFBSSxVQUFVLEVBQUUsQ0FBQztnQkFDZixxQkFBcUI7Z0JBQ3JCLE1BQU0sY0FBYyxDQUFDLGdCQUFnQixDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsZ0JBQWdCLFVBQVUsRUFBRSxDQUFDLENBQUM7Z0JBRXZGLElBQUksVUFBVSxLQUFLLFdBQVcsRUFBRSxDQUFDO29CQUMvQiw4QkFBOEI7b0JBQzlCLE1BQU0sUUFBUSxHQUFHLFlBQVksQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7b0JBQzNELE1BQU0sY0FBYyxDQUFDLG1CQUFtQixDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUUsV0FBVyxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsQ0FBQyxDQUFDO29CQUNyRixJQUFJLFFBQVEsR0FBRyxDQUFDLEVBQUUsQ0FBQzt3QkFDakIsTUFBTSxjQUFjLENBQUMsa0JBQWtCLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxRQUFRLENBQUMsQ0FBQztvQkFDdkUsQ0FBQztvQkFDRCxPQUFPLENBQUMsR0FBRyxDQUFDLCtCQUErQixPQUFPLGVBQWUsUUFBUSxHQUFHLENBQUMsQ0FBQztnQkFFaEYsQ0FBQztxQkFBTSxJQUFJLFVBQVUsS0FBSyxRQUFRLElBQUksVUFBVSxLQUFLLE1BQU0sSUFBSSxVQUFVLEtBQUssV0FBVyxFQUFFLENBQUM7b0JBQzFGLDBDQUEwQztvQkFDMUMsTUFBTSxjQUFjLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxRQUFRLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFO3dCQUNoRixJQUFJLEVBQUUsVUFBVTt3QkFDaEIsT0FBTyxFQUFFLFFBQVEsVUFBVSxFQUFFO3FCQUM5QixDQUFDLENBQUM7b0JBQ0gsT0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsT0FBTyxhQUFhLFVBQVUsRUFBRSxDQUFDLENBQUM7Z0JBQzVFLENBQUM7WUFDSCxDQUFDO1FBQ0gsQ0FBQztJQUVILENBQUM7SUFBQyxPQUFPLEtBQUssRUFBRSxDQUFDO1FBQ2YsT0FBTyxDQUFDLEtBQUssQ0FBQywrQkFBK0IsRUFBRSxLQUFLLENBQUMsQ0FBQztRQUN0RCxtREFBbUQ7SUFDckQsQ0FBQztJQUVELE1BQU0sS0FBSyxHQUFHLFlBQVksQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUVyRCxPQUFPO1FBQ0wsVUFBVSxFQUFFLEdBQUc7UUFDZixPQUFPLEVBQUU7WUFDUCxjQUFjLEVBQUUsaUJBQWlCO1NBQ2xDO1FBQ0QsSUFBSSxFQUFFLEtBQUs7S0FDWixDQUFDO0FBQ0osQ0FBQztBQUVELFNBQVMsbUJBQW1CLENBQUMsT0FBZTtJQUMxQyxNQUFNLEtBQUssR0FBRyxZQUFZLENBQUMsaUJBQWlCLENBQUMsT0FBTyxDQUFDLENBQUM7SUFFdEQsT0FBTztRQUNMLFVBQVUsRUFBRSxHQUFHO1FBQ2YsT0FBTyxFQUFFO1lBQ1AsY0FBYyxFQUFFLGlCQUFpQjtTQUNsQztRQUNELElBQUksRUFBRSxLQUFLO0tBQ1osQ0FBQztBQUNKLENBQUMiLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBBUElHYXRld2F5UHJveHlFdmVudCwgQVBJR2F0ZXdheVByb3h5UmVzdWx0IH0gZnJvbSAnYXdzLWxhbWJkYSc7XG5cbmNvbnNvbGUubG9nKCc9PT0gTEFNQkRBIElOSVRJQUxJWkFUSU9OIFNUQVJUID09PScpO1xuY29uc29sZS5sb2coJ0Vudmlyb25tZW50IHZhcmlhYmxlczonLCB7XG4gIFNFU1NJT05fVEFCTEVfTkFNRTogcHJvY2Vzcy5lbnYuU0VTU0lPTl9UQUJMRV9OQU1FLFxuICBBVURJT19CVUNLRVRfTkFNRTogcHJvY2Vzcy5lbnYuQVVESU9fQlVDS0VUX05BTUUsXG4gIEFXU19SRUdJT046IHByb2Nlc3MuZW52LkFXU19SRUdJT04sXG4gIE5PREVfRU5WOiBwcm9jZXNzLmVudi5OT0RFX0VOVlxufSk7XG5cbmNvbnNvbGUubG9nKCdBdHRlbXB0aW5nIHRvIGltcG9ydCBzZXJ2aWNlcy4uLicpO1xudHJ5IHtcbiAgY29uc29sZS5sb2coJ0ltcG9ydGluZyBzZXJ2aWNlcyBmcm9tIC4uL3NlcnZpY2VzJyk7XG4gIGNvbnN0IHNlcnZpY2VzID0gcmVxdWlyZSgnLi4vc2VydmljZXMnKTtcbiAgY29uc29sZS5sb2coJ0F2YWlsYWJsZSBzZXJ2aWNlczonLCBPYmplY3Qua2V5cyhzZXJ2aWNlcykpO1xuICBcbiAgdmFyIHsgXG4gICAgRFRNRlNlcnZpY2UsIFxuICAgIFR3aU1MU2VydmljZSwgXG4gICAgRHluYW1vU2Vzc2lvbk1hbmFnZXIsXG4gICAgUzNTZXJ2aWNlLFxuICAgIFRyYW5zY3JpcHRpb25Qcm9jZXNzb3JcbiAgfSA9IHNlcnZpY2VzO1xuICBcbiAgY29uc29sZS5sb2coJ1NlcnZpY2VzIGltcG9ydGVkIHN1Y2Nlc3NmdWxseScpO1xufSBjYXRjaCAoaW1wb3J0RXJyb3IpIHtcbiAgY29uc29sZS5lcnJvcignQ1JJVElDQUw6IEZhaWxlZCB0byBpbXBvcnQgc2VydmljZXM6JywgaW1wb3J0RXJyb3IpO1xuICBjb25zb2xlLmVycm9yKCdJbXBvcnQgZXJyb3Igc3RhY2s6JywgaW1wb3J0RXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IGltcG9ydEVycm9yLnN0YWNrIDogJ05vIHN0YWNrIHRyYWNlJyk7XG4gIHRocm93IGltcG9ydEVycm9yO1xufVxuXG5jb25zb2xlLmxvZygnSW5pdGlhbGl6aW5nIHNlcnZpY2UgaW5zdGFuY2VzLi4uJyk7XG50cnkge1xuICB2YXIgZHRtZlNlcnZpY2UgPSBuZXcgRFRNRlNlcnZpY2UoKTtcbiAgY29uc29sZS5sb2coJ0RUTUZTZXJ2aWNlIGluaXRpYWxpemVkJyk7XG4gIFxuICB2YXIgdHdpbWxTZXJ2aWNlID0gbmV3IFR3aU1MU2VydmljZSgpO1xuICBjb25zb2xlLmxvZygnVHdpTUxTZXJ2aWNlIGluaXRpYWxpemVkJyk7XG4gIFxuICB2YXIgc2Vzc2lvbk1hbmFnZXIgPSBuZXcgRHluYW1vU2Vzc2lvbk1hbmFnZXIoe1xuICAgIHRhYmxlTmFtZTogcHJvY2Vzcy5lbnYuU0VTU0lPTl9UQUJMRV9OQU1FIHx8ICdwcm9tcHRjYWxsLXNlc3Npb25zJyxcbiAgICByZWdpb246IHByb2Nlc3MuZW52LkFXU19SRUdJT04gfHwgJ3VzLWVhc3QtMSdcbiAgfSk7XG4gIGNvbnNvbGUubG9nKCdEeW5hbW9TZXNzaW9uTWFuYWdlciBpbml0aWFsaXplZCcpO1xuXG4gIHZhciBzM1NlcnZpY2UgPSBuZXcgUzNTZXJ2aWNlKHtcbiAgICBidWNrZXROYW1lOiBwcm9jZXNzLmVudi5BVURJT19CVUNLRVRfTkFNRSB8fCAncHJvbXB0Y2FsbC1hdWRpby1idWNrZXQnLFxuICAgIHJlZ2lvbjogcHJvY2Vzcy5lbnYuQVdTX1JFR0lPTiB8fCAndXMtZWFzdC0xJ1xuICB9KTtcbiAgY29uc29sZS5sb2coJ1MzU2VydmljZSBpbml0aWFsaXplZCcpO1xuXG4gIHZhciB0cmFuc2NyaXB0aW9uUHJvY2Vzc29yID0gbmV3IFRyYW5zY3JpcHRpb25Qcm9jZXNzb3IoczNTZXJ2aWNlLCB7XG4gICAgcmVnaW9uOiBwcm9jZXNzLmVudi5BV1NfUkVHSU9OIHx8ICd1cy1lYXN0LTEnLFxuICAgIGNvbmZpZGVuY2VUaHJlc2hvbGQ6IDAuNyxcbiAgICBtYXhSZXRyaWVzOiAyXG4gIH0pO1xuICBjb25zb2xlLmxvZygnVHJhbnNjcmlwdGlvblByb2Nlc3NvciBpbml0aWFsaXplZCcpO1xuICBcbn0gY2F0Y2ggKGluaXRFcnJvcikge1xuICBjb25zb2xlLmVycm9yKCdDUklUSUNBTDogRmFpbGVkIHRvIGluaXRpYWxpemUgc2VydmljZXM6JywgaW5pdEVycm9yKTtcbiAgY29uc29sZS5lcnJvcignSW5pdGlhbGl6YXRpb24gZXJyb3Igc3RhY2s6JywgaW5pdEVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBpbml0RXJyb3Iuc3RhY2sgOiAnTm8gc3RhY2sgdHJhY2UnKTtcbiAgdGhyb3cgaW5pdEVycm9yO1xufVxuXG5jb25zb2xlLmxvZygnPT09IExBTUJEQSBJTklUSUFMSVpBVElPTiBDT01QTEVURSA9PT0nKTtcblxuZXhwb3J0IGNvbnN0IGhhbmRsZXIgPSBhc3luYyAoZXZlbnQ6IEFQSUdhdGV3YXlQcm94eUV2ZW50KTogUHJvbWlzZTxBUElHYXRld2F5UHJveHlSZXN1bHQ+ID0+IHtcbiAgY29uc29sZS5sb2coJz09PSBXRUJIT09LIFJFUVVFU1QgU1RBUlQgPT09Jyk7XG4gIGNvbnNvbGUubG9nKCdSZXF1ZXN0IElEOicsIGV2ZW50LnJlcXVlc3RDb250ZXh0Py5yZXF1ZXN0SWQpO1xuICBjb25zb2xlLmxvZygnUGF0aDonLCBldmVudC5wYXRoKTtcbiAgY29uc29sZS5sb2coJ01ldGhvZDonLCBldmVudC5odHRwTWV0aG9kKTtcbiAgY29uc29sZS5sb2coJ0hlYWRlcnM6JywgSlNPTi5zdHJpbmdpZnkoZXZlbnQuaGVhZGVycywgbnVsbCwgMikpO1xuICBjb25zb2xlLmxvZygnQm9keTonLCBldmVudC5ib2R5KTtcbiAgY29uc29sZS5sb2coJz09PSBXRUJIT09LIFJFUVVFU1QgREVUQUlMUyA9PT0nKTtcbiAgXG4gIGNvbnN0IHBhdGggPSBldmVudC5wYXRoO1xuICBjb25zdCBodHRwTWV0aG9kID0gZXZlbnQuaHR0cE1ldGhvZDtcbiAgXG4gIHRyeSB7XG4gICAgY29uc29sZS5sb2coJ1Byb2Nlc3Npbmcgd2ViaG9vayByZXF1ZXN0Li4uJyk7XG4gICAgY29uc29sZS5sb2coJ1JlcXVlc3QgcGF0aDonLCBwYXRoKTtcbiAgICBjb25zb2xlLmxvZygnSFRUUCBtZXRob2Q6JywgaHR0cE1ldGhvZCk7XG4gICAgXG4gICAgLy8gUGFyc2UgVHdpbGlvIHdlYmhvb2sgcGFyYW1ldGVyc1xuICAgIGNvbnN0IGJvZHkgPSBldmVudC5ib2R5ID8gcGFyc2VGb3JtRGF0YShldmVudC5ib2R5KSA6IHt9O1xuICAgIGNvbnNvbGUubG9nKCdSYXcgYm9keTonLCBldmVudC5ib2R5KTtcbiAgICBjb25zb2xlLmxvZygnUGFyc2VkIHdlYmhvb2sgYm9keTonLCBKU09OLnN0cmluZ2lmeShib2R5LCBudWxsLCAyKSk7XG4gICAgXG4gICAgLy8gUm91dGUgdG8gYXBwcm9wcmlhdGUgaGFuZGxlciBiYXNlZCBvbiBwYXRoXG4gICAgY29uc29sZS5sb2coJ1JvdXRpbmcgcmVxdWVzdC4uLicpO1xuICAgIGNvbnNvbGUubG9nKCdQYXRoIG1hdGNoaW5nIGNoZWNrOicsIHtcbiAgICAgIHBhdGgsXG4gICAgICB2b2ljZU1hdGNoOiBwYXRoLmluY2x1ZGVzKCcvd2ViaG9vay92b2ljZScpLFxuICAgICAgc3BlZWNoTWF0Y2g6IHBhdGguaW5jbHVkZXMoJy93ZWJob29rL3NwZWVjaCcpLFxuICAgICAgZHRtZk1hdGNoOiBwYXRoLmluY2x1ZGVzKCcvd2ViaG9vay9kdG1mJyksXG4gICAgICBldmVudHNNYXRjaDogcGF0aC5pbmNsdWRlcygnL3dlYmhvb2svZXZlbnRzJyksXG4gICAgICBtZXRob2RNYXRjaDogaHR0cE1ldGhvZCA9PT0gJ1BPU1QnXG4gICAgfSk7XG4gICAgXG4gICAgaWYgKHBhdGguaW5jbHVkZXMoJy93ZWJob29rL3ZvaWNlJykgJiYgaHR0cE1ldGhvZCA9PT0gJ1BPU1QnKSB7XG4gICAgICBjb25zb2xlLmxvZygn4pyFIFJvdXRpbmcgdG8gdm9pY2Ugd2ViaG9vayBoYW5kbGVyJyk7XG4gICAgICByZXR1cm4gaGFuZGxlVm9pY2VXZWJob29rKGJvZHksIGV2ZW50KTtcbiAgICB9IGVsc2UgaWYgKHBhdGguaW5jbHVkZXMoJy93ZWJob29rL3NwZWVjaCcpICYmIGh0dHBNZXRob2QgPT09ICdQT1NUJykge1xuICAgICAgY29uc29sZS5sb2coJ+KchSBSb3V0aW5nIHRvIHNwZWVjaCB3ZWJob29rIGhhbmRsZXIgLSBFTkRQT0lOVCBSRUFDSEVEJyk7XG4gICAgICByZXR1cm4gaGFuZGxlU3BlZWNoV2ViaG9vayhib2R5LCBldmVudCk7XG4gICAgfSBlbHNlIGlmIChwYXRoLmluY2x1ZGVzKCcvd2ViaG9vay9kdG1mJykgJiYgaHR0cE1ldGhvZCA9PT0gJ1BPU1QnKSB7XG4gICAgICBjb25zb2xlLmxvZygn4pyFIFJvdXRpbmcgdG8gRFRNRiB3ZWJob29rIGhhbmRsZXInKTtcbiAgICAgIHJldHVybiBhd2FpdCBoYW5kbGVEVE1GV2ViaG9vayhib2R5LCBldmVudCk7XG4gICAgfSBlbHNlIGlmIChwYXRoLmluY2x1ZGVzKCcvd2ViaG9vay9ldmVudHMnKSAmJiBodHRwTWV0aG9kID09PSAnUE9TVCcpIHtcbiAgICAgIGNvbnNvbGUubG9nKCfinIUgUm91dGluZyB0byBldmVudHMgd2ViaG9vayBoYW5kbGVyJyk7XG4gICAgICByZXR1cm4gYXdhaXQgaGFuZGxlRXZlbnRzV2ViaG9vayhib2R5KTtcbiAgICB9XG4gICAgXG4gICAgY29uc29sZS5sb2coJ+KdjCBObyBtYXRjaGluZyByb3V0ZSBmb3VuZCcpO1xuICAgIGNvbnNvbGUubG9nKCdBdmFpbGFibGUgcm91dGVzIHNob3VsZCBiZTogL3dlYmhvb2svdm9pY2UsIC93ZWJob29rL3NwZWVjaCwgL3dlYmhvb2svZHRtZiwgL3dlYmhvb2svZXZlbnRzJyk7XG4gICAgY29uc29sZS5sb2coJ0FjdHVhbCBwYXRoIHJlY2VpdmVkOicsIHBhdGgpO1xuICAgIFxuICAgIC8vIEFkZCBhIHRlc3QgZW5kcG9pbnQgZm9yIGRlYnVnZ2luZ1xuICAgIGlmIChwYXRoLmluY2x1ZGVzKCcvdGVzdCcpIHx8IHBhdGggPT09ICcvJykge1xuICAgICAgY29uc29sZS5sb2coJ1Rlc3QgZW5kcG9pbnQgaGl0IC0gTGFtYmRhIGlzIHdvcmtpbmcnKTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL2pzb24nIH0sXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHtcbiAgICAgICAgICBtZXNzYWdlOiAnTGFtYmRhIGlzIHdvcmtpbmcnLFxuICAgICAgICAgIHRpbWVzdGFtcDogbmV3IERhdGUoKS50b0lTT1N0cmluZygpLFxuICAgICAgICAgIHBhdGg6IHBhdGgsXG4gICAgICAgICAgbWV0aG9kOiBodHRwTWV0aG9kXG4gICAgICAgIH0pXG4gICAgICB9O1xuICAgIH1cbiAgICBcbiAgICAvLyBEZWZhdWx0IHJlc3BvbnNlXG4gICAgcmV0dXJuIGNyZWF0ZVR3aU1MUmVzcG9uc2UoJ0hlbGxvIGZyb20gUHJvbXB0Q2FsbCBBSS4gUGxlYXNlIHRyeSBjYWxsaW5nIGFnYWluLicpO1xuICAgIFxuICB9IGNhdGNoIChlcnJvcikge1xuICAgIGNvbnNvbGUuZXJyb3IoJz09PSBDUklUSUNBTCBFUlJPUiBJTiBXRUJIT09LIEhBTkRMRVIgPT09Jyk7XG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgdHlwZTonLCBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IuY29uc3RydWN0b3IubmFtZSA6IHR5cGVvZiBlcnJvcik7XG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgbWVzc2FnZTonLCBlcnJvciBpbnN0YW5jZW9mIEVycm9yID8gZXJyb3IubWVzc2FnZSA6IFN0cmluZyhlcnJvcikpO1xuICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHN0YWNrOicsIGVycm9yIGluc3RhbmNlb2YgRXJyb3IgPyBlcnJvci5zdGFjayA6ICdObyBzdGFjayB0cmFjZScpO1xuICAgIGNvbnNvbGUuZXJyb3IoJ1JlcXVlc3QgY29udGV4dDonLCB7XG4gICAgICBwYXRoOiBldmVudC5wYXRoLFxuICAgICAgbWV0aG9kOiBldmVudC5odHRwTWV0aG9kLFxuICAgICAgcmVxdWVzdElkOiBldmVudC5yZXF1ZXN0Q29udGV4dD8ucmVxdWVzdElkXG4gICAgfSk7XG4gICAgY29uc29sZS5lcnJvcignPT09IEVORCBDUklUSUNBTCBFUlJPUiA9PT0nKTtcbiAgICBcbiAgICByZXR1cm4ge1xuICAgICAgc3RhdHVzQ29kZTogNTAwLFxuICAgICAgaGVhZGVyczoge1xuICAgICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3htbCdcbiAgICAgIH0sXG4gICAgICBib2R5OiAnPD94bWwgdmVyc2lvbj1cIjEuMFwiIGVuY29kaW5nPVwiVVRGLThcIj8+PFJlc3BvbnNlPjxTYXk+U29ycnksIHRoZXJlIHdhcyBhbiBlcnJvci4gUGxlYXNlIHRyeSBhZ2Fpbi48L1NheT48L1Jlc3BvbnNlPidcbiAgICB9O1xuICB9XG59O1xuXG5mdW5jdGlvbiBwYXJzZUZvcm1EYXRhKGJvZHk6IHN0cmluZyk6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4ge1xuICByZXR1cm4gVHdpTUxTZXJ2aWNlLnBhcnNlV2ViaG9va1BhcmFtcyhib2R5KTtcbn1cblxuZnVuY3Rpb24gZ2V0QmFzZVVybChldmVudDogQVBJR2F0ZXdheVByb3h5RXZlbnQpOiBzdHJpbmcge1xuICByZXR1cm4gYGh0dHBzOi8vJHtldmVudC5oZWFkZXJzLkhvc3R9JHtldmVudC5yZXF1ZXN0Q29udGV4dC5zdGFnZSA/IGAvJHtldmVudC5yZXF1ZXN0Q29udGV4dC5zdGFnZX1gIDogJyd9YDtcbn1cblxuYXN5bmMgZnVuY3Rpb24gaGFuZGxlVm9pY2VXZWJob29rKGJvZHk6IFJlY29yZDxzdHJpbmcsIHN0cmluZz4sIGV2ZW50OiBBUElHYXRld2F5UHJveHlFdmVudCk6IFByb21pc2U8QVBJR2F0ZXdheVByb3h5UmVzdWx0PiB7XG4gIGNvbnN0IHsgY2FsbFNpZCwgZnJvbSwgdG8sIGNhbGxTdGF0dXMgfSA9IFR3aU1MU2VydmljZS5leHRyYWN0VHdpbGlvUGFyYW1zKGJvZHkpO1xuICBcbiAgY29uc29sZS5sb2coYEluY29taW5nIGNhbGwgZnJvbSAke2Zyb219IHRvICR7dG99LCBDYWxsU2lkOiAke2NhbGxTaWR9LCBTdGF0dXM6ICR7Y2FsbFN0YXR1c31gKTtcbiAgXG4gIHRyeSB7XG4gICAgLy8gQ3JlYXRlIG5ldyBzZXNzaW9uIHdoZW4gY2FsbCBzdGFydHNcbiAgICBjb25zdCBzZXNzaW9uID0gYXdhaXQgc2Vzc2lvbk1hbmFnZXIuY3JlYXRlU2Vzc2lvbihjYWxsU2lkLCBmcm9tKTtcbiAgICBcbiAgICAvLyBBZGQgc3lzdGVtIG1lc3NhZ2UgdG8gdHJhY2sgY2FsbCBzdGFydFxuICAgIGF3YWl0IHNlc3Npb25NYW5hZ2VyLmFkZFN5c3RlbU1lc3NhZ2Uoc2Vzc2lvbi5zZXNzaW9uSWQsIGBDYWxsIHN0YXJ0ZWQgZnJvbSAke2Zyb219IHRvICR7dG99LCBTdGF0dXM6ICR7Y2FsbFN0YXR1c31gKTtcbiAgICBcbiAgICBjb25zb2xlLmxvZyhgQ3JlYXRlZCBzZXNzaW9uIGZvciBDYWxsU2lkOiAke2NhbGxTaWR9LCBTZXNzaW9uSWQ6ICR7c2Vzc2lvbi5zZXNzaW9uSWR9YCk7XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgY3JlYXRpbmcgc2Vzc2lvbjonLCBlcnJvcik7XG4gICAgLy8gQ29udGludWUgd2l0aCBjYWxsIGV2ZW4gaWYgc2Vzc2lvbiBjcmVhdGlvbiBmYWlsc1xuICB9XG4gIFxuICAvLyBDcmVhdGUgVHdpTUwgcmVzcG9uc2Ugd2l0aCB3ZWxjb21lIG1lc3NhZ2UgYW5kIHJlY29yZGluZ1xuICBjb25zdCB3ZWxjb21lTWVzc2FnZSA9IGR0bWZTZXJ2aWNlLmdlbmVyYXRlV2VsY29tZVdpdGhJbnN0cnVjdGlvbnMoKTtcbiAgXG4gIC8vIEdldCB0aGUgYmFzZSBVUkwgZnJvbSB0aGUgZXZlbnRcbiAgY29uc3QgYmFzZVVybCA9IGdldEJhc2VVcmwoZXZlbnQpO1xuICBcbiAgY29uc3QgdHdpbWwgPSB0d2ltbFNlcnZpY2UuY3JlYXRlV2VsY29tZVdpdGhSZWNvcmRpbmcod2VsY29tZU1lc3NhZ2UsIHtcbiAgICBhY3Rpb246IGAke2Jhc2VVcmx9L3dlYmhvb2svc3BlZWNoYCxcbiAgICBtZXRob2Q6ICdQT1NUJyxcbiAgICBtYXhMZW5ndGg6IDMwLFxuICAgIHRpbWVvdXQ6IDEwLFxuICAgIHBsYXlCZWVwOiB0cnVlLFxuICAgIHJlY29yZGluZ1N0YXR1c0NhbGxiYWNrOiBgJHtiYXNlVXJsfS93ZWJob29rL2V2ZW50c2AsXG4gICAgcmVjb3JkaW5nU3RhdHVzQ2FsbGJhY2tNZXRob2Q6ICdQT1NUJ1xuICB9KTtcblxuICByZXR1cm4ge1xuICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICBoZWFkZXJzOiB7XG4gICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3htbCdcbiAgICB9LFxuICAgIGJvZHk6IHR3aW1sXG4gIH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZVNwZWVjaFdlYmhvb2soYm9keTogUmVjb3JkPHN0cmluZywgc3RyaW5nPiwgZXZlbnQ6IEFQSUdhdGV3YXlQcm94eUV2ZW50KTogUHJvbWlzZTxBUElHYXRld2F5UHJveHlSZXN1bHQ+IHtcbiAgY29uc29sZS5sb2coJz09PSBTUEVFQ0ggV0VCSE9PSyBIQU5ETEVSIFNUQVJUID09PScpO1xuICBjb25zb2xlLmxvZygnU3BlZWNoIGVuZHBvaW50IHJlYWNoZWQgc3VjY2Vzc2Z1bGx5IC0gbm8gNDAzIGVycm9yIGhlcmUnKTtcbiAgXG4gIGNvbnN0IHsgcmVjb3JkaW5nVXJsLCBjYWxsU2lkLCByZWNvcmRpbmdEdXJhdGlvbiB9ID0gVHdpTUxTZXJ2aWNlLmV4dHJhY3RUd2lsaW9QYXJhbXMoYm9keSk7XG4gIFxuICBjb25zb2xlLmxvZygnU3BlZWNoIHdlYmhvb2sgcGFyYW1ldGVyczonLCB7XG4gICAgY2FsbFNpZCxcbiAgICByZWNvcmRpbmdVcmwsXG4gICAgcmVjb3JkaW5nRHVyYXRpb24sXG4gICAgYWxsUGFyYW1zOiBib2R5XG4gIH0pO1xuICBcbiAgY29uc29sZS5sb2coYFNwZWVjaCByZWNvcmRpbmcgcmVjZWl2ZWQgZm9yIENhbGxTaWQ6ICR7Y2FsbFNpZH0sIFVSTDogJHtyZWNvcmRpbmdVcmx9LCBEdXJhdGlvbjogJHtyZWNvcmRpbmdEdXJhdGlvbn1zYCk7XG4gIFxuICAvLyBMb2cgZW52aXJvbm1lbnQgYW5kIHNlcnZpY2Ugc3RhdHVzXG4gIGNvbnNvbGUubG9nKCdTZXJ2aWNlIHN0YXR1cyBjaGVjazonLCB7XG4gICAgc2Vzc2lvbk1hbmFnZXJFeGlzdHM6ICEhc2Vzc2lvbk1hbmFnZXIsXG4gICAgczNTZXJ2aWNlRXhpc3RzOiAhIXMzU2VydmljZSxcbiAgICB0cmFuc2NyaXB0aW9uUHJvY2Vzc29yRXhpc3RzOiAhIXRyYW5zY3JpcHRpb25Qcm9jZXNzb3IsXG4gICAgdHdpbWxTZXJ2aWNlRXhpc3RzOiAhIXR3aW1sU2VydmljZVxuICB9KTtcbiAgXG4gIHRyeSB7XG4gICAgY29uc29sZS5sb2coJ0F0dGVtcHRpbmcgdG8gZmluZCBzZXNzaW9uIGJ5IENhbGxTaWQuLi4nKTtcbiAgICAvLyBGaW5kIHNlc3Npb24gYnkgQ2FsbFNpZFxuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBzZXNzaW9uTWFuYWdlci5nZXRTZXNzaW9uQnlDYWxsU2lkKGNhbGxTaWQpO1xuICAgIGNvbnNvbGUubG9nKCdTZXNzaW9uIGxvb2t1cCByZXN1bHQ6Jywgc2Vzc2lvbiA/ICdGb3VuZCcgOiAnTm90IGZvdW5kJyk7XG4gICAgXG4gICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICBjb25zb2xlLndhcm4oYFNlc3Npb24gbm90IGZvdW5kIGZvciBDYWxsU2lkOiAke2NhbGxTaWR9YCk7XG4gICAgICBjb25zb2xlLmxvZygnUmV0dXJuaW5nIGVycm9yIHJlc3BvbnNlIGR1ZSB0byBtaXNzaW5nIHNlc3Npb24nKTtcbiAgICAgIC8vIENvbnRpbnVlIHdpdGggY2FsbCBldmVuIGlmIHNlc3Npb24gbm90IGZvdW5kXG4gICAgICBjb25zdCB0d2ltbCA9IHR3aW1sU2VydmljZS5jcmVhdGVTYXlSZXNwb25zZSgnU29ycnksIHRoZXJlIHdhcyBhbiBlcnJvci4gUGxlYXNlIHRyeSBhZ2Fpbi4nKTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3htbCcgfSxcbiAgICAgICAgYm9keTogdHdpbWxcbiAgICAgIH07XG4gICAgfVxuICAgIFxuICAgIGNvbnNvbGUubG9nKCdTZXNzaW9uIGZvdW5kOicsIHtcbiAgICAgIHNlc3Npb25JZDogc2Vzc2lvbi5zZXNzaW9uSWQsXG4gICAgICBzdGF0dXM6IHNlc3Npb24uc3RhdHVzLFxuICAgICAgY29udmVyc2F0aW9uQ291bnQ6IHNlc3Npb24uY29udmVyc2F0aW9uPy5sZW5ndGggfHwgMFxuICAgIH0pO1xuXG4gICAgY29uc29sZS5sb2coJ1ZhbGlkYXRpbmcgYXVkaW8gcXVhbGl0eS4uLicpO1xuICAgIC8vIFZhbGlkYXRlIGF1ZGlvIHF1YWxpdHlcbiAgICBjb25zdCBhdWRpb1ZhbGlkYXRpb24gPSB0cmFuc2NyaXB0aW9uUHJvY2Vzc29yLnZhbGlkYXRlQXVkaW9RdWFsaXR5KHtcbiAgICAgIHVybDogcmVjb3JkaW5nVXJsLFxuICAgICAgZHVyYXRpb246IHJlY29yZGluZ0R1cmF0aW9uID8gcGFyc2VGbG9hdChyZWNvcmRpbmdEdXJhdGlvbikgOiB1bmRlZmluZWRcbiAgICB9KTtcbiAgICBcbiAgICBjb25zb2xlLmxvZygnQXVkaW8gdmFsaWRhdGlvbiByZXN1bHQ6Jywge1xuICAgICAgaXNWYWxpZDogYXVkaW9WYWxpZGF0aW9uLmlzVmFsaWQsXG4gICAgICBpc3N1ZXM6IGF1ZGlvVmFsaWRhdGlvbi5pc3N1ZXNcbiAgICB9KTtcblxuICAgIGlmICghYXVkaW9WYWxpZGF0aW9uLmlzVmFsaWQpIHtcbiAgICAgIGNvbnNvbGUud2FybihgQXVkaW8gcXVhbGl0eSBpc3N1ZXMgZm9yIENhbGxTaWQgJHtjYWxsU2lkfTpgLCBhdWRpb1ZhbGlkYXRpb24uaXNzdWVzKTtcbiAgICAgIGNvbnNvbGUubG9nKCdBZGRpbmcgc3lzdGVtIG1lc3NhZ2UgYWJvdXQgYXVkaW8gcXVhbGl0eSBpc3N1ZXMuLi4nKTtcbiAgICAgIGF3YWl0IHNlc3Npb25NYW5hZ2VyLmFkZFN5c3RlbU1lc3NhZ2Uoc2Vzc2lvbi5zZXNzaW9uSWQsIGBBdWRpbyBxdWFsaXR5IGlzc3VlczogJHthdWRpb1ZhbGlkYXRpb24uaXNzdWVzLmpvaW4oJywgJyl9YCk7XG4gICAgICBcbiAgICAgIGNvbnNvbGUubG9nKCdHZW5lcmF0aW5nIGF1ZGlvIHF1YWxpdHkgcmV0cnkgcmVzcG9uc2UuLi4nKTtcbiAgICAgIC8vIEFzayB1c2VyIHRvIHRyeSBhZ2FpblxuICAgICAgLy8gVXNlIGV4aXN0aW5nIHdlbGNvbWUgc3lzdGVtIGZvciBhdWRpbyBxdWFsaXR5IGlzc3Vlc1xuICAgICAgY29uc3QgYmFzZVVybCA9IGdldEJhc2VVcmwoZXZlbnQpO1xuICAgICAgY29uc3QgcmVjb3JkV2l0aERUTUYgPSBkdG1mU2VydmljZS5nZW5lcmF0ZVJlY29yZFdpdGhEVE1GVHdpTUwoe1xuICAgICAgICBzcGVlY2hBY3Rpb246IGAke2Jhc2VVcmx9L3dlYmhvb2svc3BlZWNoYCxcbiAgICAgICAgZHRtZkFjdGlvbjogYCR7YmFzZVVybH0vd2ViaG9vay9kdG1mYCxcbiAgICAgICAgbWF4TGVuZ3RoOiAzMCxcbiAgICAgICAgdGltZW91dDogMTAsXG4gICAgICAgIHByb21wdDogJ0kgaGFkIHRyb3VibGUgd2l0aCB5b3VyIGF1ZGlvLiBQbGVhc2Ugc3BlYWsgY2xlYXJseS4nXG4gICAgICB9KTtcblxuICAgICAgY29uc3QgdHdpbWwgPSB0d2ltbFNlcnZpY2UuY3JlYXRlQ29tcGxleFJlc3BvbnNlKFtcbiAgICAgICAgdHdpbWxTZXJ2aWNlLmNyZWF0ZVNheVZlcmIoJ0kgaGFkIHRyb3VibGUgd2l0aCB5b3VyIGF1ZGlvLiBQbGVhc2Ugc3BlYWsgY2xlYXJseS4nKSxcbiAgICAgICAgcmVjb3JkV2l0aERUTUZcbiAgICAgIF0pO1xuICAgICAgXG4gICAgICBjb25zb2xlLmxvZygnUmV0dXJuaW5nIGF1ZGlvIHF1YWxpdHkgcmV0cnkgVHdpTUwgcmVzcG9uc2UnKTtcbiAgICAgIHJldHVybiB7XG4gICAgICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3htbCcgfSxcbiAgICAgICAgYm9keTogdHdpbWxcbiAgICAgIH07XG4gICAgfVxuXG4gICAgY29uc29sZS5sb2coJ0FkZGluZyBpbml0aWFsIHJlY29yZGluZyBpbmZvIHRvIHNlc3Npb24uLi4nKTtcbiAgICAvLyBBZGQgaW5pdGlhbCByZWNvcmRpbmcgaW5mbyB0byBzZXNzaW9uXG4gICAgYXdhaXQgc2Vzc2lvbk1hbmFnZXIuYWRkVXNlck1lc3NhZ2Uoc2Vzc2lvbi5zZXNzaW9uSWQsICdTcGVlY2ggcmVjb3JkZWQgLSBwcm9jZXNzaW5nIHRyYW5zY3JpcHRpb24uLi4nLCByZWNvcmRpbmdVcmwpO1xuICAgIGNvbnNvbGUubG9nKGBVcGRhdGVkIHNlc3Npb24gJHtzZXNzaW9uLnNlc3Npb25JZH0gd2l0aCBzcGVlY2ggcmVjb3JkaW5nYCk7XG5cbiAgICAvLyBQcm9jZXNzIHRyYW5zY3JpcHRpb24gYXN5bmNocm9ub3VzbHkgYnV0IHdhaXQgZm9yIHJlc3VsdFxuICAgIHRyeSB7XG4gICAgICBjb25zb2xlLmxvZyhgU3RhcnRpbmcgdHJhbnNjcmlwdGlvbiBmb3Igc2Vzc2lvbiAke3Nlc3Npb24uc2Vzc2lvbklkfWApO1xuICAgICAgY29uc29sZS5sb2coJ1RyYW5zY3JpcHRpb24gcGFyYW1ldGVyczonLCB7XG4gICAgICAgIHJlY29yZGluZ1VybCxcbiAgICAgICAgc2Vzc2lvbklkOiBzZXNzaW9uLnNlc3Npb25JZCxcbiAgICAgICAgY2FsbFNpZFxuICAgICAgfSk7XG4gICAgICBcbiAgICAgIGNvbnN0IHRyYW5zY3JpcHRpb25SZXN1bHQgPSBhd2FpdCB0cmFuc2NyaXB0aW9uUHJvY2Vzc29yLnByb2Nlc3NBdWRpb0Zyb21VcmwoXG4gICAgICAgIHJlY29yZGluZ1VybCwgXG4gICAgICAgIHNlc3Npb24uc2Vzc2lvbklkLCBcbiAgICAgICAgY2FsbFNpZFxuICAgICAgKTtcblxuICAgICAgY29uc29sZS5sb2coYFRyYW5zY3JpcHRpb24gY29tcGxldGVkOiAke3RyYW5zY3JpcHRpb25Qcm9jZXNzb3IuZm9ybWF0UmVzdWx0Rm9yTG9nZ2luZyh0cmFuc2NyaXB0aW9uUmVzdWx0KX1gKTtcbiAgICAgIGNvbnNvbGUubG9nKCdGdWxsIHRyYW5zY3JpcHRpb24gcmVzdWx0OicsIHtcbiAgICAgICAgdGV4dDogdHJhbnNjcmlwdGlvblJlc3VsdC50ZXh0LFxuICAgICAgICBjb25maWRlbmNlOiB0cmFuc2NyaXB0aW9uUmVzdWx0LmNvbmZpZGVuY2UsXG4gICAgICAgIGlzQWNjZXB0YWJsZTogdHJhbnNjcmlwdGlvblByb2Nlc3Nvci5pc1RyYW5zY3JpcHRpb25BY2NlcHRhYmxlKHRyYW5zY3JpcHRpb25SZXN1bHQpXG4gICAgICB9KTtcblxuICAgICAgLy8gVXBkYXRlIHNlc3Npb24gd2l0aCB0cmFuc2NyaXB0aW9uIHJlc3VsdFxuICAgICAgaWYgKHRyYW5zY3JpcHRpb25Qcm9jZXNzb3IuaXNUcmFuc2NyaXB0aW9uQWNjZXB0YWJsZSh0cmFuc2NyaXB0aW9uUmVzdWx0KSkge1xuICAgICAgICBjb25zb2xlLmxvZygnVHJhbnNjcmlwdGlvbiBpcyBhY2NlcHRhYmxlLCB1cGRhdGluZyBzZXNzaW9uLi4uJyk7XG4gICAgICAgIC8vIEdvb2QgdHJhbnNjcmlwdGlvbiAtIHVwZGF0ZSBzZXNzaW9uIHdpdGggdHJhbnNjcmliZWQgdGV4dFxuICAgICAgICBhd2FpdCBzZXNzaW9uTWFuYWdlci5hZGRVc2VyTWVzc2FnZShcbiAgICAgICAgICBzZXNzaW9uLnNlc3Npb25JZCwgXG4gICAgICAgICAgdHJhbnNjcmlwdGlvblJlc3VsdC50ZXh0LCBcbiAgICAgICAgICByZWNvcmRpbmdVcmwsXG4gICAgICAgICAgdHJhbnNjcmlwdGlvblJlc3VsdC5jb25maWRlbmNlXG4gICAgICAgICk7XG4gICAgICAgIFxuICAgICAgICBjb25zb2xlLmxvZyhgU3VjY2Vzc2Z1bGx5IHRyYW5zY3JpYmVkIGZvciBzZXNzaW9uICR7c2Vzc2lvbi5zZXNzaW9uSWR9OiBcIiR7dHJhbnNjcmlwdGlvblJlc3VsdC50ZXh0fVwiYCk7XG4gICAgICAgIFxuICAgICAgICBjb25zb2xlLmxvZygnR2VuZXJhdGluZyBEVE1GIGdhdGhlciByZXNwb25zZS4uLicpO1xuICAgICAgICAvLyBDb250aW51ZSB0byBEVE1GIGdhdGhlcmluZyBmb3IgdXNlciB0byBwcmVzcyAxIHRvIHN1Ym1pdFxuICAgICAgICBjb25zdCBiYXNlVXJsID0gZ2V0QmFzZVVybChldmVudCk7XG4gICAgICAgIGNvbnN0IHR3aW1sID0gdHdpbWxTZXJ2aWNlLmNyZWF0ZUdhdGhlclJlc3BvbnNlKCcnLCB7XG4gICAgICAgICAgYWN0aW9uOiBgJHtiYXNlVXJsfS93ZWJob29rL2R0bWZgLFxuICAgICAgICAgIHRpbWVvdXQ6IDMwLFxuICAgICAgICAgIG51bURpZ2l0czogMSxcbiAgICAgICAgICBmaW5pc2hPbktleTogJydcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc29sZS5sb2coJ1JldHVybmluZyBzdWNjZXNzZnVsIHRyYW5zY3JpcHRpb24gVHdpTUwgcmVzcG9uc2UnKTtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICBzdGF0dXNDb2RlOiAyMDAsXG4gICAgICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3htbCcgfSxcbiAgICAgICAgICBib2R5OiB0d2ltbFxuICAgICAgICB9O1xuXG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLmxvZygnVHJhbnNjcmlwdGlvbiBxdWFsaXR5IGlzIHBvb3IsIGFza2luZyB1c2VyIHRvIHJldHJ5Li4uJyk7XG4gICAgICAgIC8vIFBvb3IgdHJhbnNjcmlwdGlvbiAtIGFzayB1c2VyIHRvIHRyeSBhZ2FpblxuICAgICAgICBjb25zdCBpc3N1ZU1lc3NhZ2UgPSB0cmFuc2NyaXB0aW9uUHJvY2Vzc29yLmdldFRyYW5zY3JpcHRpb25Jc3N1ZU1lc3NhZ2UodHJhbnNjcmlwdGlvblJlc3VsdCk7XG4gICAgICAgIFxuICAgICAgICBhd2FpdCBzZXNzaW9uTWFuYWdlci5hZGRTeXN0ZW1NZXNzYWdlKFxuICAgICAgICAgIHNlc3Npb24uc2Vzc2lvbklkLCBcbiAgICAgICAgICBgVHJhbnNjcmlwdGlvbiBpc3N1ZTogJHtpc3N1ZU1lc3NhZ2V9IChjb25maWRlbmNlOiAke3RyYW5zY3JpcHRpb25SZXN1bHQuY29uZmlkZW5jZX0pYFxuICAgICAgICApO1xuICAgICAgICBcbiAgICAgICAgY29uc29sZS5sb2coYFRyYW5zY3JpcHRpb24gcXVhbGl0eSBpc3N1ZSBmb3Igc2Vzc2lvbiAke3Nlc3Npb24uc2Vzc2lvbklkfTogY29uZmlkZW5jZSAke3RyYW5zY3JpcHRpb25SZXN1bHQuY29uZmlkZW5jZX1gKTtcbiAgICAgICAgXG4gICAgICAgIC8vIEFzayB1c2VyIHRvIHNwZWFrIGFnYWluIHVzaW5nIGV4aXN0aW5nIHN5c3RlbVxuICAgICAgICBjb25zdCBiYXNlVXJsID0gZ2V0QmFzZVVybChldmVudCk7XG4gICAgICAgIGNvbnN0IHJlY29yZFdpdGhEVE1GID0gZHRtZlNlcnZpY2UuZ2VuZXJhdGVSZWNvcmRXaXRoRFRNRlR3aU1MKHtcbiAgICAgICAgICBzcGVlY2hBY3Rpb246IGAke2Jhc2VVcmx9L3dlYmhvb2svc3BlZWNoYCxcbiAgICAgICAgICBkdG1mQWN0aW9uOiBgJHtiYXNlVXJsfS93ZWJob29rL2R0bWZgLFxuICAgICAgICAgIG1heExlbmd0aDogMzAsXG4gICAgICAgICAgdGltZW91dDogMTAsXG4gICAgICAgICAgcHJvbXB0OiBpc3N1ZU1lc3NhZ2VcbiAgICAgICAgfSk7XG5cbiAgICAgICAgY29uc3QgdHdpbWwgPSB0d2ltbFNlcnZpY2UuY3JlYXRlQ29tcGxleFJlc3BvbnNlKFtcbiAgICAgICAgICB0d2ltbFNlcnZpY2UuY3JlYXRlU2F5VmVyYihpc3N1ZU1lc3NhZ2UpLFxuICAgICAgICAgIHJlY29yZFdpdGhEVE1GXG4gICAgICAgIF0pO1xuXG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICAgIGhlYWRlcnM6IHsgJ0NvbnRlbnQtVHlwZSc6ICdhcHBsaWNhdGlvbi94bWwnIH0sXG4gICAgICAgICAgYm9keTogdHdpbWxcbiAgICAgICAgfTtcbiAgICAgIH1cblxuICAgIH0gY2F0Y2ggKHRyYW5zY3JpcHRpb25FcnJvcikge1xuICAgICAgY29uc29sZS5lcnJvcignVHJhbnNjcmlwdGlvbiBwcm9jZXNzaW5nIGZhaWxlZDonLCB0cmFuc2NyaXB0aW9uRXJyb3IpO1xuICAgICAgXG4gICAgICBhd2FpdCBzZXNzaW9uTWFuYWdlci5hZGRTeXN0ZW1NZXNzYWdlKFxuICAgICAgICBzZXNzaW9uLnNlc3Npb25JZCwgXG4gICAgICAgIGBUcmFuc2NyaXB0aW9uIGZhaWxlZDogJHt0cmFuc2NyaXB0aW9uRXJyb3IgaW5zdGFuY2VvZiBFcnJvciA/IHRyYW5zY3JpcHRpb25FcnJvci5tZXNzYWdlIDogJ1Vua25vd24gZXJyb3InfWBcbiAgICAgICk7XG4gICAgICBcbiAgICAgIC8vIEZhbGxiYWNrIC0gYXNrIHVzZXIgdG8gdHJ5IGFnYWluIHVzaW5nIGV4aXN0aW5nIHN5c3RlbVxuICAgICAgY29uc3QgYmFzZVVybCA9IGdldEJhc2VVcmwoZXZlbnQpO1xuICAgICAgY29uc3QgcmVjb3JkV2l0aERUTUYgPSBkdG1mU2VydmljZS5nZW5lcmF0ZVJlY29yZFdpdGhEVE1GVHdpTUwoe1xuICAgICAgICBzcGVlY2hBY3Rpb246IGAke2Jhc2VVcmx9L3dlYmhvb2svc3BlZWNoYCxcbiAgICAgICAgZHRtZkFjdGlvbjogYCR7YmFzZVVybH0vd2ViaG9vay9kdG1mYCxcbiAgICAgICAgbWF4TGVuZ3RoOiAzMCxcbiAgICAgICAgdGltZW91dDogMTAsXG4gICAgICAgIHByb21wdDogXCJJJ20gaGF2aW5nIHRyb3VibGUgcHJvY2Vzc2luZyB5b3VyIHNwZWVjaC4gUGxlYXNlIHRyeSBzcGVha2luZyBtb3JlIGNsZWFybHkuXCJcbiAgICAgIH0pO1xuXG4gICAgICBjb25zdCB0d2ltbCA9IHR3aW1sU2VydmljZS5jcmVhdGVDb21wbGV4UmVzcG9uc2UoW1xuICAgICAgICB0d2ltbFNlcnZpY2UuY3JlYXRlU2F5VmVyYihcIkknbSBoYXZpbmcgdHJvdWJsZSBwcm9jZXNzaW5nIHlvdXIgc3BlZWNoLiBQbGVhc2UgdHJ5IHNwZWFraW5nIG1vcmUgY2xlYXJseS5cIiksXG4gICAgICAgIHJlY29yZFdpdGhEVE1GXG4gICAgICBdKTtcblxuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3RhdHVzQ29kZTogMjAwLFxuICAgICAgICBoZWFkZXJzOiB7ICdDb250ZW50LVR5cGUnOiAnYXBwbGljYXRpb24veG1sJyB9LFxuICAgICAgICBib2R5OiB0d2ltbFxuICAgICAgfTtcbiAgICB9XG5cbiAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICBjb25zb2xlLmVycm9yKCdFcnJvciBpbiBzcGVlY2ggd2ViaG9vayBoYW5kbGVyOicsIGVycm9yKTtcbiAgICBcbiAgICAvLyBGYWxsYmFjayByZXNwb25zZVxuICAgIGNvbnN0IHR3aW1sID0gdHdpbWxTZXJ2aWNlLmNyZWF0ZVNheVJlc3BvbnNlKCdTb3JyeSwgdGhlcmUgd2FzIGFuIGVycm9yIHByb2Nlc3NpbmcgeW91ciBzcGVlY2guIFBsZWFzZSB0cnkgY2FsbGluZyBhZ2Fpbi4nKTtcbiAgICByZXR1cm4ge1xuICAgICAgc3RhdHVzQ29kZTogNTAwLFxuICAgICAgaGVhZGVyczogeyAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3htbCcgfSxcbiAgICAgIGJvZHk6IHR3aW1sXG4gICAgfTtcbiAgfVxufVxuXG5hc3luYyBmdW5jdGlvbiBoYW5kbGVEVE1GV2ViaG9vayhib2R5OiBSZWNvcmQ8c3RyaW5nLCBzdHJpbmc+LCBldmVudDogQVBJR2F0ZXdheVByb3h5RXZlbnQpOiBQcm9taXNlPEFQSUdhdGV3YXlQcm94eVJlc3VsdD4ge1xuICBjb25zdCB7IGRpZ2l0cywgY2FsbFNpZCwgZnJvbSwgdG8gfSA9IFR3aU1MU2VydmljZS5leHRyYWN0VHdpbGlvUGFyYW1zKGJvZHkpO1xuICBcbiAgY29uc29sZS5sb2coYERUTUYgaW5wdXQgcmVjZWl2ZWQ6ICR7ZGlnaXRzfSBmb3IgQ2FsbFNpZDogJHtjYWxsU2lkfWApO1xuICBcbiAgdHJ5IHtcbiAgICAvLyBGaW5kIHNlc3Npb24gYnkgQ2FsbFNpZCBhbmQgdHJhY2sgRFRNRiBpbnB1dFxuICAgIGNvbnN0IHNlc3Npb24gPSBhd2FpdCBzZXNzaW9uTWFuYWdlci5nZXRTZXNzaW9uQnlDYWxsU2lkKGNhbGxTaWQpO1xuICAgIGlmIChzZXNzaW9uKSB7XG4gICAgICBhd2FpdCBzZXNzaW9uTWFuYWdlci5hZGRTeXN0ZW1NZXNzYWdlKHNlc3Npb24uc2Vzc2lvbklkLCBgRFRNRiBpbnB1dCByZWNlaXZlZDogJHtkaWdpdHN9YCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGNvbnNvbGUud2FybihgU2Vzc2lvbiBub3QgZm91bmQgZm9yIENhbGxTaWQ6ICR7Y2FsbFNpZH1gKTtcbiAgICB9XG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgdHJhY2tpbmcgRFRNRiBpbnB1dCBpbiBzZXNzaW9uOicsIGVycm9yKTtcbiAgfVxuICBcbiAgY29uc3QgZHRtZklucHV0ID0ge1xuICAgIGRpZ2l0cyxcbiAgICBjYWxsU2lkLFxuICAgIGZyb20sXG4gICAgdG9cbiAgfTtcbiAgXG4gIGNvbnN0IHJlc3BvbnNlID0gZHRtZlNlcnZpY2UucHJvY2Vzc0RUTUZJbnB1dChkdG1mSW5wdXQpO1xuICBcbiAgY29uc3QgdmVyYnM6IHN0cmluZ1tdID0gW107XG4gIFxuICBpZiAocmVzcG9uc2UubWVzc2FnZSkge1xuICAgIHZlcmJzLnB1c2godHdpbWxTZXJ2aWNlLmNyZWF0ZVNheVZlcmIocmVzcG9uc2UubWVzc2FnZSkpO1xuICB9XG4gIFxuICBpZiAocmVzcG9uc2UuYWN0aW9uID09PSAnc3VibWl0Jykge1xuICAgIC8vIFVzZXIgcHJlc3NlZCBcIjFcIiAtIHByb2Nlc3MgdGhlaXIgc3Bva2VuIHByb21wdFxuICAgIHZlcmJzLnB1c2godHdpbWxTZXJ2aWNlLmNyZWF0ZVNheVZlcmIoJ1Byb2Nlc3NpbmcgeW91ciByZXF1ZXN0IG5vdy4gUGxlYXNlIHdhaXQuJykpO1xuICAgIC8vIEluIGxhdGVyIHRhc2tzLCB0aGlzIHdpbGwgdHJpZ2dlciBBSSBwcm9jZXNzaW5nXG4gICAgdmVyYnMucHVzaCh0d2ltbFNlcnZpY2UuY3JlYXRlU2F5VmVyYignVGhpcyBpcyBhIHBsYWNlaG9sZGVyIHJlc3BvbnNlLiBZb3VyIEFJIHByb2Nlc3Npbmcgd2lsbCBiZSBpbXBsZW1lbnRlZCBpbiBsYXRlciB0YXNrcy4nKSk7XG4gICAgdmVyYnMucHVzaCh0d2ltbFNlcnZpY2UuY3JlYXRlUGF1c2VWZXJiKDEpKTtcbiAgICB2ZXJicy5wdXNoKHR3aW1sU2VydmljZS5jcmVhdGVTYXlWZXJiKCdJcyB0aGVyZSBhbnl0aGluZyBlbHNlIEkgY2FuIGhlbHAgeW91IHdpdGg/JykpO1xuICAgIFxuICAgIC8vIENvbnRpbnVlIHdpdGggYW5vdGhlciByZWNvcmRpbmcgc2Vzc2lvblxuICAgIGNvbnN0IGJhc2VVcmwgPSBnZXRCYXNlVXJsKGV2ZW50KTtcbiAgICBjb25zdCByZWNvcmRXaXRoRFRNRiA9IGR0bWZTZXJ2aWNlLmdlbmVyYXRlUmVjb3JkV2l0aERUTUZUd2lNTCh7XG4gICAgICBzcGVlY2hBY3Rpb246IGAke2Jhc2VVcmx9L3dlYmhvb2svc3BlZWNoYCxcbiAgICAgIGR0bWZBY3Rpb246IGAke2Jhc2VVcmx9L3dlYmhvb2svZHRtZmAsXG4gICAgICBtYXhMZW5ndGg6IDMwLFxuICAgICAgdGltZW91dDogMTAsXG4gICAgICBwcm9tcHQ6IGR0bWZTZXJ2aWNlLmdlbmVyYXRlQ29udHJvbHNSZW1pbmRlcigpXG4gICAgfSk7XG4gICAgdmVyYnMucHVzaChyZWNvcmRXaXRoRFRNRik7XG4gICAgXG4gIH0gZWxzZSBpZiAocmVzcG9uc2UuYWN0aW9uID09PSAnZW5kX2NhbGwnKSB7XG4gICAgLy8gVXNlciBwcmVzc2VkIFwiMFwiIC0gZW5kIHRoZSBjYWxsIGdyYWNlZnVsbHlcbiAgICB0cnkge1xuICAgICAgLy8gRmluZCBzZXNzaW9uIGJ5IENhbGxTaWQgYW5kIHVwZGF0ZSBzdGF0dXMgdG8gY29tcGxldGVkXG4gICAgICBjb25zdCBzZXNzaW9uID0gYXdhaXQgc2Vzc2lvbk1hbmFnZXIuZ2V0U2Vzc2lvbkJ5Q2FsbFNpZChjYWxsU2lkKTtcbiAgICAgIGlmIChzZXNzaW9uKSB7XG4gICAgICAgIGF3YWl0IHNlc3Npb25NYW5hZ2VyLnVwZGF0ZVNlc3Npb25TdGF0dXMoc2Vzc2lvbi5zZXNzaW9uSWQsICdjb21wbGV0ZWQnLCBEYXRlLm5vdygpKTtcbiAgICAgICAgYXdhaXQgc2Vzc2lvbk1hbmFnZXIuYWRkU3lzdGVtTWVzc2FnZShzZXNzaW9uLnNlc3Npb25JZCwgJ0NhbGwgZW5kZWQgYnkgdXNlciByZXF1ZXN0IChwcmVzc2VkIDApJyk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICBjb25zb2xlLndhcm4oYFNlc3Npb24gbm90IGZvdW5kIGZvciBDYWxsU2lkOiAke2NhbGxTaWR9YCk7XG4gICAgICB9XG4gICAgfSBjYXRjaCAoZXJyb3IpIHtcbiAgICAgIGNvbnNvbGUuZXJyb3IoJ0Vycm9yIHVwZGF0aW5nIHNlc3Npb24gb24gY2FsbCBlbmQ6JywgZXJyb3IpO1xuICAgIH1cbiAgICB2ZXJicy5wdXNoKHR3aW1sU2VydmljZS5jcmVhdGVIYW5ndXBWZXJiKCkpO1xuICAgIFxuICB9IGVsc2UgaWYgKHJlc3BvbnNlLmFjdGlvbiA9PT0gJ2hlbHAnKSB7XG4gICAgLy8gVXNlciBwcmVzc2VkIFwiKlwiIC0gcHJvdmlkZSBoZWxwXG4gICAgdmVyYnMucHVzaCh0d2ltbFNlcnZpY2UuY3JlYXRlUGF1c2VWZXJiKDEpKTtcbiAgICBcbiAgICAvLyBDb250aW51ZSB3aXRoIHJlY29yZGluZyBhZnRlciBoZWxwXG4gICAgY29uc3QgYmFzZVVybCA9IGdldEJhc2VVcmwoZXZlbnQpO1xuICAgIGNvbnN0IHJlY29yZFdpdGhEVE1GID0gZHRtZlNlcnZpY2UuZ2VuZXJhdGVSZWNvcmRXaXRoRFRNRlR3aU1MKHtcbiAgICAgIHNwZWVjaEFjdGlvbjogYCR7YmFzZVVybH0vd2ViaG9vay9zcGVlY2hgLFxuICAgICAgZHRtZkFjdGlvbjogYCR7YmFzZVVybH0vd2ViaG9vay9kdG1mYCxcbiAgICAgIG1heExlbmd0aDogMzAsXG4gICAgICB0aW1lb3V0OiAxMCxcbiAgICAgIHByb21wdDogJ1BsZWFzZSBzcGVhayB5b3VyIHF1ZXN0aW9uIGFmdGVyIHRoZSBiZWVwLidcbiAgICB9KTtcbiAgICB2ZXJicy5wdXNoKHJlY29yZFdpdGhEVE1GKTtcbiAgICBcbiAgfSBlbHNlIHtcbiAgICAvLyBJbnZhbGlkIGlucHV0IC0gcHJvdmlkZSBndWlkYW5jZSBhbmQgY29udGludWVcbiAgICB2ZXJicy5wdXNoKHR3aW1sU2VydmljZS5jcmVhdGVQYXVzZVZlcmIoMSkpO1xuICAgIFxuICAgIGNvbnN0IGJhc2VVcmwgPSBnZXRCYXNlVXJsKGV2ZW50KTtcbiAgICBjb25zdCByZWNvcmRXaXRoRFRNRiA9IGR0bWZTZXJ2aWNlLmdlbmVyYXRlUmVjb3JkV2l0aERUTUZUd2lNTCh7XG4gICAgICBzcGVlY2hBY3Rpb246IGAke2Jhc2VVcmx9L3dlYmhvb2svc3BlZWNoYCxcbiAgICAgIGR0bWZBY3Rpb246IGAke2Jhc2VVcmx9L3dlYmhvb2svZHRtZmAsXG4gICAgICBtYXhMZW5ndGg6IDMwLFxuICAgICAgdGltZW91dDogMTAsXG4gICAgICBwcm9tcHQ6ICdQbGVhc2Ugc3BlYWsgeW91ciBxdWVzdGlvbiBhZnRlciB0aGUgYmVlcC4nXG4gICAgfSk7XG4gICAgdmVyYnMucHVzaChyZWNvcmRXaXRoRFRNRik7XG4gIH1cbiAgXG4gIGNvbnN0IHR3aW1sID0gdHdpbWxTZXJ2aWNlLmNyZWF0ZUNvbXBsZXhSZXNwb25zZSh2ZXJicyk7XG4gIFxuICByZXR1cm4ge1xuICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICBoZWFkZXJzOiB7XG4gICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3htbCdcbiAgICB9LFxuICAgIGJvZHk6IHR3aW1sXG4gIH07XG59XG5cbmFzeW5jIGZ1bmN0aW9uIGhhbmRsZUV2ZW50c1dlYmhvb2soYm9keTogUmVjb3JkPHN0cmluZywgc3RyaW5nPik6IFByb21pc2U8QVBJR2F0ZXdheVByb3h5UmVzdWx0PiB7XG4gIGNvbnN0IHsgcmVjb3JkaW5nU3RhdHVzLCBjYWxsU2lkLCBjYWxsU3RhdHVzLCBjYWxsRHVyYXRpb24gfSA9IFR3aU1MU2VydmljZS5leHRyYWN0VHdpbGlvUGFyYW1zKGJvZHkpO1xuICBcbiAgY29uc29sZS5sb2coYEV2ZW50IHJlY2VpdmVkIGZvciBDYWxsU2lkOiAke2NhbGxTaWR9LCBSZWNvcmRpbmcgU3RhdHVzOiAke3JlY29yZGluZ1N0YXR1c30sIENhbGwgU3RhdHVzOiAke2NhbGxTdGF0dXN9YCk7XG4gIFxuICB0cnkge1xuICAgIC8vIEZpbmQgc2Vzc2lvbiBieSBDYWxsU2lkXG4gICAgY29uc3Qgc2Vzc2lvbiA9IGF3YWl0IHNlc3Npb25NYW5hZ2VyLmdldFNlc3Npb25CeUNhbGxTaWQoY2FsbFNpZCk7XG4gICAgaWYgKCFzZXNzaW9uKSB7XG4gICAgICBjb25zb2xlLndhcm4oYFNlc3Npb24gbm90IGZvdW5kIGZvciBDYWxsU2lkOiAke2NhbGxTaWR9YCk7XG4gICAgICAvLyBDb250aW51ZSBwcm9jZXNzaW5nIGV2ZW4gaWYgc2Vzc2lvbiBub3QgZm91bmRcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gSGFuZGxlIGRpZmZlcmVudCB0eXBlcyBvZiBldmVudHNcbiAgICAgIGlmIChyZWNvcmRpbmdTdGF0dXMpIHtcbiAgICAgICAgLy8gUmVjb3JkaW5nIHN0YXR1cyBldmVudHNcbiAgICAgICAgYXdhaXQgc2Vzc2lvbk1hbmFnZXIuYWRkU3lzdGVtTWVzc2FnZShzZXNzaW9uLnNlc3Npb25JZCwgYFJlY29yZGluZyBzdGF0dXM6ICR7cmVjb3JkaW5nU3RhdHVzfWApO1xuICAgICAgICBcbiAgICAgICAgaWYgKHJlY29yZGluZ1N0YXR1cyA9PT0gJ2NvbXBsZXRlZCcpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhgUmVjb3JkaW5nIGNvbXBsZXRlZCBmb3IgQ2FsbFNpZDogJHtjYWxsU2lkfWApO1xuICAgICAgICB9IGVsc2UgaWYgKHJlY29yZGluZ1N0YXR1cyA9PT0gJ2ZhaWxlZCcpIHtcbiAgICAgICAgICBjb25zb2xlLmxvZyhgUmVjb3JkaW5nIGZhaWxlZCBmb3IgQ2FsbFNpZDogJHtjYWxsU2lkfWApO1xuICAgICAgICAgIGF3YWl0IHNlc3Npb25NYW5hZ2VyLmFkZFN5c3RlbU1lc3NhZ2Uoc2Vzc2lvbi5zZXNzaW9uSWQsICdSZWNvcmRpbmcgZmFpbGVkIC0gYXVkaW8gbWF5IG5vdCBiZSBhdmFpbGFibGUnKTtcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgXG4gICAgICBpZiAoY2FsbFN0YXR1cykge1xuICAgICAgICAvLyBDYWxsIHN0YXR1cyBldmVudHNcbiAgICAgICAgYXdhaXQgc2Vzc2lvbk1hbmFnZXIuYWRkU3lzdGVtTWVzc2FnZShzZXNzaW9uLnNlc3Npb25JZCwgYENhbGwgc3RhdHVzOiAke2NhbGxTdGF0dXN9YCk7XG4gICAgICAgIFxuICAgICAgICBpZiAoY2FsbFN0YXR1cyA9PT0gJ2NvbXBsZXRlZCcpIHtcbiAgICAgICAgICAvLyBDYWxsIGVuZGVkIC0gdXBkYXRlIHNlc3Npb25cbiAgICAgICAgICBjb25zdCBkdXJhdGlvbiA9IGNhbGxEdXJhdGlvbiA/IHBhcnNlSW50KGNhbGxEdXJhdGlvbikgOiAwO1xuICAgICAgICAgIGF3YWl0IHNlc3Npb25NYW5hZ2VyLnVwZGF0ZVNlc3Npb25TdGF0dXMoc2Vzc2lvbi5zZXNzaW9uSWQsICdjb21wbGV0ZWQnLCBEYXRlLm5vdygpKTtcbiAgICAgICAgICBpZiAoZHVyYXRpb24gPiAwKSB7XG4gICAgICAgICAgICBhd2FpdCBzZXNzaW9uTWFuYWdlci51cGRhdGVDYWxsRHVyYXRpb24oc2Vzc2lvbi5zZXNzaW9uSWQsIGR1cmF0aW9uKTtcbiAgICAgICAgICB9XG4gICAgICAgICAgY29uc29sZS5sb2coYENhbGwgY29tcGxldGVkIGZvciBDYWxsU2lkOiAke2NhbGxTaWR9LCBEdXJhdGlvbjogJHtkdXJhdGlvbn1zYCk7XG4gICAgICAgICAgXG4gICAgICAgIH0gZWxzZSBpZiAoY2FsbFN0YXR1cyA9PT0gJ2ZhaWxlZCcgfHwgY2FsbFN0YXR1cyA9PT0gJ2J1c3knIHx8IGNhbGxTdGF0dXMgPT09ICduby1hbnN3ZXInKSB7XG4gICAgICAgICAgLy8gQ2FsbCBmYWlsZWQgLSB1cGRhdGUgc2Vzc2lvbiB3aXRoIGVycm9yXG4gICAgICAgICAgYXdhaXQgc2Vzc2lvbk1hbmFnZXIudXBkYXRlU2Vzc2lvblN0YXR1cyhzZXNzaW9uLnNlc3Npb25JZCwgJ2ZhaWxlZCcsIERhdGUubm93KCksIHtcbiAgICAgICAgICAgIGNvZGU6IGNhbGxTdGF0dXMsXG4gICAgICAgICAgICBtZXNzYWdlOiBgQ2FsbCAke2NhbGxTdGF0dXN9YFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGNvbnNvbGUubG9nKGBDYWxsIGZhaWxlZCBmb3IgQ2FsbFNpZDogJHtjYWxsU2lkfSwgU3RhdHVzOiAke2NhbGxTdGF0dXN9YCk7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9XG4gICAgXG4gIH0gY2F0Y2ggKGVycm9yKSB7XG4gICAgY29uc29sZS5lcnJvcignRXJyb3IgaGFuZGxpbmcgZXZlbnQgd2ViaG9vazonLCBlcnJvcik7XG4gICAgLy8gQ29udGludWUgcHJvY2Vzc2luZyBldmVuIGlmIHNlc3Npb24gdXBkYXRlIGZhaWxzXG4gIH1cbiAgXG4gIGNvbnN0IHR3aW1sID0gdHdpbWxTZXJ2aWNlLmNyZWF0ZUNvbXBsZXhSZXNwb25zZShbXSk7XG4gIFxuICByZXR1cm4ge1xuICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICBoZWFkZXJzOiB7XG4gICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3htbCdcbiAgICB9LFxuICAgIGJvZHk6IHR3aW1sXG4gIH07XG59XG5cbmZ1bmN0aW9uIGNyZWF0ZVR3aU1MUmVzcG9uc2UobWVzc2FnZTogc3RyaW5nKTogQVBJR2F0ZXdheVByb3h5UmVzdWx0IHtcbiAgY29uc3QgdHdpbWwgPSB0d2ltbFNlcnZpY2UuY3JlYXRlU2F5UmVzcG9uc2UobWVzc2FnZSk7XG4gIFxuICByZXR1cm4ge1xuICAgIHN0YXR1c0NvZGU6IDIwMCxcbiAgICBoZWFkZXJzOiB7XG4gICAgICAnQ29udGVudC1UeXBlJzogJ2FwcGxpY2F0aW9uL3htbCdcbiAgICB9LFxuICAgIGJvZHk6IHR3aW1sXG4gIH07XG59Il19